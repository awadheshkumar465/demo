<?php
/**
Template Name: Our Blog Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    
<div class="main-content">   
    <section class="wel-come">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-sm-7">
                    
                        <div class="blog_list">
                            <?php
                            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
                            $blog = array(
                                'post_type'=>'post',
                                'publish'           => true,
                                'posts_per_page'    => 8,
                                'paged'             => $paged,
                                'order'=>'DESC',
                            );
                            $blog_query = new WP_Query( $blog );
                            if ( $blog_query->have_posts() ):
                                while ( $blog_query->have_posts() ) : $blog_query->the_post(); 
                                    $blog_id = get_the_ID();
                                    $post_thumbnail_id = get_post_thumbnail_id();
                                    $post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id ); ?>
                                    <article class="cmsmasters_post_masonry">
                                        <div class="cmsmasters_post_cont">
                                            <figure class="cmsmasters_img_wrap">
                                                <a href="#" title="" class="cmsmasters_img_link">
                                                    <img src="<?php echo $post_thumbnail_url; ?>" class=" wp-post-image" alt="" title="">
                                                </a>
                                            </figure>
                                            <div class="cmsmasters_post_header">
                                                <h5 class="cmsmasters_post_title entry-title">
                                                   <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </h5>
                                                <div class="cmsmasters_post_content">
                                                   <?php echo wp_trim_words( get_the_content(), 20, '...' ); ?>
                                                </div>
                                                <div class="cmsmasters_post_footer">
                                                <span class="cmsmasters_post_date">
                                                    <abbr class="published" title="<?php echo get_the_date('', $post->ID); ?>"><?php echo get_the_date('', $post->ID); ?></abbr>                 
                                                </span>
                                                <span class="cmsmasters_comments">:
                                                    <a class="cmsmasters_theme_icon_comment" href="#" title=""><i class="fa fa-comment-o"></i> <span><?php  echo $post->comment_count; ?></span></a>
                                                </span>
                                            </div>
                                            </div>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                                <nav aria-label="Page navigation example" class="servic_pagi">
                                    <ul class="pagination">
                                        <li class="page-item">
                                            <?php
                                            $big = 999999999; // need an unlikely integer
                                             echo paginate_links( array(
                                                'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                                                'format' => '?paged=%#%',
                                                'current' => max( 1, get_query_var('paged') ),
                                                'total' => $blog_query->max_num_pages,
                                                'prev_text'    => __('«'),
                                                'next_text'    => __('»')
                                            ) ); ?>
                                        </li>
                                    </ul>
                                </nav>
                            <?php endif; ?>
                        </div>                  
                    
                </div>

                  <div class="col-md-3 col-sm-5 wow slideInDown animated">
                    <div class="nbtsow-social-wrap">
                        <h3 class="nbtsow-title">Get Connected</h3>
                        <ul class="list_blogSocial">
                             <?php dynamic_sidebar('social-link'); ?>
                        </ul>    
                    </div>                                                                            
                    <section class="widget_search">
                      <h3 class="widget-title">Search the blog</h3>
                      <?php dynamic_sidebar('sidebar-1'); ?>
                    </section>
                    <div class="box_post">
                        <h3>Latest Post</h3>
                        <ul class="list_product">
                            <?php
                            $latest_post = array('post_type'=>'post','publish'=> true,'posts_per_page'=> 5);
                            $latest_blog_query = new WP_Query( $latest_post );
                            if ( $latest_blog_query->have_posts() ):
                              while ( $latest_blog_query->have_posts() ) : $latest_blog_query->the_post(); ?>
                                <li>
                                  <div class="product-thumb"> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a></div>
                                  <div class="product-details">
                                    <div class="product-meta">
                                      <h4 class="product-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                      </div>
                                    <p class="product-date"><?php echo get_the_date('', $post->ID); ?></p>
                                    </div>
                                </li>
                              <?php endwhile;
                            endif; ?> 
                        </ul>
                    </div>

                    <div class="box_post">
                      <h3>More Services</h3>
                      <ul class="list_product">
                        <?php
                            $service_post = array('post_type'=>'service','publish'=> true,'posts_per_page'=> 6);
                            $services_query = new WP_Query( $service_post );
                            if ( $services_query->have_posts() ):
                              while ( $services_query->have_posts() ) : $services_query->the_post(); ?>
                                <li>
                                  <div class="product-thumb"> <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a></div>
                                  <div class="product-details">
                                    <div class="product-meta">
                                      <h4 class="product-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                      </div>
                                    <p class="product-date"><?php echo get_the_date('', $post->ID); ?></p>
                                    </div>
                                </li>
                              <?php endwhile;
                            endif; ?>
                        </ul>
                    </div>
                  </div>
            </div>
        </div>
    </section>
</div>

<?php endwhile; 
endif; ?>

<?php get_footer();
