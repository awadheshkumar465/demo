<?php
/**

**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php $ids =  get_the_ID(); 
	$image_path = get_field( "blog_header_image", $ids ); ?>
    <section>
	<div class="container">
		<div class="row">
			<div class="col-sm-7 col-md-12">
				<div class="single-details">
					<!-- <div class="deteils-img">
						<div class="demo">
						    <div class="item">            
						        <div class="clearfix">
						            <div class="lSSlideOuter ">
						            	<div class="lSSlideWrapper usingCss services-featured-image">
						            		 <?php //the_post_thumbnail(); ?>
										</div>
									</div>
						   		</div>
							</div>
						</div>	
					</div>	 -->				
					<div class="temp-details">
						<div class="dmv-heading">
								<h3><?php the_title(); ?></h3>
						</div>
						<p><?php the_content(); ?></p>
					</div>
				</div>
			</div>
			<?php endwhile; 
			endif; ?>	
		</div>
	</div>
</section>
<?php get_footer();
