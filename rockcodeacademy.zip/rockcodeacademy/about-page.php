<?php
/**
Template Name: About-Us Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="about_page">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 wow fadeIn">
                    <div class="aboutusLeft">
                        <h2 class="same_heading"><?php the_title(); ?></h2>
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-lg-5 wow fadeIn">
                    <div class="aboutusRight">
                        <ul>
                            <?php
                            if( have_rows('about_right_side_content') ): 
                                while( have_rows('about_right_side_content') ) : the_row();
                                    $location = get_sub_field('about_rightside_icon'); ?>
                                    <li>
                                        <img src="<?php echo get_sub_field('about_rightside_icon'); ?>" />
                                        <h3><?php echo get_sub_field('about_rightside_title'); ?></h3>
                                        <?php echo get_sub_field('about_rightside_content'); ?>
                                    </li>
                                <?php endwhile;
                            endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="our_team">
                <h2 class="same_heading">Meet the Team</h2>
                <div class="row">
                    <?php $count = 0;
                    $ourteams = array(
                        'post_type'=>'ourteam',
                        'publish'           => true,
                        'posts_per_page'    => 4,
                        'order'=>'DESC',
                    );
                    $ourteams_query = new WP_Query( $ourteams );
                    if ( $ourteams_query->have_posts() ):
                        while ( $ourteams_query->have_posts() ) : $ourteams_query->the_post(); ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="team_list">
                                    <figure>
                                        <?php the_post_thumbnail(); ?>
                                        <figcaption>
                                            <ul>
                                                <li><a href="<?php the_field('facebook_link'); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                                <li><a href="<?php the_field('twitter_link'); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                                <li><a href="<?php the_field('linkedin_link'); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                                <li><a href="<?php the_field('instagram_link'); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                                <li><a href="<?php the_field('google-plus_link'); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </figcaption>
                                    </figure>
                                    <h4><?php the_title(); ?></h4>
                                    <h5><?php echo get_field('designation'); ?></h5>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="our_partner">
                <h2 class="same_heading">Meet the Partners</h2>
                <div class="owl-carousel owl-theme" id="partners_slid">
                    <?php $count = 0;
                    $ourteams = array(
                        'post_type'=>'partner',
                        'publish'           => true,
                        'posts_per_page'    => -1,
                        'order'=>'DESC',
                    );
                    $ourteams_query = new WP_Query( $ourteams );
                    if ( $ourteams_query->have_posts() ):
                        while ( $ourteams_query->have_posts() ) : $ourteams_query->the_post(); ?>
                            <div class="item">
                                <div class="ptnrs_slid">
                                  <?php the_post_thumbnail(); ?>
                                </div>
                            </div>
                         <?php endwhile ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <div class="apply_resume">
        <div class="overlay"></div>
        <div class="container">
            <h2 class="same_heading">Upload CV</h2>
            <?php echo do_shortcode('[contact-form-7 id="240" title="About Us"]'); ?>
        </div>      
    </div>
<?php endwhile; 
endif; ?>

<script>
    $('#partners_slid').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:true
        },
        1000:{
            items:5,
            nav:true,
            loop:true
        }
    }
})
</script>

<?php get_footer();
