<?php
/**
Template Name: Our Services Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    
<div class="main-content">   
    <div class="container">
        <div class="row">
            <?php $count = 0;
            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
            $services = array(
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'service-cat',
                                    'field' => 'slug',
                                    'order' => 'ASC',
                                    'terms' => array('clubs', 'training' ),
                                ),
                            ),
                        'post_type' => 'service',
                        'posts_per_page'=>6,
                        'paged'             => $paged,
                        'order'=>'DESC',
                        ); 
            $services_query = new WP_Query( $services );
            if ( $services_query->have_posts() ):
                while ( $services_query->have_posts() ) : $services_query->the_post(); ?>
            <div class="rtin-main-cols col-lg-4 col-md-4 col-sm-4 col-xs-12 wow fadeInDown animated">
                <div class="rt-course-box">
                    <div class="rtin-thumbnail hvr-bounce-to-right"> 
                        <?php the_post_thumbnail(); ?>
                        <a href="<?php the_permalink(); ?>" title=""><i class="fa fa-link" aria-hidden="true"></i></a>
                        <div class="rtin-price">
                            <div class="course-price"> <span class="price">Free</span></div>
                        </div>
                    </div>
                    <div class="rtin-content-wrap">
                        <div class="rtin-content">
                            <h3 class="rtin-title"><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3>
                            <!-- <div class="rtin-author"><a href="#">Lorem Ipsum is simply dummy</a></div> -->
                            <div class="rtin-description"><?php the_content(); ?></div>
                        </div>      
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <nav aria-label="Page navigation example" class="servic_pagi">
                <ul class="pagination">
                    <li class="page-item">
                        <?php
                        $big = 999999999; // need an unlikely integer
                         echo paginate_links( array(
                            'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'total' => $services_query->max_num_pages,
                            'prev_text'    => __('«'),
                            'next_text'    => __('»')
                        ) ); ?>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
        </div>                  
    </div>
</div>

<?php endwhile; 
endif; ?>

<?php get_footer();
