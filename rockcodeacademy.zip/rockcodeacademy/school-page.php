<?php
/**
Template Name: School Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="all_same_page school-page">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <?php the_post_thumbnail(); ?>
                    
                </div>
                <div class="col-md-6">
                    <?php the_content(); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <?php echo get_field('benefits_of_rca'); ?>
                </div>
                <div class="col-md-6">
                    <h2 class="same_heading">Request a Quote</h3>
                    <?php echo get_field('request_a_quote'); ?>
                </div>
            </div> 
        </div>
    </div>
<?php endwhile;  endif; ?>
<?php get_footer();
