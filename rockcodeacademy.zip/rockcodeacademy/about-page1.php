<?php
/**
Template Name: About-Us Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    

    <div class="about_page">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 wow fadeIn">
                    <div class="aboutusLeft">
                        <h2 class="same_heading"><?php the_title(); ?></h2>
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-lg-5 wow fadeIn">
                    <div class="aboutusRight">
                        <ul>
                            <li>
                                <img src="<?php echo get_stylesheet_directory_uri();?>/images/sign.png" alt="" />
                                <h3>Our Strategy</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae ipsam enim expedita, facilis.</p>
                            </li>
                            <li>
                                <img src="<?php echo get_stylesheet_directory_uri();?>/images/wallet.png" alt="" />
                                <h3>Company Analysis</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae ipsam enim expedita, facilis.</p>
                            </li>
                            <li>
                                <img src="<?php echo get_stylesheet_directory_uri();?>/images/structure.png" alt="" />
                                <h3>Team Organization</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae ipsam enim expedita, facilis.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="our_team">
                <h2 class="same_heading">Meet the Team</h2>
                <div class="row">
                    <?php $count = 0;
                    $ourteams = array(
                        'post_type'=>'ourteam',
                        'publish'           => true,
                        'posts_per_page'    => 4,
                        'order'=>'DESC',
                    );
                    $ourteams_query = new WP_Query( $ourteams );
                    if ( $ourteams_query->have_posts() ):
                        while ( $ourteams_query->have_posts() ) : $ourteams_query->the_post(); ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="team_list">
                                    <figure>
                                        <?php the_post_thumbnail(); ?>
                                        <figcaption>
                                            <ul>
                                                <li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                                <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                                <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                                <li><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                                <li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                            </ul>
                                        </figcaption>
                                    </figure>
                                    <h4><?php the_title(); ?></h4>
                                    <h5><?php echo get_field('designation'); ?></h5>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="our_partner">
                <h2 class="same_heading">Meet the Partners</h2>
                <div class="owl-carousel owl-theme" id="partners_slid">
                    <?php $count = 0;
                    $ourteams = array(
                        'post_type'=>'partner',
                        'publish'           => true,
                        'posts_per_page'    => -1,
                        'order'=>'DESC',
                    );
                    $ourteams_query = new WP_Query( $ourteams );
                    if ( $ourteams_query->have_posts() ):
                        while ( $ourteams_query->have_posts() ) : $ourteams_query->the_post(); ?>
                            <div class="item">
                                <div class="ptnrs_slid">
                                  <?php the_post_thumbnail(); ?>
                                </div>
                            </div>
                         <?php endwhile ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <div class="apply_resume">
        <div class="overlay"></div>
        <div class="container">
            <h2 class="same_heading">Upload CV</h2>
            <form>
                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Name</label>
                        <input type="text" class="form-control" placeholder="">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Email</label>
                        <input type="email" class="form-control" placeholder="">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Phone</label>
                        <input type="text" class="form-control" placeholder="">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Subject</label>
                        <input type="text" class="form-control" placeholder="">
                    </div>
                    <div class="form-group col-md-12">
                        <label>Massage</label>
                        <textarea class="form-control" rows="4" placeholder=""></textarea>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Upload CV</label>
                        <input type="file" class="form-control">
                    </div>
                    <div class="checkbox col-md-6">
                        <label>
                            <input type="checkbox"> Check me out
                        </label>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-default">Submit</button>
                    </div>
                </div>
            </form>
        </div>      
    </div>
<?php endwhile; 
endif; ?>

<script>
    $('#partners_slid').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:true
        },
        1000:{
            items:5,
            nav:true,
            loop:true
        }
    }
})
</script>

<?php get_footer();
