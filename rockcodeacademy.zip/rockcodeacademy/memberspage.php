<?php
/**
Template Name: Member Page
**/

get_header(); ?>
<div class="main-content">
	<section class="members_page">
		<div class="container">
			<div class="row">
				<?php 
				$args = array(
					'blog_id'      => $GLOBALS['blog_id'],
					'role'         => '',
					'role__in'     => array(),
					'role__not_in' => array(),
					'meta_key'     => '',
					'meta_value'   => '',
					'meta_compare' => '',
					'meta_query'   => array(),
					'date_query'   => array(),        
					'include'      => array(),
					'exclude'      => array(),
					'orderby'      => 'login',
					'order'        => 'ASC',
					'offset'       => '',
					'search'       => '',
					'number'       => '',
					'count_total'  => false,
					'fields'       => 'all',
					'who'          => '',
				 ); 
				$result = get_users( $args );
				foreach ($result as $userlist) { ?>
					<?php  $userid = $userlist->ID; 
					$description = $userlist->description;
					$role = implode(', ', $userlist->roles);
					$role = str_replace( array( '-', '.' ), ' ', $role);
					if($role == "administrator") {
						//echo "administrator";
					}
					else{ ?>
						<div class="col-md-4 col-sm-4 wow fadeInDown" data-wow-delay="1s">
					        <div class="members_list">
					        	<figure>
					        		<img src="<?php echo get_stylesheet_directory_uri();?>/images/study1.jpg" alt="" />
					        	</figure>
					        	<div class="members_list_dtls">
					        		<h2><?php echo $role; ?></h2>
					        		<p><?php echo $description; ?></p>
					        		<!--
					        		<ul>
					        			<li><a href="#"><i class="fa fa-user"></i>20</a></li>
					        			<li><a href="#"><i class="fa fa-book"></i>20</a></li>
					        			<li><a href="#"><i class="fa fa-eye"></i>20</a></li>
					        		</ul>-->
					        		<a href="#" class="learn_now">Members</a>
					        		
					        	</div>
					        </div>
						</div>
					<?php
					} 
				} ?>
				<!--
				<div class="col-md-4 col-sm-4 wow fadeInDown" data-wow-delay="1s">
			        <div class="members_list">
			        	<figure>
			        		<img src="images/study1.jpg" alt="" />
			        	</figure>
			        	<div class="members_list_dtls">
			        		<h2>Kids Club</h2>
			        		<p>There are many variations of passages of Lorem Ipsum available</p>
			        		<ul>
			        			<li><a href="#"><i class="fa fa-user"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-book"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-eye"></i>20</a></li>
			        		</ul>
			        		<a href="#" class="learn_now">Members</a>
			        	</div>
			        </div>
				</div>	
				<div class="col-md-4 col-sm-4 wow fadeInDown" data-wow-delay="1.2s">
			        <div class="members_list">
			        	<figure>
			        		<img src="images/study1.jpg" alt="" />
			        	</figure>
			        	<div class="members_list_dtls">
			        		<h2>Young Coders</h2>
			        		<p>There are many variations of passages of Lorem Ipsum available</p>
			        		<ul>
			        			<li><a href="#"><i class="fa fa-user"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-book"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-eye"></i>20</a></li>
			        		</ul>
			        		<a href="#" class="learn_now">Members</a>
			        	</div>
			        </div>
				</div>	
				<div class="col-md-4 col-sm-4 wow fadeInDown" data-wow-delay="1.4s">
			        <div class="members_list">
			        	<figure>
			        		<img src="images/study1.jpg" alt="" />
			        	</figure>
			        	<div class="members_list_dtls">
			        		<h2>Codemaniacs Startups</h2>
			        		<p>There are many variations of passages of Lorem Ipsum available</p>
			        		<ul>
			        			<li><a href="#"><i class="fa fa-user"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-book"></i>20</a></li>
			        			<li><a href="#"><i class="fa fa-eye"></i>20</a></li>
			        		</ul>
			        		<a href="#" class="learn_now">Members</a>
			        	</div>
			        </div>
				</div>	-->				
			</div>
		</div>
	</section>
</div>

<?php get_footer(); ?>