<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */
?>
</div><!-- #content -->
	<footer class="main_footer">	   
		<div class="container">
			<div class="row">
				<div class="f_middle wow fadeInDown animated">
					<div class="col-md-4">
						<div class="f_heading">
							<?php 
							$custom_logo_id = get_theme_mod( 'custom_logo' );
							$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );?>
							<h3><a class="footer-logo" href="<?php echo site_url(); ?>"><img src="<?php echo $image[0]; ?>"></a></h3>
						</div>
						<div class="f_heading footer-add">
							<?php dynamic_sidebar('sidebar-2'); ?>
						</div>
					</div>
					<div class="col-md-8">
						<div class="working_hours">
							<div class="row">
								<div class="col-sm-4">
									<div class="f_heading">
										<h3>Policies includes</h3>
									</div>
									<?php dynamic_sidebar('sidebar-3'); ?>
								</div>
								<div class="col-sm-4">
									<div class="f_heading">
										<h3>Quick Links</h3>
									</div>
									<?php dynamic_sidebar('footer-3'); ?>
								  </div>
								<div class="col-sm-4">
									<div class="f_heading footer-add">
										<?php dynamic_sidebar('footer-4'); ?>
										<div class="social-demo">
											<?php dynamic_sidebar('social-link'); ?>
										</div> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<?php dynamic_sidebar('footer-5'); ?>
				</div>
			</div>
		</div>
	</div><!-- .site-content-contain -->
	<?php echo do_shortcode('[chatbot page_id="1704689196245280"]'); ?>
</div><!-- #page -->

<script>
   wow = new WOW(
     {
       animateClass: 'animated',
       offset: 100
     }
   );
   wow.init();
</script>
<script>
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        navigation : true,
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem : true,
        pagination : false,
        autoPlay:false
	    //autoplayHoverPause:true
      });
    });
    $(document).ready(function() {
      $("#student-demo").owlCarousel({
        items : 5,
        itemsDesktop : [1180,4],
        itemsDesktopSmall : [800,3],
        itemsTablet: [600,2],
        itemsMobile : [450,1], 
        lazyLoad : true,
        navigation : false,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    });
</script>
<script type="text/javascript">
	$(window).scroll(function() {   
	    if ($(window).scrollTop() >=50) { 
	    if($('#nav-top').hasClass( "navi" ))
	  	{
	  		//jQuery('#header').removeClass("fixed-theme");
	  	}
	  	else
	  	{
	  		$('#nav-top').addClass("navi");
	  	}
	    }
		else{
			$('#nav-top').removeClass("navi");
		}
	 });
</script>
<script type="text/javascript">
	$(document).ready(function() {
   $('.navbar a.dropdown-toggle').on('click', function(e) {
        var $el = $(this);
        var $parent = $(this).offsetParent(".dropdown-menu");
        $(this).parent("li").toggleClass('open');

        if(!$parent.parent().hasClass('nav')) {
            $el.next().css({"top": $el[0].offsetTop, "left": $parent.outerWidth() - 4});
        }

        $('.nav li.open').not(jQuery(this).parents("li")).removeClass("open");
        return false;
    });
});

</script>



<script>
	$(document).ready(function(){
	  $(".more-list").click(function(){
	     $(".near-list").toggle();
	     if($(".near-list").is(':visible')) {
		   $(".more-list").text("Less More");
		    } else {
		   $(".more-list").text("View More");
		  }
	  });
	});
    $(document).ready(function() {
      $("#owl-demo").owlCarousel({
        navigation : true,
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem : true,
        pagination : false,
        autoPlay:false
	    //autoplayHoverPause:true
      });
    });
    jQuery(document).ready(function() {
      jQuery("#cate-slid").owlCarousel({
        items : 4,
        itemsDesktop : [1180,3],
        itemsDesktopSmall : [800,2],
        itemsTablet: [600,2],
        itemsMobile : [450,1], 
        lazyLoad : true,
        navigation : true,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    });
    jQuery(document).ready(function() {
      jQuery("#cate-slid3").owlCarousel({
        items : 4,
        itemsDesktop : [1180,3],
        itemsDesktopSmall : [800,2],
        itemsTablet: [600,2],
        itemsMobile : [450,1], 
        lazyLoad : true,
        navigation : true,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    });
    jQuery(document).ready(function() {
      jQuery(".cate-slid2").owlCarousel({
        items : 3,
        itemsDesktop : [1100,3],
        itemsDesktopSmall : [900,2],
        itemsTablet: [600,2],
        itemsMobile : [500,1],
        lazyLoad : true,
        navigation : true,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    });


    $(document).ready(function() {
    	$("#owl-test").owlCarousel({
			navigation : false,
			slideSpeed : 300,
			pagination : true,
			singleItem : true,
			autoPlay : true
		});
    });
	
	  
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            },
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            });
			
	
		

		jQuery(function(){ // document ready
		   /* if (!!jQuery('#sticky').length) { // make sure "#sticky" element exists
		      var el = jQuery('#sticky');
		      var stickyTop = jQuery('#sticky').offset().top; // returns number
		      var footerTop = jQuery('footer').offset().top; // returns number
		      var stickyHeight = jQuery('#sticky').height();
		      var limit = footerTop - stickyHeight - 30;
		      jQuery(window).scroll(function(){ // scroll event
		          var windowTop = jQuery(window).scrollTop(); // returns number
		            
		          if (stickyTop < windowTop){
		             el.css({ position: 'fixed', top: 80 });
		          }
		          else {
		             el.css('position','static');
		          }
		            
		          if (limit < windowTop) {
		          var diff = limit - windowTop;
		          el.css({top: diff});
		          }     
		        });
		   	 }*/
		});
				
    
</script>
<?php wp_footer(); ?>

</body>
</html>
