<?php
/**
Template Name: Parents Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="all_same_page parent-page">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="col-md-6">
                     <?php the_content(); ?>
                </div>
            </div>
        </div>
        <div class="apply_resume">
            <div class="overlay"></div>
            <div class="container">
                <h2 class="same_heading">Consent Form</h2>
                <?php echo do_shortcode('[contact-form-7 id="389" title="Consent Form"]'); ?>
            </div>      
        </div>
    </div>
<?php endwhile; 
endif; ?>


<?php get_footer();
