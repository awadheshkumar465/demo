<?php
/**

**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php $ids =  get_the_ID(); ?>
	<section class="our-work particular-service">
	    <div class="details">
	        <div class="container">
	        	<div class="row">
	        		<div class="col-sm-12">
	        			<div class="heading text-center">
	        				<h2>Our <span>Courses</span></h2>
						</div>
		                <div class="col-sm-8">
	                        <div class="box-text service-lft-cont">
	                        	<h2><?php the_title(); ?> Tutorials Points</h2>
	                            <?php
                        		if( have_rows('curriculum_for_this_course') ):
								    while( have_rows('curriculum_for_this_course') ) : the_row();  ?>
								    	<p><?php the_sub_field('tutorial_name'); ?></p>
								        <video width="320" height="240" controls>
										  <source src="<?php the_sub_field('tutorial_points'); ?>">
										</video>
										<?php	
								    endwhile;
								endif;    
	                            ?>
	                           
	                        </div>
		                </div>

		                <div class="col-sm-4 services-featured-image">
		                    <div class="box-image service-lft-cont">
		                           <?php the_post_thumbnail(); ?>
		                    </div>
		                </div>

	        		</div>
	        	</div>
	        </div>   
	    </div>
	</section>
<?php endwhile; 
endif; ?>

<?php get_footer();
