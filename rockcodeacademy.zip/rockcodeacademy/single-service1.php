<?php
/**

**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <section>
	<div class="container">
		<div class="row">
			<div class="col-sm-7 col-md-8">
				<div class="single-details">
					<div class="deteils-img">
						<div class="demo">
						    <div class="item">            
						        <div class="clearfix">
						            <div class="lSSlideOuter ">
						            	<div class="lSSlideWrapper usingCss services-featured-image">
						            		 <?php the_post_thumbnail(); ?>
										</div>
									</div>
						   		</div>
							</div>
						</div>	
					</div>					
					<div class="temp-details">
						<div class="dmv-heading">
							<h3><?php the_title(); ?></h3>
						</div>
						<p><?php the_content(); ?></p>
					</div>
				</div>
			</div>
			<?php endwhile; 
			endif; ?>

			<?php
			$services = array(
                'post_type'=>'service',
                'publish'           => true,
                'posts_per_page'    => -1,
                'order'=>'DESC',
            );
            $services_query = new WP_Query( $services ); ?>
					<div class="col-sm-5 col-md-4">
						<div id="sticky" class="sidebar-new" style="position: static; top: 80px;">					
							<div class="bg-serch">
		                    	<div class="inner-bg-serch">
		                    		<div class="contant">
		                    			<div class="heading-se">
		                    				<h3>More Services</h3>
		                    			</div>
		                    			<div class="rpwe-block ">
		                    				<ul class="rpwe-ul">
		                    					<?php 
		                    					if ( $services_query->have_posts() ):
									                while ( $services_query->have_posts() ) : $services_query->the_post();
									                $service_id = get_the_ID();
									                $post_thumbnail_id = get_post_thumbnail_id();
									        		$post_thumbnail_url = wp_get_attachment_url( $post_thumbnail_id );
									        		if($service_id == $ids) { } else{?>
				                    					<li class="rpwe-li rpwe-clearfix">
				                    						<a class="rpwe-img" href="" rel="bookmark">
				                    							<img class="rpwe-alignleft rpwe-thumb rpwe-default-thumb" src="<?php echo $post_thumbnail_url; ?>" width="45" height="45"/>
				                    						</a>
				                    						<h3 class="rpwe-title">
				                    							<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
				                    						</h3>
				                    						<div class="rpwe-summary">
				                    							<?php echo wp_trim_words( get_the_content(), 12, '...' ); ?>
				                    						</div>
				                    					</li>
				                    				<?php }
				                    				 endwhile; 
												endif; ?>
		                    				</ul>
		                    			</div>
		                    		</div>
		                    	</div>
		                    </div>	
						</div>
					</div>
				
		</div>
	</div>
</section>
	
	<?php /*
	<section class="our-work particular-service">
	    <div class="details">
	        <div class="container">
	        	<div class="row">
	        		<div class="col-sm-12">
						<div class="col-sm-4 services-featured-image">
		                    <div class="box-image service-lft-cont">
		                           <?php the_post_thumbnail(); ?>
		                    </div>
		                </div>
		                <div class="col-sm-8">
	                        <div class="box-text service-lft-cont">
	                            <h2 class="service-name"><?php the_title(); ?></h2>
	                             <p><b>By</b> <?php echo get_the_author(); ?> <?php echo get_the_date('', $post->ID); ?>&nbsp;<?php echo get_the_time('', $post->ID); ?></p>
	                            <?php the_excerpt(); ?>
	                        </div>
		                </div>

	        		</div>
	        	</div>
	        </div>   
	    </div>
	</section>

	*/ ?>

<?php get_footer();
