<?php

function mychildtheme_enqueue_styles() {
    $parent_style = 'parent-style';
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ));
    wp_enqueue_style('bootstrap-min-style',get_stylesheet_directory_uri() .'/css/bootstrap.min.css');
    wp_enqueue_style('font-awesome-style',get_stylesheet_directory_uri() .'/css/font-awesome.css');
    wp_enqueue_style('master-style',get_stylesheet_directory_uri() .'/css/master.css');
    wp_enqueue_style('owl-carousel-style',get_stylesheet_directory_uri() .'/css/owl.carousel.css');
    wp_enqueue_style('owl-theme-style',get_stylesheet_directory_uri() .'/css/owl.theme.css');
    wp_enqueue_style('animate-style',get_stylesheet_directory_uri() .'/css/animate.css');
    wp_enqueue_script( 'jquery-min', get_stylesheet_directory_uri() .'/js/jquery-3.2.1.min.js', false );
    wp_enqueue_script( 'wow-min-script', get_stylesheet_directory_uri() .'/js/wow.min.js', false );
    wp_enqueue_script( 'bootstrap-min-script', get_stylesheet_directory_uri() .'/js/bootstrap.min.js', false );
    wp_enqueue_script( 'owl-carousel-min-script', get_stylesheet_directory_uri() .'/js/owl.carousel.min.js', false );
}
add_action( 'wp_enqueue_scripts', 'mychildtheme_enqueue_styles' );

/* Create Custom Footer Sidebar */
function my_custom_sidebar() {
    register_sidebar(
        array (
            'name' => __( 'Footer-3', 'your-theme-domain' ),
            'id' => 'footer-3',
            'description' => __( 'Add widgets here to appear in your footer.', 'your-theme-domain' ),
            'before_widget' => '<div class="widget-content">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
    register_sidebar(
        array (
            'name' => __( 'Footer-4', 'your-theme-domain' ),
            'id' => 'footer-4',
            'description' => __( 'Add widgets here to appear in your footer.', 'your-theme-domain' ),
            'before_widget' => '<div class="widget-content">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        )

    );

    register_sidebar(

        array (

            'name' => __( 'Bottom Footer', 'your-theme-domain' ),

            'id' => 'footer-5',

            'description' => __( 'Add widgets here to appear in your footer.', 'your-theme-domain' ),

            'before_widget' => '<div class="widget-content">',

            'after_widget' => "</div>",

            'before_title' => '<h3 class="widget-title">',

            'after_title' => '</h3>',

        )

    );

    register_sidebar(

        array (

            'name' => __( 'Top Social Links', 'your-theme-domain' ),

            'id' => 'social-link',

            'description' => __( 'Add widgets here to appear in your Top Social Link.', 'your-theme-domain' ),

            'before_widget' => '<div class="widget-content">',

            'after_widget' => "</div>",

            'before_title' => '<h3 class="widget-title">',

            'after_title' => '</h3>',

        )

    );

}

add_action( 'widgets_init', 'my_custom_sidebar' );



function the_breadcrumb() {

    $sep = ' » ';

    if (!is_front_page()) { ?>
        <ul class="breadcrumbs">
        <li><a href="<?php echo get_option('home'); ?>">Home</a></li>
        <?php
        if (is_tax()){ ?>
            <li><?php echo single_cat_title(); ?> </li>
        <?php } 
        elseif (is_archive()){
            if ( is_day() ) {
                printf( __( '%s', 'text_domain' ), get_the_date() );
            } 
            elseif ( is_month() ) {
                printf( __( '%s', 'text_domain' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'text_domain' ) ) );
            } 
            elseif ( is_year() ) {
                printf( __( '%s', 'text_domain' ), get_the_date( _x( 'Y', 'yearly archives date format', 'text_domain' ) ) );
            }
            elseif ( is_archive() ) { ?>
               <li><?php echo post_type_archive_title($prefix, false); ?></li>
            <?php }
            else { ?>
                <li> <?php echo single_cat_title(); ?> </li>
            <?php }
        }
        if (is_single()) { ?>
            <li> <?php echo the_title(); ?></li>
        <?php }
        if (is_page()) { ?>
            <li> <?php echo the_title(); ?></li>
        <?php }
        if (is_home()){
            global $post;
            $page_for_posts_id = get_option('page_for_posts');
            if ( $page_for_posts_id ) { 
                $post = get_page($page_for_posts_id);
                setup_postdata($post);
                the_title();
                rewind_posts();
            }
        }
        echo '</ul>';
    }
}


remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);

/* creating for user role */

add_role('kids-club', __(
    'Kids Club'),
    array(
        'read'              => true,
        'edit_posts'   => false,
        'delete_posts' => false,
        'edit_pages' => false,
        'create_posts' => false,
        'publish_posts' => false,
        'edit_others_posts' => false,
        )
);
add_role('young-coders', __(
    'Young Coders'),
    array(
        'read'              => true,
        'edit_posts'   => false,
        'delete_posts' => false,
        'edit_pages' => false,
        'create_posts' => false,
        'publish_posts' => false,
        'edit_others_posts' => false,
        )
);
add_role('codemaniacs-startups', __(
    'Codemaniacs Startups'),
    array(
        'read'              => true,
        'edit_posts'   => false,
        'delete_posts' => false,
        'edit_pages' => false,
        'create_posts' => false,
        'publish_posts' => false,
        'edit_others_posts' => false,
        )
);

/* Ending */



//1. Add a new form element...
add_action( 'register_form', 'myplugin_register_form' );
function myplugin_register_form() {
    global $wp_roles; 
    echo '<label for="user_email">User Type</label>';
    echo '<select name="role" class="input">';
    foreach ( $wp_roles->roles as $key=>$value ) {
       // Exclude default roles such as administrator etc. Add your own
       if ( ! in_array( $value['name'], [ 'Administrator', 'Contributor', 'Editor', 'Author', 'Subscriber', 'Customer', 'Shop manager', ] )) {
          echo '<option value="'.$key.'">'.$value['name'].'</option>';
       }
    }
    echo '</select>';

                 

}
//2. Add validation.
add_filter( 'registration_errors', 'myplugin_registration_errors', 10, 3 );
function myplugin_registration_errors( $errors, $sanitized_user_login, $user_email ) {

    if ( empty( $_POST['role'] ) || ! empty( $_POST['role'] ) && trim( $_POST['role'] ) == '' ) {
         $errors->add( 'role_error', __( '<strong>ERROR</strong>: You must include a role.', 'mydomain' ) );
    }

    if ( empty( $_POST['description'] ) || ! empty( $_POST['description'] ) && trim( $_POST['description'] ) == '' ) {
         $errors->add( 'description_error', __( '<strong>ERROR</strong>: You must include a description.', 'mydomain' ) );
    }
    return $errors;
}

//3. Finally, save our extra registration user meta.
add_action( 'user_register', 'myplugin_user_register' );
function myplugin_user_register( $user_id ) {
   $user_id = wp_update_user( array( 'ID' => $user_id, 'role' => $_POST['role'] ) );
   $user_id = wp_update_user( array( 'ID' => $user_id, 'description' => $_POST['description'] ) );
}




