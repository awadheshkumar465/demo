<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>

<div class="rtin-main-cols col-lg-4 col-md-4 col-sm-4 col-xs-12 wow slideInLeft animated <?php post_class(); ?>" id="post-<?php the_ID(); ?>">
	<div class="rt-course-box">
        <div class="rtin-thumbnail hvr-bounce-to-right">
			<?php
			if ( is_sticky() && is_home() ) :
				echo twentyseventeen_get_svg( array( 'icon' => 'thumb-tack' ) );
			endif;
			?>
			<?php if ( '' !== get_the_post_thumbnail() && ! is_single() ) : ?>
				<?php the_post_thumbnail( 'twentyseventeen-featured-image' ); ?>
				<a href="<?php the_permalink(); ?>" title=""><i class="fa fa-link" aria-hidden="true"></i></a>
                <div class="rtin-price">
                    <div class="course-price"> <span class="price">Free</span></div>
                </div>
			<?php endif; ?>
		</div>
		<div class="rtin-content-wrap">
            <div class="rtin-content">
				<?php
				if ( 'post' === get_post_type() ) {
					echo '<div class="entry-meta">';
						if ( is_single() ) {
							twentyseventeen_posted_on();
						} else {
							echo twentyseventeen_time_link();
							twentyseventeen_edit_link();
						};
					echo '</div><!-- .entry-meta -->';
				};

				if ( is_single() ) {
					the_title( '<h1 class="entry-title">', '</h1>' );
				} elseif ( is_front_page() && is_home() ) {
					the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
				} else {
					the_title( '<h3 class="rtin-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
				}
				?>
				 <div class="rtin-description"><?php the_content(); ?></div>
			</div>
		</div>

			<?php /*
			<div class="entry-content">
				<?php
				the_content( sprintf(
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'twentyseventeen' ),
					get_the_title()
				) );

				wp_link_pages( array(
					'before'      => '<div class="page-links">' . __( 'Pages:', 'twentyseventeen' ),
					'after'       => '</div>',
					'link_before' => '<span class="page-number">',
					'link_after'  => '</span>',
				) );
				?>
			</div>
			<?php
			if ( is_single() ) {
				twentyseventeen_entry_footer();
			} */
			?>
	</div>

</div><!-- #post-## -->
