<?php
/**
Template Name: FAQs Page
**/
get_header(); ?>
<div class="main-content all_same_page">   
    <div class="container faq-container">
        <div class="row">
        	<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
	            <?php $count = 0;
	            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
	            $faqs = array(
	            		'post_type'=>'faqs',
	            		'posts_per_page'=>6, 
	            		'order'=>'DESC',
	            		'paged' => $paged
	            	);
            	$faqs_query = new WP_Query( $faqs );
	            if ( $faqs_query->have_posts() ):
	                while ( $faqs_query->have_posts() ) : $faqs_query->the_post(); ?>
	                	<div class="col-md-12 faqs-container">
	                    	<div class="panel panel-default">
	                        	<div class="panel-heading" role="tab" id="heading<?php echo $count; ?>">
	                            	<h4 class="panel-title">
	                                	<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $count; ?>" aria-expanded="true" aria-controls="collapse<?php echo $count; ?>">
	                                    <?php the_title(); ?>
	                                	</a>
	                           		</h4>
	                        	</div>
		                        <div id="collapse<?php echo $count; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $count; ?>">
		                            <div class="panel-body">
		                                <?php the_content(); ?>
		                            </div>
		                        </div>
	                    	</div>    
	                	</div>
	            	<?php $count++; endwhile; ?>
		            
	        	<?php endif; ?>
	    	</div>
        </div>                  
    </div>
</div>


<?php get_footer();