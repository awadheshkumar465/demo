<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site home_page">
	<article class="slider-arti">	
		<header id="main_header_id">
			<div class="header-main">
				<div class="top-header">
					<div class="container">
						<div class="row">
							<div class="col-sm-6 col-xs-6 wow slideInDown animated">
								<?php dynamic_sidebar('social-link'); ?>
							</div>
							<div class="col-sm-6 col-xs-6 wow slideInDown animated">
								<div class="top-navi">
									<ul>
									<?php
										if ( is_user_logged_in() ) {
										    echo '<li><a href="'.wp_logout(site_url()).'">Sign Out</a></li>';
										} else {
										    echo '<li><a href="'.site_url().'/login/">Sign In</a></li>';
                                            echo '<li><a href="'.site_url().'/register/">Register</a></li>';
										}
									 ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
	            <nav class="navbar navbar-default  navbar-static-top menu-header wow fadeInDown animated" id="nav-top">
					<div class="container">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							</button>
							<?php 
                            $custom_logo_id = get_theme_mod( 'custom_logo' );
							$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
							//print_r($image);
							 ?>

                                <?php show_easylogo(); ?>

						</div>					
						<div class="collapse navbar-collapse text-right" id="bs-example-navbar-collapse-1">
							<a class="skip-link screen-reader-text" href="#content">
								<?php _e( 'Skip to content', 'twentyseventeen' ); ?>
							</a>
							<?php if ( has_nav_menu( 'top' ) ) : ?>
								<?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
							<?php endif; ?>
						</div>
					</div>
				</nav>
			</div>
		</header>
		<?php
		if (is_front_page()){ ?>
		<div class="home_slider">
			<div id="demo">
				<div id="owl-demo" class="owl-carousel">
					<?php 
					$slider = array('post_type'=>'slider', 'posts_per_page'=>-1, 'order'=>'ASC');
					$slider_query = new WP_Query( $slider );
					if ( $slider_query->have_posts() ):
						while ( $slider_query->have_posts() ) : $slider_query->the_post();
		       				 $slider_img = wp_get_attachment_url( get_post_thumbnail_id() ); ?>
                			<div class="item">
								<div class="home-slider-img">
									<?php the_post_thumbnail();?>
			                      	<div class="banner_text wow slideInDown  animated">
				                        <h1><?php the_title(); ?></h1>
				                        <a href="<?php the_field('read_more_link'); ?>">
				                        	<?php  the_field('read_more_name'); ?>
										</a>
									</div>
								</div>
							</div>
						<?php endwhile;
					endif; ?>
				</div>
			</div>
		</div>
		<?php } ?>
	</article>
	<div class="site-content-contain">
		<div id="content" class="site-content main-content">
        	<?php
        	if (!is_front_page()){
        	$ids = get_the_ID(); 
            $image_path = get_field( "header_image", $ids );
                if (is_page()){ ?>
                <div class="header-banner">
                    <div class="educare-breadcroumb-area" style="background: url('<?php echo $image_path; ?>')">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 text-center">
                                	<?php
                                	if (is_page()){ ?>
                                		<h2><?php the_title(); ?></h2>
                                	<?php }
                                	else{?>
                                    <h2><?php echo single_cat_title(); ?></h2>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
                elseif(is_single()){ ?>
                    <div class="header-banner">
                        <div class="educare-breadcroumb-area" style="background: url('http://votivejoomla.in/rockcodeacademy/wp-content/uploads/2018/03/slide-bg.jpg')">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php
                                        if (is_single()) { ?>
                                            <h2><?php the_title(); ?></h2>
                                        <?php }
                                        else{?>
                                        <h2><?php echo single_cat_title(); ?></h2>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                elseif(is_tax()){
                        $ids = get_the_ID(); 
                        $image_path = get_field( "service_header_image", $ids );?>
                    <div class="header-banner">
                        <div class="educare-breadcroumb-area" style="background: url('<?php echo $image_path; ?>')">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php
                                        if (is_single()) { ?>
                                            <h2><?php the_title(); ?></h2>
                                        <?php }
                                        else{?>
                                        <h2><?php echo single_cat_title(); ?></h2>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }
                else{
                    $ids = get_the_ID(); 
                    $image_path = get_field( "service_header_image", $ids );?>
                    <div class="header-banner">
                        <div class="educare-breadcroumb-area" style="background: url('http://votivejoomla.in/rockcodeacademy/wp-content/uploads/2018/03/slide-bg.jpg')">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php
                                        if (is_single()) { ?>
                                            <h2><?php the_title(); ?></h2>
                                        <?php }
                                        elseif (is_archive()) { ?>
                                            <h2><?php echo post_type_archive_title($prefix, false); ?></h2>
                                        <?php }
                                        else{?>
                                        <h2><?php echo single_cat_title(); ?></h2>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }  ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12 the-breadcrumb">     
                     <?php the_breadcrumb(); ?>
                </div>
            </div>
        </div>    
