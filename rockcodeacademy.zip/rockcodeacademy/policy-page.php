<?php
/**
Template Name: Policy Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 
$ids =  get_the_ID();?>
    <div class="all_same_page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="same_heading"><?php the_title(); ?></h2>
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
        <div class="container faq-container">
            <div class="row">
                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                    <?php $count = 0;
                    $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
                    $faqs = array(
                            'post_type'=>'policy',
                            'posts_per_page'=>-1, 
                            'order'=>'DESC',
                            'paged' => $paged
                        );
                    $faqs_query = new WP_Query( $faqs );
                    if ( $faqs_query->have_posts() ):
                        while ( $faqs_query->have_posts() ) : $faqs_query->the_post(); ?>
                            <div class="col-md-12 col-sm-12 faqs-container" style="margin-bottom: 1%;">
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="heading<?php echo $count; ?>">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $count; ?>" aria-expanded="true" aria-controls="collapse<?php echo $count; ?>">
                                            <?php the_title(); ?>
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo $count; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo $count; ?>">
                                        <div class="panel-body">
                                            <?php the_content(); ?>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        <?php $count++; endwhile; ?>
                        
                    <?php endif; ?>
                </div>
            </div>                  
        </div>
    </div>
<?php endwhile; 
endif; ?>


<?php get_footer();
