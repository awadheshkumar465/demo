<?php
/**
Template Name: Inner Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <div class="all_same_page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php 
                        $ids =  get_the_ID();
                        if ( has_post_thumbnail() ) { ?>
                            <div class="col-md-6 innerpage-content-lft"> 
                                <?php the_post_thumbnail();?>
                            </div>
                            <div class="col-md-6 innerpage-content-rgt">
                                <h2 class="same_heading"><?php the_title(); ?></h2>
                                <?php the_content(); ?>
                            </div>
                        <?php }
                        else { ?>
                            <div class="full-width-content">
                                <?php the_content(); ?>
                            </div>
                        <?php } ?>
                    
                </div>
                
            </div>
        </div>
        <div class="apply_resume" style="background: url('<?php echo get_field( "header_image", $ids ); ?>');">
            <div class="overlay"></div>
            <div class="container">
                <h2 class="same_heading">Contact Information</h2>
                <?php echo do_shortcode('[contact-form-7 id="389" title="Consent Form"]'); ?>
            </div>      
        </div>
    </div>
<?php endwhile; 
endif; ?>


<?php get_footer();
