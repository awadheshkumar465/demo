<?php
/**
Template Name: Courses Pages
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    

    <section class="courses_page">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="1s">
                    <div class="courses_list">
                        <div class="top_course"> Top Courses </div>
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses1.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#">Courses</a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="1.2s">
                    <div class="courses_list">
                        <div class="top_course"> Top Courses </div>
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses2.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#">Courses</a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="1.4s">
                    <div class="courses_list">
                        <div class="top_course"> Top Courses </div>
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses3.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#"> Courses </a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="1.6s">
                    <div class="courses_list">
                        <div class="top_course"> Top Courses </div>
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses4.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#"> Courses </a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="1.8s">
                    <div class="courses_list">
                        <div class="top_course"> Top Courses </div>
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses1.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#">Courses</a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 wow fadeInDown" data-wow-delay="2s">
                    <div class="courses_list">
                        <figure>
                            <img src="<?php echo get_stylesheet_directory_uri();?>/images/courses2.jpg" alt="" />
                            <figcaption>
                                <a href="#">Read More</a>
                            </figcaption>
                        </figure>
                        <div class="crslist_contant">
                            <h2><a href="#">Courses</a></h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                            <div class="rating">
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star-half-o"></span>
                            </div>
                            <div class="course_meta">
                                <ul>
                                    <li><i class="fa fa-users"></i>45</li>
                                    <li><i class="fa fa-thumbs-o-up"></i> 20</li>
                                    <li><i class="fa fa-comments-o"></i> 2</li>
                                    <li><i class="fa fa-inr"></i> 200</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
<?php endwhile; 
endif; ?>


<?php get_footer();
