<?php defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require $_SERVER['DOCUMENT_ROOT'].'/blocktrail/vendor/autoload.php';
use Blocktrail\SDK\BlocktrailSDK;
use Blocktrail\SDK\Wallet;
use Blocktrail\SDK\WalletInterface;
use Blocktrail\SDK\Connection\Exceptions\ObjectNotFound;
use Blocktrail\SDK\Services\BlocktrailBatchUnspentOutputFinder;
use Blocktrail\SDK\WalletV1Sweeper;

class Webservices extends REST_Controller 
{  
  public function __construct() {
    date_default_timezone_set('Africa/Douala');
    parent:: __construct();
    $this->param = Request();
  }
  /*__________________________________-PRIVATE-END-_______________________*/
    private function client(){

      //Initialize Client
      $myAPIKEY     = get_option('blocktrail_api_key');
      $myAPISECRET  = get_option('blocktrailsecret');
      $testnet      = true; //false for bitcoin mainnet or true for testnet
      // Initialize the SDK
      try { 
        $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
      } 
      catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      return $client;
    }
    private function walletAdmin($client){

      //Wallet Creation 

      $testnet        = true; //false for bitcoin mainnet or true for testnet
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
   
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }       
        return $wallet;
    }
    private function ourFees($amount){
      
      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      { 
        $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); 
      }
            
      return $trade_fees;
    }
    private function AdderssAdmin($client){

      //Wallet Creation 

      $testnet        = true; //false for bitcoin mainnet or true for testnet
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
   
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        $address = $wallet->getNewAddress(); 
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }       
        return $address;
    }
    private function getBalance($wallet){    

      list($confirmed, $unconfirmed) = $wallet->getBalance();

      $confirmedbtc = BlocktrailSDK::toBTC($confirmed);
      $unconfirmedbtc = BlocktrailSDK::toBTC($unconfirmed);

      $balance = array('santoshi' => $confirmed,
                       'btc'=> $confirmedbtc,
                       'unsantoshi' => $unconfirmed,
                       'unbtc'=> $unconfirmedbtc,
                      );

      //$balance = $wallet->getBalance();
      return $balance;
    }
    private function networkFees($client,$walletIdent, $walletPassword, $amount, $from ='XAF', $to='BTC'){

      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      
      //echo $btcamountRecieved;die();
      if($from == 'XAF'){
        $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);

      }else{
        $btcamountRecieved = $amount;

      }
      $btc = convert_exponantial_to_decimal($btcamountRecieved);

      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees)) {
       $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); }
       $trade_fee = get_conversion_bitcoin_with_amount('XAF','BTC', $trade_fees);
       $trade_fees_btc = convert_exponantial_to_decimal($trade_fee);

      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } 
        catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
          //$this->response(Results(0,array(),"{$e->getMessage()}".$walletIdent."MyName".$walletPassword));
      }
      try {
        // Or you can initialize an already existing wallet
        //print_r($btc);die();
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));
        } 
        catch (Exception $e) {
          if($e->getMessage() == "Values should be more than dust (2730)"){
            $this->response(Results(0,array(),"BTC Values should be greater than 0.0001"));
          }
          elseif($e->getMessage() == "Values should be non zero") {
            $this->response(Results(0,array(),"Values should be greater than zero"));
          }
          else{
            $this->response(Results(0,array(),"{$e->getMessage()}"));
          }
      }
      $balance = $this->getBalance($wallet);
      
      $fees = array('btc'=>$btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'trade_fees_btc'=> $trade_fees_btc,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );

      
      return $fees;
    }

    
    private function pay($wallet,$BTCreceiverAddress,$btc){

      try {
        $satoshiamount = BlocktrailSDK::toSatoshi($btc);        
        $outputs = array($BTCreceiverAddress => $satoshiamount);
        
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
        $kb = $result['size']/1000;
        $am = (int)round($kb*$result['fees']['optimal']);      
        $txHash = $wallet->pay($outputs, null, true, true, Wallet::FEE_STRATEGY_OPTIMAL, $am);
        }
        catch (Exception $e) {
          //$this->response(Results(0,array(),"{BTC Amount".$btc." KB ".$kb." Fee ".$result['fees']['optimal']." AM ".$am."}"));
          $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }
      return $txHash;
    }
    private function Withdraw($data){
      global $wpdb;
      date_default_timezone_set('Africa/Douala');
      $user_id = $data['user_id'];
      $time = date('Y-m-d h:i:s');
      $nonce = rand();
      $currency_type_amount = $data['transfer_amount'];
      $fullname = $data['fullname'];
      $senderMsisdn = $data['senderMsisdn'];
      $sp_id = get_option('sp_id');
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip');
      $service_id = get_option('service_id');
      //$country_name = $data['country_name'];

      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;     
      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
      <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
      <spId>'.$spID.'</spId>
      <spPassword>'.$PasswordDigest.'</spPassword>

      <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
      </soap:Header>
      <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
      <serviceId>DiaspoCC</serviceId>
      <parameter>
      <name>DueAmount</name>
      <value>'.$currency_type_amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$senderMsisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>CurrCode</name>
      <value>XAF</value>
      </parameter>
      <parameter>
      <name>SenderID</name>
      <value>DiaspoCC</value>
      </parameter>
      </ns3:processRequest>
      </soap:Body>
      </soap:Envelope>';

      $to = "test5@kit-services.com,votiveyogesh@gmail.com";
      $subject = "TESTBED URL - Send Request";
      $txt = $xml_post_string;
      $headers = "From: info@diaspo-cc.com," . "\r\n";
      mail($to,$subject,$txt,$headers);

      $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';

      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME') {
              $arr_name[$i++] = $value['value'];
            }
            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));

      if(count($arr) != count($arr1))
      { 
        $arr1[] = '';
      }
      $arr2 = array_combine($arr, $arr1);

      return $arr2;
    }
    private function Deposit($data){

      global $wpdb;
      $user_id = $data['user_id'];
      $msisdn =  $data['senderMsisdn'];
      $fullname = $data['fullname'];
      $amount = $data['transfer_amount'];
      $order_id = $data['order_id'];
      
      $Narration = '';
      $left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
      $lang = get_user_meta( $user_id, 'diaspo_user_language', true );
      $message = '';
      $subject = ''; 
      $user_info = get_userdata($user_id);
      $to = $user_info->user_email;
      
      $sp_id = get_option('sp_id'); 
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip'); 
      $service_id = get_option('service_id');
            
      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17";

      $nonce = rand();
      $rand = rand(3, 4);
      date_default_timezone_set('Africa/Douala');
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;

      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
      <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
      <ns1:spId>'.$spID.'</ns1:spId>
      <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
      <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
      </soapenv:Header>
      <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
      <serviceId>diaspoCC</serviceId>
      <parameter>
      <name>Amount</name>
      <value>'.$amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$msisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>serviceId</name>
      <value>'.$service_id.'</value>
      </parameter>
      <parameter>
      <name>appVersion</name>
      <value>1.7</value>
      </parameter>
      <parameter>
      <name>Narration</name>
      <value>'.$Narration.'</value>
      </parameter>
      <parameter>
      <name>PrefLang</name>
      <value>en</value>
      </parameter>
      <parameter>
      <name>OpCoID</name>
      <value>23701</value>
      </parameter>
      </ns1:processRequest>
      </soapenv:Body>
      </soapenv:Envelope>
      ';

      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);   
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME')
            {
              $arr_name[$i++] = $value['value'];
            }

            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));
      $arr2 = array_combine($arr, $arr1);
      return $arr2;
    }
    private function momonum($user_id){

      $mobile = get_user_meta($user_id,'diaspo_user_phone',false);
      $momo = $mobile[0];
      $count_code = get_user_meta( $user_id , 'country_flag_code', true );
      if (empty($count_code)) {
        $count_code = "237";
      }
      $country_code = $count_code;
      /* 03-11-2018 Start*/
      $momonum = $country_code.$momo;
      //$momonum = $momo;
      /* 03-11-2018 End */
      return $momonum;
    }
    private function userName($user_id){

      $first_name = get_user_meta($user_id,'first_name',false);
      $last_name = get_user_meta($user_id,'last_name',false);
      $sender_name = $first_name[0].' '.$last_name[0];
      return $sender_name;
    }
  /*__________________________________-PUBLIC-END-_______________________*/
                  
    /*REGISTATION*/
    public function signup_post(){
      $input = $this->param;         
      $required = array ('email','password','phone','deviceid','devicetype','country','language');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
          $count = email_exists($input['email']);
        if (!$count) {
            //$OTP = 1234;//mt_rand(1000, 9999);
            $OTP = mt_rand(1000, 9999);
            $inputs = array('email' => $input['email'],
                            'password' => base64_encode($input['password']),
                            'diaspo_user_phone' => $input['phone'],                           
                            'otp_code' => $OTP,
                            'deviceid' => $input['deviceid'],
                            'devicetype' => $input['devicetype'],
                            'devicetoken' => $input['devicetoken'],
                            'country_flag_code' => $input['country'],
                            'diaspo_user_language' => $input['language']
                            );
            $InsertId = InsertData("wp_before_activation_user_list", $inputs);
            if (!empty($InsertId)) {
        
        $siteurl = get_option('siteurl');
              $toNumber = '+'.$input['country'].$input['phone'];
        
        
        
              $fromNumber = get_option('from_number');
              $messageFormate = get_option('body_message');
              $messageWOTP = $messageFormate.' '.$siteurl.': '.$OTP;
        
        //$toNumber = '+237672921262';
        $this->sendSms($toNumber, $fromNumber, $messageWOTP);
        
        
              $resp = array('status' => "true", 'message' => "we have sent one time password in your registered mobile number, please verify it", 'id' => (string)$InsertId,'response' => new stdclass);
            }
            else{
              $resp = array('status' => "false", 'message' => "Internal Server Error", 'response' =>New stdclass);
            }          
        }
        else{
          $resp = array('status' => "false", 'message' => "Email already Exist in our database", 'response' => new stdclass); 
        }
      }
      else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*RESEND OTP FOR SIGNUP*/
    public function resendSignupOtp_post(){
      $input = $this->param;         
      $required = array('id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){       

        //$OTP = 1234;//mt_rand(1000, 9999);
        $OTP = mt_rand(1000, 9999);
        $get = Get_Data("wp_before_activation_user_list", array('list_id' => $input['id']));
        if ($get) {
          $Updated = UpdateData("wp_before_activation_user_list", array('otp_code' => $OTP), array('list_id' => $input['id']));
          if (!empty($Updated)) {
        
      $siteurl = get_option('siteurl');
            $toNumber = '+'.$get['country_flag_code'].$get['diaspo_user_phone'];  
    
            $fromNumber = get_option('from_number');
            $messageFormate = get_option('body_message');
            $messageWOTP = $messageFormate.' '.$siteurl.': '.$OTP;
      
            $this->sendSms($toNumber, $fromNumber, $messageWOTP); 

            $resp = array('status' => "true", 'message' => "we have send one time password in your registered mobile number, please verify it", 'response' => array('id' => $input['id']) );
          }else{
            $resp = array('status' => "false", 'message' => "Internal Server Error", 'response' =>New stdclass);
          }
        }else{
          $resp = array('status' => "false", 'message' => "Data not found", 'response' =>New stdclass);
        }          
        
      }else{
        $resp = $Error;
      }
      $this->response($resp); 
    }
    /*OTP VERIFICATION*/
    public function signupOtpVerify_post(){
      $input = $this->param;         
      $required = array ('id','otp');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){      
        $results = Get_Record("wp_before_activation_user_list", array('list_id' => $input['id'], 'otp_code' => $input['otp']));


        $password_decrt = base64_decode($results->password);

        if ($results) {
          $user_id = wp_create_user($results->email, $password_decrt, $results->email);
          
          update_user_meta($user_id,'deviceid', $results->deviceid);   
          update_user_meta($user_id,'devicetype', $results->devicetype);   
          update_user_meta($user_id,'devicetoken', $results->devicetoken);
          $kee = wp_generate_password(20, false);
      
          $mail = send_mail("Please activate your account:  "."http://dsp.lab.kit-services.com/webapi/index.php/Verify/signupEmailVerify/".$kee."", "Activation Link" ,$results->email);          
          
          update_user_meta( $user_id, 'diaspo_activation_key', $kee);
          update_user_meta( $user_id, 'diaspo_user_status', 'deactive');
          update_user_meta( $user_id , 'diaspo_pdf_status' , 'Start');         
          update_user_meta( $user_id, 'diaspo_user_phone', $results->diaspo_user_phone);
          update_user_meta( $user_id, 'diaspo_user_newsletter', $results->diaspo_user_newsletter);
          update_user_meta( $user_id, 'country_flag_code', $results->country_flag_code);
          update_user_meta( $user_id, 'diaspo_user_language', $results->diaspo_user_language);

          $resp = array('status' => "true", 'message' => "Your mobile number has been verified successfully", 'response' => array('user_id' => (string)$user_id));
        }
        else{
          $resp = array('status' => "false", 'message' => "one time password not matched", 'response' =>New stdclass);
        }
        
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*LOGIN*/
    public function login_post(){ 

      $input = $this->param;   
      $required = array ('user_name','user_pass','deviceid','devicetype'/*,'devicetoken'*/);
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_login = $input['user_name'];
        $user_password = $input['user_pass'];
        $creds['user_login'] = $user_login;
        $creds['user_password'] = $user_password;
        $user = get_user_by( 'login', $user_login );
        if ($user && wp_check_password($user_password, $user->data->user_pass, $user->ID)) {
          $user_id = $user->data->ID;
          $status = get_user_meta($user_id,'diaspo_user_status',true);
          if ("active" == get_user_meta($user_id,'diaspo_user_status',true)) {
              $deviceid = update_user_meta($user_id,'deviceid', $input['deviceid']);   
              $devicetype = update_user_meta($user_id,'devicetype', $input['devicetype']);   
              //$devicetoken = update_user_meta($user_id,'devicetoken', $input['devicetoken']);
              $pin = get_user_meta($user->ID,'pin',true);
              if (!empty($pin)) {
                $pinstatus = "true";
              }
              else{
                $pinstatus = "false";
              }
              $results = array('user_id' => $user->data->ID,
                               'email' => $user->data->user_email,
                               'Phone' => get_user_meta($user->ID,'diaspo_user_phone',true),
                               'first_name' => get_user_meta($user->ID,'first_name',true),
                               'last_name' => get_user_meta($user->ID,'last_name',true),
                               'nickname' => get_user_meta($user->ID,'nickname',true),
                               'pinstatus' => $pinstatus                          
                              );
              $resp = array( 'status' => 'true', 'message' => "You are successfully login, please verify it", 'response' => $results);
          }
          else{
              $resp = array( 'status' => 'false', 'message' => 'Please verify the Email provided first.');
          }
        }
        else{
          $user = wp_signon($creds, false ); 
          if ( 'incorrect user' == $user->get_error_code()){
            $resp = array( 'status' => 'false', 'message' => 'Please check the Email provided.');
          }
            else if( 'incorrect_password' == $user->get_error_code() ){
              $resp = array( 'status' => 'false', 'message' =>'Email or password invalid. Please try again.');
            }
            else{
            $resp = array( 'status' => 'false', 'message' => $user->get_error_message());
          }
        }
      }
      else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD*/
    public function forgotPassword_post(){

      $input = $this->param;   
      $required = array ('forgot');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){               
        $forgot = strtolower($input['forgot']);
        $check = Get_Data("wp_users", array('user_email'=> $forgot));
        if ($check) {
          //$OTP = 1234;//mt_rand(1000,9999);
          $OTP = mt_rand(1000,9999);
          $user_id = $check['ID'];
          
          $data = update_user_meta( $user_id, 'otp', $OTP);                    
          $mail = send_mail("OTP is: ".$OTP,"OTP for forgot password",$forgot);
          if(!empty($mail)){
            $resp = array( 'status' => 'true', 'message' => "we have sent one time password in your registered email id, please verify it", 'response' => array('user_id' => $user_id));
          }
        }
        else{
          $resp = array( 'status' => 'false', 'message' => "This email is not found in our database", 'response' => new stdclass);
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD OTP VERIFICATION*/
    public function forgotOtpVerify_post(){
      $input = $this->param;         
      $required = array('user_id','otp');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];
        if ($otp == $input['otp']) {
          $resp = array('status' => "true", 'message' => "One time password has been verified successfully", 'user_id' => (string)$user_id, 'response' => New stdclass);
        }else{
          $resp = array('status' => "false", 'message' => "one time password did not matched", 'user_id' => (string)$user_id, 'response' =>New stdclass);
        }   
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD CHANGE*/
    public function forgotPasswordChange_post(){
      $input = $this->param;         
      $required = array('user_id','password');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $password = $input['password'];
        wp_set_password( $password, $user_id );

        $resp = array('status' => "true", 'message' => "Your password has been changed successfully", 'response' => new stdclass);           
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*SEND OTP 03-11-2018 */
    public function sendOtp_post(){
      $input = $this->param;         
      $required = array('user_id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){       
        $user_id = $input['user_id'];
        $OTP = mt_rand(1000, 9999);
        $update = update_user_meta( $user_id, 'otp', $OTP); 
        $Email = Get_Data("wp_users", array('ID'=> $user_id));
        $email = $Email['user_email'];
        if(!empty($email)){
          $mail = send_mail("OTP is: ".$OTP,"OTP for change password",$email);
            $resp = array('status' => "true", 'message' => "we have send one time password in your registered email, please verify it", 'response' => array('id' => $user_id,'email'=> $email));
        }
        else{
          $resp = array ('status' => "false", 'message' => "success", 'response' => array('email_address' => 'Email Address Not Availabel..'));
        }    
        
      }
      else{
        $resp = $Error;
      }
      $this->response($resp); 
    }
    /*FORGOT PASSWORD CHANGE*/
    public function changePassword_post(){
      $input = $this->param;         
      $required = array('user_id','password');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $password = $input['password'];
        $user_password = $input['oldpassword'];
        $user = get_user_by( 'ID', $user_id );
        if ($user && wp_check_password($user_password, $user->data->user_pass, $user->ID)) {          
          wp_set_password($password, $user_id);
          $resp = array('status' => "true", 'message' => "Your password has been changed successfully", 'response' => new stdclass);
        }
        else{
          $resp = array('status' => "false", 'message' => "Old password does not match", 'response' => new stdclass);
        }         
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*SET PIN*/
    public function pinSet_post(){

      $input = $this->param;   
      $required = array('user_id','pin','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $get = get_user_meta($input['user_id'],'pin',false); 
        if ($get) {          
           $data = update_user_meta($input['user_id'],'pin',$input['pin'],"");        
        } else{          
          $data = add_user_meta($input['user_id'],'pin',$input['pin'], false);
        }
        $resp = array( 'status' => 'true', 'message' => "Your PIN successfully Set", 'response' => array('user_id' => $data));
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PIN*/
    public function pinGet_post(){

      $input = $this->param;   
      $required = array('user_id','pin','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $get = get_user_meta($input['user_id'],'pin',false);
        $pin = $get[0];
        if ($pin == $input['pin']) {
          $resp = array( 'status' => 'true', 'message' => "Your pin has been matched successfully", 'response' => new stdclass );
        }else{
          $resp = array( 'status' => 'false', 'message' => "Your pin has not been matched", 'response' => new stdclass);
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PROFILE*/
    public function getProfile_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      
      if ($Error == "0"){
          $user_id = $input['user_id'];
          $get = Get_Data("wp_users", array('ID' => $user_id));
          $email= $get['user_email'];
          $phone= get_user_meta($user_id,'diaspo_user_phone',false);
          $first_name= get_user_meta($user_id,'first_name',false);
          $last_name= get_user_meta($user_id,'last_name',false);
          //$country= get_user_meta($user_id,'diaspo_user_country_of_origin',false);
          $country= get_user_meta($user_id,'country_flag_code',false);
          $language = get_user_meta($user_id,'diaspo_user_language',false);

          
          //$address= get_user_meta($user_id,'bitcoin_user_address',false);
      
      $countryList =  array(
                        array('name' => "",'code' => $country[0]?$country[0]:"",'language_code' => $language[0]),
                        array('name' => "Algeria", 'code' => "213", 'language_code' => "DZ"),
                        array('name' => "Angola", 'code' => "244", 'language_code' => "AO"),
                        array('name' => "Burundi", 'code' => "257", 'language_code' => "BI"),
                        array('name' => "Botswana", 'code' => "267", 'language_code' => "BW"),
                        array('name' => "Benin", 'code' => "229", 'language_code' => "BJ"),
                        array('name' => "Burkina Faso", 'code' => "226", 'language_code' => "BF"),
                        array('name' => "Cameroon", 'code' => "237", 'language_code' => "CM"),
                        array('name' => "Cape Verde", 'code' => "238", 'language_code' => "CV"),
                        array('name' => "Central African Republic", 'code' => "236", 'language_code' => "CF"),
                        array('name' => "Chad", 'code' => "235", 'language_code' => "TD"),
                        array('name' => "Côte d’Ivoire", 'code' => "225", 'language_code' => "CI"),
                        array('name' => "Comoros", 'code' => "269", 'language_code' => "RE"),
                        array('name' => "Congo", 'code' => "243", 'language_code' => " CG"),
                        array('name' => "Democratic Republic of the Congo", 'code' => "243", 'language_code' => "CD"),
                        array('name' => "Djibouti", 'code' => "253", 'language_code' => "DJ"),
                        array('name' => "eSwatini", 'code' => "268", 'language_code' => "SZ"),
                        array('name' => "Ethiopia", 'code' => "251", 'language_code' => "ET"),
                        array('name' => "Eritrea", 'code' => "291", 'language_code' => "ER"),
                        array('name' => "France", 'code' => "33", 'language_code' => "FR"),
                        array('name' => "Gabon", 'code' => "241", 'language_code' => "GA"),
                        array('name' => "Gambia", 'code' => "220", 'language_code' => "GM"),
                        array('name' => "Ghana", 'code' => "233", 'language_code' => "GH"),
                        array('name' => "Guinea", 'code' => "224", 'language_code' => "GN"),
                        array('name' => "Kenya", 'code' => "254", 'language_code' => "KE"),
                        array('name' => "Liberia", 'code' => "231", 'language_code' => "LR"),
                        array('name' => "Libya", 'code' => "218", 'language_code' => "LY"),
                        array('name' => "Lesotho", 'code' => "266", 'language_code' => "LS"),
                        array('name' => "Madagascar", 'code' => "261", 'language_code' => "MG"),
                        array('name' => "Mali", 'code' => "223", 'language_code' => "ML"),
                        array('name' => "Malawi", 'code' => "265", 'language_code' => "MW"),
                        array('name' => "Mauritania", 'code' => "222", 'language_code' => "MR"),
                        array('name' => "Mauritius", 'code' => "230", 'language_code' => "MU"),
                        array('name' => "Morocco", 'code' => "212", 'language_code' => "MA"),
                        array('name' => "Mozambique", 'code' => "258", 'language_code' => "MZ"),
                        array('name' => "South Africa", 'code' => "27", 'language_code' => "ZA"),
                        array('name' => "Namibia", 'code' => "264", 'language_code' => "NA"),
                        array('name' => "Niger", 'code' => "227", 'language_code' => "NE"),
                        array('name' => "Nigeria", 'code' => "234", 'language_code' => "NG"),
                        array('name' => "Réunion", 'code' => "262", 'language_code' => " ZA"),
                        array('name' => "Rwanda", 'code' => "250", 'language_code' => "RW"),
                        array('name' => "Senegal", 'code' => "221", 'language_code' => "SN"),
                        array('name' => "Seychelles", 'code' => "248", 'language_code' => "SC"),
                        array('name' => "Sierra Leone", 'code' => "232", 'language_code' => "SL"),
                        array('name' => "Somalia", 'code' => "252", 'language_code' => "SO"),
                        array('name' => "South Sudan", 'code' => "211", 'language_code' => "SS"),
                        array('name' => "Sudan", 'code' => "211", 'language_code' => "SD"),
                        array('name' => "Tanzania", 'code' => "255", 'language_code' => "TZ"),
                        array('name' => "Togo", 'code' => "228", 'language_code' => "TG"),
                        array('name' => "Tunisia", 'code' => "216", 'language_code' => "TN"),
                        array('name' => "Uganda", 'code' => "256", 'language_code' => "UG"),
                        array('name' => "Zambia", 'code' => "260", 'language_code' => "ZM"),
                        array('name' => "Zimbabwe", 'code' => "263", 'language_code' => "ZW")
                        );
          $languageList =  array(array('code' => $language[0]?$language[0]:""),
                          array('name' => "USA", 'code' => "EN", 'language' => "English"),
                          array('name' => "Cameroon", 'code' => "CM", 'language' => "Bantu"),
                          array('name' => "France", 'code' => "FR", 'language' => "French")
                          );

          
          $data = array('user_id' => $get['ID'],
                      'email' => $get['user_email']?$get['user_email']:"",
                      'phone' => $phone[0]?$phone[0]:"",
                      'first_name' => $first_name[0]?$first_name[0]:"",
                      'last_name' => $last_name[0]?$last_name[0]:"",
                      // 'country' => $country[0]?$country[0]:"",
                      // 'language' => $language[0]?$language[0]:"",

                      'country_list' => $countryList,
                      'language_list' => $languageList,
                      //'Wallet' => $walletData
                    );
        
       

        $resp = Results(200,$data);
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PROFILE*/
  
  /*GET COUNTRY LIST*/
    public function getCountryList_post(){

      $input = $this->param;   
      $required = array('deviceid');
      $Error = check_required_value($required, $input);
      
      if ($Error == "0"){
        
          $countryList =  array(
                          array('name' => "Algeria", 'code' => "213", 'language_code' => "DZ"),
                          array('name' => "Angola", 'code' => "244", 'language_code' => "AO"),
                          array('name' => "Burundi", 'code' => "257", 'language_code' => "BI"),
                          array('name' => "Botswana", 'code' => "267", 'language_code' => "BW"),
                          array('name' => "Benin", 'code' => "229", 'language_code' => "BJ"),
                          array('name' => "Burkina Faso", 'code' => "226", 'language_code' => "BF"),
                          array('name' => "Cameroon", 'code' => "237", 'language_code' => "CM"),
                          array('name' => "Cape Verde", 'code' => "238", 'language_code' => "CV"),
                          array('name' => "Central African Republic", 'code' => "236", 'language_code' => "CF"),
                          array('name' => "Chad", 'code' => "235", 'language_code' => "TD"),
                          array('name' => "Côte d’Ivoire", 'code' => "225", 'language_code' => "CI"),
                          array('name' => "Comoros", 'code' => "269", 'language_code' => "RE"),
                          array('name' => "Congo", 'code' => "243", 'language_code' => " CG"),
                          array('name' => "Democratic Republic of the Congo", 'code' => "243", 'language_code' => "CD"),
                          array('name' => "Djibouti", 'code' => "253", 'language_code' => "DJ"),
                          array('name' => "eSwatini", 'code' => "268", 'language_code' => "SZ"),
                          array('name' => "Ethiopia", 'code' => "251", 'language_code' => "ET"),
                          array('name' => "Eritrea", 'code' => "291", 'language_code' => "ER"),
                          array('name' => "France", 'code' => "33", 'language_code' => "FR"),
                          array('name' => "Gabon", 'code' => "241", 'language_code' => "GA"),
                          array('name' => "Gambia", 'code' => "220", 'language_code' => "GM"),
                          array('name' => "Ghana", 'code' => "233", 'language_code' => "GH"),
                          array('name' => "Guinea", 'code' => "224", 'language_code' => "GN"),
                          array('name' => "Kenya", 'code' => "254", 'language_code' => "KE"),
                          array('name' => "Liberia", 'code' => "231", 'language_code' => "LR"),
                          array('name' => "Libya", 'code' => "218", 'language_code' => "LY"),
                          array('name' => "Lesotho", 'code' => "266", 'language_code' => "LS"),
                          array('name' => "Madagascar", 'code' => "261", 'language_code' => "MG"),
                          array('name' => "Mali", 'code' => "223", 'language_code' => "ML"),
                          array('name' => "Malawi", 'code' => "265", 'language_code' => "MW"),
                          array('name' => "Mauritania", 'code' => "222", 'language_code' => "MR"),
                          array('name' => "Mauritius", 'code' => "230", 'language_code' => "MU"),
                          array('name' => "Morocco", 'code' => "212", 'language_code' => "MA"),
                          array('name' => "Mozambique", 'code' => "258", 'language_code' => "MZ"),
                          array('name' => "South Africa", 'code' => "27", 'language_code' => "ZA"),
                          array('name' => "Namibia", 'code' => "264", 'language_code' => "NA"),
                          array('name' => "Niger", 'code' => "227", 'language_code' => "NE"),
                          array('name' => "Nigeria", 'code' => "234", 'language_code' => "NG"),
                          array('name' => "Réunion", 'code' => "262", 'language_code' => " ZA"),
                          array('name' => "Rwanda", 'code' => "250", 'language_code' => "RW"),
                          array('name' => "Senegal", 'code' => "221", 'language_code' => "SN"),
                          array('name' => "Seychelles", 'code' => "248", 'language_code' => "SC"),
                          array('name' => "Sierra Leone", 'code' => "232", 'language_code' => "SL"),
                          array('name' => "Somalia", 'code' => "252", 'language_code' => "SO"),
                          array('name' => "South Sudan", 'code' => "211", 'language_code' => "SS"),
                          array('name' => "Sudan", 'code' => "211", 'language_code' => "SD"),
                          array('name' => "Tanzania", 'code' => "255", 'language_code' => "TZ"),
                          array('name' => "Togo", 'code' => "228", 'language_code' => "TG"),
                          array('name' => "Tunisia", 'code' => "216", 'language_code' => "TN"),
                          array('name' => "Uganda", 'code' => "256", 'language_code' => "UG"),
                          array('name' => "Zambia", 'code' => "260", 'language_code' => "ZM"),
                          array('name' => "Zimbabwe", 'code' => "263", 'language_code' => "ZW")
                          );
          $languageList =  array(
                          array('name' => "USA", 'code' => "EN", 'language' => "English"),
                          array('name' => "Cameroon", 'code' => "CM", 'language' => "Bantu"),
                          array('name' => "France", 'code' => "FR", 'language' => "French")
                                    );

        
          $data = array('user_id' => '',
                      'email' => '',
                      'phone' => '',
                      'first_name' => '',
                      'country_list' => $countryList,
                      'language_list' => $languageList,
                    );
        

        $resp = Results(200,$data);
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET COUNTRY LIST*/
  
    public function updateProfile_post(){

      $input = $this->param;   
      $required = array('user_id','name','phone','country','language','deviceid');
      $Error = checkvalid($required, $input);
      $imagename ='';
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $phone = $input['phone'];
        $name = $input['name'];
        $exp = explode(" ", $name);
        $first_name = $exp[0];
        $last_name = $exp[1];
        if($_FILES) {
          $config['upload_path'] = './uploads';
          $config['allowed_types'] = 'gif|jpg|png';
          $config['encrypt_name'] = true;   
          //$this->upload->initialize($config);      
          $this->load->library('upload', $config);
          if (!$this->upload->do_upload("image_upload")) { 
             $error = array('error' => $this->upload->display_errors());
          }
          else { 
              $image_name = array('upload_data' => $this->upload->data());
              $imagename = $image_name['upload_data']['file_name'];                  
          }
        } 
        if ($last_name) {
          update_user_meta($user_id,'last_name', $last_name);
        }
        update_user_meta($user_id,'first_name', $first_name);
        update_user_meta($user_id,'diaspo_user_phone', $input['phone']);
        update_user_meta($user_id,'country_flag_code', $input['country']);
        update_user_meta($user_id,'diaspo_user_language', $input['language']);
        update_user_meta($user_id,'profile_image', $imagename);
        //update_user_meta($user_id,'bitcoin_user_address', $input['address']);
        $momonum = get_user_meta($user_id,'diaspo_user_phone',false);
        if ($phone == $momonum) {
          $result = array('user_id' => $user_id, 'phonestatus' => '0', 'phone' => $phone, 'country' => $input['country']);
          $resp = Results(200 ,$result, "Your profile data has been updated successfully");     
        }
        else{

          $OTP = mt_rand(1000, 9999);
        
          $update = update_user_meta( $user_id, 'otp', $OTP); 
          
          $siteurl = get_option('siteurl');
          $toNumber = '+'.$input['country'].$phone;
          $fromNumber = get_option('from_number');
          $messageFormate = get_option('body_message');
          $messageWOTP = $messageFormate.' '.$siteurl.': '.$OTP;
          $this->sendSms($toNumber, $fromNumber, $messageWOTP);
      
          $result = array('user_id' => $user_id, 'phonestatus' => '1', 'phone' => $phone, 'country' => $input['country']);
          $resp = Results(200 ,$result, "Sent OTP in mobile number, Please verify OTP");
        }        

        

      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD OTP VERIFICATION*/
    public function phoneUpdateVerify_post(){
      $input = $this->param;         
      $required = array('user_id','otp', 'phone', 'country');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];
        if ($otp == $input['otp']) {

          update_user_meta($user_id,'diaspo_user_phone', $input['phone']);
          update_user_meta($user_id,'country_flag_code', $input['country']);

          $resp = array('status' => "true", 'message' => "Your profile data has been updated successfully", 'user_id' => (string)$user_id, 'response' => New stdclass);
        }else{
          $resp = array('status' => "false", 'message' => "one time password did not matched", 'user_id' => (string)$user_id, 'response' =>New stdclass);
        }   
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*GET COUNTRY AND LANGUAGE LIST*/
    public function getCountryAndLanguage_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        // $country = all_Data("wp_countries");
        // $language = all_Data("wp_countries", array('active' => 1));
          $result['country'] =  array(array('name' => "English", 'code' => "+27", 'language' => "en"),
                            array('name' => "France", 'code' => "+33", 'language' => "fr")
                            );
          $result['language'] =  array(array('name' => "English", 'code' => "+27"),
                            array('name' => "France", 'code' => "+33")
                            );
          
          $resp = Results(200 ,$result);
          
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }        
    /*LOGOUT*/
    public function logout_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        update_user_meta($user_id,'deviceid', 0);
        $data = UpdateData("wp_users", array('user_status ' => 0), array('ID' => $user_id));
        if ($data) {
          $result = array('data' => $data);  
          $resp = Results(200 ,$result, "successfully Logout"); 
        }
        else{            
          $resp = Results(500 ,$result, "successfully Logout"); 
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*CONVERT BITCOIN*/
    public function convertCurrency_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','amount','currency','change');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $data = get_conversion_bitcoin_with_amount($input['currency'], $input['change'],$input['amount']);
        if ($data) {
          $result = array('value' => (string)$data); 
          $resp = Results(200 ,$result);  
        }
        else{
          $resp = Results(500 ,$result); 
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transaction_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        global $wpdb;
        $user_id = $input['user_id'];
        $all = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' ORDER BY order_id DESC ");
        if($all){
          $Result['all'] = $all;
        }
        else{
          $Result['all'] = "Record Not Found";
        }
        $receive = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND type = 'Buy' AND payment_status = 'completed' ORDER BY order_id DESC ");
        if($receive){
          $Result['recive'] = $receive;
        }
        else{
          $Result['recive'] = [];
        }
        $send = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND type = 'Send' AND btc_status = 'Completed' ORDER BY order_id DESC ");
        if($send){
          $Result['send'] = $send;
        }
        else{
          $Result['send'] = [];
        }
        $resp = Results(200,$Result);
      }
      else{
      $resp = $Error;
      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionRecive_post(){
      global $wpdb;
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $Result = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND type = 'Sell' AND payment_status = 'Completed' ORDER BY order_id DESC ");
        $resp = Results(200,$Result);
      }else{

      $resp = $Error;

      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionSend_post(){
      global $wpdb;
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $Result = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND type = 'Buy' AND payment_status = 'completed' ORDER BY order_id DESC ");
        $resp = Results(200,$Result);
      }
      else{
      $resp = $Error;
      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionAll_post(){
      global $wpdb;
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $Result = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' ORDER BY order_id DESC ");
        $resp = Results(200,$Result);
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*WALLET LIST*/
    public function Wallet_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletList = all_Data("wp_user_wallets", array('user_id' => $user_id, 'status_pass' => '1'));
         
        $momonum = $this->momonum($input['user_id']);
        $Adminmomo = $this->momonum("1");
        if ($walletList) {
          foreach ($walletList as $wallet) {

          $result[] = array('wallet_id' => $wallet['wallet_id'],
                            'blocktrail_public_keys' => $wallet['blocktrail_public_keys'],
                            'wallet_identifier' => $wallet['wallet_identifier'],
                            'status_pass' => $wallet['status_pass'],
                            'momonum' => $momonum,
                            'Adminmomo' => $Adminmomo,
                            );
        }  
          $resp = Results(200 ,$result); 
        }
        else{            
          $resp = Results(200 ,$result, "Wallet not found"); 
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*WALLET LIST*/
    public function momo_post(){

      $input = $this->param;   
      
      if ($input['type'] == "buy"){
        $result = $this->momonum($input['user_id']);

        $resp = Results(200, array('momonum' => $result));
      }else{
        $result = $this->momonum("1");
        $resp = Results(200, array('momonum' => $result));
      }
      $this->response($resp);
    }
    /*RECIVE BITCOIN*/
    public function reciveBitcoin_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $get = all_Data("wp_user_wallets", array('user_id' => $user_id)); 

        $client = $this->client();
        $wallet_password = base64_decode($get[0]['wallet_password']);
        $wallet_identifier = $get[0]['wallet_identifier'];
        
        if(!empty($wallet_identifier)){
          if(!empty($wallet_password)){
            $wallet = $client->initWallet($wallet_identifier, $wallet_password);
            $wallet_address = $wallet->getNewAddress();
            if ($wallet_address) {
              $result = array('adress' => $wallet_address); 
              $resp = Results(200 ,$result,"Success");
            }
            else{
              $resp = Results(0 ,$result,"Wallet Address Not Found"); 
            }
          }
          else{
            $resp = array ('status' => "false" , 'message' => "Please Enter the Wallet Password", 'response' => NULL()); 
          }
        }
        else{
          $resp = Results(0 ,$result,"Please Create Wallet First..");
        }
        
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*CREATE WALLET*/
    public function createWallet_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','identifier','status_pass');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $identifier = $input['identifier'];
        $status_pass = $input['status_pass'];
        if ($status_pass == 1) {          
          $passparse1 = $input['passpharse'];
          $passparse = base64_encode($passparse1);
        }else{
          $passparse1 = "12345678";
          $passparse = base64_encode($passparse1);
        }
        $check = CountData("wp_user_wallets", array('user_id' => $user_id));
        if ($check == 0) {
          $count = CountData("wp_user_wallets", array('wallet_identifier' => $input['identifier'])); 
          if ($count == 0) {
            //Wallet Creation
            $client = $this->client();
            list($wallet, $primaryMnemonic, $backupMnemonic, $blocktrailPublicKeys) = $client->createNewWallet($identifier, $passparse1);
                      
            $newVal = $primaryMnemonic['blocktrail_public_keys'][0];
            /* 04-10-2018 Start*/
            $wallet = $client->initWallet($identifier, $passparse1);
            $wallet_address = $wallet->getNewAddress();
            /* 04-10-2018 End */
            $wallet_id = generate_license();
            $insert = array('user_id' => $user_id,
                            'wallet_identifier' => $identifier,
                            'wallet_password' => $passparse, 
                            'wallet_id' => $wallet_id, 
                            'primaryMnemonic' => json_encode($primaryMnemonic), 
                            'blocktrail_public_keys' => $newVal[0],
                            'status_pass' => 1
                            );
            $insertData = InsertData('wp_user_wallets',$insert);
            if ($insertData) {
              $data = Get_Data('wp_user_wallets', array('id' => $insertData));
            }       
            $resp = array( 'status' => 'true', 'message' => "Wallet created successfully",'response' => array('wallet_address' => $wallet_address, 'user_id'=>$user_id, 'wallet_identifier'=>$identifier, 'wallet_password'=>$passparse1, 'wallet_id'=>$wallet_id, 'primaryMnemonic'=>json_encode($primaryMnemonic), 'blocktrail_public_keys' => $newVal[0], 'status_pass'=> 1));
          }
          else{
            $resp = array( 'status' => 'false', 'message' => "Wallet already exist", 'response' => new stdclass);
          }
        }
        else{
            $resp = array( 'status' => 'false', 'message' => "Wallet already created", 'response' => new stdclass);
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*WALLET BALANCE*/
    public function walletBalance_post() {

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        /* comment for 30-10-2018 Start according to yogesh Sir*/
        $user_number = get_user_meta($user_id,'diaspo_user_mtn_phone',true);
        /* End 30-10-2018 */
        $user_number = get_user_meta($user_id,'diaspo_user_phone',true);
        $country_flag_code = get_user_meta($user_id,'country_flag_code',true);
        $language_code = get_user_meta($user_id,'diaspo_user_language',true);
        $client = $this->client();
        
        try {
          $wallets = $client->allWallets();
          $identif = $this->common_model->getWalletList($user_id);
          $count = (int)$wallets['total']/10;
          $identname = array();            
          for ($i=0; $i <= $count; $i++) { 
            $wallets = $client->allWallets($i+1, 10);
            foreach ($wallets['data'] as $wallet ) {
              if (in_array($wallet['identifier'], $identif)) {
                 $identname[] = array('identifier' => $wallet['identifier'],
                                      'balance' => BlocktrailSDK::toBTC($wallet['balance']),
                                      'amount' => (string)get_conversion_bitcoin_with_amount("BTC", "XAF", BlocktrailSDK::toBTC($wallet['balance']))?:"0.00000000",
                                      'user_number' => (string)$user_number,
                                      'language_code' => $language_code,
                                      'country_flag_code' => $country_flag_code
                                     );
              }              
            }
          }
          $resp = Results(200,$identname, "Success");          
        } 
        catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}")); 
        }          
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*BUY BITCOIN*/
    public function buy_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','xafamount','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $amount = $input['xafamount'];
        $momonum = $this->momonum($user_id);
        $Buyer_name = $this->userName($user_id);
        $data = array('transfer_amount' => $input['xafamount'],
                      'fullname' => $full_name,
                      'senderMsisdn' => $momonum,
                      'user_id' => $user_id
                    );

        $pemfile = $_SERVER['DOCUMENT_ROOT'].'certificates_MTN/client_certnew.pem';        
        $Result = $this->Withdraw($data);
        if($Result['StatusCode'] == 1000){ 
          $current_day = date("Y-m-d H:i:s");      
          $client = $this->client();
          $network =$this->networkFees($client,$walletIdent, $walletPassword, $amount);
       
          $XAF = number_format($amount-$network['our_fees']);

          $amount_paid_btc = convert_exponantial_to_decimal($network['btc']-$network['trade_fees_btc']);

          $btc_amount_to_rec = convert_exponantial_to_decimal($network['btc']-$network['network_fees_in_btc']-$network['trade_fees_btc']);

          $inputs = array('user_id' => $user_id,
                          'type'=> "Buy",                          
                          'recipient_name' => $Buyer_name,
                          'mtn_number' => substr($momonum,3),
                          'amount_in_xaf'=> $amount,
                          'our_fees_in_xaf'=> $network['our_fees'],
                          'total_amount_in_xaf' => $XAF,
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'payment_status' => 'pending',
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $amount_paid_btc,
                          'btc_network' => $network['network_fees_in_btc'],
                          'btc_amount_to_rec' => $btc_amount_to_rec,
                          'btc_status' => "pending",
                          'recipient_address' => $network['address'],
                          'conversion_rate' => $network['rate'],
                          'status_code' =>$Result['StatusCode'],
                          'walletid' => $walletIdent,
                          'OpCoID' => $Result['OpCoID']?$Result['OpCoID']:"",
                          'date_time' => $current_day,
                          'ProcessingNumber' => $Result['ProcessingNumber'],
                          'MOMTransactionID' => $Result['MOMTransactionID']?$Result['MOMTransactionID']:""
                          );
          $order_id = insertData("wp_trade_order_history",$inputs);
          $resp = results(100, array('user_id' => $user_id,'order_id'=>(string)$order_id), "please wait for approved");
        }
        else{
          $Result['user_id'] = $user_id;
          $resp = results(0,$Result, "Rejected");
        }        
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*BUY STATUS GET*/
    public function buyBitcoinAndPayStatus_post(){

        $input = $this->param;   
        $required = array('user_id','deviceid','order_id',);
        $Error = checkvalid($required, $input);
        if ($Error == "0"){
          $user_id = $input['user_id'];
          $order_id = $input['order_id'];
          $deviceid = $input['deviceid'];
          $ProcessingNumber = $input['ProcessingNumber'];

          $orderStatus = Get_Data("wp_trade_order_history", array('order_id' => $order_id));

          if ($orderStatus) {
            $current_day = date("Y-m-d H:i:s");
            $results = array('user_id' => $orderStatus['user_id'],
                            'order_id' => $orderStatus['order_id'],
                            'mtn_number' => $orderStatus['mtn_number'],
                            'type' => $orderStatus['type'],
                            'recipient_name' => $orderStatus['recipient_name'],
                            'amount_in_xaf' => $orderStatus['amount_in_xaf'],
                            'our_fees_in_xaf' => $orderStatus['our_fees_in_xaf'],
                            'network_fees_in_xaf' => $orderStatus['network_fees_in_xaf'],
                            'total_amount_in_xaf' => $orderStatus['total_amount_in_xaf'],
                            'btc_amount_to_rec' => $orderStatus['btc_amount_to_rec'],
                            'conversion_rate' => $orderStatus['conversion_rate'],
                            'payment_status' => $orderStatus['payment_status'],
                            'btc_status' => $orderStatus['btc_status'],
                            'date_time' => $current_day,
                            'ProcessingNumber' => $orderStatus['ProcessingNumber'],
                            'MOMTransactionID' => $orderStatus['MOMTransactionID'],
                            'OpCoID' => $orderStatus['OpCoID']
                           );

            if ($orderStatus['payment_status'] == 'Completed') {
              if ($orderStatus['btc_status'] == 'Completed') {
                 $results['status'] = '2';
                $resp = results(200,$results, 'Transactions successfully');
              }else{
                $results['status'] = '1';
                $resp = results(100,$results, 'Payment Done successfully');
              }
             
            }elseif ($orderStatus['payment_status'] == 'pending') {
              $results['status'] = '0';
              $resp = results(100,$results, 'Wait for approved');
             
            }elseif($orderStatus['payment_status'] == 'Rejected'){
              $results['status'] = '3';
              $resp = results(0,$results, 'Transactions rejected');

            }
          }
        }else{
          $resp = $Error;
        }
        $this->response($resp);
    }
    /*SELL BITCOIN*/
    public function sell_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','xafamount','address','identifier'/*,'payamount','ourfees','netfees','btcamount','momonum','convrate'*/);
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $amount = $input['xafamount'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $sender_name = $this->userName($user_id);
        //$momonum = $this->momonum($user_id);
        $momonum = "237672921262";
        $client = $this->client();
        $network = $this->networkFees($client,$walletIdent, $walletPassword,$amount);
        $wallet = $network['wallet'];
        $XAF = number_format($amount-$network['our_fees']-$network['network_fees_in_xaf']);
        $amount_paid_btc = convert_exponantial_to_decimal($network['btc']-$network['trade_fees_btc']);
        $btc_amount_to_rec = convert_exponantial_to_decimal($network['btc']-$network['network_fees_in_btc']-$network['trade_fees_btc']);
        $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
        $walletPasswordAdmin = get_option('testnet_wallet_password');
        if(!empty($walletIdentAdmin) && !empty($walletPasswordAdmin)){
          $BTCreceiverAddress = $this->AdderssAdmin($client);
        }
        $btc = $network['btc'];
        try {
          $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
          if (!empty($txHash)) { 
            $current_day = date("Y-m-d H:i:s");
            $inputs = array('user_id' => $user_id,
                            'recipient_name' => $sender_name,
                            'mtn_number' => $momonum,
                            'type'=> "Sell",
                            'amount_in_xaf' => $amount,
                            'our_fees_in_xaf' => $network['our_fees'],
                            'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                            'total_amount_in_xaf' => $XAF,
                            'payment_status' => 'pending',
                            'btc_amount' => $network['btc'],
                            'amount_paid_btc' => $amount_paid_btc,
                            'btc_network' => $network['network_fees_in_btc'],
                            'btc_amount_to_rec' => $btc_amount_to_rec,
                            'btc_status' => "Completed",
                            'date_time' => $current_day,
                            'recipient_address' => $BTCreceiverAddress,
                            'transaction_id' => $txHash,
                            'conversion_rate' => $network['rate']
                            );
            $order_id = insertData("wp_trade_order_history",$inputs);  
            $data = array();                 
            $data['order_id'] = $order_id;
            $data['transfer_amount'] = $XAF;
            $data['fullname'] = $sender_name;
            $data['senderMsisdn'] = $momonum;
            $data['user_id'] = $user_id;   
            $response_array = $this->Deposit($data);
            if (!empty($response_array)) {
              $mail = send_mail("Sell Process",array('btc_Response' => $txHash,'mtn_Response'=> $response_array), "test5@kit-services.com,votiveyogesh@gmail.com");
              $StatusCode = $response_array['StatusCode'];
              $StatusDesc = $response_array['StatusDesc'];
              $MOMTransactionID = $response_array['MOMTransactionID'];
              $ProcessingNumber = $response_array['ProcessingNumber'];
              $SenderID = $response_array['SenderID'];
              $MSISDNNum = $response_array['MSISDNNum'];
              $OpCoID = $response_array['OpCoID'];
              $mtn_status = '';
              if($StatusCode == 01){
                $mtn_status = 'completed';
              }
              else{
                $mtn_status = 'rejected';
              }
              $Result = array('status_code' => $StatusCode,
                             'OpCoID' => $OpCoID?$OpCoID:"",
                             'ProcessingNumber' => $ProcessingNumber,
                             'MOMTransactionID' => $MOMTransactionID,
                             'payment_status' => $mtn_status
                            );
              $Update = UpdateData("wp_trade_order_history", $Result, array('order_id' => $order_id));
              if ($response_array['StatusCode'] == 01) {
                $Result['user_id'] = $user_id;
                $Result['order_id'] = (string)$order_id;
                $resp = Results(200, $Result, "Completed");
              }
              else{ 
                $response_array['user_id'] = $user_id;
                $response_array['order_id'] = (string)$order_id;           
                $resp = Results(0, $response_array, "Error");                            
              }     
            }
            else{
              $resp = Results(0, $response_array);            
            }
          }
          else{
            $resp = Results(0, array(), "failed"); 
          }              
        } 
        catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*RECIVE BITCOIN*/
    public function recived_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $mobile = get_user_meta($user_id,'diaspo_user_phone',false);
        $momo = $mobile[0];
        $count_code = get_user_meta( $user_id , 'country_flag_code', true );
        $country_code = $count_code;
        $momonum = $country_code.$momo;
        $client = $this->client();
        try {        
          
          $wallet = $client->initWallet($walletIdent, $walletPassword);
          $address = $wallet->getNewAddress();
          $momonum = $momonum;         
        } catch (Exception $e) {

          $this->response(Results(0,array(),"{$e->getMessage()}"));       
        } 
        $data = array('user_id' => $user_id,
                        'address' => $address,
                        'momonum' => $momonum,
                        'type' => "0"

                        );
        $resp = Results(200,$data);

      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
  
    /*CALCULATION BITCOIN*/    
    public function getCalulationAmount_post(){
      $input = $this->param; 
      $required = array('user_id','deviceid','amount','from_currency','change_currency','type');
      $Error = checkvalid($required, $input);
      //$Error = 0;
      if ($Error == "0"){
        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";
        $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1); 
        //$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
        $btcamountRecieved = get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'], $amount);
        $btc = convert_exponantial_to_decimal($btcamountRecieved);
        $momonum = $this->momonum($user_id);
        $client = $this->client();
        if ($input['type'] == "Buy") {
          if (empty($walletIdent)) {
            $data = array(
                          'btc' => $btc?$btc:"",
                          'our_fees' => $trade_fees?$trade_fees:"",
                          'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                          'rate' => (string)$rate,
                          'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                          'wallet_address' => $address?$address:"",
                          'momonum' => $momonum
                          );
          }
          else{
            $network = $this->networkFees($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC');
            //print_r($network);die();
            $our_fees = $network['our_fees'];
            $trade_fees_btc = $network['trade_fees_btc'];
            $network_fees_in_xaf = $network['network_fees_in_xaf'];
            $network_fees_in_btc = $network['network_fees_in_btc'];
            $address = $network['address'];
            $btc = $network['btc'];
            $rate = $network['rate'];
            $momonum = $this->momonum($user_id);
            $xafFinalAmount = number_format($amount+$our_fees+$network_fees_in_xaf, 2, '.', '');
            $data = array(
                      'btc' => $btc,
                      'our_fees' => $our_fees,
                      'our_fees_btc' => $trade_fees_btc,
                      'network_fees'=> (string)$network_fees_in_xaf,
                      'network_fees_in_btc' => (string)$network_fees_in_btc,
                      'rate' => (string)$rate,
                      'total_amount' => $xafFinalAmount,
                      'wallet_address' => $address,
                      'momonum' => $momonum
                      );
          }
        }
        elseif ($input['type'] == "Sell") {
          $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
          $walletPasswordAdmin = get_option('testnet_wallet_password');
          $btcamountRecieved=get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'],$input['amount']);
          $btc = convert_exponantial_to_decimal($btcamountRecieved);
          /*echo $btc;
          die();*/
          $network = $this->networkFees($client,$walletIdentAdmin, $walletPasswordAdmin, $amount);

          $network_fees_in_xaf = $network['network_fees_in_xaf'];
          $network_fees_in_btc = $network['network_fees_in_btc'];
          $trade_fees_btc = $network['trade_fees_btc'];
          $address = $network['address'];
          //$btc = $network['btc'];
          if(empty($network['btc'])){
            $btc = convert_exponantial_to_decimal($btcamountRecieved);
          }
          else{
            $btc = $network['btc'];
          }
          $our_fees = $network['our_fees'];
          $rate = $network['rate'];
          $xafFinalAmount = number_format($amount-$our_fees-$network_fees_in_xaf, 2, '.', '');
          //$momonum = "237672921262";
          $data = array(
                    'btc' => $btc,
                    'our_fees' => $our_fees,
                    'our_fees_btc' => $trade_fees_btc,
                    'network_fees'=> (string)$network_fees_in_xaf,
                    'network_fees_in_btc' => (string)$network_fees_in_btc,
                    'rate' => (string)$rate,
                    'total_amount' => $xafFinalAmount,
                    'wallet_address' => $address,
                    'momonum' => $momonum
                    );
        }
        elseif ($input['type'] == "Send") {
           $data = array(
                    'btc' => $btc?$btc:"",
                    'our_fees' => $trade_fees?$trade_fees:"",
                    'our_fees_btc' => $trade_fees_btc?$trade_fees_btc:"",
                    'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                    'network_fees_in_btc'=> $network_fees_in_btc?$network_fees_in_btc:"",
                    'rate' => (string)$rate,
                    'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                    'wallet_address' => $address?$address:"",
                    'momonum' => $momonum?$momonum:""
                    );
          
        }
        else{
          $btcamountRecieved=get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'],$input['amount']);
          $btc = convert_exponantial_to_decimal($btcamountRecieved);
          $data = array(
                    'btc' => $btc?$btc:"",
                    'our_fees' => $trade_fees?$trade_fees:"",
                    'our_fees_btc' => $trade_fees_btc?$trade_fees_btc:"",
                    'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                    'network_fees_in_btc'=> $network_fees_in_btc?$network_fees_in_btc:"",
                    'rate' => (string)$rate,
                    'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                    'wallet_address' => $address?$address:"",
                    'momonum' => $momonum?$momonum:""
                    );
        }

        $resp = Results(200 ,$data,"Success");
      }
      else{
        $resp = $Error;
        //print_r($Error);die();
      }
      $this->response($resp);    
    }
    
    /*CALCULATION BITCOIN*/    
    public function calulation_post(){
      $input = $this->param;
      $required = array('user_id','deviceid','amount','from_currency','change_currency');
      $Error = check_required_value($required, $input);
      //print_r($Error);die();
      if ($Error == "0"){
        // $walletIdent = $input['identifier'];
        // $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";
        //$momonum = $this->momonum($user_id);
        //$momonum = "237672921262";

        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);

        $btcamountRecieved = get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'],$input['amount']);


        //$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
        $btc = convert_exponantial_to_decimal($btcamountRecieved);
        //print_r($btc);die;

        $client = $this->client();

        if ($input['type'] == "Sell") {
          
        $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
        $walletPasswordAdmin = get_option('testnet_wallet_password');
        $network = $this->networkFees($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$input['from_currency'], $input['change_currency']);
        

        $our_fees = $network['our_fees'];
        $network_fees_in_xaf = $network['network_fees_in_xaf'];
        $address = $network['address'];
        $btc = $network['btc'];
        $rate = $network['rate'];
        $xafFinalAmount = number_format($amount-$our_fees-$network_fees_in_xaf, 2, '.', '');
        $data = array(
                      'btc' => $btc,
                      'our_fees' => $our_fees,
                      'network_fees'=> (string)$network_fees_in_xaf,
                      'network_fees_btc'=> (string)$network['network_fees_in_btc'],
                      'rate' => (string)$rate,
                      'total_amount' => $xafFinalAmount,
                      'wallet_address' => "",
                      'momonum' => $this->momonum($user_id)
                      );
        }
        else{
          $data = array(
                      'btc' => $btc?$btc:"",
                      'our_fees' => $trade_fees?$trade_fees:"",
                      'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                      'rate' => (string)$rate,
                      'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                      'wallet_address' => $address?$address:"",
                      'momonum' => $this->momonum($user_id)
                      );
        }

        $resp = Results(200 ,$data,"Success");
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);    
    }
    /*SEND BITCOIN CALCULATION*/
    public function sendCalculation_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','identifier','amount');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";
        $client = $this->client();
        $network =$this->networkFees($client, $walletIdent, $walletPassword, $amount);
        $network_fees_in_btc = $network['network_fees_in_btc'];
        $network_fees_in_xaf = $network['network_fees_in_xaf'];
        $address = $network['address'];
        $btc = $network['btc'];
        $rate = $network['rate'];
        $balance = $network['balance'];
        $btcFinalAmount = convert_exponantial_to_decimal($btc-$network_fees_in_btc);
        $data = array(
                        'btc' => $btc,
                        'network_fees'=> (string)$network_fees_in_xaf,
                        'total_amount' => $btcFinalAmount,
                        'wallet_address' => "",
                        'balance_btc' => $balance,
                        'balancexaf' => (string)(get_conversion_bitcoin_with_amount('BTC','XAF',$balance)),
                        'momonum' => $this->momonum($user_id),
                        'rate' => $rate
                        );
        $resp = Results(200 ,$data, "Success");
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*SEND BITCOIN OTP*/
    public function OTPForSend_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $momonum = substr($input['momonum'],3);

        $first_name = get_user_meta($user_id,'first_name',false);
        $last_name = get_user_meta($user_id,'last_name',false);
        $full_name = $first_name[0].' '.$last_name[0];

        //$OTP = 1234;//mt_rand(1000, 9999);
        $OTP = mt_rand(1000, 9999);        
        $Update = update_user_meta( $user_id, 'otp', $OTP);       
        
        $Email = Get_Data("wp_users", array('ID'=> $user_id));
        $email = $Email['user_email'];

        $message1 .= "<html><head><title>Welcome to CodexWorld</title></head><body style='font-family: 'open Sans';font-size: 14px; line-height:20px;'>";
        $message1 .= "<div style='padding: 0 10px;max-width: 670px;margin: 0 auto; background-color: #fff;'>";
        $message1 .= "<div style='max-width:670px;width:100%;margin:0 auto 30px;background: #fff;border:1px solid #ccc;'>";
        $message1 .= "<div style='background: #2B88FF; padding: 15px 40px; margin-bottom: 18px;'>";
        $message1 .= "<div style='width: 88%;display:block;padding: 10px 40px 0px;background: #2B88FF;'>";
        $site_url = site_url();
        $message1 .= "<p style='text-align: center; padding: 5px 0px; margin:0px;'><a href='".$site_url."' target='_blank' style='color: #fff; font-size: 14px; text-transform: uppercase; text-decoration: none;'>";
        $message1 .="<img src='".get_stylesheet_directory_uri()."/img/logo.png' style='max-width: 100px;'/></a></p>";
        $message1 .= "</div>";
        $message1 .= "</div>";
        $message1 .= "<div style='background: #fff;'>";
        $message1 .= "<div style='padding: 0px 40px;'>";
        $message1 .= "<p><strong> ".$full_name."</strong></p>";
        $message1 .= "<p>Your have requested online access to our mobile. We have generated a One-time OTP for you which will verify that you have requested access.</p>";
        $message1 .= "<p><strong> OTP :- ".$OTP."</strong></p>";
        $message1 .= "<p>Please enter this code into the form that you have accessed,and thank you for utilizing our services.</p>";
        $message1 .= "</div>";  
        $message1 .= "<div style='width: 88%;display:block;padding: 10px 40px 0px;background: #2B88FF;'>";
        $site_url = site_url();
        $message1 .= "<p style='text-align: center; padding: 5px 0px; margin:0px;'><a href='".$site_url."' target='_blank' style='color: #fff; font-size: 14px; text-transform: uppercase; text-decoration: none;'>";
        $message1 .="<img src='".get_stylesheet_directory_uri()."/img/logo.png' style='max-width: 100px;'/></a></p>";
        $message1 .= "</div></div></div></div></body></html>";
        //print_r($message1);
        //die();
        $mail = send_mail($message1,"OTP for transaction",$email);
        if(!empty($mail)){
          $resp = Results(200 ,array('user_id' => $user_id), "OTP sent successfully in your registered email."); 
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*SEND BITCOIN OTP VERIFY PROCESS*/
    public function OTPVerifyForSend_post(){

      $input = $this->param;
      $required = array('user_id','deviceid','otp');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];        
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];

        if ($otp == $input['otp']) {

          $resp = Results(200 ,array("user_id" => $user_id), "OTP matched successfully"); 
        }else{
          $resp = Results(0 ,array(), "OTP not matched" ); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    
  /*SEND BITCOIN TO BITCOIN*/
    public function send_post(){

      $input = $this->param;   
      //$required = array('user_id','deviceid','address', 'xafamount','identifier','from_currency','change_currency');
    
      $required = array('user_id','deviceid','address','xafamount','identifier');
      //$Error = checkvalid($required, $input);
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $amount = $input['xafamount'];
        $BTCreceiverAddress = $input['address'];
        $note = $input['note'];
        $datetime = date('Y-m-d h:i:s');
        $Email = Get_Data("wp_users", array('ID'=> $user_id));
        $email = $Email['user_email'];


        $momonum = $this->momonum($user_id);
        $sender_name = $this->userName($user_id);

        $client = $this->client();
        $network =$this->networkFees($client,$walletIdent,$walletPassword,$amount);
        $wallet = $network['wallet']; 
         
        $btc = $network['btc'];
        
        $SendBTC = convert_exponantial_to_decimal($btc-$network['network_fees_in_btc']);
          
        $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
        if (!empty($txHash)) {
          $inputs = array('transaction_id' => $txHash,
                          'user_id' => $user_id,
                          'walletid' => $walletIdent,
                          'recipient_address' => $BTCreceiverAddress,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $input['ourfees'],
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'btc_amount_to_rec' => $SendBTC,
                          'conversion_rate' => $network['rate'],
                          'type'=> "Send",
                          'btc_status' => "Completed",
                          'date_time' => $datetime,
                          'note' => $input['note']
                            );      
          $order_id = insertData("wp_trade_order_history",$inputs);   
          $Result = array('order_id' => (string)$order_id,
                          'transaction_id' => $txHash,
                          );
              
          $mail = send_mail("Send BTC to BTC",array('btc_Response' => $txHash,'order_id'=> $order_id), $email.",votiveyogesh@gmail.com");

          $resp = Results(200 ,$Result, "Success");
        }
        else{
          $inputs = array('transaction_id' =>$txHash?$txHash:"",
                          'user_id' => $user_id,
                          'walletid' => $walletIdent,
                          'recipient_address' => $BTCreceiverAddress,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $input['ourfees'],
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'btc_amount_to_rec' => $SendBTC,
                          'conversion_rate' => $network['rate'],
                          'type'=> "Send",
                          'btc_status' => "Rejected",
                          'note' => $input['note']
                          );      
          $order_id = insertData("wp_trade_order_history",$inputs);
          $Result = array('order_id' => (string)$order_id,
                          'transaction_id' => $txHash?$txHash:"",
                          );
          $mail = send_mail("Send BTC to BTC",array('btc_Response' => 'FAILER','order_id'=> $order_id), "votiveyogesh@gmail.com");             
          $resp = Results(200 ,$Result, "Success");
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
   
   /*SEND BTC TO FIAT*/
    public function sendBTF_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','address','xafamount','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $note = $input['note'];
        $amount = $input['xafamount'];
        $recivermomonum = $input['address'];

        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;

        //$momonum = $this->momonum($user_id);
        $momonum = $input['address'];
        $sender_name = $this->userName($user_id);
        $client = $this->client();

        $network =$this->networkFees($client,$walletIdent, $walletPassword, $amount);
        $totel_Fees = $network['network_fees_in_xaf'];
        $totel_XAF = number_format($amount-$totel_Fees);
        
        $SendBTC = convert_exponantial_to_decimal($btc-$network['network_fees_in_btc']);

        $wallet = $network['wallet'];         
        $btc = $network['btc'];    
        $BTCreceiverAddress = $this->AdderssAdmin($client);
        $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
        if (!empty($txHash)) {
          $inputs = array('user_id' => $user_id,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'type'=> "Send",
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $network['our_fees'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'total_amount_in_xaf' => $totel_XAF,  
                          'payment_status' => 'pending',                        
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'btc_amount_to_rec' => $SendBTC,
                          'btc_status' => "Completed",                          
                          'recipient_momonum' => $BTCreceiverAddress,                         
                          //'recipient_address' => $recivermomonum, 
                          'transaction_id' => $txHash,
                          'conversion_rate' => $network['rate'],
                          'note' => $input['note'],
                          'walletid' => $walletIdent,
                          ); 
          $order_id = insertData("wp_trade_order_history",$inputs);
          $data = array();                 
          $data['order_id'] = $order_id;
          $data['transfer_amount'] = $totel_XAF;
          $data['fullname'] = $sender_name;
          $data['senderMsisdn'] = $momonum;
          $data['user_id'] = $user_id;

          $pay = $this->Deposit($data);

          $mail = send_mail("Send BTC to FIAT",array('btc_Response' => $txHash,'order_id'=> $order_id, 'response' => $pay), "votiveyogesh@gmail.com");

          $Result = array('status_code' => $pay['StatusCode'],
                             'OpCoID' => $pay['OpCoID']?$pay['OpCoID']:"",
                             'ProcessingNumber' => $pay['ProcessingNumber'],
                             'MOMTransactionID' => $pay['MOMTransactionID']
                            );
          $Update =UpdateData("wp_trade_order_history", $Result, array('order_id' => $order_id));

          if ($pay['StatusCode'] == 01) { 

            $results = array('order_id' => (string)$order_id,
                            'transaction_id' => $txHash,
                            'status_code' => $pay['StatusCode'],
                            'OpCoID' => $pay['OpCoID']?$pay['OpCoID']:"",
                            'ProcessingNumber' => $pay['ProcessingNumber'],
                            'MOMTransactionID' => $pay['MOMTransactionID']?$pay['MOMTransactionID']:""
                          );             
            $resp = Results(200 ,$results, "Success");

          }
            else{
            $pay['order_id'] = $order_id; 
            $pay['MOMTransactionID'] = $pay['MOMTransactionID']?$pay['MOMTransactionID']:"";
            $resp = Results(0 ,$pay, "Error");
          }
        }
        else{
          $resp = Results(0 , array(), "Error");
        }
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*Over View in bticoin 01-11-2018 Start*/
    public function overViewBTCold_post(){
       $input = $this->param;
       $required = array('user_id','deviceid','identifier');
       //$Error = checkvalid($required, $input);
       $Error = check_required_value($required, $input);
        if ($Error == "0"){
          $client = $this->client();
          $user_id = $input['user_id'];
          $walletIdent = $input['identifier'];
          $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
          $wallet = $client->initWallet($walletIdent, $walletPassword);
          $todate = strtotime(date($input['to']));
          $fromdate = strtotime(date($input['from']));
          list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
          $tx = $wallet->transactions(1,2);
          $data['total'] = $data['confirmed']+$data['unconfirmed'];
          $data['result'] = $data['total'];
          $data['total'] = $tx['total'];
          $data['per_page'] = $tx['per_page'];
          $data['current_page'] = $tx['current_page'];

          if (!empty($tx)) {
            $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
            for ($i=1; $i < $pages+1; $i++) {
              $txs = $wallet->transactions($i,2,DESC);
              $trax = $txs['data'];
              foreach ($trax as $traxs) {
                $transactions_balance = (string)$traxs['wallet']['balance'];
                if(0 > $transactions_balance){
                  $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                  $data['debit'][] = array(
                                     'hash' => $traxs['hash'],                
                                     'total_fee' => (string)$traxs['total_fee'],
                                     'wallet_value_change' => (string)$traxs['wallet_value_change'],
                                     'previous_balance' => (string)$data['result'],            
                                     'transactions_balance' => (string)$traxs['wallet']['balance'],
                                     'available_balance' => (string)$data['result']+ $traxs['wallet']['balance'],            
                                     'date' => date("Y-m-d", $traxs['time']),
                                     'time' => date("Y-m-d H:i:s", $traxs['time']),
                                     'inputs' => (string)$traxs['inputs'][0]['value'],
                                     'outputs' => (string)$traxs['outputs'][0]['value'],
                                     /*'value1' => $traxs['outputs'][1]['value']?$traxs['outputs'][1]['value']:"",
                                     'address' => $traxs['addresses'],                 
                                     'addresses' => $traxs['wallet']['addresses'],
                                     'time1' => $traxs['time'],*/
                                     );
                }
                else{
                  $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                  $data['credit'][] = array(
                                     'hash' => $traxs['hash'],                
                                     'total_fee' => (string)$traxs['total_fee'],
                                     'wallet_value_change' => (string)$traxs['wallet_value_change'],
                                     'previous_balance' => (string)$data['result'],            
                                     'transactions_balance' => (string)$traxs['wallet']['balance'],
                                     'available_balance' => (string)$data['result']+ $traxs['wallet']['balance'],            
                                     'date' => date("Y-m-d", $traxs['time']),
                                     'time' => date("Y-m-d H:i:s", $traxs['time']),
                                     'inputs' => (string)$traxs['inputs'][0]['value'],
                                     'outputs' => (string)$traxs['outputs'][0]['value'],
                                     /*'value1' => $traxs['outputs'][1]['value']?$traxs['outputs'][1]['value']:"",
                                     'address' => $traxs['addresses'],                 
                                     'addresses' => $traxs['wallet']['addresses'],
                                     'time1' => $traxs['time'],*/
                                     );
                }  
              }
            }
          }
          $resp = Results(200,$data, "Success");
        }
        else{
          $resp = $Error;
        }
        $this->response($resp);      
    }

    /*Over View in bticoin 01-11-2018 End*/

    function getStartAndEndDate($week, $year) {
      $dateTime = new DateTime();
      $dateTime->setISODate($year, $week);
      $result['start_date'] = $dateTime->format('Y-m-d 00:00:00');
      $dateTime->modify('+6 days');
      $result['end_date'] = $dateTime->format('Y-m-d 23:59:59');
      return $result;
    }

    function getMonthStartAndEndDate($month, $year) {
      $dateTime = new DateTime();
      $dateTime->setISODate($year, $month);
      $result['start_date'] = $dateTime->format('Y-m-01 00:00:00');
      $result['end_date'] = $dateTime->format('Y-m-d 23:59:59');
      return $result;

      /*$query_date = '2010-02-04'; // First day of the month. 
      echo date('Y-m-01', strtotime($query_date)); // Last day of the month. 
      echo date('Y-m-t', strtotime($query_date));*/
    }

    public function overViewBTC_post(){

      $input = $this->param;
      $required = array('user_id','deviceid','identifier','type');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){

        $client = $this->client();

        // $add = $client->address("2MwX4yZoZ94dx1LnAesrFE8DBJAz8MpHDRV");
        // print_r($add);die;        
        // $da = $input['from'];
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $wallet = $client->initWallet($walletIdent, $walletPassword);

        $todate = strtotime(date($input['to']));
        $fromdate = strtotime(date($input['from']));

        $type = $input['type'];
        $week = $input['week']?$input['week']:"W";
        $year = $input['year']?$input['week']:"Y-m-d";

        if ($type == 3) {
          $ddate = date("Y-m-d H:i:s");
          $date = new DateTime($ddate);
          $week_num = $date->format($week);
          //$month = $date->format("M");
          $year_num = $date->format($year);                
          $date = $this->getStartAndEndDate($week_num, $year_num);
          $start_date = $date['start_date'];
          $end_date = $date['end_date'];
        }
        elseif ($type == 2) {
          $start_date = date(''.$year.' 00:00:00',strtotime('first day of this month'));
          $end_date = date(''.$year.' 23:59:59',strtotime('last day of this month'));
        }
        elseif ($type == 2) {
          $start_date = date(''.$year.' 00:00:00',strtotime('first day of this month'));
          $end_date = date(''.$year.' 23:59:59',strtotime('last day of this month'));
        }                
        list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
        $tx = $wallet->transactions(1,2);

        //print_r($tx);die;
        $data['total'] = $data['confirmed']+$data['unconfirmed'];
        $data['result'] = $data['total'];
        $data['total'] = $tx['total'];
        $data['per_page'] = $tx['per_page'];
        $data['current_page'] = $tx['current_page'];

        if (!empty($tx)) {
          
          $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
          for ($i=1; $i < $pages+1; $i++) {
            $txs = $wallet->transactions($i,2,DESC);
            $trax = $txs['data'];
            foreach ($trax as $traxs) {
              //print_r($traxs);//die;

              // $date =  date("Y-m-d");
              // $week = (int)date('W', $date);

                // $ddate = date("Y-m-d H:i:s");
                // $date = new DateTime($ddate);
                // $week = $date->format("W");
                // $month = $date->format("M");
                // $year = $date->format("Y");                
                // $weeks = $this->getStartAndEndDate($week, $year);
                //die;

              if ($todate <= $traxs['time'] && $fromdate >= $traxs['time'] ) {
              
                $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                $data['data'][] = array('hash' => $traxs['hash'],                
                                        'total_fee' => $traxs['total_fee'],
                                        'wallet_value_change' => $traxs['wallet_value_change'],
                                        'previous_balance' => $data['result'],            
                                        'transactions_balance' => $traxs['wallet']['balance'],
                                        'available_balance' => $data['result']+ $traxs['wallet']['balance'],            
                                        'date' => date("Y-m-d", $traxs['time']),
                                        'time' => date("Y-m-d H:i:s", $traxs['time']),
                                        // 'value0' => $traxs['outputs'][0]['value'],
                                        // 'value1' => $traxs['outputs'][1]['value']?$traxs['outputs'][1]['value']:"",
                                        // 'address' => $traxs['addresses'],                 
                                        // 'addresses' => $traxs['wallet']['addresses'],
                                        // 'time1' => $traxs['time'],
                                        );
              //print_r($data);die;
              }
            }
          }
        }//die;
        //$result = array_reverse($data);
        $resp = Results(200,$data, "Success");
 
        }else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*Over View in XAF*/
    public function overViewXAF_post(){
      $input = $this->param;
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $result = all_Data('wp_trade_order_history', array('user_id' => $user_id));
        //print_r($result);die;
        $resp = Results(200,$data, "Success");
 
      }else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*SEND FIAT TO FIAT*/
    public function sendFTF_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','address','xafamount');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $note = $input['note'];
        /*Sender momonum*/
        $momonum = $this->momonum($user_id);
        $sender_name = $this->userName($user_id);
        /*Reciver momonum */
        $momoAddress = $input['address'];

        $data = array();
        $data['transfer_amount'] = $input['xafamount'];
        $data['fullname'] = $sender_name;
        $data['senderMsisdn'] = /*$momoAddress;//*/$momonum;
        $data['reciverMsisdn'] = $momoAddress;
        $data['user_id'] = $user_id;

        $pemfile = $_SERVER['DOCUMENT_ROOT'].'certificates_MTN/client_certnew.pem';

        $response_array = $this->common_model->transferBTC($data);

        if ($response_array['StatusCode'] == 1000) {
          $information =array('user_id' => $user_id,
                              'recipient_name' => $sender_name,
                              'mtn_number' => substr($momonum,3),
                              'type'=> "Send",
                              'amount_in_xaf' => $input['xafamount'],         
                              'total_amount_in_xaf' => $input['xafamounts'],             
                              'payment_status' => 'pending',
                              'btc_status' => "pending",
                              'recipient_address' => $momoAddress,             
                              'OpCoID' => $response_array['OpCoID']?$response_array['OpCoID']:"",
                              'ProcessingNumber' => $response_array['ProcessingNumber'],
                              'MOMTransactionID' => $response_array['MOMTransactionID'],
                              //'our_fees_in_xaf' => $input['ourfees'],
                              //'network_fees_in_xaf' => $input['netfees'],
                              //'btc_amount_to_rec' => $input['btcamount'],
                              //'conversion_rate' => $input['convrate'],
                            );          
          $InsertId = insertData("wp_trade_order_history", $information);
          $resp = Results(200, array('order_id' => $InsertId), "Success");
        }
        else{
          $resp = Results(0, $response_array, "Error");
        }
        //print_r($response_array);die;
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*ALL WALLET LIST*/
    public function walletList_post(){

      try {        
        $client = $this->client();
        $wall = $client->allWallets();
        $wallet = $wall['data'];
        
        for ($i=0; $i < count($wallet); $i++) { 
          $wallets[] = array('WalletName' => $wallet[$i]['identifier'],
                            'Santoshi' => $wallet[$i]['balance'],
                            'Bitcoin' =>  BlocktrailSDK::toBTC($wallet[$i]['balance']),
                            'unc_Santoshi' => $wallet[$i]['unc_balance'],
                            'unc_Bitcoin' =>  BlocktrailSDK::toBTC($wallet[$i]['unc_balance']),
                            'tx_count' => $wallet[$i]['tx_cnt'],
                            'unc_tx_count' => $wallet[$i]['unc_tx_cnt']                            
                            );
        }

        $resp = Results(200,$wallets, "Success");

        $this->response($resp);       
      } catch (Exception $e) {

        $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }    
    }
    /*DEMO*/
    public function demo_post(){
      $input = $this->param;
      $txId = $input['id'];
      $client = $this->client();  


      $address = $client->address("2N58JuMDchfiMt3eD4VZJGPZE73qxyWyQSX"); 
      $resp = Results(200,$address,"Success");
      $this->response($resp);      
    }
    /*DEMO*/
    public function demo1_post(){
      $input = $this->param;
      $txId = $input['id'];
      $client = $this->client();      
      

      $tx = $client->addressTransactions("2N58JuMDchfiMt3eD4VZJGPZE73qxyWyQSX");
      
      
      

      $resp = Results(200,$tx, "Success");
      $this->response($resp);      
    }
    /*TEST*/
    public function Test_post(){
      global $wpdb;
      $input = $this->param; 
      $ProcessingNumber = $input['ProcessingNumber'];

      $rowdata = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE ProcessingNumber = '".$ProcessingNumber."'");
      //print_r($rowdata);//die;
      $user_id = $rowdata->user_id;
      //$amount = $rowdata->total_amount_in_xaf;
      $BTCreceiverAddress = $rowdata->recipient_address;
      $btc = $rowdata->amount_paid_btc;

      //Initialize Client
      $myAPIKEY     = get_option('blocktrail_api_key');
      $myAPISECRET  = get_option('blocktrailsecret');
      $testnet      = true;//false for bitcoin mainnet or true for testnet
      // Initialize the SDK
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
      try { 
        $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
        } catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        } catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      } 

      
      try {
        $satoshiamount = BlocktrailSDK::toSatoshi($btc);        
        $outputs = array($BTCreceiverAddress => $satoshiamount);
        
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
        $kb = $result['size']/1000;
        $am = (int)round($kb*$result['fees']['optimal']);      
        $txHash = $wallet->pay($outputs, null, true, true, Wallet::FEE_STRATEGY_OPTIMAL, $am);
        }catch (Exception $e) {

          $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }
      if ($txHash) {
        $Update = $wpdb->query("UPDATE `wp_trade_order_history` SET  transaction_id = '".$txHash."', btc_status = '".Completed."' WHERE ProcessingNumber = '".$ProcessingNumber."'");
      }
      print_r($txHash);
    die;
     


    
      //$user_id = $rowdata->user_id;
    }
  /*______________________________________-Start-______________________*/


    /*CALCULATION BITCOIN*/    
    public function getCalulationAmount1_post(){

      $input = $this->param;

      $required = array('user_id','deviceid','amount','from_currency','change_currency','type');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $amount = $input['amount'];
        $momonum = $this->momonum($user_id);
        $from = $input['from_currency'];
        $to = $input['change_currency'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";

        $client = $this->client();

        if ($from == "XAF" && $to == "BTC") {
        

          if ($input['type'] == "Buy" && !empty($walletIdent) && !empty($walletPassword)) {

            $network = $this->networkFees1($client,$walletIdent, $walletPassword, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
          elseif ($input['type'] == "Sell") {
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees1($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);

            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => $network['address']?$network['address']:"",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
          else{
            
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees1($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => "",
                          'total_amount_btc' => "",
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
        }
        else{
          if ($input['type'] == "Buy" && !empty($walletIdent) && !empty($walletPassword)) {
            $network = $this->networkFees2($client,$walletIdent, $walletPassword, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
          elseif ($input['type'] == "Sell") {
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');
            $network = $this->networkFees2($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => $network['address']?$network['address']:"",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
          else{
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees2($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => "",
                          'total_amount_btc' => "",
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
        }
        $resp = Results(200 ,$data,"Success");
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);    
    }


    private function networkFees1($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC'){

      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);
      $btc = convert_exponantial_to_decimal($btcamountRecieved);

      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      { $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); }

       $trade_fee = get_conversion_bitcoin_with_amount('XAF','BTC', $trade_fees);
       $trade_fees_btc = convert_exponantial_to_decimal($trade_fee);

      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try {
        // Or you can initialize an already existing wallet
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));

        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      $balance = $this->getBalance($wallet);
      $fees = array('xaf'=> $amount,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'btc'=> $btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'our_fees_btc'=> $trade_fees_btc,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );
      return $fees;
    }

    private function networkFees2($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC'){
      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);
      //echo $btc = convert_exponantial_to_decimal($btcamountRecieved);die;
      $btc = $amount;
      $xaf = number_format($btcamountRecieved);
      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees)){
        $trade_fees = number_format(($xaf*$tradeFees)/100, 2, '.', '');
        $trade_fees_btc = convert_exponantial_to_decimal(($amount*$tradeFees)/100); 
      }
      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try {
        // Or you can initialize an already existing wallet
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      $balance = $this->getBalance($wallet);
      $fees = array('xaf'=> $xaf,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'btc'=> $btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'our_fees_btc'=> $trade_fees_btc,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );
      return $fees;
    }



    /* 25-09-2018 Start Bitcoin Wallet Graph */
    public function bitcoinWalletGraph_post(){
      $input = $this->param;
      $required = array('user_id','deviceid','identifier','type');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $client = $this->client();
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $get = all_Data("wp_user_wallets", array('user_id' => $user_id)); 
        $walletPassword = base64_decode($get[0]['wallet_password']);
        //$walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $wallet = $client->initWallet($walletIdent, $walletPassword);
      
        $type = $input['type'];
        $week = $input['week']?$input['week']:"W";
        $year = $input['year']?$input['week']:"Y-m-d";
        
        if ($type == 1) {
          $monday = strtotime("last monday");
          $monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
          $sunday = strtotime(date("Y-m-d",$monday)." +6 days");
          $this_week_sd = date("Y-m-d",$monday);
          $this_week_ed = date("Y-m-d",$sunday);
          $start_date = $this_week_sd;
          $end_date = $this_week_ed;
        }
        elseif ($type == 2) {
          $ddate = date("Y-m-d H:i:s");
          $date = new DateTime($ddate);
          $week_num = $date->format($week);
          $month = $date->format("M");
          $year_num = $date->format($year);                
          $date = $this->getMonthStartAndEndDate($month, $year_num);
          $start_date = $date['start_date'];
          $end_date = $date['end_date'];
        }
        elseif ($type == 3 || $type == '') {
          echo "Please select the Type";
        }             
        list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
        $tx = $wallet->transactions(1,2);
        $data['total'] = $data['confirmed']+$data['unconfirmed'];
        $data['result'] = $data['total'];
        $data['total'] = $tx['total'];
        $data['per_page'] = $tx['per_page'];
        $data['current_page'] = $tx['current_page'];
        if (!empty($tx)) {
          $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
          for ($i=1; $i < $pages+1; $i++) {
            $txs = $wallet->transactions($i,2,DESC);
            $trax = $txs['data'];
            $total_output_value_amout = 0;
            foreach ($trax as $traxs) {
                if ($start_date <= date("Y-m-d H:i:s", $traxs['time']) && $end_date >= date("Y-m-d H:i:s", $traxs['time'])) {
                  $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                  $data['result'] = BlocktrailSDK::toBTC($data['result']);
                  $total_input_value = BlocktrailSDK::toBTC($traxs['total_input_value']);
                  $total_output_value = BlocktrailSDK::toBTC($traxs['total_output_value']);

                  $total_input_value_amout = $total_input_value_amout + $total_input_value;
                  $data['total_input_value_amount'] = (string)$total_input_value_amout;
                  $total_input_value_per = ($data['total_input_value_amount'] * 100 ) / 1;
                  $data['total_input_value_btc_per'] = number_format($total_input_value_per,2);

                  $total_output_value_amounts = $total_output_value_amounts + $total_output_value;
                  $data['total_output_value_amount'] = (string)$total_output_value_amounts;
                  $total_output_value_per = ($data['total_output_value_amount'] * 100 ) / 1;
                  $data['total_output_value_btc_per'] = number_format($total_output_value_per,2);

                  $total_input_value_xaf = get_conversion_bitcoin_with_amount('BTC','XAF', $data['total_input_value_amount']);
                  $data['total_input_value_xaf'] = (string)$total_input_value_xaf;
                  $total_output_value_xaf = get_conversion_bitcoin_with_amount('BTC','XAF', $data['total_output_value_amount']);
                  $data['total_output_value_xaf'] = (string)$total_output_value_xaf;

                  $mydate = date("Y-m-d", $traxs['time']);
                  $data1[$mydate] = $data1[$mydate] + BlocktrailSDK::toBTC($traxs['total_input_value']);
                  $data2[$mydate] = $data2[$mydate] + BlocktrailSDK::toBTC($traxs['total_output_value']);
                }
                else{
                  $data['total_input_value_amount'] = "0";
                  $data['total_input_value_btc_per'] = "0";
                  $data['total_output_value_amount'] = "0";
                  $data['total_output_value_btc_per'] = "0";
                  $data['total_input_value_xaf'] = "0";
                  $data['total_output_value_xaf'] = "0";
                }   
            }
          }
          $j = 0;
          $i = 0;
          foreach ($data1 as $key => $data1value) {
            $data['input_value_in_btc'][$j]['date'] = $key;
            $data['input_value_in_btc'][$j]['value'] = (string)$data1value;
            $j++;
          }
          foreach ($data2 as $keys => $data2value) {
            $data['output_value_in_btc'][$i]['date'] = $keys;
            $data['output_value_in_btc'][$i]['value'] = (string)$data2value;
            $i++;
          }
        }
        $resp = Results(200,$data, "Success");
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /* 25-09-2018 End Bitcoin Wallet Graph */


    /* 26-09-2018 Start Mobile Money Graph */
    public function mobileMoneyGraph_post(){
      $input = $this->param;
      $required = array('user_id','mtn_number','type');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        global $wpdb;
        $client = $this->client();
        $user_id = $input['user_id'];
        $mtn_number = $input['mtn_number'];
        $type = $input['type'];
        if ($type == 1) {
          $monday = strtotime("last monday");
          $monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;
          $sunday = strtotime(date("Y-m-d",$monday)." +6 days");
          $this_week_sd = date("Y-m-d",$monday);
          $this_week_ed = date("Y-m-d",$sunday);
          $start_date = $this_week_sd;
          $end_date = $this_week_ed;
          $sdate = date("Y-m-d",strtotime($start_date));
          $edate = date("Y-m-d",strtotime($end_date));
        }
        elseif ($type == 2) {
          $ddate = date("Y-m-d H:i:s");
          $date = new DateTime($ddate);
          $week_num = $date->format($week);
          $month = $date->format("M");
          $year_num = $date->format($year);                
          $date = $this->getMonthStartAndEndDate($month, $year_num);
          $start_date = $date['start_date'];
          $end_date = $date['end_date'];
          $sdate = date("Y-m-d",strtotime($start_date));
          $edate = date("Y-m-d",strtotime($end_date));
        }
        elseif ($type == 3 || $type == '') {
          echo "Please select the Type";
        }                
        $allorderhistory = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND mtn_number = '".$mtn_number."' AND btc_status = 'Completed' AND (date_time BETWEEN '".$sdate."' AND '".$edate."')");
        $allorderhistory_count = $wpdb->get_var("SELECT COUNT(*) FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' AND mtn_number = '".$mtn_number."' AND (date_time BETWEEN '".$sdate."' AND '".$edate."')");
        $date_time1 = [];
        if (!empty($allorderhistory)) {
          foreach ($allorderhistory as $orderhistory) {
            $date_time = $orderhistory->date_time;
            if ($start_date <= $date_time && $end_date >= $date_time) {
              $order_type = $orderhistory->type;
              if($order_type == "Sell"){
                $total_input_value = $orderhistory->amount_paid_btc;
                $amount_in_xaf = $orderhistory->amount_in_xaf;
                $mydate = date('Y-m-d', strtotime($orderhistory->date_time));
                $sell_total_input_value_in_btc = $sell_total_input_value_in_btc + $total_input_value;
                if(!empty($sell_total_input_value_in_btc)){
                  $data['total_input_value_in_btc'] = (string)$sell_total_input_value_in_btc;
                }
                else{
                  $data['total_input_value_in_btc'] = "0";
                }
                $sell_total_input_value_in_xaf = $sell_total_input_value_in_xaf + $amount_in_xaf;
                if(!empty($sell_total_input_value_in_xaf)){
                  $data['total_input_value_in_xaf'] = (string)number_format($sell_total_input_value_in_xaf,2);
                }
                else{
                  $data['total_input_value_in_xaf'] = "0";
                }
                $total_input_value_per = ( $data['total_input_value_in_btc'] * 100 ) / 1;
                if(!empty($total_input_value_per)){
                  $data['total_input_value_btc_per'] = number_format($total_input_value_per,6);
                }
                else{
                  $data['total_input_value_btc_per'] = "0";
                }
                $data1[$mydate] = $data1[$mydate] + $orderhistory->amount_paid_btc;
              }
              if ($order_type == "Buy") {
                $total_output_value = $orderhistory->amount_paid_btc;
                $amount_in_xaf = $orderhistory->amount_in_xaf;
                $mydate = date('Y-m-d', strtotime($orderhistory->date_time));
                $buy_total_output_value_in_btc = $buy_total_output_value_in_btc + $total_output_value;
                if(!empty($buy_total_output_value_in_btc)){
                  $data['total_output_value_in_btc'] = (string)$buy_total_output_value_in_btc;
                }
                else{
                  $data['total_output_value_in_btc'] = "0";
                }
                $buy_total_output_value_in_xaf = $buy_total_output_value_in_xaf + $amount_in_xaf;
                if(!empty($buy_total_output_value_in_xaf)){
                  $data['total_output_value_in_xaf'] = (string)$buy_total_output_value_in_xaf;
                }
                else{
                  $data['total_output_value_in_xaf'] = "0";
                }
                $total_output_value_per = ( $data['total_output_value_in_btc'] * 100 ) / 1;
                if(!empty($total_output_value_per)){
                  $data['total_output_value_btc_per'] = number_format($total_output_value_per,2);
                }
                else{
                  $data['total_output_value_btc_per'] = "0";
                }
                
                $data2[$mydate] = $data2[$mydate] + $orderhistory->amount_paid_btc;
              }
              else{
                $data['total_output_value_in_btc'] = "0";
                $data['total_output_value_in_xaf'] = "0";
                $data['total_output_value_btc_per'] = "0";
              }
            }
          }
          $j = 0;
          $i = 0;
          if(!empty($data1)){
            foreach ($data1 as $key => $data1value) {
              $data['input_value_in_btc'][$j]['date'] = $key;
              $data['input_value_in_btc'][$j]['value'] = (string)$data1value;
              $j++;
            }
          }
          else{
            $data['input_value_in_btc'][$j]['date'] = "0";
            $data['input_value_in_btc'][$j]['value'] = "0";
          }
          if(!empty($data2)){
            foreach ($data2 as $keys => $data2value) {
              $data['output_value_in_btc'][$i]['date'] = $keys;
              $data['output_value_in_btc'][$i]['value'] = (string)$data2value;
              $i++;
            }
          }
          else{
            $data['output_value_in_btc'][$i]['date'] = "0";
            $data['output_value_in_btc'][$i]['value'] = "0";
          }
          
        }
        $resp = Results(200,$data, "Success");
      }
      else{
       $resp = $Error;
       }
      $this->response($resp);      
    }
    /* 26-09-2018 End Mobile Graph */

    /* 04-10-2018 create backup_recorvery_correct_array web-service Start */
    public function backupRecorveryCorrectArray_post(){
      $input = $this->param;
      $required = array('user_id','wallet_id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $wallet_id = $input['wallet_id'];
        $walletList = all_Data("wp_user_wallets", array('user_id' => $user_id, 'wallet_id' => $wallet_id));
        foreach ($walletList as $walletData) {
          $primaryMnemonic = $walletData['primaryMnemonic'];
          $jsondata['backup_seed_data'] = json_decode($primaryMnemonic);
          for ($j=0; $j < count($jsondata['backup_seed_data']); $j++) { 
              $backup_seed = $jsondata['backup_seed_data']->backup_seed;
          }
          $data = explode(" ",$backup_seed);
        }

        $arr = array();
        $a = count($data);
        $arra = array();
        for ($i=0; $i < count($data); $i++) { 
          $arr['ordering'][] = array("name" => $data[$i]);
           $arra[] = array("name" => $data[$i]);
        }
        shuffle($arra);
        $arr['random'] = $arra;
        $resp = Results(200,$arr, "Success");
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);  
    }

    /* 04-10-2018 create backup_recorvery_correct_array web-service End */
    public function updatePharseVerify_post(){
      $input = $this->param;
      $required = array('user_id','wallet_id','pharse_verify');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $wallet_id = $input['wallet_id'];
        $pharse_verify = $input['pharse_verify'];
        global $wpdb;
        $table_name = $wpdb->prefix . 'user_wallets';
        $dataupdate = $wpdb->query("UPDATE $table_name SET pharse_verify = '".$pharse_verify."' WHERE wallet_id = '".$wallet_id."'");
        if($dataupdate == 1) {
          $resp = array ('status' => "true", 'message' => "Pharse Verify Update successfully", 'response' => array('wallet_id' => $wallet_id));
        }
        else{
          $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());  
        }  
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);  
    }

    public function updatePrivateKeyVerify_post(){
      $input = $this->param;
      $required = array('user_id','wallet_id','private_key_verify');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $wallet_id = $input['wallet_id'];
        $private_key_verify = $input['private_key_verify'];
        global $wpdb;
        $table_name = $wpdb->prefix . 'user_wallets';
        $dataupdates = $wpdb->query("UPDATE $table_name SET private_key_verify = '".$private_key_verify."' WHERE wallet_id = '".$wallet_id."'");
        if($dataupdates == 1) {
          $resp = array ('status' => "true", 'message' => "Private Key Verify Update successfully", 'response' => array('wallet_id' => $wallet_id));
        }
        else{
          $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());  
        }  
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);  
    }



    /* Create New Web-service for our_fee_calculation Start 16-10-2018 Start */
    function ourFeeCalculation_post(){
      $input = $this->param;         
      $required = array ('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $amt = $input['amt'];
        $tradeFees = get_option('trade_fees'); 
        /* $from_number = get_user_meta( $user_id, 'diaspo_user_mtn_phone', true ); */
        $from_number = "+237672921262";    
        if(!empty($tradeFees)){
          if(!empty($amt)){
            $trade_fees = number_format(($amt*$tradeFees)/100, 2, '.', ''); 
            $resp = array ('status' => "true", 'message' => "success", 'response' => array('netourfees' => $trade_fees, 'from_number' => $from_number));
          }
          else{
            $trade_fees = "0.00"; 
            $resp = array ('status' => "true", 'message' => "success", 'response' => array('netourfees' => $trade_fees, 'from_number' => $from_number));
          }  
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp);  
    }
    /* Create New Web-service for our_fee_calculation End 16-10-2018 Start */

    /* Create New Web-service for mobileMoneySend Start 16-10-2018 Start */
    function mobileMoneySend_post(){
      $input = $this->param;         
      $required = array ('user_id','deviceid','transfer_amount','from_number','to_number','our_fees');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $total_amount = 0;
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        //$total_amount = $input['total_amount'];
        $transfer_amount = $input['transfer_amount'];
        $from_number = $input['from_number'];
        $to_number = $input['to_number'];
        $our_fees = $input['our_fees'];
        $total_amount = $transfer_amount + $our_fees;
        $nonce = rand();
        $first_name = get_user_meta( $user_id, 'first_name', true );
        $last_name = get_user_meta( $user_id, 'last_name', true );
        $fullname = $first_name.' '.$last_name;
        $time = date('Y-m-d h:i:s');
        //$senderMsisdn = get_user_meta( $user_id, 'msisdn', true );
        $senderMsisdn = '237672921262';
        $msisdnNo = str_replace('+', '', $to_number);
        $african_mtn_regi_country = get_user_meta( $user_id, 'diaspo_user_country_of_origin', true );
        $sp_id = get_option('sp_id'); 
        $sp_password = get_option('sp_password');
        $testbed_ip = get_option('testbed_ip');
        $service_id = get_option('service_id');
        $country_name = $data['country_name'];
        $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
        date_default_timezone_set('Africa/Douala');
        $createdDate = date('Ymd');
        $createdTime = date('His');
        $created = $createdDate.$createdTime;
        $spID = $sp_id;
        $password = $sp_password;
        $PasswordDigest = md5($spID.$password.$createdDate);
        $euro_trans_amount = get_conversion_bitcoin_with_amount('XAF','EUR', $total_amount);
        $euro_trans_amount = convert_exponantial_to_decimal($euro_trans_amount);
        $digits = 5;
        $payment_id = rand(pow(10, $digits-1), pow(10, $digits)-1);
        $headers = array(
          "Content-type: text/xml;charset=\"utf-8\"",
          "Content-Length:569",
          "Host:127.0.0.1",
          "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
        ); 
        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
          <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
          <soap:Header>
            <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
              <spId>'.$spID.'</spId>
              <spPassword>'.$PasswordDigest.'</spPassword>
              
              <timeStamp>'.$createdDate.'</timeStamp>
            </ns2:RequestSOAPHeader>
          </soap:Header>
          <soap:Body>
            <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
              <serviceId>DiaspoCC</serviceId>
                <parameter>
                  <name>DueAmount</name>
                  <value>'.$total_amount.'</value>
                </parameter>
                <parameter>
                  <name>MSISDNNum</name>
                  <value>'.$senderMsisdn.'</value>
                </parameter>
                <parameter>
                  <name>ProcessingNumber</name>
                  <value>'.$nonce.'</value>
                </parameter>
                <parameter>
                  <name>CurrCode</name>
                  <value>XAF</value>
                </parameter>
                <parameter>
                  <name>SenderID</name>
                  <value>DiaspoCC</value>
                </parameter>
              </ns3:processRequest>
            </soap:Body>
          </soap:Envelope>';
          $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
          $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
          $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
          $certPass = 'ZHDqdw7y243zpDD';
          // PHP cURL  for https connection with auth
          $ch = curl_init();
          //Added on 07.04.17 for logging
          curl_setopt($ch, CURLOPT_VERBOSE, true);
          $curl_log = fopen("curl.txt", 'w+');
          curl_setopt($ch, CURLOPT_STDERR, $curl_log);
          //Logging Partially End
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
          curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);     
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
          curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
          //Added on 10.04.17 for handling error "100-continue"
          curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
          curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
          // converting
          $response = curl_exec($ch);
          curl_close($ch);
          $xml = simplexml_load_string($response);
          $xml_parser = xml_parser_create();
          xml_parse_into_struct($xml_parser, $response, $vals, $index);
          xml_parser_free($xml_parser);
          $arr_name =  array();
          $arr_val =  array();
          $i=0;
          $j = 0;
          foreach ($vals as $key => $value) {
            foreach ($value as $key_1 => $value_val) {
              if($key_1 == "tag" || $key_1 == "value"){
                if($value['tag'] == 'NAME') {
                  $arr_name[$i++] = $value['value'];
                }
                if($value['tag'] == 'VALUE'){
                  $arr_val[$j++] = $value['value'];
                }
              }
            }
          }
          $arr = array_values(array_unique($arr_name));
          $arr1 = array_values(array_unique($arr_val));
          if(count($arr) != count($arr1)){ 
           $arr1[] = '';
          }
          $arr2 = array_combine($arr, $arr1);
          $statusCode = $arr2['StatusCode'];
          $ProcessingNumber = $arr2['ProcessingNumber'];
          $MOMTransactionID = $arr2['MOMTransactionID'];
          $StatusDesc = $arr2['StatusDesc'];
          $SenderID = $arr2['SenderID'];
          $ThirdPartyAcctRef = $arr2['ThirdPartyAcctRef'];
          if($arr2['StatusCode'] == 1000) { 
            $current_day = date("Y-m-d H:i:s");      
            $inputs = array(
                'order_id' => '' ,
                'user_id' => $user_id,
                'payment_transaction_id' => $payment_id ,
                'trans_type' => 'Transfer' ,
                'euro_trans_amount' => $euro_trans_amount,
                'xaf_trans_amount' => $transfer_amount ,
                'trans_fees' => $our_fees,
                'full_name' => $fullname,
                'date_time' => $time,
                'mtn_mobile_number' => $to_number, 
                'african_mtn_regi_country' => $african_mtn_regi_country,
                'partner_mobile_money' => '',
                'payment_status' => 'pending' , 
                'mtn_status' => 'pending', 
                'MOMTransactionID' => $MOMTransactionID,
                'ProcessingNumber' => $ProcessingNumber,
                'SenderID' => $SenderID, 
                'MSISDNNum' => $msisdnNo, 
                'OpCoID' => '', 
                'receipt_link' => '', 
                'status_code' => $statusCode, 
                'error_ticket_id' => '', 
                'sending_reason' => '');     
            $order_id = insertData("wp_mtn_order_history",$inputs);
            $resp = results(100, array('user_id' => $user_id,'order_id'=>(string)$order_id), "Please Wait For Approvel");
          }
          else{
            $Result['user_id'] = $user_id;
            $resp = results(0,$Result, "Rejected");
          }  
        }
        else{
          $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
        }
        $this->response($resp);  
      }

    /* Create New Web-service for our_fee_calculation Start 16-10-2018 Start */


    function mobileMoneySendApproved_post(){
      $input = $this->param;         
        $required = array ('user_id','deviceid', 'order_id');
        $Error = check_required_value($required, $input);
        if ($Error == "0"){
          $user_id = $input['user_id'];
          $deviceid = $input['deviceid'];
          $order_id = $input['order_id'];
          $orderStatus = Get_Data("wp_mtn_order_history", array('order_id' => $order_id));
          $payment_status = $orderStatus['payment_status'];
          if($payment_status == 'Completed'){
            $resp = array ('status' => "true", 'message' => "Transaction Successfully", 'response' => array('approval_status' => '1'));
          }
          elseif($payment_status == 'pending'){
            $resp = array ('status' => "true", 'message' => "Please Wait For Approval", 'response' => array('approval_status' => '0'));
          }
          elseif($payment_status == 'rejected'){
            $resp = array ('status' => "true", 'message' => "Transaction Rejected", 'response' => array('approval_status' => '2'));
          }
          else{
            $resp = array ('status' => "true", 'message' => "Transaction Failed", 'response' => array('approval_status' => '3'));
          }
        }
        else{
          $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
        }
        $this->response($resp); 
    }


    function mobileMoneyTransferStatus_post(){
      $input = $this->param;         
      $required = array ('user_id','deviceid', 'order_id');
      $Error = check_required_value($required, $input);
      global $wpdb;
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $order_id = $input['order_id'];
        $row = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = '".$order_id."'");
        $payment_status = $row->payment_status;
        $mtn_status = $row->mtn_status;
        if($payment_status == 'Completed' && $mtn_status == 'completed'){
          $resp = array ('status' => "true", 'message' => "success", 'response' => array('transfer_status' => 'Money Transfer Successfully..'));
        }
        else{
          $resp = array ('status' => "false", 'message' => "success", 'response' => array('transfer_status' => 'Money Transfer Pending..'));
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp); 
    }


    function mobileMoneyReceive_post(){
      $input = $this->param;         
      $required = array ('user_id','deviceid');
      $Error = check_required_value($required, $input);
      global $wpdb;
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $diaspo_user_mtn_phone = get_user_meta( $user_id, 'country_flag_code', true ).get_user_meta( $user_id, 'diaspo_user_phone', true );
    
        if(!empty($diaspo_user_mtn_phone)){
          $resp = array ('status' => "true", 'message' => "success", 'response' => array('mtn_mobile_number' => (string)$diaspo_user_mtn_phone));
        }
        else{
          $resp = array ('status' => "false", 'message' => "MTN Mobile Number Not Available..", 'response' => array());
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp); 
    }


    function mobileMoneyTransactionHistory_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        global $wpdb;
        $user_id = $input['user_id'];
       // echo "SELECT * FROM wp_mtn_order_history INNER JOIN wp_trade_order_history ON wp_mtn_order_history.user_id = wp_trade_order_history.user_id";
        $all = $wpdb->get_results("SELECT * FROM `wp_mtn_order_history` WHERE user_id = '".$user_id."' ORDER BY order_id DESC ");
        $array2 = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' && type = 'Sell' ORDER BY order_id DESC ");
        //$all = array_merge($array1, $array2); 
        //print_r($res);
        //die();
        
        if($all || $array2 ){
          foreach ($all as $value) {
            $trans_type = $value->trans_type;
            $btc_type = $value->type;
            if($trans_type == "Recharge"){
              $type = "1";
            }
            else{
              $type = "0";
            }
            if($value->mtn_status=='completed' OR $value->mtn_status=='Successfully processed transaction.')
            {
               $st= 2;
            }
            elseif($value->mtn_status=="Transaction couldn't be completed" OR $value->mtn_status=='Deposit Transfer not processed: Own Mobile Account Number entered')
            {
               $st= 1;
            }
            elseif($value->mtn_status=="General failure.")
            {
               $st= 4;
            }
            elseif($value->mtn_status=="pending")
            {
              $st= 3;
            }
            $data['all'][] = array(
                          'full_name' => $value->full_name,
                          'xaf_trans_amount' => $value->xaf_trans_amount,
                          'trans_type' => $value->trans_type,
                          'date_time' => $value->date_time,
                          'mtn_mobile_number' => $value->mtn_mobile_number,
                          'payment_status' => $value->payment_status,
                          'mtn_status' =>$st,
                          'btc_type' => $btc_type,
                          'btc_amount_to_rec' => $btc_amount_to_rec,
                          'type' => $type,
                          'confirmations_status'=>0,
                        );
          }
          $Result['all'] = $data['all'];

          if (count($array2) > 0) {
             foreach ($array2 as $value1) {

                if($value1->payment_status=='completed' OR $value1->payment_status=='Successfully processed transaction.')
            {
               $st1= 2;
            }
            elseif($value1->payment_status=="Transaction couldn't be completed" OR $value1->payment_status=='Deposit Transfer not processed: Own Mobile Account Number entered')
            {
               $st1= 1;
            }
            elseif($value1->payment_status=="General failure.")
            {
               $st1= 4;
            }
            elseif($value1->payment_status=="pending")
            {
              $st1= 3;
            }
              $data1['all'][] = array(
                          'full_name' => $value1->recipient_name,
                          'xaf_trans_amount' => $value1->amount_in_xaf,
                          'trans_type' => $value1->type,
                          'date_time' => $value1->date_time,
                          'mtn_mobile_number' => $value1->mtn_number,
                          'payment_status' => $value1->btc_status,
                          'mtn_status' => $st1,
                          'type' => "1",
                           'confirmations_status'=>0,
                        );
            }
            $Result['all'] = $data1['all'];
          }
        }
        else{
          $Result['all'] = [];
        }
        $receive = $wpdb->get_results("SELECT * FROM `wp_mtn_order_history` WHERE user_id = '".$user_id."' AND trans_type = 'Recharge' AND payment_status = 'Completed' ORDER BY order_id DESC ");
         $receive1 = $wpdb->get_results("SELECT * FROM `wp_trade_order_history` WHERE user_id = '".$user_id."' && type = 'Sell' && btc_status = 'Completed' ORDER BY order_id DESC ");
         //print_r($receive1); die();
        if($receive || $receive1 ){
          foreach ($receive as $receive_value) {
            $trans_type = $receive_value->trans_type;
            if($trans_type == "Recharge"){
              $type = "1";
            }
            else{
              $type = "0";
            }

            if($receive_value->mtn_status=='completed' OR $receive_value->mtn_status=='Successfully processed transaction.')
            {
               $st= 2;
            }
            elseif($receive_value->mtn_status=="Transaction couldn't be completed" OR $receive_value->mtn_status=='Deposit Transfer not processed: Own Mobile Account Number entered')
            {
               $st= 1;
            }
            elseif($receive_value->mtn_status=="General failure.")
            {
               $st= 4;
            }
            elseif($receive_value->mtn_status=="pending")
            {
              $st= 3;
            }
            $data['recive'][] = array(
                          'full_name' => $receive_value->full_name,
                          'xaf_trans_amount' => $receive_value->xaf_trans_amount,
                          'trans_type' => $receive_value->trans_type,
                          'date_time' => $receive_value->date_time,
                          'mtn_mobile_number' => $receive_value->mtn_mobile_number,
                          'payment_status' => $receive_value->payment_status,
                          'mtn_status' => $receive_value->mtn_status,
                          'type' => $type,
                           'confirmations_status'=>0,
                        ); 
          }
          $Result['recive'] = $data['recive'];
          if (count($receive1) > 0) {
            foreach ($receive1 as $values) {

                if($values->payment_status=='completed' OR $values->payment_status=='Successfully processed transaction.')
            {
               $st1= 2;
            }
            elseif($values->payment_status=="Transaction couldn't be completed" OR $values->payment_status=='Deposit Transfer not processed: Own Mobile Account Number entered')
            {
               $st1= 1;
            }
            elseif($values->payment_status=="General failure.")
            {
               $st1= 4;
            }
            elseif($values->payment_status=="pending")
            {
              $st1= 3;
            }
              $data1['recive'][] = array(
                          'full_name' => $values->recipient_name,
                          'xaf_trans_amount' => $values->amount_in_xaf,
                          'trans_type' => $values->type,
                          'date_time' => $values->date_time,
                          'mtn_mobile_number' => $values->mtn_number,
                          'payment_status' => $values->btc_status,
                          'mtn_status' => $st1,
                          'type' => "1",
                           'confirmations_status'=>0,
                        );
            }
            $Result['recive'] = $data1['recive'];
          }
         

          



        }
        else{
          $Result['recive'] = [];
        }
        $send = $wpdb->get_results("SELECT * FROM `wp_mtn_order_history` WHERE user_id = '".$user_id."' AND trans_type = 'Transfer' AND payment_status = 'Completed' ORDER BY order_id DESC ");
        if($send){
          foreach ($send as $send_value) {
            $trans_type = $send_value->trans_type;
            if($trans_type == "Recharge"){
              $type = "1";
            }
            else{
              $type = "0";
            }
             if($send_value->mtn_status=='completed' OR $send_value->mtn_status=='Successfully processed transaction.')
            {
               $st= 2;
            }
            elseif($send_value->mtn_status=="Transaction couldn't be completed" OR $send_value->mtn_status=='Deposit Transfer not processed: Own Mobile Account Number entered')
            {
               $st= 1;
            }
            elseif($send_value->mtn_status=="General failure.")
            {
               $st= 4;
            }
            elseif($send_value->mtn_status=="pending")
            {
              $st= 3;
            }
            $data['send'][] = array(
                          'full_name' => $send_value->full_name,
                          'xaf_trans_amount' => $send_value->xaf_trans_amount,
                          'trans_type' => $send_value->trans_type,
                          'date_time' => $send_value->date_time,
                          'mtn_mobile_number' => $send_value->mtn_mobile_number,
                          'payment_status' => $send_value->payment_status,
                          'mtn_status' => $st,
                          'type' => $type,
                           'confirmations_status'=>0,
                        );
            
          }
          $Result['send'] = $data['send'];
        }
        else{
          $Result['send'] = [];
        }
        $resp = Results(200,$Result);
      }
      else{
        $resp = $Error;
      }
      $this->response($resp); 
    }


    function getQRCodeBTC_post(){
      $input = $this->param;         
      $required = array ('user_id','deviceid','amount','address');
      $Error = check_required_value($required, $input);
      global $wpdb;
      if ($Error == "0"){

        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $amount = $input['amount'];
        $address = $input['address'];
        $amount = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
        $btc = convert_exponantial_to_decimal($amount);
        $data = 'bitcoin:'.$address.'?amount='.$btc.'';
        if(!empty($data)){
          $resp = array ('status' => "true", 'message' => "success", 'response' => array('data' => (string)$data));
        }
        else{
          $resp = array ('status' => "false", 'message' => "success", 'response' => array('data' => 'Data Not Availabel..'));
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp); 
    }

    function getQRCodeMTN_post(){
    
    
    global $wpdb;
      $input = $this->param;         
      $required = array ('user_id','deviceid','amount','mobile_numner');
      $Error = check_required_value($required, $input);
      
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $amount = $input['amount'];
        $mobile_numner = $input['mobile_numner'];
        $data = 'msisdn:'.$mobile_numner.'?amount_xaf='.$amount.'';
        if(!empty($data)){
          $resp = array ('status' => "true", 'message' => "success", 'response' => array('data' => (string)$data));
        }
        else{
          $resp = array ('status' => "false", 'message' => "success", 'response' => array('data' => 'Data Not Availabel..'));
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp); 
    }



    /* getTransactionHistory  01-11-2018 Start*/
    public function getTransactionHistory_post(){
       $input = $this->param;
       $required = array('user_id','deviceid');
       //$Error = checkvalid($required, $input);
       $Error = check_required_value($required, $input);
        if ($Error == "0"){
          $client = $this->client();
          $user_id = $input['user_id'];
          $deviceid = $input['deviceid'];
          $get = all_Data("wp_user_wallets", array('user_id' => $user_id)); 
          $walletPassword = base64_decode($get[0]['wallet_password']);
          $identifier = $get[0]['wallet_identifier'];
          $wallet = $client->initWallet($identifier, $walletPassword);
          $todate = strtotime(date($input['to']));
          $fromdate = strtotime(date($input['from']));
          list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
          $tx = $wallet->transactions(1,2);
          $data['total'] = $data['confirmed']+$data['unconfirmed'];
          $data['result'] = $data['total'];
          $data['total'] = $tx['total'];
          $data['per_page'] = $tx['per_page'];
          $data['current_page'] = $tx['current_page'];
          if (!empty($tx)) {
            $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
            for ($i=1; $i < $pages+1; $i++) {
              $txs = $wallet->transactions($i,2,DESC);
              $trax = $txs['data'];
              foreach ($trax as $traxs) {
                $transactions_balance = (string)$traxs['wallet']['balance'];
                if(0 > $transactions_balance){
                  $type = "0";
                }
                else{
                  $type = "1";
                }
                $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                $available_balance = $data['result'] + (string)$traxs['wallet']['balance'];

                /* 16-11-2018 Start */

                /* 16-11-2018 End*/
                $data['all'][] = array(
                                     'hash' => $traxs['hash'],                
                                     'total_fee' => (string)$traxs['total_fee'],
                                     'wallet_value_change' => (string)$traxs['wallet_value_change'],
                                     'previous_balance' => (string)$data['result'],            
                                     'transactions_balance' => (string)$traxs['wallet']['balance'],
                                     'available_balance' => (string)$available_balance,            
                                     'date' => date("Y-m-d", $traxs['time']),
                                     'time' => date("Y-m-d H:i:s", $traxs['time']),
                                     'inputs' => (string)$traxs['inputs'][0]['value'],
                                     'outputs' => (string)$traxs['outputs'][0]['value'],
                                     'type' => $type,
                                     'confirmations_status' => (string)$traxs['confirmations'],
                                     );
                if(0 > $transactions_balance){
                  $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                  $available_balance = $data['result'] + (string)$traxs['wallet']['balance'];
                  $data['debit'][] = array(
                                     'hash' => $traxs['hash'],                
                                     'total_fee' => (string)$traxs['total_fee'],
                                     'wallet_value_change' => (string)$traxs['wallet_value_change'],
                                     'previous_balance' => (string)$data['result'],            
                                     'transactions_balance' => (string)$traxs['wallet']['balance'],
                                     'available_balance' => (string)$available_balance,            
                                     'date' => date("Y-m-d", $traxs['time']),
                                     'time' => date("Y-m-d H:i:s", $traxs['time']),
                                     'inputs' => (string)$traxs['inputs'][0]['value'],
                                     'outputs' => (string)$traxs['outputs'][0]['value'],
                                     'type' => "0",
                                     'confirmations_status' => (string)$traxs['confirmations'],
                                     );
                }
                else{
                  $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                  $available_balance = $data['result'] + (string)$traxs['wallet']['balance'];
                  $data['credit'][] = array(
                                     'hash' => $traxs['hash'],                
                                     'total_fee' => (string)$traxs['total_fee'],
                                     'wallet_value_change' => (string)$traxs['wallet_value_change'],
                                     'previous_balance' => (string)$data['result'],            
                                     'transactions_balance' => (string)$traxs['wallet']['balance'],
                                     'available_balance' => (string)$available_balance,            
                                     'date' => date("Y-m-d", $traxs['time']),
                                     'time' => date("Y-m-d H:i:s", $traxs['time']),
                                     'inputs' => (string)$traxs['inputs'][0]['value'],
                                     'outputs' => (string)$traxs['outputs'][0]['value'],
                                     'type' => "1",
                                     'confirmations_status' => (string)$traxs['confirmations'],
                                     );
                }  
              }
            }
          }
          $resp = Results(200,$data, "Success");
        }
        else{
          $resp = $Error;
        }
        $this->response($resp);      
    }

    /*getTransactionHistory 01-11-2018 End*/

    /* Create New Web-Service sendConversionFees */
    public function sendConversionFees_post(){
    
    global $wpdb;
      $input = $this->param;         
      $required = array ('user_id','deviceid','identifier','amount','from_currency','change_currency');
      $Error = check_required_value($required, $input);
      
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $deviceid = $input['deviceid'];
        $amount = $input['amount'];
        $identifier = $input['identifier'];
        $from = $input['from_currency'];
        $to = $input['change_currency'];
        $method_type = $input['method_type'];
        $get = all_Data("wp_user_wallets", array('wallet_identifier' => $identifier)); 
        $client = $this->client();
        $wallet_password = base64_decode($get[0]['wallet_password']);
        $wallet_identifier = $get[0]['wallet_identifier'];
        $mobile_number = get_user_meta( $user_id, 'diaspo_user_phone', true );
        $country_code = get_user_meta( $user_id, 'country_flag_code', true );
        if(!empty($wallet_identifier)){
          if(!empty($wallet_password)){
            $network = $this->networkFees($client,$wallet_identifier, $wallet_password, $amount, $from, $to);
            $rate = $network['rate'];
            $btc_amount = $network['btc'];
            $network_fees_in_btc = $network['network_fees_in_btc'];
            if($from == "BTC"){
              $amount1 = get_conversion_bitcoin_with_amount('BTC', 'XAF', $amount);
              $xaf_amount = convert_exponantial_to_decimal($amount1);
            }
            else{
              $xaf_amount = $amount;
            }
            $xafFinalAmount = number_format($xaf_amount+$network['our_fees']+$network_fees_in_btc, 2, '.', '');
            if($method_type == "Sell"){
              global $wpdb;
              $fees = '';
              $rate = get_option('currency_coversion_rate');
              $euroAmount = number_format($xaf_amount/$rate, 2, '.', '');
              $recharge_fees = $wpdb->get_row("SELECT recharge_fees FROM `wp_add_fees_recharge` WHERE ( amount_in_min <= '".$euroAmount."' AND amount_in_max >= '".$euroAmount."' )");
              if(!empty($recharge_fees->recharge_fees)){
                $fees = $recharge_fees->recharge_fees;
                $xaf_fees = number_format($fees * $rate, 2, '.', '');
              }
              else{
                $newfees = $wpdb->get_row("SELECT MAX(recharge_fees) AS extra_fees FROM `wp_add_fees_recharge`");
                $fees = $newfees->extra_fees;
                $xaf_fees = number_format($fees * $rate, 2, '.', '');
              }
              $data = array(
                'btc_amount' => $network['btc'], 
                'network_fees_in_btc' => $network['network_fees_in_btc'], 
                'network_fees_in_xaf' => $network['network_fees_in_xaf'], 
                'our_fees' => $xaf_fees,
                'wallet_address' => $network['address'],
                'wallet_password' => $wallet_password,
                'mobile_number' => $mobile_number,
                'xaf_amount' => $xaf_amount,
                'btc' => $network['btc'],
                'rate' => (string)$rate,
                'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                'country_code' => $country_code
              );
            }
            else{
              $data = array(
                'btc_amount' => $network['btc'], 
                'network_fees_in_btc' => $network['network_fees_in_btc'], 
                'network_fees_in_xaf' => $network['network_fees_in_xaf'], 
                'our_fees' => $network['our_fees'],
                'wallet_address' => $network['address'],
                'wallet_password' => $wallet_password,
                'mobile_number' => $mobile_number,
                'xaf_amount' => $xaf_amount,
                'btc' => $network['btc'],
                'rate' => (string)$rate,
                'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                'country_code' => $country_code
              );
            }
            $resp = array ('status' => "true", 'message' => "success", 'response' => $data);
          }
          else{
            $resp = array ('status' => "false" , 'message' => "Please Enter the Wallet Password", 'response' => NULL()); 
          }
        }
        else{
          $resp = Results(0 ,$result,"Please Create Wallet First..");
        }
      }
      else{
        $resp = array ('status' => "false" , 'message' => "Data not found", 'response' => NULL());
      }
      $this->response($resp);
    }
  
  
  /*Start--------SendSMS via Twillo API*/
  private function sendSms($to, $from, $body){
  
  $account_sid_live = get_option('account_sid_live');
  $auth_token_live = get_option('auth_token_live');
  $xmlpost = [
    "To" => $to,
  "From" => $from,
  "Body" => $body
  ];
  $cpt = curl_init("https://api.twilio.com/2010-04-01/Accounts/".$account_sid_live."/Messages.xml");
  curl_setopt_array($cpt, [
  CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_USERPWD => $account_sid_live.':'.$auth_token_live,
  CURLOPT_POSTFIELDS => http_build_query($xmlpost),
  ]);

  $result = curl_exec($cpt);

  curl_close($cpt);

        //print_r($response);
        $xml = simplexml_load_string($result);
        $json = json_encode($xml);
        $arr = json_decode($json,true);
        //print_r($arr);
    
  }
    /*END-------SendSMS via Twillo API*/




    public function mailChecker_post(){
      $input = $this->param;         
      $required = array('user_id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){       
        $user_id = $input['user_id'];
        //$OTP = 1234;//mt_rand(1000, 9999);
        $OTP = mt_rand(1000, 9999);
        $update = update_user_meta( $user_id, 'otp', $OTP); 
        $Email = Get_Data("wp_users", array('ID'=> $user_id));
        $email = $Email['user_email'];
        $mail = send_mail("Message Area: ","My Subject","votivewp.awadhesh@gmail.com");
        if(!empty($mail)){
          echo "Mail successfully";
        } 
        else{
          echo "Mail Not Successfully";
        }  
        
      }
      else{
        $resp = $Error;
      }
      $this->response($resp); 
    }




    /*mobile OTP For Send*/
    public function mobileOTPForSend_post(){
      $input = $this->param;   
      $required = array('user_id','deviceid','phone','country_code');
      $Error = check_required_value($required, $input);
      if($Error == "0"){
        $user_id = $input['user_id'];
        $phone =   $input['phone'];
        $OTP = mt_rand(1000, 9999);
        $update = update_user_meta( $user_id, 'otp', $OTP); 
        $siteurl = get_option('siteurl');
        $toNumber = '+'.$input['country_code'].$phone;
        $fromNumber = get_option('from_number');
        $messageFormate = get_option('body_message');
        $messageWOTP = $messageFormate.' '.$siteurl.': '.$OTP;
        $this->sendSms($toNumber, $fromNumber, $messageWOTP);
        $result = array('user_id' => $user_id, 'phone' => $phone, 'country_code' => $input['country_code']);
        $resp = Results(200 ,$result, "Sent OTP in mobile number, Please verify OTP");
      }
      else{
        $resp = $Error;
      }
      $this->response($resp);
    }




}