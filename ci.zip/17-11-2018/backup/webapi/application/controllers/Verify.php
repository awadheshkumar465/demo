<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Verify extends CI_Controller 
{
    function __construct(){
    parent::__construct();
	}

	    /*OTP VERIFICATION*/
    public function signupEmailVerify(){
        	
        //echo $Key =  $this->uri->segment(2);
        get_header();
        $Key =  $this->uri->segment(3);
        $serch = Get_Data('wp_usermeta', array('meta_value' => $Key));
        $user_id = $serch['user_id'];
        update_user_meta( $user_id, 'diaspo_user_status', 'active'); ?>
        <section id="error" class="container">
        <h1>User Activation Link</h1>
        <p><?php echo "Your account has been activated successfully. Please Go to Login Page"; ?></p>
        </section>
        <style type="text/css">
            #error {
                text-align: center;
                margin-top: 150px;
                margin-bottom: 150px;
            }
            
        </style>
        <?php 
        
        //$resp = array('status' => "true", 'message' => "Your mobile number has been verified successfully", 'response' => array('user_id' => (string)$user_id));
        get_footer();
    }

}
?>