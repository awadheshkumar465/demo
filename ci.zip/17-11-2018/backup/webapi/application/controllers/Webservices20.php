<?php defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require $_SERVER['DOCUMENT_ROOT'].'/blocktrail/vendor/autoload.php';
use Blocktrail\SDK\BlocktrailSDK;
use Blocktrail\SDK\Wallet;
use Blocktrail\SDK\WalletInterface;
use Blocktrail\SDK\Connection\Exceptions\ObjectNotFound;
use Blocktrail\SDK\Services\BlocktrailBatchUnspentOutputFinder;
use Blocktrail\SDK\WalletV1Sweeper;

class Webservices extends REST_Controller 
{  
  public function __construct() {
    date_default_timezone_set('Asia/Kolkata');
    parent:: __construct();
    $this->param = Request();
  }
  /*__________________________________-PRIVATE-END-_______________________*/
    private function client(){

      //Initialize Client
      $myAPIKEY     = get_option('blocktrail_api_key');
      $myAPISECRET  = get_option('blocktrailsecret');
      $testnet      = true;//false for bitcoin mainnet or true for testnet
      // Initialize the SDK
      try { 
        $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
      } catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      return $client;
    }
    private function walletAdmin($client){

      //Wallet Creation 

      $testnet        = true; //false for bitcoin mainnet or true for testnet
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
   
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }       
        return $wallet;
    }
    private function ourFees($amount){
      
      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      { 
        $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); 
      }
            
      return $trade_fees;
    }
    private function AdderssAdmin($client){

      //Wallet Creation 

      $testnet        = true; //false for bitcoin mainnet or true for testnet
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
   
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        $address = $wallet->getNewAddress(); 
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }       
        return $address;
    }
    private function getBalance($wallet){    

      list($confirmed, $unconfirmed) = $wallet->getBalance();

      $confirmedbtc = BlocktrailSDK::toBTC($confirmed);
      $unconfirmedbtc = BlocktrailSDK::toBTC($unconfirmed);

      $balance = array('santoshi' => $confirmed,
                       'btc'=> $confirmedbtc,
                       'unsantoshi' => $unconfirmed,
                       'unbtc'=> $unconfirmedbtc,
                      );

      //$balance = $wallet->getBalance();
      return $balance;
    }
    private function networkFees($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC'){

      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);
      $btc = convert_exponantial_to_decimal($btcamountRecieved);

      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      { $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); }

       $trade_fee = get_conversion_bitcoin_with_amount('XAF','BTC', $trade_fees);
       $trade_fees_btc = convert_exponantial_to_decimal($trade_fee);

      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try {
        // Or you can initialize an already existing wallet
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));

        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      $balance = $this->getBalance($wallet);
      
      $fees = array('btc'=>$btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'trade_fees_btc'=> $trade_fees_btc,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );

      
      return $fees;
    }

    
    private function pay($wallet,$BTCreceiverAddress,$btc){

      try {
        $satoshiamount = BlocktrailSDK::toSatoshi($btc);        
        $outputs = array($BTCreceiverAddress => $satoshiamount);
        
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
        $kb = $result['size']/1000;
        $am = (int)round($kb*$result['fees']['optimal']);      
        $txHash = $wallet->pay($outputs, null, true, true, Wallet::FEE_STRATEGY_OPTIMAL, $am);
        }catch (Exception $e) {

          $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }
      return $txHash;
    }
    private function Withdraw($data){
      
      global $wpdb;
      date_default_timezone_set('Africa/Douala');
      $user_id = $data['user_id'];
      $time = date('Y-m-d h:i:s');
      $nonce = rand();
      $currency_type_amount = $data['transfer_amount'];
      $fullname = $data['fullname'];
      $senderMsisdn = $data['senderMsisdn'];
      $sp_id = get_option('sp_id');
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip');
      $service_id = get_option('service_id');
      //$country_name = $data['country_name'];

      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
     
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;     
      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
      <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
      <spId>'.$spID.'</spId>
      <spPassword>'.$PasswordDigest.'</spPassword>

      <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
      </soap:Header>
      <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
      <serviceId>DiaspoCC</serviceId>
      <parameter>
      <name>DueAmount</name>
      <value>'.$currency_type_amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$senderMsisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>CurrCode</name>
      <value>XAF</value>
      </parameter>
      <parameter>
      <name>SenderID</name>
      <value>DiaspoCC</value>
      </parameter>
      </ns3:processRequest>
      </soap:Body>
      </soap:Envelope>';

      $to = "test5@kit-services.com,votiveyogesh@gmail.com,votivephp.prashant@gmail.com";
      $subject = "TESTBED URL - Send Request";
      $txt = $xml_post_string;
      $headers = "From: info@diaspo-cc.com," . "\r\n";
      mail($to,$subject,$txt,$headers);

      $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';

      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME') {
              $arr_name[$i++] = $value['value'];
            }
            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));

      if(count($arr) != count($arr1))
      { 
        $arr1[] = '';
      }
      $arr2 = array_combine($arr, $arr1);

      return $arr2;
    }
    private function Deposit($data){

      global $wpdb;
      $user_id = $data['user_id'];
      $msisdn =  $data['senderMsisdn'];
      $fullname = $data['fullname'];
      $amount = $data['transfer_amount'];
      $order_id = $data['order_id'];

     
      
      
      // $rowdata = get_user_meta( $user_id , 'diaspo_user_phone', true );
      // $country_code = get_user_meta( $user_id , 'country_flag_code', true );
      // $msisdn = $country_code.$rowdata;
      $Narration = '';
      $left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
      $lang = get_user_meta( $user_id, 'diaspo_user_language', true );
      $message = '';
      $subject = ''; 
      $user_info = get_userdata($user_id);
      $to = $user_info->user_email;
      
      $sp_id = get_option('sp_id'); 
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip'); 
      $service_id = get_option('service_id');
            
      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17";

      $nonce = rand();
      $rand = rand(3, 4);
      date_default_timezone_set('Africa/Douala');
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;

      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
      <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
      <ns1:spId>'.$spID.'</ns1:spId>
      <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
      <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
      </soapenv:Header>
      <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
      <serviceId>diaspoCC</serviceId>
      <parameter>
      <name>Amount</name>
      <value>'.$amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$msisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>serviceId</name>
      <value>'.$service_id.'</value>
      </parameter>
      <parameter>
      <name>appVersion</name>
      <value>1.7</value>
      </parameter>
      <parameter>
      <name>Narration</name>
      <value>'.$Narration.'</value>
      </parameter>
      <parameter>
      <name>PrefLang</name>
      <value>en</value>
      </parameter>
      <parameter>
      <name>OpCoID</name>
      <value>23701</value>
      </parameter>
      </ns1:processRequest>
      </soapenv:Body>
      </soapenv:Envelope>
      ';

      /*$pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';*/

      //print_r($headers);
      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME')
            {
              $arr_name[$i++] = $value['value'];
            }

            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));
      $arr2 = array_combine($arr, $arr1);
      return $arr2;
    }
    private function momonum($user_id){

      $mobile = get_user_meta($user_id,'diaspo_user_phone',false);
      $momo = $mobile[0];
      $count_code = get_user_meta( $user_id , 'country_flag_code', true );
      if (empty($count_code)) {
        $count_code = "237";
      }
      $country_code = $count_code;
      $momonum = $country_code.$momo;
      return $momonum;
    }
    private function userName($user_id){

      $first_name = get_user_meta($user_id,'first_name',false);
      $last_name = get_user_meta($user_id,'last_name',false);
      $sender_name = $first_name[0].' '.$last_name[0];
      return $sender_name;
    }
  /*__________________________________-PUBLIC-END-_______________________*/
                  
    /*REGISTATION*/
    public function signup_post(){
      $input = $this->param;         
      $required = array ('email','password','phone','deviceid','devicetype'/*,'devicetoken'*/);
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
          $count = email_exists($input['email']);
          if (!$count) {
            $OTP = 1234;//mt_rand(1000, 9999);
            $inputs = array('email' => $input['email'],
                            'password' => base64_encode($input['password']),
                            'diaspo_user_phone' => $input['phone'],                           
                            'otp_code' => $OTP,
                            'deviceid' => $input['deviceid'],
                            'devicetype' => $input['devicetype'],
                            'devicetoken' => $input['devicetoken']
                            );
            $InsertId = InsertData("wp_before_activation_user_list", $inputs);
            if (!empty($InsertId)) {

              $toNumber = $input['phone'];
              $fromNumber = get_option('from_number');
              $messageFormate = get_option('body_message');
              $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
              //$send = sendSms($toNumber, $fromNumber, $messageWOTP); 

              $resp = array('status' => "true", 'message' => "we have send one time password in your registered mobile number, please verify it", 'id' => (string)$InsertId,'response' => new stdclass);
            }else{
              $resp = array('status' => "false", 'message' => "Internal Server Error", 'response' =>New stdclass);
            }          
          }else{
            
              $resp = array('status' => "false", 'message' => "Email already Exist in our database", 'response' => new stdclass); 
          }
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*RESEND OTP FOR SIGNUP*/
    public function resendSignupOtp_post(){
      $input = $this->param;         
      $required = array('id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){       

        $OTP = 1234;//mt_rand(1000, 9999);
        $get = Get_Data("wp_before_activation_user_list", array('list_id' => $input['id']));
        if ($get) {
          $Updated = UpdateData("wp_before_activation_user_list", array('otp_code' => $OTP), array('list_id' => $input['id']));

          if (!empty($Updated)) {

            $toNumber = $get['diaspo_user_phone'];
            $fromNumber = get_option('from_number');
            $messageFormate = get_option('body_message');
            $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
            $send = sendSms($toNumber, $fromNumber, $messageWOTP); 

            $resp = array('status' => "true", 'message' => "we have send one time password in your registered mobile number, please verify it", 'response' => array('id' => $input['id']) );
          }else{
            $resp = array('status' => "false", 'message' => "Internal Server Error", 'response' =>New stdclass);
          }
        }else{
          $resp = array('status' => "false", 'message' => "Data not found", 'response' =>New stdclass);
        }          
        
      }else{
        $resp = $Error;
      }
      $this->response($resp); 
    }
    /*OTP VERIFICATION*/
    public function signupOtpVerify_post(){
      $input = $this->param;         
      $required = array ('id','otp');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){      
        $results = Get_Record("wp_before_activation_user_list", array('list_id' => $input['id'], 'otp_code' => $input['otp']));


        $password_decrt = base64_decode($results->password);

        if ($results) {
          $user_id = wp_create_user($results->email, $password_decrt, $results->email);
          
          update_user_meta($user_id,'deviceid', $results->deviceid);   
          update_user_meta($user_id,'devicetype', $results->devicetype);   
          update_user_meta($user_id,'devicetoken', $results->devicetoken);
          $kee = wp_generate_password(20, false);
          $mail = send_mail("http://dsp.lab.kit-services.com/webapi/index.php/Verify/signupEmailVerify/".$kee."", "Activation Link" ,$results->email);          
          update_user_meta( $user_id, 'diaspo_activation_key', $kee);
          update_user_meta( $user_id, 'diaspo_user_status', 'deactive');
          update_user_meta( $user_id , 'diaspo_pdf_status' , 'Start');         
          update_user_meta( $user_id, 'diaspo_user_phone', $results->diaspo_user_phone);
          update_user_meta( $user_id, 'diaspo_user_newsletter', $results->diaspo_user_newsletter);



          $resp = array('status' => "true", 'message' => "Your mobile number has been verified successfully", 'response' => array('user_id' => (string)$user_id));
        }else{
          $resp = array('status' => "false", 'message' => "one time password not matched", 'response' =>New stdclass);
        }
        
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*LOGIN*/
    public function login_post(){ 

      $input = $this->param;   
      $required = array ('user_name','user_pass','deviceid','devicetype'/*,'devicetoken'*/);
      $Error = check_required_value($required, $input);
      if ($Error == "0"){

        $user_login = $input['user_name'];
        $user_password = $input['user_pass'];
        $creds['user_login'] = $user_login;
        $creds['user_password'] = $user_password;
        $user = get_user_by( 'login', $user_login );
        if ($user && wp_check_password($user_password, $user->data->user_pass, $user->ID)) {
          $user_id = $user->data->ID;

          $status = get_user_meta($user_id,'diaspo_user_status',true);

          if ("active" == get_user_meta($user_id,'diaspo_user_status',true)) {
          
            $deviceid = update_user_meta($user_id,'deviceid', $input['deviceid']);   
            $devicetype = update_user_meta($user_id,'devicetype', $input['devicetype']);   
            //$devicetoken = update_user_meta($user_id,'devicetoken', $input['devicetoken']);
            $pin = get_user_meta($user->ID,'pin',true);
            if (!empty($pin)) {
              $pinstatus = "true";
            }else{
              $pinstatus = "false";
            }
            

            $results = array('user_id' => $user->data->ID,
                             'email' => $user->data->user_email,
                             'Phone' => get_user_meta($user->ID,'diaspo_user_phone',true),
                             'first_name' => get_user_meta($user->ID,'first_name',true),
                             'last_name' => get_user_meta($user->ID,'last_name',true),
                             'nickname' => get_user_meta($user->ID,'nickname',true),
                             'pinstatus' => $pinstatus                          
                            );
            $resp = array( 'status' => 'true', 'message' => "You are successfully login, please verify it", 'response' => $results);
          }else{
            $resp = array( 'status' => 'false', 'message' => 'Please verify the Email provided first.');
          }
        }else{
          $user = wp_signon($creds, false ); 
          if ( 'incorrect user' == $user->get_error_code()){
            $resp = array( 'status' => 'false', 'message' => 'Please check the Email provided.');
          }
          else if( 'incorrect_password' == $user->get_error_code() ){
            $resp = array( 'status' => 'false', 'message' =>'Email or Password invalid. Please try again.');
          }else{
            $resp = array( 'status' => 'false', 'message' => $user->get_error_message());
          }
        }
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD*/
    public function forgotPassword_post(){

      $input = $this->param;   
      $required = array ('forgot');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){               
        $forgot = strtolower($input['forgot']);
        $check = Get_Data("wp_users", array('user_email'=> $forgot));
        if ($check) {
          $OTP = 1234;//mt_rand(1000,9999);
          $user_id = $check['ID'];
          
          $data = update_user_meta( $user_id, 'otp', $OTP);                    
          $mail = send_mail("OTP is: ".$OTP,"OTP for forgot password",$forgot);
          //$update = update_user_meta( $user_id, 'otp', $OTP); 
          //$phone = get_user_meta($user_id,'diaspo_user_phone',true);
          // $toNumber = $phone;
          // $fromNumber = get_option('from_number');
          // $messageFormate = get_option('body_message');
          // $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
          // $send = sendSms($toNumber, $fromNumber, $messageWOTP);
          $resp = array( 'status' => 'true', 'message' => "we have send one time password in your registered mobile number or email id, please verify it", 'response' => array('user_id' => $user_id));
        }else{
          $resp = array( 'status' => 'false', 'message' => "This email is not found in our database", 'response' => new stdclass);
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD OTP VERIFICATION*/
    public function forgotOtpVerify_post(){
      $input = $this->param;         
      $required = array('user_id','otp');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];
        if ($otp == $input['otp']) {
          $resp = array('status' => "true", 'message' => "One time password has been verified successfully", 'user_id' => (string)$user_id, 'response' => New stdclass);
        }else{
          $resp = array('status' => "false", 'message' => "one time password did not matched", 'user_id' => (string)$user_id, 'response' =>New stdclass);
        }   
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD CHANGE*/
    public function forgotPasswordChange_post(){
      $input = $this->param;         
      $required = array('user_id','password');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $password = $input['password'];
        wp_set_password( $password, $user_id );

        $resp = array('status' => "true", 'message' => "Your password has been changed successfully", 'response' => new stdclass);           
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*SEND OTP*/
    public function sendOtp_post(){
      $input = $this->param;         
      $required = array('user_id');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){       
        $user_id = $input['user_id'];
        $OTP = 1234;//mt_rand(1000, 9999);
        
        $update = update_user_meta( $user_id, 'otp', $OTP); 
        $Email = Get_Data("wp_users", array('ID'=> $user_id));
        $email = $Email['user_email'];
        $mail = send_mail("OTP is: ".$OTP,"OTP for change password",$email);
          // if (!empty($Updated)) {
            // $phone = get_user_meta($user_id,'diaspo_user_phone',true);
            // $toNumber = $phone;
            // $fromNumber = get_option('from_number');
            // $messageFormate = get_option('body_message');
            // $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
            // $send = sendSms($toNumber, $fromNumber, $messageWOTP); 

            $resp = array('status' => "true", 'message' => "we have send one time password in your registered mobile number or email, please verify it", 'response' => array('id' => $user_id));      
        
      }else{
        $resp = $Error;
      }
      $this->response($resp); 
    }
    /*FORGOT PASSWORD CHANGE*/
    public function changePassword_post(){
      $input = $this->param;         
      $required = array('user_id','password');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $password = $input['password'];
        $user_password = $input['oldpassword'];
        $user = get_user_by( 'ID', $user_id );
        if ($user && wp_check_password($user_password, $user->data->user_pass, $user->ID)) {          
          wp_set_password($password, $user_id);
          $resp = array('status' => "true", 'message' => "Your password has been changed successfully", 'response' => new stdclass);
        }else{
          $resp = array('status' => "false", 'message' => "Your password has not been changed", 'response' => new stdclass);
        }         
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*SET PIN*/
    public function pinSet_post(){

      $input = $this->param;   
      $required = array('user_id','pin','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $get = get_user_meta($input['user_id'],'pin',false); 
        if ($get) {          
           $data = update_user_meta($input['user_id'],'pin',$input['pin'],"");        
        } else{          
          $data = add_user_meta($input['user_id'],'pin',$input['pin'], false);
        }
        $resp = array( 'status' => 'true', 'message' => "Your password key successfully add", 'response' => array('user_id' => $data));
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PIN*/
    public function pinGet_post(){

      $input = $this->param;   
      $required = array('user_id','pin','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $get = get_user_meta($input['user_id'],'pin',false);
        $pin = $get[0];
        if ($pin == $input['pin']) {
          $resp = array( 'status' => 'true', 'message' => "Your pin has been matched successfully", 'response' => new stdclass );
        }else{
          $resp = array( 'status' => 'false', 'message' => "Your pin has not been matched", 'response' => new stdclass);
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PROFILE*/
    public function getProfile_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $get = Get_Data("wp_users", array('ID' => $user_id));

        $email= $get['user_email'];
        $phone= get_user_meta($user_id,'diaspo_user_phone',false);
        $first_name= get_user_meta($user_id,'first_name',false);
        $last_name= get_user_meta($user_id,'last_name',false);
        //$country= get_user_meta($user_id,'diaspo_user_country_of_origin',false);
        $country= get_user_meta($user_id,'country_flag_code',false);
        $language= get_user_meta($user_id,'diaspo_user_language',false);
        //$address= get_user_meta($user_id,'bitcoin_user_address',false);
        
        $countryList =  array(array('code' => $country[0]?$country[0]:""),
                            array('name' => "Cameroon", 'code' => "237"),
                            array('name' => "France", 'code' => "33")
                            );
        $languageList =  array(array('code' => $language[0]?$language[0]:""),
                            array('name' => "Cameroon", 'code' => "cmr", 'language' => "Bantu"),
                            array('name' => "France", 'code' => "fr", 'language' => "french")
                            );

        

        $data = array('user_id' => $get['ID'],
                      'email' => $get['user_email']?$get['user_email']:"",
                      'phone' => $phone[0]?$phone[0]:"",
                      'first_name' => $first_name[0]?$first_name[0]:"",
                      'last_name' => $last_name[0]?$last_name[0]:"",
                      // 'country' => $country[0]?$country[0]:"",
                      // 'language' => $language[0]?$language[0]:"",

                      'country_list' => $countryList,
                      'language_list' => $languageList,
                      //'Wallet' => $walletData
                    );

        $resp = Results(200,$data);
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*GET PROFILE*/
    public function updateProfile_post(){

      $input = $this->param;   
      $required = array('user_id','name','phone','country','language','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $phone = $input['phone'];
        $name = $input['name'];
        $exp = explode(" ", $name);
        $first_name = $exp[0];
        $last_name = $exp[1];
        if ($last_name) {
          update_user_meta($user_id,'last_name', $last_name);
        }
        update_user_meta($user_id,'first_name', $first_name);
        update_user_meta($user_id,'diaspo_user_phone', $input['phone']);
        update_user_meta($user_id,'country_flag_code', $input['country']);
        update_user_meta($user_id,'diaspo_user_language', $input['language']);
        //update_user_meta($user_id,'bitcoin_user_address', $input['address']);
        $momonum = get_user_meta($user_id,'diaspo_user_phone',false);
        if ($phone == $momonum) {
          $result = array('user_id' => $user_id, 'phonestatus' => '0', 'phone' => $phone, 'country' => $input['country']);
          $resp = Results(200 ,$result, "Your profile data has been updated successfully");     
        }else{

          $OTP = 1234;//mt_rand(1000, 9999);
        
          $update = update_user_meta( $user_id, 'otp', $OTP); 
          $Email = Get_Data("wp_users", array('ID'=> $user_id));
          $email = $Email['user_email'];
          //$mail = send_mail("OTP is: ".$OTP,"OTP for change password",$email);

          
          // $toNumber = $phone;
          // $fromNumber = get_option('from_number');
          // $messageFormate = get_option('body_message');
          // $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
          // $send = sendSms($toNumber, $fromNumber, $messageWOTP);

          $result = array('user_id' => $user_id, 'phonestatus' => '1', 'phone' => $phone, 'country' => $input['country']);
          $resp = Results(200 ,$result, "Please verify OTP");
        }        

        

      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*FORGOT PASSWORD OTP VERIFICATION*/
    public function phoneUpdateVerify_post(){
      $input = $this->param;         
      $required = array('user_id','otp', 'phone', 'country');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id']; 
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];
        if ($otp == $input['otp']) {

          update_user_meta($user_id,'diaspo_user_phone', $input['phone']);
          update_user_meta($user_id,'country_flag_code', $input['country']);

          $resp = array('status' => "true", 'message' => "Your profile data has been updated successfully", 'user_id' => (string)$user_id, 'response' => New stdclass);
        }else{
          $resp = array('status' => "false", 'message' => "one time password did not matched", 'user_id' => (string)$user_id, 'response' =>New stdclass);
        }   
      }else{
        $resp = $Error;        
      }
      $this->response($resp);
    }
    /*GET COUNTRY AND LANGUAGE LIST*/
    public function getCountryAndLanguage_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        // $country = all_Data("wp_countries");
        // $language = all_Data("wp_countries", array('active' => 1));
          $result['country'] =  array(array('name' => "English", 'code' => "+27", 'language' => "en"),
                            array('name' => "France", 'code' => "+33", 'language' => "fr")
                            );
          $result['language'] =  array(array('name' => "English", 'code' => "+27"),
                            array('name' => "France", 'code' => "+33")
                            );
          
          $resp = Results(200 ,$result);
          
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }        
    /*LOGOUT*/
    public function logout_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = check_required_value($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        update_user_meta($user_id,'deviceid', 0);
        $data = UpdateData("wp_users", array('user_status ' => 0), array('ID' => $user_id));
        if ($data) {
          $result = array('data' => $data);  
          $resp = Results(200 ,$result, "successfully Logout"); 
        }else{            
          $resp = Results(500 ,$result, "successfully Logout"); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*CONVERT BITCOIN*/
    public function convertCurrency_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','amount','currency','change');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        
        $data = get_conversion_bitcoin_with_amount($input['currency'], $input['change'],$input['amount']);
        if ($data) {
          $result = array('value' => (string)$data); 
          $resp = Results(200 ,$result);  
        }else{
          $resp = Results(500 ,$result); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transaction_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];

        $Result['all'] = all_Data("wp_trade_order_history", array('user_id' => $user_id));
        $Result['recive'] = all_Data("wp_trade_order_history", array('user_id' => $user_id, 'type' => "Buy", 'payment_status'=> "completed"));
        $Result['send'] = all_Data("wp_trade_order_history", array('user_id' => $user_id, 'type' => "Sell", 'payment_status'=> "Completed"));
        
        $resp = Results(200,$Result);
      }else{

      $resp = $Error;

      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionRecive_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $Result = all_Data("wp_trade_order_history", array('user_id' => $user_id, 'type' => "Sell", 'payment_status'=> "Completed"));
        
        $resp = Results(200,$Result);
      }else{

      $resp = $Error;

      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionSend_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];

        
        $Result = all_Data("wp_trade_order_history", array('user_id' => $user_id, 'type' => "Buy", 'payment_status'=> "completed"));
         
        $resp = Results(200,$Result);
      }else{

      $resp = $Error;

      }
      $this->response($resp);
    }
    /*TRANSACTION BITCOIN*/
    public function transactionAll_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];

        $Result = all_Data("wp_trade_order_history", array('user_id' => $user_id));
        
        $resp = Results(200,$Result);
      }else{

      $resp = $Error;

      }
      $this->response($resp);
    }
    /*WALLET LIST*/
    public function Wallet_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletList = all_Data("wp_user_wallets", array('user_id' => $user_id, 'status_pass' => '1'));
         
        $momonum = $this->momonum($input['user_id']);
        $Adminmomo = $this->momonum("1");
        if ($walletList) {
          foreach ($walletList as $wallet) {

          $result[] = array('wallet_id' => $wallet['wallet_id'],
                            'blocktrail_public_keys' => $wallet['blocktrail_public_keys'],
                            'wallet_identifier' => $wallet['wallet_identifier'],
                            'status_pass' => $wallet['status_pass'],
                            'momonum' => $momonum,
                            'Adminmomo' => $Adminmomo,
                            );
        }  
          $resp = Results(200 ,$result); 
        }else{            
          $resp = Results(200 ,$result, "Wallet not found"); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*WALLET LIST*/
    public function momo_post(){

      $input = $this->param;   
      
      if ($input['type'] == "buy"){
        $result = $this->momonum($input['user_id']);

        $resp = Results(200, array('momonum' => $result));
      }else{
        $result = $this->momonum("1");
        $resp = Results(200, array('momonum' => $result));
      }
      $this->response($resp);
    }
    /*RECIVE BITCOIN*/
    public function reciveBitcoin_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $get = get_user_meta($input['user_id'],'bitcoin_user_address',true);  

        if ($get) {
          $result = array('adress' => $get); 
          $resp = Results(200 ,$result,"Success");
        }else{
          $resp = Results(0 ,$result,"Data not found"); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*CREATE WALLET*/
    public function createWallet_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','identifier','status_pass');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $identifier = $input['identifier'];
        $status_pass = $input['status_pass'];
        if ($status_pass == 1) {          
          $passparse = $input['passpharse'];
        }else{
          $passparse = "12345678";
        }
        $check = CountData("wp_user_wallets", array('user_id' => $user_id));
        if ($check == 0) {
        
          $count = CountData("wp_user_wallets", array('wallet_identifier' => $input['identifier'])); 
          if ($count == 0) {
          
            //Wallet Creation
            $client = $this->client();
            list($wallet, $primaryMnemonic, $backupMnemonic, $blocktrailPublicKeys) = $client->createNewWallet($identifier, $passparse);
                      
            $newVal = $primaryMnemonic['blocktrail_public_keys'][0];
            
            $wallet_id = generate_license();
            
            $insert = array('user_id' => $user_id,
                            'wallet_identifier' => $identifier, 
                            'wallet_id' => $wallet_id, 
                            'primaryMnemonic' => json_encode($primaryMnemonic), 
                            'blocktrail_public_keys' => $newVal[0],
                            'status_pass' => 1
                            );

            $insertData = InsertData('wp_user_wallets',$insert);

            if ($insertData) {
              $data = Get_Data('wp_user_wallets', array('id' => $insertData));
            }       
            $resp = array( 'status' => 'true', 'message' => "Wallet created successfully", 'response' => array('user_id' => $data));
          }else{
            $resp = array( 'status' => 'false', 'message' => "Wallet already exist", 'response' => new stdclass);
          }
        }else{
            $resp = array( 'status' => 'false', 'message' => "Wallet already created", 'response' => new stdclass);
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*WALLET BALANCE*/
    public function walletBalance_post() {

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        
        $client = $this->client();
        
        try {
          $wallets = $client->allWallets();
          $identif = $this->common_model->getWalletList($user_id);
          $count = (int)$wallets['total']/10;
          $identname = array();            
          for ($i=0; $i <= $count; $i++) { 
            $wallets = $client->allWallets($i+1, 10);
            foreach ($wallets['data'] as $wallet ) {
              if (in_array($wallet['identifier'], $identif)) {
                 $identname[] = array('identifier' => $wallet['identifier'],
                                      'balance' => BlocktrailSDK::toBTC($wallet['balance']),
                                      'amount' => (string)get_conversion_bitcoin_with_amount("BTC", "XAF", BlocktrailSDK::toBTC($wallet['balance']))?:"0.00000000"
                                     );
              }              
            }
          }
          $resp = Results(200,$identname, "Success");          
        } 
        catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}")); 
        }          
      }else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*BUY BITCOIN*/
    public function buy_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','xafamount','address','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $amount = $input['xafamount'];
        $momonum = $this->momonum($user_id);
        $Buyer_name = $this->userName($user_id);

        $data = array('transfer_amount' => $input['xafamount'],
                      'fullname' => $full_name,
                      'senderMsisdn' => $momonum,
                      'user_id' => $user_id
                    );

        $pemfile = $_SERVER['DOCUMENT_ROOT'].'certificates_MTN/client_certnew.pem';        
        $Result = $this->Withdraw($data);
        if($Result['StatusCode'] == 1000)
        {          
          $client = $this->client();
          $network =$this->networkFees($client,$walletIdent, $walletPassword, $amount);
       
          $XAF = number_format($amount-$network['our_fees']);

          $amount_paid_btc = convert_exponantial_to_decimal($network['btc']-$network['trade_fees_btc']);

          $btc_amount_to_rec = convert_exponantial_to_decimal($network['btc']-$network['network_fees_in_btc']-$network['trade_fees_btc']);

          $inputs = array('user_id' => $user_id,
                          'type'=> "Buy",                          
                          'recipient_name' => $Buyer_name,
                          'mtn_number' => substr($momonum,3),
                          'amount_in_xaf'=> $amount,
                          'our_fees_in_xaf'=> $network['our_fees'],
                          'total_amount_in_xaf' => $XAF,
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'payment_status' => 'pending',
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $amount_paid_btc,
                          'btc_network' => $network['network_fees_in_btc'],
                          'btc_amount_to_rec' => $btc_amount_to_rec,
                          'btc_status' => "pending",
                          'recipient_address' => $network['address'],
                          'conversion_rate' => $network['rate'],
                          'status_code' =>$Result['StatusCode'],
                          'walletid' => $walletIdent,
                          'OpCoID' => $Result['OpCoID']?$Result['OpCoID']:"",
                          'ProcessingNumber' => $Result['ProcessingNumber'],
                          'MOMTransactionID' => $Result['MOMTransactionID']?$Result['MOMTransactionID']:""
                          );


          $order_id = insertData("wp_trade_order_history",$inputs);
          
          
          $resp = results(100, array('user_id' => $user_id,'order_id'=>(string)$order_id), "please wait for approved");

        }else{

          
          $Result['user_id'] = $user_id;
          $resp = results(0,$Result, "Rejected");
        }        
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*BUY STATUS GET*/
    public function buyBitcoinAndPayStatus_post(){

        $input = $this->param;   
        $required = array('user_id','deviceid','order_id',);
        $Error = checkvalid($required, $input);
        if ($Error == "0"){
          $user_id = $input['user_id'];
          $order_id = $input['order_id'];
          $deviceid = $input['deviceid'];
          $ProcessingNumber = $input['ProcessingNumber'];

          $orderStatus = Get_Data("wp_trade_order_history", array('order_id' => $order_id));

          if ($orderStatus) {

            $results = array('user_id' => $orderStatus['user_id'],
                            'order_id' => $orderStatus['order_id'],
                            'mtn_number' => $orderStatus['mtn_number'],
                            'type' => $orderStatus['type'],
                            'recipient_name' => $orderStatus['recipient_name'],
                            'amount_in_xaf' => $orderStatus['amount_in_xaf'],
                            'our_fees_in_xaf' => $orderStatus['our_fees_in_xaf'],
                            'network_fees_in_xaf' => $orderStatus['network_fees_in_xaf'],
                            'total_amount_in_xaf' => $orderStatus['total_amount_in_xaf'],
                            'btc_amount_to_rec' => $orderStatus['btc_amount_to_rec'],
                            'conversion_rate' => $orderStatus['conversion_rate'],
                            'payment_status' => $orderStatus['payment_status'],
                            'btc_status' => $orderStatus['btc_status'],
                            'ProcessingNumber' => $orderStatus['ProcessingNumber'],
                            'MOMTransactionID' => $orderStatus['MOMTransactionID'],
                            'OpCoID' => $orderStatus['OpCoID']
                           );

            if ($orderStatus['payment_status'] == 'Completed') {
              if ($orderStatus['btc_status'] == 'Completed') {
                 $results['status'] = '2';
                $resp = results(200,$results, 'Transactions successfully');
              }else{
                $results['status'] = '1';
                $resp = results(100,$results, 'Payment Done successfully');
              }
             
            }elseif ($orderStatus['payment_status'] == 'pending') {
              $results['status'] = '0';
              $resp = results(100,$results, 'Wait for approved');
             
            }elseif($orderStatus['payment_status'] == 'Rejected'){
              $results['status'] = '3';
              $resp = results(0,$results, 'Transactions rejected');

            }
          }
        }else{
          $resp = $Error;
        }
        $this->response($resp);
    }
    /*SELL BITCOIN*/
    public function sell_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','xafamount','address','identifier'/*,'payamount','ourfees','netfees','btcamount','momonum','convrate'*/);
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $amount = $input['xafamount'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;

        $sender_name = $this->userName($user_id);
        $momonum = $this->momonum($user_id);

        $client = $this->client();
        $network = $this->networkFees($client,$walletIdent, $walletPassword,$amount);
        $wallet = $network['wallet'];

        $XAF = number_format($amount-$network['our_fees']-$network['network_fees_in_xaf']);
        $amount_paid_btc = convert_exponantial_to_decimal($network['btc']-$network['trade_fees_btc']);
        $btc_amount_to_rec = convert_exponantial_to_decimal($network['btc']-$network['network_fees_in_btc']-$network['trade_fees_btc']);
        //print_r($network);die;
        $BTCreceiverAddress = $input['address'];
        $btc = $network['btc'];

        try {
          $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
          if (!empty($txHash)) { 

            $inputs = array('user_id' => $user_id,
                            'recipient_name' => $sender_name,
                            'mtn_number' => $momonum,
                            'type'=> "Sell",
                            'amount_in_xaf' => $amount,
                            'our_fees_in_xaf' => $network['our_fees'],
                            'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                            'total_amount_in_xaf' => $XAF,
                            'payment_status' => 'pending',
                            'btc_amount' => $network['btc'],
                            'amount_paid_btc' => $amount_paid_btc,
                            'btc_network' => $network['network_fees_in_btc'],
                            'btc_amount_to_rec' => $btc_amount_to_rec,
                            'btc_status' => "Completed",
                            'recipient_address' => $BTCreceiverAddress,
                            'transaction_id' => $txHash,
                            'conversion_rate' => $network['rate']
                            );

            $order_id = insertData("wp_trade_order_history",$inputs);  

            $data = array();                 
            $data['order_id'] = $order_id;
            $data['transfer_amount'] = $XAF;
            $data['fullname'] = $sender_name;
            $data['senderMsisdn'] = $momonum;
            $data['user_id'] = $user_id;        
            
          
            $response_array = $this->Deposit($data);
            
            if (!empty($response_array)) {



              $mail = send_mail("Sell Process",array('btc_Response' => $txHash,'mtn_Response'=> $response_array), "test5@kit-services.com,votiveyogesh@gmail.com,votivephp.prashant@gmail.com");



              $StatusCode = $response_array['StatusCode'];
              $StatusDesc = $response_array['StatusDesc'];
              $MOMTransactionID = $response_array['MOMTransactionID'];
              $ProcessingNumber = $response_array['ProcessingNumber'];
              $SenderID = $response_array['SenderID'];
              $MSISDNNum = $response_array['MSISDNNum'];
              $OpCoID = $response_array['OpCoID'];
              $mtn_status = '';

              $Result = array('status_code' => $StatusCode,
                             'OpCoID' => $OpCoID?$OpCoID:"",
                             'ProcessingNumber' => $ProcessingNumber,
                             'MOMTransactionID' => $MOMTransactionID,
                             'payment_status' => $response_array['StatusDesc']
                            );
              $Update = UpdateData("wp_trade_order_history", $Result, array('order_id' => $order_id));

              if ($response_array['StatusCode'] == 01) {
                $Result['user_id'] = $user_id;
                $Result['order_id'] = (string)$order_id;
                $resp = Results(200, $Result, "Completed");
              }else{ 
                $response_array['user_id'] = $user_id;
                $response_array['order_id'] = (string)$order_id;           
                $resp = Results(0, $response_array, "Error");                            
              }
              
              
                
                  
            }else{
            
              $resp = Results(0, $response_array); 
                             
            }
            
          }else{
            $resp = Results(0, array(), "failed"); 
          }              
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
        }
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*RECIVE BITCOIN*/
    public function recived_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $mobile = get_user_meta($user_id,'diaspo_user_phone',false);
        $momo = $mobile[0];
        $count_code = get_user_meta( $user_id , 'country_flag_code', true );
        $country_code = $count_code;
        $momonum = $country_code.$momo;
        $client = $this->client();
        try {        
          
          $wallet = $client->initWallet($walletIdent, $walletPassword);
          $address = $wallet->getNewAddress();
          $momonum = $momonum;         
        } catch (Exception $e) {

          $this->response(Results(0,array(),"{$e->getMessage()}"));       
        } 
        $data = array('user_id' => $user_id,
                        'address' => $address,
                        'momonum' => $momonum,
                        'type' => "0"

                        );
        $resp = Results(200,$data);

      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*CALCULATION BITCOIN*/    
    public function getCalulationAmount_post(){

      $input = $this->param; 

      $required = array('user_id','deviceid','amount','from_currency','change_currency','type');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";

        $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1); 

        //$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);

        $btcamountRecieved = get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'], $amount);

        $btc = convert_exponantial_to_decimal($btcamountRecieved);
        $momonum = $this->momonum($user_id);

        $client = $this->client();


        if ($input['type'] == "Buy") {

          
          if (empty($walletIdent)) {
            $data = array(
                          'btc' => $btc?$btc:"",
                          'our_fees' => $trade_fees?$trade_fees:"",
                          'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",

                          'rate' => (string)$rate,
                          'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                          'wallet_address' => $address?$address:"",
                          'momonum' => $momonum
                          );
          }else{
            
            
            $network = $this->networkFees($client,$walletIdent, $walletPassword, $amount);
            //print_r($network);
            //die();
            $our_fees = $network['our_fees'];
            $trade_fees_btc = $network['trade_fees_btc'];
            $network_fees_in_xaf = $network['network_fees_in_xaf'];
            $network_fees_in_btc = $network['network_fees_in_btc'];
            $address = $network['address'];
            $btc = $network['btc'];
            $rate = $network['rate'];
            $momonum = $this->momonum($user_id);
            $xafFinalAmount = number_format($amount+$our_fees+$network_fees_in_xaf, 2, '.', '');


              $data = array(
                        'btc' => $btc,
                        // 'our_fees' => $our_fees,
                        // 'network_fees'=> (string)$network_fees_in_xaf,
                        'our_fees' => $our_fees,
                        'our_fees_btc' => $trade_fees_btc,
                        'network_fees'=> (string)$network_fees_in_xaf,
                        'network_fees_in_btc' => (string)$network_fees_in_btc,
                        'rate' => (string)$rate,
                        'total_amount' => $xafFinalAmount,
                        'wallet_address' => $address,
                        'momonum' => $momonum
                        );
            }
        }elseif ($input['type'] == "Sell") {
          
          $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
          $walletPasswordAdmin = get_option('testnet_wallet_password');
          $network = $this->networkFees($client,$walletIdentAdmin, $walletPasswordAdmin, $amount);

          $network_fees_in_xaf = $network['network_fees_in_xaf'];
          $network_fees_in_btc = $network['network_fees_in_btc'];
          $trade_fees_btc = $network['trade_fees_btc'];
          $address = $network['address'];
          $btc = $network['btc'];
          $our_fees = $network['our_fees'];
          $rate = $network['rate'];
          $xafFinalAmount = number_format($amount-$our_fees-$network_fees_in_xaf, 2, '.', '');
          //$momonum = "237672921262";
          $data = array(
                        'btc' => $btc,
                        'our_fees' => $our_fees,
                        'our_fees_btc' => $trade_fees_btc,
                        'network_fees'=> (string)$network_fees_in_xaf,
                        'network_fees_in_btc' => (string)$network_fees_in_btc,
                        'rate' => (string)$rate,
                        'total_amount' => $xafFinalAmount,
                        'wallet_address' => $address,
                        'momonum' => $momonum
                        );
        }else{
          $data = array(
                          'btc' => $btc?$btc:"",
                          'our_fees' => $trade_fees?$trade_fees:"",
                          'our_fees_btc' => $trade_fees_btc?$trade_fees_btc:"",
                          'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                          'network_fees_in_btc'=> $network_fees_in_btc?$network_fees_in_btc:"",
                          'rate' => (string)$rate,
                          'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                          'wallet_address' => $address?$address:"",
                          'momonum' => $momonum?$momonum:""
                          );
        }

        $resp = Results(200 ,$data,"Success");
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);    
    }
    
    /*CALCULATION BITCOIN*/    
    public function Calulation_post(){

      $input = $this->param;
      //print_r($input);
      $required = array('user_id','deviceid','amount','from_currency','change_currency');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        // $walletIdent = $input['identifier'];
        // $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";
        //$momonum = $this->momonum($user_id);
        //$momonum = "237672921262";

        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);

        $btcamountRecieved = get_conversion_bitcoin_with_amount($input['from_currency'], $input['change_currency'],$input['amount']);


        //$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
        $btc = convert_exponantial_to_decimal($btcamountRecieved);
        //print_r($btc);die;

        $client = $this->client();

        if ($input['type'] == "Sell") {
          
        $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
        $walletPasswordAdmin = get_option('testnet_wallet_password');
        $network = $this->networkFees($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$input['from_currency'], $input['change_currency']);
        

        $our_fees = $network['our_fees'];
        $network_fees_in_xaf = $network['network_fees_in_xaf'];
        $address = $network['address'];
        $btc = $network['btc'];
        $rate = $network['rate'];
        $xafFinalAmount = number_format($amount-$our_fees-$network_fees_in_xaf, 2, '.', '');
        $data = array(
                      'btc' => $btc,
                      'our_fees' => $our_fees,
                      'network_fees'=> (string)$network_fees_in_xaf,
                      'network_fees_btc'=> (string)$network['network_fees_in_btc'],
                      'rate' => (string)$rate,
                      'total_amount' => $xafFinalAmount,
                      'wallet_address' => "",
                      'momonum' => $this->momonum($user_id)
                      );
        }
        else{
          $data = array(
                          'btc' => $btc?$btc:"",
                          'our_fees' => $trade_fees?$trade_fees:"",
                          'network_fees'=> $network_fees_in_xaf?$network_fees_in_xaf:"",
                          'rate' => (string)$rate,
                          'total_amount' => $xafFinalAmount?$xafFinalAmount:"",
                          'wallet_address' => $address?$address:"",
                          'momonum' => $this->momonum($user_id)
                          );
        }

        $resp = Results(200 ,$data,"Success");
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);    
    }
    /*SEND BITCOIN CALCULATION*/
    public function sendCalculation_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','identifier','amount');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $user_id = $input['user_id'];         
        $amount = intval($input['amount']);
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";
        $client = $this->client();

        $network =$this->networkFees($client,$walletIdent, $walletPassword, $amount);
        
        $network_fees_in_btc = $network['network_fees_in_btc'];
        $address = $network['address'];
        $btc = $network['btc'];
        $rate = $network['rate'];
        $balance = $network['balance'];

        $btcFinalAmount = convert_exponantial_to_decimal($btc-$network_fees_in_btc);
        $data = array(
                        'btc' => $btc,
                        //'our_fees' => "",
                        'network_fees'=> (string)$network_fees_in_btc,
                        'total_amount' => $btcFinalAmount,
                        'wallet_address' => "",
                        'balance_btc' => $balance,
                        'balancexaf' => (string)(get_conversion_bitcoin_with_amount('BTC','XAF',$balance)),
                        'momonum' => $this->momonum($user_id),
                        'rate' => $rate
                        );
        $resp = Results(200 ,$data, "Success");
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*SEND BITCOIN OTP*/
    public function OTPForSend_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $momonum = substr($input['momonum'],3);
        $OTP = 1234;//mt_rand(1000, 9999);        
        $Update = update_user_meta( $user_id, 'otp', $OTP);       
        
        
        $toNumber = $momonum;
        $fromNumber = get_option('from_number');
        $messageFormate = get_option('body_message');
        $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
        $send = sendSms($toNumber, $fromNumber, $messageWOTP);

        $resp = Results(200 ,array('user_id' => $user_id), "Please Verify OTP"); 
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*SEND BITCOIN OTP VERIFY PROCESS*/
    public function OTPVerifyForSend_post(){

      $input = $this->param;
      $required = array('user_id','deviceid','otp');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];        
        $get = get_user_meta($user_id,'otp',false);
        $otp = $get[0];

        if ($otp == $input['otp']) {

          $resp = Results(200 ,array("user_id" => $user_id), "OTP matched successfully"); 
        }else{
          $resp = Results(0 ,array(), "OTP not matched" ); 
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }    
    /*SEND BITCOIN TO BITCOIN*/
    public function send_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','address', 'xafamount','identifier','from_currency','change_currency');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $amount = $input['xafamount'];
        $BTCreceiverAddress = $input['address'];
        $note = $input['note'];


        $momonum = $this->momonum($user_id);
        $sender_name = $this->userName($user_id);

        $client = $this->client();
        $network =$this->networkFees($client,$walletIdent,$walletPassword,$amount);
        $wallet = $network['wallet']; 
         
        $btc = $network['btc'];
        
        $SendBTC = convert_exponantial_to_decimal($btc-$network['network_fees_in_btc']);
          
        $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
        if (!empty($txHash)) {
          $inputs = array('transaction_id' => $txHash,
                          'user_id' => $user_id,
                          'walletid' => $walletIdent,
                          'recipient_address' => $BTCreceiverAddress,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $input['ourfees'],
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'btc_amount_to_rec' => $SendBTC,
                          'conversion_rate' => $network['rate'],
                          'type'=> "Send",
                          'btc_status' => "Completed",
                          'note' => $input['note']
                            );      
          $order_id = insertData("wp_trade_order_history",$inputs);   
          $Result = array('order_id' => (string)$order_id,
                          'transaction_id' => $txHash,
                          );
          $mail = send_mail("Send BTC to BTC",array('btc_Response' => $txHash,'order_id'=> $order_id), "votiveyogesh@gmail.com,votivephp.prashant@gmail.com");

          $resp = Results(200 ,$Result, "Success");
        }else{
          $inputs = array('transaction_id' =>$txHash?$txHash:"",
                          'user_id' => $user_id,
                          'walletid' => $walletIdent,
                          'recipient_address' => $BTCreceiverAddress,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $input['ourfees'],
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'btc_amount_to_rec' => $SendBTC,
                          'conversion_rate' => $network['rate'],
                          'type'=> "Send",
                          'btc_status' => "Rejected",
                          'note' => $input['note']
                          );      
          $order_id = insertData("wp_trade_order_history",$inputs);
          $Result = array('order_id' => (string)$order_id,
                          'transaction_id' => $txHash?$txHash:"",
                          );
          $mail = send_mail("Send BTC to BTC",array('btc_Response' => 'FAILER','order_id'=> $order_id), "votiveyogesh@gmail.com,votivephp.prashant@gmail.com");             
          $resp = Results(200 ,$Result, "Success");
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*SEND FIAT TO FIAT*/
    public function sendBTF_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','address','xafamount','identifier');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $note = $input['note'];
        $amount = $input['xafamount'];
        $recivermomonum = $input['address'];

        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;

        //$momonum = $this->momonum($user_id);
        $momonum = $input['address'];
        $sender_name = $this->userName($user_id);
        $client = $this->client();

        $network =$this->networkFees($client,$walletIdent, $walletPassword, $amount);
        $totel_Fees = $network['network_fees_in_xaf'];
        $totel_XAF = number_format($amount-$totel_Fees);
        
        $SendBTC = convert_exponantial_to_decimal($btc-$network['network_fees_in_btc']);

        $wallet = $network['wallet'];         
        $btc = $network['btc'];    
        $BTCreceiverAddress = $this->AdderssAdmin($client);
        $txHash = $this->pay($wallet,$BTCreceiverAddress,$btc);
        if (!empty($txHash)) {

          $inputs = array('user_id' => $user_id,
                          'recipient_name' => $sender_name,
                          'mtn_number' => $momonum,
                          'type'=> "Send",
                          'amount_in_xaf' => $amount,
                          //'our_fees_in_xaf' => $network['our_fees'],
                          'network_fees_in_xaf' => $network['network_fees_in_xaf'],
                          'total_amount_in_xaf' => $totel_XAF,  
                          'payment_status' => 'pending',                        
                          'btc_amount' => $network['btc'],
                          'amount_paid_btc' => $network['btc'],
                          'btc_network' => $network['network_fees_in_btc'],
                          'btc_amount_to_rec' => $SendBTC,
                          'btc_status' => "Completed",                          
                          'recipient_momonum' => $BTCreceiverAddress,                         
                          //'recipient_address' => $recivermomonum, 
                          'transaction_id' => $txHash,
                          'conversion_rate' => $network['rate'],
                          'note' => $input['note'],
                          'walletid' => $walletIdent,
                          ); 
          $order_id = insertData("wp_trade_order_history",$inputs);

          $data = array();                 
          $data['order_id'] = $order_id;
          $data['transfer_amount'] = $totel_XAF;
          $data['fullname'] = $sender_name;
          $data['senderMsisdn'] = $momonum;
          $data['user_id'] = $user_id;

          $pay = $this->Deposit($data);

          $mail = send_mail("Send BTC to FIAT",array('btc_Response' => $txHash,'order_id'=> $order_id, 'response' => $pay), "votiveyogesh@gmail.com,votivephp.prashant@gmail.com");

          $Result = array('status_code' => $pay['StatusCode'],
                             'OpCoID' => $pay['OpCoID']?$pay['OpCoID']:"",
                             'ProcessingNumber' => $pay['ProcessingNumber'],
                             'MOMTransactionID' => $pay['MOMTransactionID']
                            );
          $Update =UpdateData("wp_trade_order_history", $Result, array('order_id' => $order_id));

          if ($pay['StatusCode'] == 01) { 

            $results = array('order_id' => (string)$order_id,
                            'transaction_id' => $txHash,
                            'status_code' => $pay['StatusCode'],
                            'OpCoID' => $pay['OpCoID']?$pay['OpCoID']:"",
                            'ProcessingNumber' => $pay['ProcessingNumber'],
                            'MOMTransactionID' => $pay['MOMTransactionID']?$pay['MOMTransactionID']:""
                          );             
            $resp = Results(200 ,$results, "Success");

          }else{
            $pay['order_id'] = $order_id; 
            $pay['MOMTransactionID'] = $pay['MOMTransactionID']?$pay['MOMTransactionID']:"";
            $resp = Results(0 ,$pay, "Error");
          }
        }else{
          $resp = Results(0 , array(), "Error");
        }
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*Over View in bticoin*/
    //public function overViewBTCold_post(){


      // $input = $this->param;
      // $required = array('user_id','deviceid','identifier');
      // $Error = checkvalid($required, $input);
      // if ($Error == "0"){

      //   $client = $this->client();

      //   // $add = $client->address("2MwX4yZoZ94dx1LnAesrFE8DBJAz8MpHDRV");
      //   // print_r($add);die;        
      //   // $da = $input['from'];
      //   $user_id = $input['user_id'];
      //   $walletIdent = $input['identifier'];
      //   $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
      //   $wallet = $client->initWallet($walletIdent, $walletPassword);

      //   $todate = strtotime(date($input['to']));
      //   $fromdate = strtotime(date($input['from']));
        
      //   list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
      //   $tx = $wallet->transactions(1,2);

      //   //print_r($tx);die;
      //   $data['total'] = $data['confirmed']+$data['unconfirmed'];
      //   $data['result'] = $data['total'];
      //   $data['total'] = $tx['total'];
      //   $data['per_page'] = $tx['per_page'];
      //   $data['current_page'] = $tx['current_page'];

      //   if (!empty($tx)) {
          
      //     $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
      //     for ($i=1; $i < $pages+1; $i++) {
      //       $txs = $wallet->transactions($i,2,DESC);
      //       $trax = $txs['data'];
      //       foreach ($trax as $traxs) {
      //         //print_r($traxs);//die;

      //         if ($todate <= $traxs['time'] && $fromdate >= $traxs['time'] ) {
              
      //           $data['result'] = $data['result'] - $traxs['wallet_value_change'];
      //           $data['data'][] = array('hash' => $traxs['hash'],                
      //                                   'total_fee' => $traxs['total_fee'],
      //                                   'wallet_value_change' => $traxs['wallet_value_change'],
      //                                   'previous_balance' => $data['result'],            
      //                                   'transactions_balance' => $traxs['wallet']['balance'],
      //                                   'available_balance' => $data['result']+ $traxs['wallet']['balance'],            
      //                                   'date' => date("Y-m-d", $traxs['time']),
      //                                   'time' => date("Y-m-d H:i:s", $traxs['time']),
      //                                   // 'value0' => $traxs['outputs'][0]['value'],
      //                                   // 'value1' => $traxs['outputs'][1]['value']?$traxs['outputs'][1]['value']:"",
      //                                   // 'address' => $traxs['addresses'],                 
      //                                   // 'addresses' => $traxs['wallet']['addresses'],
      //                                   // 'time1' => $traxs['time'],
      //                                   );
      //         //print_r($data);die;
      //         }
      //       }
      //     }
      //   }//die;
      //   //$result = array_reverse($data);
      //   $resp = Results(200,$data, "Success");
 
      //   }else{
      //   $resp = $Error;
      // }
      // $this->response($resp);      
    //}

    function getStartAndEndDate($week, $year) {
      $dateTime = new DateTime();
      $dateTime->setISODate($year, $week);
      $result['start_date'] = $dateTime->format('Y-m-d 00:00:00');
      $dateTime->modify('+6 days');
      $result['end_date'] = $dateTime->format('Y-m-d 23:59:59');
      return $result;
    }





    public function overViewBTC_post(){


      $input = $this->param;
      $required = array('user_id','deviceid','identifier','type');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $client = $this->client();

        // $add = $client->address("2MwX4yZoZ94dx1LnAesrFE8DBJAz8MpHDRV");
        // print_r($add);die;        
        // $da = $input['from'];
        $user_id = $input['user_id'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
        $wallet = $client->initWallet($walletIdent, $walletPassword);

        $todate = strtotime(date($input['to']));
        $fromdate = strtotime(date($input['from']));

        $type = $input['type'];
        $week = $input['week']?$input['week']:"W";
        $year = $input['year']?$input['week']:"Y-m-d";

        if ($type == 3) {
          $ddate = date("Y-m-d H:i:s");
          $date = new DateTime($ddate);
          $week_num = $date->format($week);
          //$month = $date->format("M");
          $year_num = $date->format($year);                
          $date = $this->getStartAndEndDate($week_num, $year_num);
          echo $start_date = $date['start_date'];
          echo $end_date = $date['end_date'];
        }elseif ($type == 2) {
          echo $start_date = date(''.$year.' 00:00:00',strtotime('first day of this month'));
          echo $end_date = date(''.$year.' 23:59:59',strtotime('last day of this month'));
        }elseif ($type == 2) {
          echo $start_date = date(''.$year.' 00:00:00',strtotime('first day of this month'));
          echo $end_date = date(''.$year.' 23:59:59',strtotime('last day of this month'));
        }                

                


        
        list($data['confirmed'], $data['unconfirmed']) = $wallet->getBalance();      
        $tx = $wallet->transactions(1,2);

        //print_r($tx);die;
        $data['total'] = $data['confirmed']+$data['unconfirmed'];
        $data['result'] = $data['total'];
        $data['total'] = $tx['total'];
        $data['per_page'] = $tx['per_page'];
        $data['current_page'] = $tx['current_page'];

        if (!empty($tx)) {
          
          $pages = $this->common_model->count($tx['total'],$tx['per_page'],$tx['current_page']);
          for ($i=1; $i < $pages+1; $i++) {
            $txs = $wallet->transactions($i,2,DESC);
            $trax = $txs['data'];
            foreach ($trax as $traxs) {
              //print_r($traxs);//die;

              // $date =  date("Y-m-d");
              // $week = (int)date('W', $date);

                // $ddate = date("Y-m-d H:i:s");
                // $date = new DateTime($ddate);
                // $week = $date->format("W");
                // $month = $date->format("M");
                // $year = $date->format("Y");                
                // $weeks = $this->getStartAndEndDate($week, $year);
                
                
                //die;










              if ($todate <= $traxs['time'] && $fromdate >= $traxs['time'] ) {
              
                $data['result'] = $data['result'] - $traxs['wallet_value_change'];
                $data['data'][] = array('hash' => $traxs['hash'],                
                                        'total_fee' => $traxs['total_fee'],
                                        'wallet_value_change' => $traxs['wallet_value_change'],
                                        'previous_balance' => $data['result'],            
                                        'transactions_balance' => $traxs['wallet']['balance'],
                                        'available_balance' => $data['result']+ $traxs['wallet']['balance'],            
                                        'date' => date("Y-m-d", $traxs['time']),
                                        'time' => date("Y-m-d H:i:s", $traxs['time']),
                                        // 'value0' => $traxs['outputs'][0]['value'],
                                        // 'value1' => $traxs['outputs'][1]['value']?$traxs['outputs'][1]['value']:"",
                                        // 'address' => $traxs['addresses'],                 
                                        // 'addresses' => $traxs['wallet']['addresses'],
                                        // 'time1' => $traxs['time'],
                                        );
              //print_r($data);die;
              }
            }
          }
        }//die;
        //$result = array_reverse($data);
        $resp = Results(200,$data, "Success");
 
        }else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*Over View in XAF*/
    public function overViewXAF_post(){


      $input = $this->param;
      $required = array('user_id','deviceid');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $result = all_Data('wp_trade_order_history', array('user_id' => $user_id));
        print_r($result);die;
        $resp = Results(200,$data, "Success");
 
      }else{
        $resp = $Error;
      }
      $this->response($resp);      
    }
    /*SEND FIAT TO FIAT*/
    public function sendFTF_post(){

      $input = $this->param;   
      $required = array('user_id','deviceid','address','xafamount');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){
        $user_id = $input['user_id'];
        $note = $input['note'];
        /*Sender momonum*/
        $momonum = $this->momonum($user_id);
        $sender_name = $this->userName($user_id);
        /*Reciver momonum */
        $momoAddress = $input['address'];

        $data = array();
        $data['transfer_amount'] = $input['xafamount'];
        $data['fullname'] = $sender_name;
        $data['senderMsisdn'] = /*$momoAddress;//*/$momonum;
        $data['reciverMsisdn'] = $momoAddress;
        $data['user_id'] = $user_id;

        $pemfile = $_SERVER['DOCUMENT_ROOT'].'certificates_MTN/client_certnew.pem';

        $response_array = $this->common_model->transferBTC($data);

        if ($response_array['StatusCode'] == 1000) {
          $information =array('user_id' => $user_id,
                              'recipient_name' => $sender_name,
                              'mtn_number' => substr($momonum,3),
                              'type'=> "Send",
                              'amount_in_xaf' => $input['xafamount'],         
                              'total_amount_in_xaf' => $input['xafamounts'],             
                              'payment_status' => 'pending',
                              'btc_status' => "pending",
                              'recipient_address' => $momoAddress,             
                              'OpCoID' => $response_array['OpCoID']?$response_array['OpCoID']:"",
                              'ProcessingNumber' => $response_array['ProcessingNumber'],
                              'MOMTransactionID' => $response_array['MOMTransactionID'],
                              //'our_fees_in_xaf' => $input['ourfees'],
                              //'network_fees_in_xaf' => $input['netfees'],
                              //'btc_amount_to_rec' => $input['btcamount'],
                              //'conversion_rate' => $input['convrate'],
                            );          
          $InsertId = insertData("wp_trade_order_history", $information);
          $resp = Results(200, array('order_id' => $InsertId), "Success");
        }else{
          $resp = Results(0, $response_array, "Error");

        }
        //print_r($response_array);die;
      }else{
        $resp = $Error;
      }
      $this->response($resp);
    }
    /*ALL WALLET LIST*/
    public function walletList_post(){

      try {        
        $client = $this->client();
        $wall = $client->allWallets();
        $wallet = $wall['data'];
        
        for ($i=0; $i < count($wallet); $i++) { 
          $wallets[] = array('WalletName' => $wallet[$i]['identifier'],
                            'Santoshi' => $wallet[$i]['balance'],
                            'Bitcoin' =>  BlocktrailSDK::toBTC($wallet[$i]['balance']),
                            'unc_Santoshi' => $wallet[$i]['unc_balance'],
                            'unc_Bitcoin' =>  BlocktrailSDK::toBTC($wallet[$i]['unc_balance']),
                            'tx_count' => $wallet[$i]['tx_cnt'],
                            'unc_tx_count' => $wallet[$i]['unc_tx_cnt']                            
                            );
        }

        $resp = Results(200,$wallets, "Success");

        $this->response($resp);       
      } catch (Exception $e) {

        $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }    
    }
    /*DEMO*/
    public function demo_post(){
      $input = $this->param;
      $txId = $input['id'];
      $client = $this->client();  

      // $user_id = $input['user_id'];
      // $walletIdent = $input['identifier'];
      // $walletPassword = $input['passpharse']?$input['passpharse']:WALLET_PASSWORD;
      // $wallet = $client->initWallet($walletIdent, $walletPassword);
      //print_r($wallet);die;
      //list($confirmed, $unconfirmed) = $wallet->doDiscovery(5);
      

      // $address = $input['address'];
      // $tx = $client->address($address);

      // $trax = $client->transaction($txId);
      // print_r($trax);die;
      // if (!empty($trax)) {
      //   //$trax = $tx['data'];
      //   //for ($i=0; $i < count($trax) ; $i++) {
      //     $result['time'] = $trax['first_seen_at'];//date("Y-m-d H:i:s", $trax['first_seen_at']);
      //     $result['total_input_value'] = $trax['total_input_value'];
      //     $result['total_fee'] = $trax['total_fee'];
      //     $result['output0svalue'] = $trax['outputs'][0]['value'];
      //     $result['outputs1value'] = $trax['outputs'][1]['value'];          
          
      //     $result['total'] = $result['outputs1value']+ $result['output0svalue']+ $result['total_fee'];
      //     $result['remain'] = $result['total_input_value']-$result['output0svalue']- $result['total_fee'];

      //     $result['total_output_value'] = $trax['total_output_value'];
      //     $result['inputsvalue'] = $trax['inputs'][0]['value'];

      //     $result['total_input_value_BTC'] = BlocktrailSDK::toBTC($trax['total_input_value']);
      //     $result['total_fee_BTC'] = BlocktrailSDK::toBTC($trax['total_fee']);
      //     $result['total_output_value_BTC']=BlocktrailSDK::toBTC($trax['total_output_value']);
          


      //   //}
      // }
      //print_r($result);die;



      //$tx = $wallet->getMaxSpendable();
      
      //$wallet = $this->walletAdmin($client);
      //$tx = $this->getTx($client, $txId);
      //$tx = $wallet->utxos(0, 23);
      //$transactions = $wallet->updateWallet(1, 23);
      // $txId = $input['id'];
      //$tx = $client->transaction($txId);
      $address = $client->address("2N58JuMDchfiMt3eD4VZJGPZE73qxyWyQSX"); 
      $resp = Results(200,$address,"Success");
      $this->response($resp);      
    }
    /*DEMO*/
    public function demo1_post(){
      $input = $this->param;
      $txId = $input['id'];
      $client = $this->client();      
      // $trax = $client->transaction($txId);
      //print_r($trax);die;
      // if (!empty($trax)) {
      //   //$trax = $tx['data'];
      //   //for ($i=0; $i < count($trax) ; $i++) {
      //     $result['time'] = $trax['first_seen_at'];//date("Y-m-d H:i:s", $trax['first_seen_at']);
      //     $result['total_input_value'] = $trax['total_input_value'];
      //     $result['total_fee'] = $trax['total_fee'];
      //     $result['output0svalue'] = $trax['outputs'][0]['value'];
      //     $result['outputs1value'] = $trax['outputs'][1]['value'];          
          
      //     $result['total'] = $result['outputs1value']+ $result['output0svalue']+ $result['total_fee'];
      //     $result['remain'] = $result['total_input_value']-$result['output0svalue']- $result['total_fee'];

      //     $result['total_output_value'] = $trax['total_output_value'];
      //     $result['inputsvalue'] = $trax['inputs'][0]['value'];

      //     $result['total_input_value_BTC'] = BlocktrailSDK::toBTC($trax['total_input_value']);
      //     $result['total_fee_BTC'] = BlocktrailSDK::toBTC($trax['total_fee']);
      //     $result['total_output_value_BTC']=BlocktrailSDK::toBTC($trax['total_output_value']);
          


      //   //}
      // }
      //print_r($result);die;

      $tx = $client->addressTransactions("2N58JuMDchfiMt3eD4VZJGPZE73qxyWyQSX");
      
      //$wallet = $this->walletAdmin($client);
      //$tx = $this->getTx($client, $txId);
      //$tx = $wallet->utxos(0, 23);
      //$transactions = $wallet->updateWallet(1, 23);
      // $txId = $input['id'];
      //$tx = $client->transaction($txId);
      

      $resp = Results(200,$tx, "Success");
      $this->response($resp);      
    }
    /*TEST*/
    public function Test_post(){
      global $wpdb;
      $input = $this->param; 
      $ProcessingNumber = $input['ProcessingNumber'];

      $rowdata = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE ProcessingNumber = '".$ProcessingNumber."'");
      //print_r($rowdata);//die;
      $user_id = $rowdata->user_id;
      //$amount = $rowdata->total_amount_in_xaf;
      $BTCreceiverAddress = $rowdata->recipient_address;
      $btc = $rowdata->amount_paid_btc;

        //Initialize Client
      $myAPIKEY     = get_option('blocktrail_api_key');


      
      $myAPISECRET  = get_option('blocktrailsecret');
      $testnet      = true;//false for bitcoin mainnet or true for testnet
      // Initialize the SDK
      $walletIdent    = get_option('testnet_wallet_identifier');
      $walletPassword = get_option('testnet_wallet_password');
      try { 
        $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
        } catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try { 
        $wallet = $client->initWallet($walletIdent,$walletPassword);
        } catch (Exception $e) {
        $this->response(Results(0,array(),"{$e->getMessage()}"));
      } 

      
      try {
        $satoshiamount = BlocktrailSDK::toSatoshi($btc);        
        $outputs = array($BTCreceiverAddress => $satoshiamount);
        
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
        $kb = $result['size']/1000;
        $am = (int)round($kb*$result['fees']['optimal']);      
        $txHash = $wallet->pay($outputs, null, true, true, Wallet::FEE_STRATEGY_OPTIMAL, $am);
        }catch (Exception $e) {

          $this->response(Results(0,array(),"{$e->getMessage()}"));       
      }
      if ($txHash) {
        $Update = $wpdb->query("UPDATE `wp_trade_order_history` SET  transaction_id = '".$txHash."', btc_status = '".Completed."' WHERE ProcessingNumber = '".$ProcessingNumber."'");
      }
      print_r($txHash);die;
     


    
      //$user_id = $rowdata->user_id;
    }
  /*______________________________________-Start-______________________*/


    /*CALCULATION BITCOIN*/    
    public function getCalulationAmount1_post(){

      $input = $this->param;

      $required = array('user_id','deviceid','amount','from_currency','change_currency','type');
      $Error = checkvalid($required, $input);
      if ($Error == "0"){

        $user_id = $input['user_id'];
        $amount = $input['amount'];
        $momonum = $this->momonum($user_id);
        $from = $input['from_currency'];
        $to = $input['change_currency'];
        $walletIdent = $input['identifier'];
        $walletPassword = $input['passpharse']?$input['passpharse']:"12345678";

        $client = $this->client();

        if ($from == "XAF" && $to == "BTC") {
        

          if ($input['type'] == "Buy" && !empty($walletIdent) && !empty($walletPassword)) {

            $network = $this->networkFees1($client,$walletIdent, $walletPassword, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }elseif ($input['type'] == "Sell") {

            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees1($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);

            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => $network['address']?$network['address']:"",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }else{
            
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees1($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => "",
                          'total_amount_btc' => "",
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
        }else{
          if ($input['type'] == "Buy" && !empty($walletIdent) && !empty($walletPassword)) {

            $network = $this->networkFees2($client,$walletIdent, $walletPassword, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }elseif ($input['type'] == "Sell") {

            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees2($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);

            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => number_format($network['xaf']-$network['our_fees']-$network['network_fees_in_xaf'], 2, '.', ''),
                          'total_amount_btc' => (string)($network['btc']-$network['our_fees_btc']-$network['network_fees_btc']),
                          'address' => $network['address']?$network['address']:"",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }else{
            
            $walletIdentAdmin = get_option('testnet_wallet_identifier'); 
            $walletPasswordAdmin = get_option('testnet_wallet_password');

            $network = $this->networkFees2($client,$walletIdentAdmin, $walletPasswordAdmin, $amount,$from,$to);
            $data = array('xaf' => $network['xaf']?$network['xaf']:"",
                          'btc' => $network['btc']?$network['btc']:"",
                          'our_fees' => $network['our_fees']?$network['our_fees']:"",
                          'our_fees_btc' => $network['our_fees_btc']?$network['our_fees_btc']:"",
                          'network_fees'=> number_format($network['network_fees_in_xaf']),
                          'network_fees_btc'=> (string)$network['network_fees_in_btc']?$network['network_fees_in_btc']:"",
                          'total_amount' => "",
                          'total_amount_btc' => "",
                          'address' => "",
                          'rate' => (string)$network['rate'],                      
                          'momonum' => $momonum
                          );
          }
        }

        $resp = Results(200 ,$data,"Success");
        
      }else{
        $resp = $Error;
      }
      $this->response($resp);    
    }


    private function networkFees1($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC'){

      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);
      $btc = convert_exponantial_to_decimal($btcamountRecieved);

      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      { $trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', ''); }

       $trade_fee = get_conversion_bitcoin_with_amount('XAF','BTC', $trade_fees);
       $trade_fees_btc = convert_exponantial_to_decimal($trade_fee);

      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try {
        // Or you can initialize an already existing wallet
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));

        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      $balance = $this->getBalance($wallet);
      
      $fees = array('xaf'=> $amount,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'btc'=> $btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'our_fees_btc'=> $trade_fees_btc,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );

      
      return $fees;
    }


    private function networkFees2($client,$walletIdent, $walletPassword, $amount, $from='XAF', $to='BTC'){

      $rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);      
      $btcamountRecieved = get_conversion_bitcoin_with_amount($from, $to, $amount);
      //echo $btc = convert_exponantial_to_decimal($btcamountRecieved);die;
      $btc = $amount;
      $xaf = number_format($btcamountRecieved);


      $tradeFees = get_option('trade_fees');        
      $trade_fees = 0.00;        
      if(!empty($tradeFees))
      {
        $trade_fees = number_format(($xaf*$tradeFees)/100, 2, '.', '');
        $trade_fees_btc = convert_exponantial_to_decimal(($amount*$tradeFees)/100); 
      }

      try {
        // Or you can initialize an already existing wallet
        $wallet = $client->initWallet($walletIdent, $walletPassword);
        
        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      try {
        // Or you can initialize an already existing wallet
        $address = $wallet->getNewAddress();        
        $toSatoshi = BlocktrailSDK::toSatoshi($btc);          
        $outputs = array($address => $toSatoshi);
        $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);  
          
        $kb = $result['size']/1000;          
        $am = (int)round($kb*$result['fees']['optimal']);
        $network_fees_in_btc = BlocktrailSDK::toBTC($am);
        
        $network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));

        } catch (Exception $e) {
          $this->response(Results(0,array(),"{$e->getMessage()}"));
      }
      $balance = $this->getBalance($wallet);


      $fees = array('xaf'=> $xaf,
                    'network_fees_in_xaf'=> $network_fees_in_xaf,
                    'our_fees' => $trade_fees,
                    'btc'=> $btc,
                    'network_fees_in_btc' => $network_fees_in_btc,
                    'our_fees_btc'=> $trade_fees_btc,
                    'rate' => (string)$rate,
                    'balance' => $balance['btc'],
                    'address' => $address,
                    'wallet' => $wallet                   
                    );
      
      // $fees = array('btc'=>$btc,
      //               'network_fees_in_btc' => $network_fees_in_btc,
      //               'trade_fees_btc'=> $trade_fees_btc,
      //               'network_fees_in_xaf'=> $network_fees_in_xaf,
      //               'our_fees' => $trade_fees,
      //               'rate' => (string)$rate,
      //               'balance' => $balance['btc'],
      //               'address' => $address,
      //               'wallet' => $wallet                   
      //               );
      
      return $fees;
    }






}