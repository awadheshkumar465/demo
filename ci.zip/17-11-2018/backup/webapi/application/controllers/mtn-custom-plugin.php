<?php
/**
 * Plugin Name: MTN Custom Plugin
 * Plugin URI: http://votivetech.com
 * Description: This plugin have features mtn rechrage and transfer money between mtn wallet.
 * Version: 1.0.0
 * Author: Yogesh Rathore
 * Author URI: http://votivetech.com
 */
 
// add css/js files

define( 'MY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
require $_SERVER['DOCUMENT_ROOT'].'blocktrail/vendor/autoload.php';
include $_SERVER['DOCUMENT_ROOT'].'phpqrcode/qrlib.php';

use Blocktrail\SDK\BlocktrailSDK;
use Blocktrail\SDK\Wallet;

function setup_plugin_files(){
	
   
	wp_enqueue_style('styles', plugin_dir_url(__FILE__) . 'css/styles.css');
	wp_enqueue_style('normalize', plugin_dir_url(__FILE__) . 'css/normalize.css');
	wp_enqueue_style('main', plugin_dir_url(__FILE__) . 'css/main.css');
	wp_enqueue_style('jquery.steps', plugin_dir_url(__FILE__) . 'css/jquery.steps.css');
    wp_enqueue_style( 'jquery-ui-datepicker-style' , '//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css');
    wp_enqueue_style('style', plugin_dir_url(__FILE__) . 'css/style.css');
	wp_enqueue_style('bootstrap', plugin_dir_url(__FILE__) . 'css/bootstrap.css');
	wp_enqueue_style('intlTelInput', plugin_dir_url(__FILE__) . 'css/intlTelInput.css');
	
	


	
	wp_enqueue_script('jquery.udselect', plugin_dir_url(__FILE__) . 'js/jquery.udselect.js');
	wp_enqueue_script('jquery.steps', plugin_dir_url(__FILE__) . 'js/jquery.steps.js');
	wp_enqueue_script( 'jquery-ui-datepicker' );
	wp_enqueue_script('intlTelInput', plugin_dir_url(__FILE__) . 'js/intlTelInput.js');
	wp_enqueue_script('utils', plugin_dir_url(__FILE__) . 'js/utils.js');
	
	wp_enqueue_script('intlTelInput', plugin_dir_url(__FILE__) . 'js/intlTelInput.js');
	wp_enqueue_script('utils', plugin_dir_url(__FILE__) . 'js/utils.js');
	wp_enqueue_script('modernizr.custom', plugin_dir_url(__FILE__) . 'js/modernizr.custom.js');
	wp_enqueue_script('jquery.signaturepad.min', plugin_dir_url(__FILE__) . 'js/jquery.signaturepad.min.js');
	
	wp_enqueue_script('klukt', 'https://klukt.com/klukt.js');
	wp_enqueue_script('jquerysession', plugin_dir_url(__FILE__) . 'js/jquerysession.js');
	wp_enqueue_script('mtn-custom', plugin_dir_url(__FILE__) . 'js/mtn-custom-script-all.js');
	
	
}
add_action('wp_head', 'setup_plugin_files' );


//plugin submenu page
function mtn_settings_plugin_menu() {
    
  add_submenu_page( 'options-general.php', 'MTN Settings', 'MTN Settings', 'manage_options','mtn-settings-identifier', 'mtn_settings_function' );
}

add_action( 'admin_menu', 'mtn_settings_plugin_menu' );

function mtn_settings_function(){
	
	global $wpdb;
	
	// set settings
	        $recharge_limit = $without_identification_recharge_limit = $currency_coversion_rate =  $currency_coversion_rate2 = $currency_coversion_rate3 = $transfer_limit = $disable_recharge_feature = $disable_mtn_registration_feature = '';
			if( isset($_POST['settingSave'] ) ){
				$recharge_limit = $_POST['recharge_limit'];
				$without_identification_recharge_limit = $_POST['without_identification_recharge_limit'];
                $currency_coversion_rate = $_POST['currency_coversion_rate'];
				
				$currency_coversion_rate1 = $_POST['currency_coversion_rate1'];
				
				$transfer_limit = $_POST['transfer_limit'];
				$disable_recharge_feature = $_POST['disable_recharge_feature'];
				$disable_mtn_registration_feature = $_POST['disable_mtn_registration_feature'];
				
				if($disable_recharge_feature == 0)
				{
					get_fresdesk_open_tickets('Notify me when Recharge service back online');
				}
				
				if($disable_mtn_registration_feature == 0)
				{
					get_fresdesk_open_tickets('Notify me when next MTN Registration slot is available');
				}

               
				if($disable_recharge_feature == 1 && get_option( 'disable_recharge_feature') == 0 )
				{
					$allUsers = get_users();
					foreach($allUsers as $user){
						
						  update_user_meta($user->ID, 'notifiedMe', 0);
					}
				}
                
                if($disable_mtn_registration_feature == 1 && get_option( 'disable_mtn_registration_feature') == 0 )
				{
					$allUsers = get_users();
					foreach($allUsers as $user){
						
						update_user_meta($user->ID, 'mtnNotifiedMe', 0);	
					}
				}				
                				
				
				update_option( 'recharge_limit', $recharge_limit );
				update_option('without_identification_recharge_limit', $without_identification_recharge_limit);
				update_option( 'currency_coversion_rate', $currency_coversion_rate );
				update_option( 'currency_coversion_rate1', $currency_coversion_rate1 );
				
				update_option( 'transfer_limit', $transfer_limit );
				
				update_option( 'disable_recharge_feature', $disable_recharge_feature );
				update_option( 'disable_mtn_registration_feature', $disable_mtn_registration_feature );
				
			}else{
				
				$recharge_limit = get_option('recharge_limit');
                $without_identification_recharge_limit = get_option('without_identification_recharge_limit');					
                $currency_coversion_rate = get_option('currency_coversion_rate');
				$currency_coversion_rate1 = get_option('currency_coversion_rate1');
				
                $transfer_limit = get_option('transfer_limit');
                $disable_recharge_feature = get_option('disable_recharge_feature');	
                $disable_mtn_registration_feature = get_option('disable_mtn_registration_feature');				
			}
			
			
			//distance limit
			
			$distance_limit = get_option('distance_limit');
			$distance_key = get_option('distance_key');
			
			if( isset($_POST['settingDistanseSave'] ) ){
				
				$distance_limit = $_POST['distance_limit'];
                $distance_key = $_POST['distance_key'];
				
				update_option( 'distance_limit', $distance_limit );
				update_option( 'distance_key', $distance_key );
				
				
			}
			
			
			//Trade Settings
			
			$trade_btcamount_xaf_limit = get_option('trade_btcamount_xaf_limit');
			$trade_fees = get_option('trade_fees');
			
			if( isset($_POST['settingTradeSave'] ) ){
				
				$trade_btcamount_xaf_limit = $_POST['trade_btcamount_xaf_limit'];
                $trade_fees = $_POST['trade_fees'];
				
				update_option( 'trade_btcamount_xaf_limit', $trade_btcamount_xaf_limit );
				update_option( 'trade_fees', $trade_fees );
				
				
			}
			
			
			//permission for dashboard statics
			
			
			if( isset($_POST['settingPerDash'] ) ){
				
				$mtn_user_id_save = $_POST['mtn_user_id_save'];
                $mtn_dash_perm = $_POST['mtn_dash_perm'];
				
				
				update_user_meta( $mtn_user_id_save, 'mtn_dash_perm', $_POST['mtn_dash_perm'] );
				
				
			}
			$permis = '';
			$mtn_user_id = $mtn_user_email = '';
			if( isset($_POST['checkStatusPerDash'] ) ){
				
				$mtn_user_email = $_POST['mtn_user_id'];
				$user = get_user_by( 'email', $mtn_user_email );
                $mtn_user_id = $user->ID;
				$permis = get_user_meta( $mtn_user_id, 'mtn_dash_perm', true);
				if(empty($permis)){$permis = 'off';}
				
			}
			
			//cron url secure code
			$secure_code = get_option('secure_code');
			if( isset($_POST['settingMtnCronUrl'] ) ){
				
				$secure_code = $_POST['secure_code'];
				update_option( 'secure_code', $secure_code );
				
			}
			
			// rewards settings
			$rewards_activate = $number_recharge_get_reward = $validity_default_year = $clR = '';
			if( isset($_POST['settingRewardsSave'] ) ){
				$rewards_activate = $_POST['rewards_activate'];
                $number_recharge_get_reward = $_POST['number_recharge_get_reward'];
				$validity_default_year = $_POST['validity_default_year'];
				
				 if($rewards_activate == 'yes')
                {
					$clR = 'display:block;';
					update_option( 'rewards_activate', $rewards_activate );
				}
                else
                {
					$clR = 'display:none;';
					update_option( 'rewards_activate', '' );
				}
				
				
				update_option( 'number_recharge_get_reward', $number_recharge_get_reward );
				update_option( 'validity_default_year', $validity_default_year );
				
			}else{
				
				$rewards_activate = get_option('rewards_activate');	
                $number_recharge_get_reward = get_option('number_recharge_get_reward');	
				$validity_default_year = get_option('validity_default_year');
				
                if($rewards_activate == 'yes')
                {
					$clR = 'display:block;';
				}
                else
                {
					$clR = 'display:none;';
				}	
                			
			}
			
			
			
			//Trade fees for Sell
			
			if(isset($_POST['settingTradeSellSave'] ) ){
				
				
				$trade_fees_xaf = $_POST['trade_fees_xaf'];
				
				
				update_option( 'trade_fees_xaf', $trade_fees_xaf );
				
				
				
			}
				
				$trade_fees_xaf = get_option('trade_fees_xaf');
				
				
			
			
			//bitstamp api
			
			if(isset($_POST['settingBitStampGatewaySave'] ) ){
				$bitstamp_client_id = $_POST['bitstamp_client_id'];
				$bitstamp_key = $_POST['bitstamp_key'];
				$bitstamp_secret = $_POST['bitstamp_secret'];
				
				
				
				update_option( 'bitstamp_client_id', $bitstamp_client_id );
				update_option( 'bitstamp_key', $bitstamp_key );
				update_option( 'bitstamp_secret', $bitstamp_secret );
			
				
			}
	  
	  
				
				$bitstamp_client_id = get_option('bitstamp_client_id');
				$bitstamp_key = get_option('bitstamp_key');
				$bitstamp_secret = get_option('bitstamp_secret');				
				
			
			//Sell Order Variable
			
			if(isset($_POST['settingSellOrderSave'] ) ){
				$sell_order_var = $_POST['sell_order_var'];
				
				update_option( 'sell_order_var', $sell_order_var );
				
			}
	           $sell_order_var = get_option('sell_order_var');
				
			
			//blocktrail api
			
			if(isset($_POST['settingBlockTrailGatewaySave'] ) ){
				$blocktrail_api_key = $_POST['blocktrail_api_key'];
				$blocktrailsecret = $_POST['blocktrailsecret'];
				$blocktrail_mode = $_POST['blocktrail_mode'];
				$live_wallet_identifier = $_POST['live_wallet_identifier'];
				$live_wallet_password = $_POST['live_wallet_password'];
				$testnet_wallet_identifier = $_POST['testnet_wallet_identifier'];
				$testnet_wallet_password = $_POST['testnet_wallet_password'];
				
				
				update_option( 'blocktrail_api_key', $blocktrail_api_key );
				update_option( 'blocktrailsecret', $blocktrailsecret );
				update_option( 'blocktrail_mode', $blocktrail_mode );
				update_option( 'live_wallet_identifier', $live_wallet_identifier );
				update_option( 'live_wallet_password', $live_wallet_password );
				update_option( 'testnet_wallet_identifier', $testnet_wallet_identifier );
				update_option( 'testnet_wallet_password', $testnet_wallet_password );
				
			}
				
				$blocktrail_api_key = get_option('blocktrail_api_key');
				$blocktrailsecret = get_option('blocktrailsecret');
				$blocktrail_mode = get_option('blocktrail_mode');				
				$live_wallet_identifier = get_option('live_wallet_identifier');
                $live_wallet_password = get_option('live_wallet_password');
				$testnet_wallet_identifier = get_option('testnet_wallet_identifier');
				$testnet_wallet_password = get_option('testnet_wallet_password');
                				
			
			
			
			//bitcoin details
			if( isset($_POST['settingBitcoinGatewaySave'] ) ){
				$bitcoin_klukt_url = $_POST['bitcoin_klukt_url'];
				$bitcoinApiKey = $_POST['bitcoinApiKey'];
				$bitcoinCurrency = $_POST['bitcoinCurrency'];
				$bitcoin_ipn_url = $_POST['bitcoin_ipn_url'];
				$confirmations_limit = $_POST['confirmations_limit'];
				
				
				update_option( 'bitcoin_klukt_url', $bitcoin_klukt_url );
				update_option( 'bitcoinApiKey', $bitcoinApiKey );
				update_option( 'bitcoinCurrency', $bitcoinCurrency );
				update_option( 'bitcoin_ipn_url', $bitcoin_ipn_url );
				update_option( 'confirmations_limit', $confirmations_limit );
				
			}else{
				$bitcoin_klukt_url = get_option('bitcoin_klukt_url');
				$bitcoinApiKey = get_option('bitcoinApiKey');
				$bitcoinCurrency = get_option('bitcoinCurrency');				
				$bitcoin_ipn_url = get_option('bitcoin_ipn_url');
                $confirmations_limit = get_option('confirmations_limit');
                				
			}
			
			 
			if( isset($_POST['settingBitcoinSave'] ) ){
				$bitcoin_public_key = $_POST['bitcoin_public_key'];
                $bitcoin_secret_key = $_POST['bitcoin_secret_key'];
				
				
				update_option( 'bitcoin_public_key', $bitcoin_public_key );
				update_option( 'bitcoin_secret_key', $bitcoin_secret_key );
				
			}else{
				$bitcoin_public_key = get_option('bitcoin_public_key');	
                $bitcoin_secret_key = get_option('bitcoin_secret_key');
                				
			}
			$result_bitcoin = '';
			if( isset($_POST['convert_bitcoin'] ) ){
				 
				$bitcoin_from = $_POST['bitcoin_from'];
                $bitcoin_to = $_POST['bitcoin_to'];
				
				
				$result_bitcoin = get_conversion_bitcoin($bitcoin_from, $bitcoin_to);
				
				
			}
			
			
			
			//paypal fees
			if( isset($_POST['paypalSettingSave'] ) ){
				$paypal_bussness_email = $_POST['paypal_bussness_email'];
                $tax_fees = $_POST['tax_fees'];
				$extra_fees = $_POST['extra_fees'];
				
				update_option( 'paypal_bussness_email', $paypal_bussness_email );
				update_option( 'tax_fees', $tax_fees );
				update_option( 'extra_fees', $extra_fees );
			}else{
				$paypal_bussness_email = get_option('paypal_bussness_email');	
                $tax_fees = get_option('tax_fees');
                $extra_fees = get_option('extra_fees');					
			}
			
			
			if(isset($_POST['mtnApiSettingSave'])){
				
				$sp_id = $_POST['sp_id'];
				$sp_password = $_POST['sp_password'];
				$testbed_ip = $_POST['testbed_ip'];
				$service_id = $_POST['service_id'];
				
                update_option( 'sp_id', $sp_id );
				update_option( 'sp_password', $sp_password );
				update_option( 'testbed_ip', $testbed_ip );
				update_option( 'service_id', $service_id );
			}else{
				
				$sp_id = get_option('sp_id');	
                $sp_password = get_option('sp_password');
				$testbed_ip = get_option('testbed_ip');	
                
				$service_id = get_option('service_id');					
			}			
				
			
			if( isset($_POST['merchantSettingSave'] ) ){
				
				$project_id = $_POST['project_id'];
				$partner_pass = $_POST['partner_pass'];
				$customer_id = $_POST['customer_id'];
				$sofort_api_key = $_POST['sofort_api_key'];
				
                
				
					
				update_option( 'project_id', $project_id );
				update_option( 'partner_pass', $partner_pass );
				update_option( 'customer_id', $customer_id );
				update_option( 'sofort_api_key', $sofort_api_key );
				
				
				
				
				
			}else{
				
				
               
				$project_id = get_option('project_id');
                $partner_pass = get_option('partner_pass');	
				$customer_id = get_option('customer_id');
                $sofort_api_key = get_option('sofort_api_key');	
									
			}
			
			//freshdeskSettingSave
			if( isset($_POST['freshdeskSettingSave'] ) ){
				$freshdesk_login_url = $_POST['freshdesk_login_url'];
				$freshdesk_email = $_POST['freshdesk_email'];
				$freshdesk_password = $_POST['freshdesk_password'];
				$freshdesk_file_password = $_POST['freshdesk_file_password'];
				
                
				
				update_option( 'freshdesk_login_url', $freshdesk_login_url );
				update_option( 'freshdesk_email', $freshdesk_email );
				update_option( 'freshdesk_password', $freshdesk_password );
				update_option( 'freshdesk_file_password', $freshdesk_file_password );
				
				
				
				
				
				
			}else{
				
				$freshdesk_login_url = get_option('freshdesk_login_url');	
                $freshdesk_email = get_option('freshdesk_email');
				$freshdesk_password = get_option('freshdesk_password');
				$freshdesk_file_password = get_option('freshdesk_file_password');
                
									
			}
			$status1_count1 = $status1_count2 = $status1_count3 = $freshdesk_flag = 0;  
			$status2_count1 = $status2_count2 = $status2_count3 = 0;
			if(isset($_POST['freshdeskSettingtrigger']))
			{
				    $freshdesk_flag = 1;
					$blogusers = get_users( 'blog_id=1&orderby=nicename' );
					// Array of WP_User objects.
					foreach ( $blogusers as $user ) {
					 $currntStatus = get_user_meta($user->ID, 'diaspo_pdf_status', true);	
					
					 
					 if($currntStatus == 'Submitted')	
					  {
						$status = get_freshdeck_status($user->user_email, 'MTN SIM Card Shipping Request');
						if($status == 4 || $status == 5)
						{
							$status1_count1++;
							update_user_meta($user->ID, 'diaspo_pdf_status', 'SIM Card has been shipped');
							date_default_timezone_set('CET');
                            update_user_meta($user->ID , 'status_change_date', 'Y/m/d' );
							
							
							
						} 	
					  }
					  else if($currntStatus == 'SIM Card Pending')
					  {
						$status = get_freshdeck_status($user->user_email, 'New MTN Registration Request');
						if($status == 4 || $status == 5)
						{
							$status2_count1++;
							update_user_meta($user->ID, 'diaspo_pdf_status', 'SIM Card Registered');
						}  
						  
					  }
					  else
					  {
						  
						  
					  }			  
		
		            }
					
						$data = get_freshdeck_all_status_counts(); 
						
						
						foreach($data as $currentData)
						{
							
							if($currentData['subject'] == 'MTN SIM Card Shipping Request')
							{
								if($currentData['status'] == 3){$status1_count3++;}
								elseif($currentData['status'] == 2){$status1_count2++;}
								else{}
							}
							else if($currentData['subject'] == 'New MTN Registration Request')
							{
								if($currentData['status'] == 3){$status2_count3++;}
								elseif($currentData['status'] == 2){$status2_count2++;}
								else{}
							}
							else
							{
								
							}			

							
						}	
					
					
				
			}	
			
			//sms setting Save
			if( isset($_POST['smsSettingSave'] ) ){
				$account_sid_live = $_POST['account_sid_live'];
				$auth_token_live = $_POST['auth_token_live'];
				$account_sid_test = $_POST['account_sid_test'];
				$auth_token_test = $_POST['auth_token_test'];
				$from_number = $_POST['from_number'];
				$body_message = $_POST['body_message'];
				
                
				
				update_option( 'account_sid_live', $account_sid_live );
				update_option( 'auth_token_live', $auth_token_live );
				update_option( 'account_sid_test', $account_sid_test );
				update_option( 'auth_token_test', $auth_token_test );
				update_option( 'from_number', $from_number );
				update_option( 'body_message', $body_message );
				
				
				
				
				
			}else{
				
				$account_sid_live = get_option('account_sid_live');	
                $auth_token_live = get_option('auth_token_live');
				$account_sid_test = get_option('account_sid_test');
                $auth_token_test = get_option('auth_token_test');	
				$from_number = get_option('from_number');
                $body_message = get_option('body_message');	
									
			}
			
			if(isset($_GET['delId']) && !empty($_GET['delId']))
			{
				
				$id = $_GET['delId'];
				$wpdb->query("DELETE FROM `wp_add_fees_recharge` WHERE id = '".$id."'");	
				
			}
            $method1 = $method2 = $method3 = $paymentsData = '';				
			if( isset($_POST['add_payment_method']) ){
				$methods = $_POST['payment_method'];
				$count = 0;
				foreach($methods as $method)
				{
					if($method == 'paypal')
					{
						$method1 = 'yes';
					}
                    elseif($method == 'sofort')	
                    {
						$method2 = 'yes';
					}
                    else
                    {
						$method3 = 'yes';
					}						
				   if($count == 0)
				   {
					 $paymentsData =  $method; 
				   }
				   else
				   {
					 $paymentsData .=  ','.$method;  
				   }
                   $count++;				   
				}
				
				update_option( 'payment_methods', $paymentsData );
				
			}
            else
			{
				$methods = explode(',',get_option('payment_methods'));
				foreach($methods as $method)
				{
					if($method == 'paypal')
					{
						$method1 = 'yes';
					}
                    elseif($method == 'sofort')	
                    {
						$method2 = 'yes';
					}
                    else
                    {
						$method3 = 'yes';
					}						
				  				   
				}
				
			}	
			// fwt and set fees
			if( isset($_POST['add_fees_recharge']) ){
				
				
				if(!empty($_POST['fees_id']))
				{
				  $id = $_POST['fees_id'];
				  $wpdb->query("UPDATE `wp_add_fees_recharge` SET amount_in_min = '".$_POST['amount_in_min']."', amount_in_max = '".$_POST['amount_in_max']."', recharge_fees = '".$_POST['recharge_fees']."' WHERE id = '".$id."'");	
				
				}	
			    else
			    {
				  $wpdb->query("INSERT INTO `wp_add_fees_recharge` (id, amount_in_min, amount_in_max, recharge_fees) VALUES('', '".$_POST['amount_in_min']."', '".$_POST['amount_in_max']."', '".$_POST['recharge_fees']."')");	
				
				}		 
			    
				
			
			
			
			    $recharge_fees = $wpdb->get_results("SELECT * FROM `wp_add_fees_recharge` ORDER BY id ASC");
				
				
				
			} else {
				$recharge_fees = $wpdb->get_results("SELECT * FROM `wp_add_fees_recharge` ORDER BY id ASC");		
			}
			
		?>
<script type="text/javascript">

jQuery(window).bind('load', function() {
    jQuery('#rewards_activate').click(function(){
		
		 if(jQuery(this).is(':checked'))
           jQuery('.rewData').show();
         else
          jQuery('.rewData').hide();
		
	});
 });       
		    function valpaymentform()
            {
					
				if(jQuery('[name="payment_method[]"]:checked').length > 0)
				{
					return true;
				}
				else
				{
					alert("Please enabled atleast one payment method checkbox");
					return false;
				}	
                    			
            }
            

			function update_fees(id)
			   {
			      
                       
	                    if(id!='')
						{
							jQuery('.add_fees_recharge').val('Update Fees');
                            jQuery('#fees_id').val(id);
                            jQuery('#amount_in_min').val(jQuery('#fees_'+id+' .a_min').html());
                            jQuery('#amount_in_max').val(jQuery('#fees_'+id+' .a_max').html());
                            jQuery('#recharge_fees').val(jQuery('#fees_'+id+' .a_fees').html());							
				            
				        }
				
			  }
			function delete_fees(id){
				url = jQuery('#delUrl').val();
				var r=confirm("Do you want to delete this?")
				if (r==true)
				  window.location = url+"&delId="+id;
				else
				  return false;
				
			}  
			
			function checkRewards(){
				var number_recharge_get_reward = jQuery('#number_recharge_get_reward').val();
				if(number_recharge_get_reward > 10)
				{
					alert('you can not add more than 10!');
					jQuery('#number_recharge_get_reward').val('');
					return false;
				}
                else
                {
					return true;
				}					
			}
				 
	    </script>
<?php
		echo '<div class="wrap "><div id="icon-tools" class="icon32"></div>';
			echo '<h2>'. __( 'MTN Options', 'softsdev' ) .'</h2>';
?>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Permission for Dashboard Statics:', 'mtn-recharge' ); ?></h3>
  
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      
      <tr>
        <td><span>Enter User Email: </span> <input name="mtn_user_id" value="<?php echo $mtn_user_email; ?>" required/>
		</td>
        <td></td>
      </tr>
	  <tr>
        <td><input type="submit" name="checkStatusPerDash" class="button-large button-primary" value="Edit Permission"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <?php if(!empty($permis)){ ?>
  <br>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <input type="hidden" name="mtn_user_id_save" value="<?php echo $mtn_user_id; ?>" />
     
	  <tr style="<?php echo $clR; ?>" class="rewData">
        <td><span>Give Permission: </span> Yes <input type="radio" name="mtn_dash_perm" <?php if($permis == 'on'){ echo 'checked'; } ?> value="on" />   No <input type="radio" name="mtn_dash_perm" <?php if($permis == 'off'){ echo 'checked'; } ?> value="off" /> </td>
        <td></td>
      </tr>
      <tr>
        <td><input type="submit" name="settingPerDash" class="button-large button-primary" value="Update Permission"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <?php } ?>
  
</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Hotspots Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Distance Limit (in KM): </span></td>
        <td><input type="text" value="<?php echo $distance_limit; ?>" name="distance_limit" /> KM</td>
      </tr>
      <tr>
        <td><span>Distance API Key: </span></td>
        <td><input type="text" value="<?php echo $distance_key; ?>" name="distance_key" style="width:300px;" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="settingDistanseSave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Trade Bitcoin Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Trade Bitcoin Amount Limit (in XAF): </span></td>
        <td><input type="text" value="<?php echo $trade_btcamount_xaf_limit; ?>" name="trade_btcamount_xaf_limit" /></td>
      </tr>
      <tr>
        <td><span>Trade Fees: </span></td>
        <td><input type="text" value="<?php echo $trade_fees; ?>" name="trade_fees" /> %</td>
      </tr>
      <tr>
        <td><input type="submit" name="settingTradeSave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Recharge/Transfer Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Recharge Limit(in XAF): </span></td>
        <td><input type="text" value="<?php echo $recharge_limit; ?>" name="recharge_limit" /></td>
      </tr>
	  <tr>
        <td><span>Recharge Limit(in XAF: without identification): </span></td>
        <td><input type="text" value="<?php echo $without_identification_recharge_limit; ?>" name="without_identification_recharge_limit" /></td>
      </tr>
      <tr>
        <td><span>Currency Coversion Rate(1 EUR = </span></td>
        <td><input type="text" value="<?php echo $currency_coversion_rate; ?>" name="currency_coversion_rate" />
          XAF</td>
      </tr>
	  <tr>
        <td><span>Currency Coversion Rate(1 EUR= </span></td>
        <td><input type="text" value="<?php echo $currency_coversion_rate1; ?>" name="currency_coversion_rate1" />
          USD</td>
      </tr>
	 
      <tr>
        <td><span>Transfer Limit(in XAF) in 1 day: </span></td>
        <td><input type="text" value="<?php echo $transfer_limit; ?>" name="transfer_limit" /></td>
      </tr>
	  
	  <tr>
        <td><span>Recharge Service: </span></td>
        <td>Enable <input type="radio" value="0" <?php if($disable_recharge_feature == 0){ echo 'checked';}?> name="disable_recharge_feature" />  Disable <input type="radio" value="1" <?php if($disable_recharge_feature == 1){ echo 'checked';}?> name="disable_recharge_feature" /></td>
      </tr>
	  
	   <tr>
        <td><span>MTN Registration Service: </span></td>
        <td>Enable <input type="radio" value="0" <?php if($disable_mtn_registration_feature == 0){ echo 'checked';}?> name="disable_mtn_registration_feature" />  Disable <input type="radio" value="1" <?php if($disable_mtn_registration_feature == 1){ echo 'checked';}?> name="disable_mtn_registration_feature" /></td>
      </tr>
	  
	  
	  
      <tr>
        <td><input type="submit" name="settingSave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Cronjob URL secure code::', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Secure Code: </span> <input type="text" value="<?php echo $secure_code; ?>"  name="secure_code" id="secure_code" /></td>
        <td></td>
      </tr>
    
      <tr>
        <td><input type="submit" name="settingMtnCronUrl" class="button-large button-primary" onclick="return checkRewards();" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Rewards for Recharge Mobile Money Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Rewards Activate: </span> <input type="checkbox" <?php if($rewards_activate == 'yes'){?> checked <?php } ?> value="yes"  name="rewards_activate" id="rewards_activate" /></td>
        <td></td>
      </tr>
      <tr style="<?php echo $clR; ?>" class="rewData">
        <td><span>Number of recharge necessary to get a reward: </span> <input type="text" id="number_recharge_get_reward" name="number_recharge_get_reward" value="<?php echo $number_recharge_get_reward; ?>" required/></td>
        <td></td>
      </tr>
	  <tr style="<?php echo $clR; ?>" class="rewData">
        <td><span>Validity Defaul Months: </span> <input type="text" id="validity_default_year" name="validity_default_year" value="<?php echo $validity_default_year; ?>" required/></td>
        <td></td>
      </tr>
      <tr>
        <td><input type="submit" name="settingRewardsSave" class="button-large button-primary" onclick="return checkRewards();" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Trade Fees for Sell:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
     
      <tr>
        <td><span>Fees (in XAF): </span> <input type="text" id="trade_fees_xaf" name="trade_fees_xaf" value="<?php echo $trade_fees_xaf; ?>" required/></td>
        <td></td>
      </tr>
	
      <tr>
        <td><input type="submit" name="settingTradeSellSave" class="button-large button-primary"  value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">


   <h3 class=""><?php echo __( 'BitStamp Api Credentials:', 'mtn-recharge' ); ?></h3>
   <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table  style="width: 100%;">
     
      <tr>
        <td style="width:20%;"><span>BitStamp Client ID: </span></td>
        <td><input type="text" value="<?php echo $bitstamp_client_id; ?>" style="width: 100%;" name="bitstamp_client_id" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>BitStamp Key: </span></td>
        <td><input type="text" value="<?php echo $bitstamp_key; ?>" style="width: 100%;" name="bitstamp_key" /></td>
      </tr>

	  
	  
	  <tr>
        <td style="width:20%;"><span>BitStamp Secret: </span></td>
        <td><input type="password" value="<?php echo $bitstamp_secret; ?>" style="width: 100%;" name="bitstamp_secret" /></td>
      </tr>
	  
      <tr>
        <td><input type="submit" name="settingBitStampGatewaySave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
   </form>
   
   <h3 class=""><?php echo __( 'Sell Order Settings:', 'mtn-recharge' ); ?></h3>
   <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table  style="width: 100%;">
     
      <tr>
        <td style="width:20%;"><span>Variable for price for Sell Order Limit (in %): </span></td>
        <td><input type="text" value="<?php echo $sell_order_var; ?>" style="width: 100%;" name="sell_order_var" /> % Float value Example: 1.25</td>
      </tr>
	  <tr>
        <td><input type="submit" name="settingSellOrderSave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
   </form>



  <h3 class=""><?php echo __( 'BlockTrail Api and Wallet Credentials:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table  style="width: 100%;">
     
      <tr>
        <td style="width:20%;"><span>Blocktrail Api Key: </span></td>
        <td><input type="text" value="<?php echo $blocktrail_api_key; ?>" style="width: 100%;" name="blocktrail_api_key" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>Blocktrail Secret: </span></td>
        <td><input type="password" value="<?php echo $blocktrailsecret; ?>" style="width: 100%;" name="blocktrailsecret" /></td>
      </tr>
	  
	  <tr>
        <td><span>Payment Mode: </span>  </td>
        <td>Live <input type="radio" name="blocktrail_mode" <?php if($blocktrail_mode == 'on'){ echo 'checked'; } ?> value="on" />   Testnet <input type="radio" name="blocktrail_mode" <?php if($blocktrail_mode == 'off'){ echo 'checked'; } ?> value="off" /></td>
      </tr>
	  
	  
	  <tr>
        <td style="width:20%;"><span>Live Wallet Identifier: </span></td>
        <td><input type="text" value="<?php echo $live_wallet_identifier; ?>" style="width: 100%;" name="live_wallet_identifier" /></td>
      </tr>
	  
      <tr>
        <td style="width:20%;"><span>Live Wallet Password: </span></td>
        <td><input type="password" value="<?php echo $live_wallet_password; ?>" style="width: 100%;" name="live_wallet_password" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>Testnet Wallet Identifier: </span></td>
        <td><input type="text" value="<?php echo $testnet_wallet_identifier; ?>" style="width: 100%;" name="testnet_wallet_identifier" /></td>
      </tr>
	  
      <tr>
        <td style="width:20%;"><span>Testnet Wallet Password: </span></td>
        <td><input type="password" value="<?php echo $testnet_wallet_password; ?>" style="width: 100%;" name="testnet_wallet_password" /></td>
      </tr>
	  <tr>
        <td><input type="submit" name="settingBlockTrailGatewaySave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  
  

  <!--<h3 class=""><//?php echo __( 'Bitcoin Wallet Credentials:', 'mtn-recharge' ); ?></h3>
  <form action="<//?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table  style="width: 100%;">
     
      <tr>
        <td style="width:20%;"><span>Bitcoin Widget klukt.com Url: </span></td>
        <td><input type="text" value="<//?php echo $bitcoin_klukt_url; ?>" style="width: 100%;" name="bitcoin_klukt_url" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>Bitcoin Api Key: </span></td>
        <td><input type="text" value="<//?php echo $bitcoinApiKey; ?>" style="width: 100%;" name="bitcoinApiKey" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>Bitcoin Currency: </span></td>
        <td><input type="text" value="<//?php echo $bitcoinCurrency; ?>" style="width: 100%;" name="bitcoinCurrency" /></td>
      </tr>
	  
      <tr>
        <td style="width:20%;"><span>Bitcoin IPN Url: </span></td>
        <td><input type="text" value="<//?php echo $bitcoin_ipn_url; ?>" style="width: 100%;" name="bitcoin_ipn_url" /></td>
      </tr>
	  
	  <tr>
        <td style="width:20%;"><span>Bitcoin min. confirmation requested: </span></td>
        <td><input type="text" value="<//?php echo $confirmations_limit; ?>" style="width: 100%;" name="confirmations_limit" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="settingBitcoinGatewaySave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form> -->

  <h3 class=""><?php echo __( 'Bitcoin converter API Credentials:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table  style="width: 100%;">
     
     <tr>
        <td><span>Public Key: </span></td>
        <td><input type="text" value="<?php echo $bitcoin_public_key; ?>" style="width: 100%;" name="bitcoin_public_key" /></td>
      </tr>
      <tr>
        <td><span>Secret key: </span></td>
        <td><input type="password" value="<?php echo $bitcoin_secret_key; ?>" style="width: 100%;" name="bitcoin_secret_key" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="settingBitcoinSave" class="button-large button-primary" value="Submit"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <br>
  <h3 class=""><?php echo __( 'Bitcoin Calculator:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
   
    <table>
      <tr>
        <td><span>Select Currency: </span></td>
        <td><select name="bitcoin_from">
		<option value="XAF" <?php if($bitcoin_from == 'XAF'){ echo  'selected="selected"';  }?>>XAF</option>
		<option value="EUR" <?php if($bitcoin_from == 'EUR'){ echo  'selected="selected"';} ?>>EUR</option>
		<option value="USD" <?php if($bitcoin_from == 'USD'){ echo  'selected="selected"';} ?>>USD</option>
		</select></td>
      </tr>
      <tr>
        <td><span>Select Currency: </span></td>
        <td><select name="bitcoin_to">
		<option value="BTC">BTC</option>
		</select></td>
      </tr>
      <tr>
        <td><input type="submit" name="convert_bitcoin" class="add_fees_recharge button-large button-primary" value="Convert"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <h3><?php if(!empty($result_bitcoin)){ echo '1 '.$bitcoin_from.' = '.$result_bitcoin.' '.$bitcoin_to; } ?></h3>
</div>



<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Paypal Fees Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Paypal Bussness Email: </span></td>
        <td><input type="text" value="<?php echo $paypal_bussness_email; ?>" name="paypal_bussness_email" /></td>
      </tr>
      <tr>
        <td><span>Tax (in %): </span></td>
        <td><input type="text" value="<?php echo $tax_fees; ?>" name="tax_fees" /></td>
      </tr>
      <tr>
        <td><span>Extra Fees: </span></td>
        <td><input type="text" value="<?php echo $extra_fees; ?>" name="extra_fees" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="paypalSettingSave" class="button-large button-primary" value="Save"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Freshdesk Account Credentials:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>Freshdesk Login Url: </span></td>
        <td><input type="text" value="<?php echo $freshdesk_login_url; ?>" style="width:300px;" name="freshdesk_login_url" /></td>
      </tr>
      <tr>
        <td><span>Freshdesk Email: </span></td>
        <td><input type="text" value="<?php echo $freshdesk_email; ?>" style="width:300px;" name="freshdesk_email" /></td>
      </tr>
      <tr>
        <td><span>Freshdesk Password: </span></td>
        <td><input type="password" value="<?php echo $freshdesk_password; ?>" style="width:300px;" name="freshdesk_password" /></td>
      </tr>
	  
	  
	  <tr>
        <td><span>Freshdesk File Download Password: </span></td>
        <td><input type="password" value="<?php echo $freshdesk_file_password; ?>" style="width:300px;" name="freshdesk_file_password" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="freshdeskSettingSave" class="button-large button-primary" value="Save"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <h3 class=""><?php echo __( 'Freshdesk Trigger:', 'mtn-recharge' ); ?></h3>
  <p>Trigger Cron Job for querying ticket (MTN SIM Card SIM Card Shipping request / New MTN Registration Request) status on freshdesk via freshdesk API.</p>
 <p>"Pending/Open shows amount of ticket in the queue. Closed/Resolved shows amount of ticket for which status has changed from "Your SIM Card will be shipped soon to SIM Card shipped" or "SIM Card Registration Pending to SIM Card registered" after clicking on "Trigger Button".</p>
 <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><input type="submit" name="freshdeskSettingtrigger" class="button-large button-primary" value="Trigger Button"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <br>
  <?php if($freshdesk_flag == 1){
  ?>
  <table width="100%;" border="1">
    <tr>
      <th style="padding:10px 0px;"><span>Subject </span></th>
      <th style="padding:10px 0px;"><span>Closed/Resolved</span></th>
      <th style="padding:10px 0px;"><span>Open<span></th>
	  <th style="padding:10px 0px;"><span>Pending</span></th>
    </tr>
    
    <tr>
      <td style="text-align:center;"><?php echo 'MTN SIM Card Shipping Request'; ?></td>
      <td style="text-align:center;"><?php echo $status1_count1; ?></td>
      <td style="text-align:center;"><?php echo $status1_count2; ?></td>
	  <td style="text-align:center;"><?php echo $status1_count3; ?></td>
    </tr>
	<tr>
      <td style="text-align:center;"><?php echo 'New MTN Registration Request'; ?></td>
      <td style="text-align:center;"><?php echo $status2_count1; ?></td>
      <td style="text-align:center;"><?php echo $status2_count2; ?></td>
	  <td style="text-align:center;"><?php echo $status2_count3; ?></td>
    </tr>
   
  </table>
  <?php } ?>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'MTN API Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
      <tr>
        <td><span>SP ID: </span></td>
        <td><input type="text" value="<?php echo $sp_id; ?>" name="sp_id" /></td>
      </tr>
	  <tr>
        <td><span>SP Password: </span></td>
        <td><input type="password" value="<?php echo $sp_password; ?>" name="sp_password" /></td>
      </tr>
       <tr>
        <td><span>Service ID: </span></td>
        <td><input type="text" value="<?php echo $service_id; ?>" name="service_id" /></td>
      </tr>
	  <tr>
        <td><span>IP: </span></td>
        <td><input type="text" value="<?php echo $testbed_ip; ?>" name="testbed_ip" /></td>
      </tr>
	  <tr>
        <td><input type="submit" name="mtnApiSettingSave" class="button-large button-primary" value="Save"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Merchant Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
     
	  <tr>
        <td><span>Project ID: </span></td>
        <td><input type="text" value="<?php echo $project_id; ?>" name="project_id" /></td>
      </tr>
      <tr>
        <td><span>Customer ID(for Sofort)</span></td>
        <td><input type="text" value="<?php echo $customer_id; ?>" name="customer_id" /></td>
      </tr>
      <tr>
	  <tr>
        <td><span>Sofort Api Key: </span></td>
        <td><input type="text" value="<?php echo $sofort_api_key; ?>" style="width:300px" name="sofort_api_key" /></td>
      </tr>
	  <tr>
        <td><input type="submit" name="merchantSettingSave" class="button-large button-primary" value="Save"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'SMS Twillo Settings:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <table>
	  <tr>
        <td><span>ACCOUNT_SID(Live): </span></td>
        <td><input type="text" value="<?php echo $account_sid_live; ?>" style="width:300px" name="account_sid_live" /></td>
      </tr>
	  <tr>
        <td><span>AUTH_TOKEN(Live): </span></td>
        <td><input type="text" value="<?php echo $auth_token_live; ?>" style="width:300px" name="auth_token_live" /></td>
      </tr>
	  <tr>
        <td><span>ACCOUNT_SID(Test): </span></td>
        <td><input type="text" value="<?php echo $account_sid_test; ?>" style="width:300px" name="account_sid_test" /></td>
      </tr>
	  <tr>
        <td><span>AUTH_TOKEN(Test): </span></td>
        <td><input type="text" value="<?php echo $auth_token_test; ?>" style="width:300px" name="auth_token_test" /></td>
      </tr>
      <tr>
        <td><span>From Number(Registred on Twillo): </span></td>
        <td><input type="text" value="<?php echo $from_number; ?>" name="from_number" /></td>
      </tr>
	  <tr>
        <td><span>Body Message(SMS format): </span></td>
        <td><textarea cols="40" rows="6" name="body_message" style="height: 120px;"><?php echo $body_message; ?></textarea></td>
      </tr>
	  
      <tr>
        <td><input type="submit" name="smsSettingSave" class="button-large button-primary" value="Save"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
</div>

<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Payment Methods:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    
    <table>
      <tr>
        <td><span>Enabled Paypal: </span></td>
        <td><input type="checkbox" <?php if($method1 == 'yes'){?> checked <?php } ?> value="paypal"  name="payment_method[]" id="paypal" /></td>
      </tr>
      <tr>
        <td><span>Enabled Sofort: </span></td>
        <td><input type="checkbox" value="sofort" <?php if($method2 == 'yes'){?> checked <?php } ?>  name="payment_method[]" id="sofort" /></td>
      </tr>
      <tr>
        <td><span>Enabled Bitcoin: </span></td>
        <td><input type="checkbox" value="bitcoin" <?php if($method3 == 'yes'){?> checked <?php } ?>  name="payment_method[]" id="bitcoin" /></td>
      </tr>
      <tr>
        <td><input type="submit" name="add_payment_method" onclick="return valpaymentform();" class="add_method button-large button-primary" value="Payment Setting"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
 
 
</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Function usage statistics (MTN Mobile Money):', 'mtn-recharge' ); ?></h3>
  <table width="100%;" border="1">
    <tr>
      <th width="70%" style="padding:10px 0px;"><span>Add contact from transfer page</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_contact_from_transfer_page'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span> Add contact from address book page</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_contact_from_add_contact'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span>Transfer initiated from address book directly</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_transfer_from_address_book'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span>Transfer initiated from address book through button on transfer page</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_transfer_from_transfer_page'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span>Used paypal payment</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_payment_with_paypal'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span>Used sofort payment</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_payment_with_sofort'); ?></td>
    </tr>
	<tr>
      <th width="70%" style="padding:10px 0px;"><span>Used bitcoin payment</span></th>
      <td width="30%" style="padding:10px 0px;"><?php echo get_option('no_of_payment_with_bitcoin'); ?></td>
    </tr>
	
  
   </table>

</div>


<div class="postbox " style="padding: 10px; margin: 10px 0px;">
  <h3 class=""><?php echo __( 'Add new fees:', 'mtn-recharge' ); ?></h3>
  <form action="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier' ?>" method="post">
    <input type="hidden" name="fees_id" id="fees_id" value="" />
    <table>
      <tr>
        <td><span>Amount in &euro; Min: </span></td>
        <td><input type="text" value=""  name="amount_in_min" id="amount_in_min" required/></td>
      </tr>
      <tr>
        <td><span>Amount in &euro; Max: </span></td>
        <td><input type="text" value=""  name="amount_in_max" id="amount_in_max" required/></td>
      </tr>
      <tr>
        <td><span>Fees in &euro;: </span></td>
        <td><input type="text" value=""  name="recharge_fees" id="recharge_fees" required/></td>
      </tr>
      <tr>
        <td><input type="submit" name="add_fees_recharge" class="add_fees_recharge button-large button-primary" value="Add Fees"  /></td>
        <td></td>
      </tr>
    </table>
  </form>
  <br />
  <?php if($recharge_fees) { ?>
  <table width="100%;" border="1">
    <tr>
      <th style="padding:10px 0px;"><span>Amount in &euro; Min </span></th>
      <th style="padding:10px 0px;"><span> Amount in &euro; Max </span></th>
      <th style="padding:10px 0px;"><span> Fees in &euro; </span></th>
      <th style="padding:10px 0px;"><span> Action </span></th>
    </tr>
    <?php foreach($recharge_fees as $fees) { ?>
    <tr id="<?php echo 'fees_'.$fees->id; ?>">
      <td style="text-align:center;" class="a_min"><?php echo $fees->amount_in_min; ?></td>
      <td style="text-align:center;" class="a_max"><?php echo $fees->amount_in_max; ?></td>
      <td style="text-align:center;" class="a_fees"><?php echo $fees->recharge_fees; ?></td>
      <td style="text-align:center;">
	  <input type="button" name="delete" value="Delete" onclick="delete_fees('<?php echo $fees->id; ?>')" /> | <input type="button" name="edit" value="Edit" onclick="update_fees('<?php echo $fees->id; ?>')"  /></td>
    </tr>
    <?php } ?>
  </table>
  <input type="hidden" id="delUrl" = value="<?php echo $_SERVER['PHP_SELF'].'?page=mtn-settings-identifier'; ?>" />
  <?php } ?>
</div>
<?php 	

     echo '</div>';
}

// create recharge form shortcode
function mtn_recharge_form(){
	
global $wpdb;
$formHtml = '';	
$rate = get_option('currency_coversion_rate');
$recharge_limit = get_option('recharge_limit');

$tax_fees = get_option('tax_fees');
$extra_fees = get_option('extra_fees');	
	
$current_user = wp_get_current_user();

$country = get_the_author_meta( 'diaspo_user_country_of_residence', $current_user->ID );
$first_name = get_user_meta($current_user->ID, 'first_name', true);
$last_name = get_user_meta($current_user->ID, 'last_name', true);


$country_code = '+'.get_user_meta( $current_user->ID , 'country_flag_code', true );
$phone = str_replace(get_user_meta( $current_user->ID , 'country_flag_code', true ), "", get_the_author_meta( 'msisdn', $current_user->ID ));


if(strlen($phone) != 9)
{
	
	$phone = substr($phone,-9); 
}
$method1 = $method2 = $method3 = '';
$methods = explode(',',get_option('payment_methods'));
$success_url = '';
if(ICL_LANGUAGE_CODE == "fr")
{$success_url = 'http://dsp.lab.kit-services.com/success-url/?lang=fr';}else{$success_url = 'http://dsp.lab.kit-services.com/success-url/';}
	
	

foreach($methods as $method)
{
	    if($method == 'paypal')
	    {
			$method1 = 'yes';
	    }
		elseif($method == 'sofort')	
		{
			$method2 = 'yes';
		}
		else
		{
			$method3 = 'yes';
		}						
				  				   
}	
$dir_url_image = plugin_dir_url(__FILE__) . 'images/';
$ajaxurl = admin_url( 'admin-ajax.php' );
$formHtml .= '<div role="form" class="" lang="en-US" dir="ltr">		                  
											<form action="#" method="post" id="singupForm">
												
												
												<div id="wizard">
												<h2 class="headTab">Basic Detail</h2>
												<section>
                                                   <div class="contact-box">
												   <div class="mainBox mainRec">
												   <h3 class="fulBox"><span><img src="'.get_stylesheet_directory_uri().'/img/user_icon.png" /></span>'.$first_name.',<br/>'.$last_name.'</h3>
												   <h3  class="fulBox"><span><img src="'.get_stylesheet_directory_uri().'/img/contact_icon.png" /></span> ('.$country_code.')'.$phone.'</h3>
												   </div>
													<input type="hidden" name="mtn_mobile" id="mtn_mobile" value="'.$phone.'" />
													<input type="hidden" id="countryCode" value="'.$country_code.'" />
													
													<p class="form_element">
														<label for="Subject">Currency Type<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<select name="currency_code" id="currency_code">
																<option value="XAF">XAF</option>
															</select>
														</span>
													</p>

													<p class="form_element">
														<label for="Subject">Amount<abbr class="required" title="required">*</abbr></label><br>
														<input type="text" class="required payment amount" id="amount" name="recharge_amount" value="" onblur="myAmount()" placeholder="Amount" />
													</p>
                                                 <p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>
												<div class="col-sm-12 mt-20">
							                		<div class="form-save">
							                			<div class="amount-div">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>Send amount</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>Fees</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                		</div>
                                                        <br/>
								                		<div class="total-pay">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>Total to Pay</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                			<div class="row" style="display:none">
									                			<div class="col-sm-8 col-xs-8">
									                				<h3>Your account gets</h3>
																	<p>&lt;users MTN phone number = Kit Number&gt;
																	will be credited with &lt;amount in currency of country where member registered for MoMo&gt;</p>
									                			</div>
									                			<div class="col-sm-4 col-xs-4 text-right">
									                				<h3>XAF 0.00</h3>
									                			</div>
								                			</div>
								                		</div>
							                		</div>
							                	</div>		
                                                <br/>
							                	<div class="col-sm-12 text-center">
							                		<h4>Exchange rate EUR 1 = XAF '.$rate.'</h4>
							                	</div>
												
                                                <input type="hidden" id="ajaxUrl" value="'.$ajaxurl.'" />
							                	<input type="hidden" id="recharge_limit" value="'.$recharge_limit.'" />
												<input type="hidden" id="paypal_tax_fees" value="'.$tax_fees.'" />
							                	<input type="hidden" id="paypal_extra_fees" value="'.$extra_fees.'" />
												
                </section>

                <h2 class="headTab">Payment</h2>
                <section>
                   <div class="contact-box"><h2>Choose Payment Method :</h2>
				   <div class="row pay_spaceing">';
		    $addi = '';		
			
			if($method2 == 'yes'){	
                if($method1 != 'yes' && $method3 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="without_extra">
							<input type="radio" class="required" name="payment_method" value="Sofort" id="Sofort" checked/><label for="Sofort" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/sofort-logo.jpg" /></label>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="without_extra">
							<input type="radio" class="required" name="payment_method" value="Sofort" id="Sofort" /><label for="Sofort" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/sofort-logo.jpg" /></label>
						</div>';
					
				}
			    
			}
            if($method1 == 'yes'){	

            
						
				if($method2 != 'yes' && $method3 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="extra_fee">
							<input type="radio" class="required" name="payment_method" value="Paypal" id="Paypal" checked/><label for="Paypal" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/paypal-logo.jpg" /></label>
							<span id="with_fee" style="font-weight: 600;padding: 10px 0 0 40px;">(With Additional Fees)</span>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="extra_fee">
							<input type="radio" class="required" name="payment_method" value="Paypal" id="Paypal" /><label for="Paypal" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/paypal-logo.jpg" /></label>
							<span id="with_fee" style="display:none;font-weight: 600;padding: 10px 0 0 40px;">(With Additional Fees)</span>
						</div>';
					
				}		
						
						
						
			}
            if($method3 == 'yes'){			
            
						
				if($method2 != 'yes' && $method1 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="without_extra_bitcoin">
							<input type="radio" class="required" name="payment_method" value="Bitcoin" id="Bitcoin" checked/><label for="Bitcoin" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/bitcoin-logo.png" /></label>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="without_extra_bitcoin">
							<input type="radio" class="required" name="payment_method" value="Bitcoin" id="Bitcoin" /><label for="Bitcoin" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/bitcoin-logo.png" /></label>
						</div>';
					
				}		
					
						
            }
            
			$dir_url_image = plugin_dir_url(__FILE__) . 'images/';
			
			$formHtml .= '</div>
				   </div>
                </section>
                
                <h2 class="headTab">Transaction Details</h2>
				
                <section>
				   
                   <div class="contact-box" style="padding-top:10px;"><div class="tranSecDetail"><h2>Transaction Details :</h2>
				   <span class="currTran">
				   <select id="currencySecDetail">
				   <option value="EUR">EUR</option>
				   <option value="XAF">XAF<sup>*</sup></option>
				   <option value="mBTC">mBTC<sup>*</sup></option>
				   <option value="USD">USD<sup>*</sup></option>
				   </select></span></div>
				   <p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>
													
                        <p><span class="detail_one">You are about to recharge</span><span id="foreign_currency"></span> <span id="amount_to_recharge">  </span> <span class="detail_one">on</span> <span id="mtn_number_to_recharge"></span> <span class="detail_one">Mobile Money account:</span></p>
                        <br>
						<div class="clearfix"></div>
                        <p><span class="detail_one">Amount to recharge:</span> <span id="trans_amount"></span></p>
						<div class="clearfix"></div>
						<p><span class="detail_one">Fees:</span><span id="trans_fees"></span></p>
						<div class="clearfix"></div>
						<p class="addFeesMargin"><span class="detail_one additinalDetail 123">Additional Fees: </span><span id="trans_paypal" class="additinalDetail"></span></p>
						<div class="clearfix additinalDetail"></div>';
						
						
		
			$rewards_activate = get_option('rewards_activate');
			$number_recharge_get_reward = get_option('number_recharge_get_reward');
			$validityYearSet = get_option('validity_default_year');
            $ResCount = get_user_meta($current_user->ID, 'reward_points', true);
            
                            			
			$imgHtml  = $resHtml = $imgsmall =  $feesFree = '';
			
			if($rewards_activate == 'yes')
			{
				if($ResCount == ''){ $ResCount = 0; }
			    
				
				if($ResCount >= $number_recharge_get_reward ){
					
					$reward_year_cycle  =  get_user_meta($current_user->ID, 'reward_year_cycle', true);
                    $validityYear = date('Y-m-d', strtotime("+".$validityYearSet." months", strtotime($reward_year_cycle)));
					//$mydata = $reward_year_cycle.'_'.$validityYear.'_'.date('Y-m-d');
				  if($validityYear > date('Y-m-d')){ 	
					  $feesFree = 0.00;
					  $ResCount = $number_recharge_get_reward;
				    }else{
						
					   $ResCount =  0;
					}  
				}
				
			    for($i=0;$i<$number_recharge_get_reward;$i++){
				 if($ResCount == 0){
					 $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargGray_icon.png" />';
					 $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmall_icon.png" />';
					 
				 }else{	
					  if($i < $ResCount){	
					   $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/recharg_icon.png" />';
					   $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmalGreen_icon.png" />';
					   
					  }else{
					   $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargGray_icon.png" />';
					   $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmall_icon.png" />';
					  }
				  }
				}
				
				$resHtml .= $ResCount.'/'.$number_recharge_get_reward.'<br><span>'.$imgsmall.'</span>';
				
				$paypal_bussness_email = get_option('paypal_bussness_email');
				
				$formHtml .= '
				<p><span class="detail_one">Rewards : '.$imgHtml.'</span><span class="fees_ffr">'.$resHtml.'</span></p>
						        <div class="clearfix"></div>';
			}
			         $bitcoin_klukt_url = get_option('bitcoin_klukt_url');	
					 $bitcoinApiKey = get_option('bitcoinApiKey');
					 $bitcoinClientEmail = $current_user->user_email;
					 $bitcoinCurrency = get_option('bitcoinCurrency');
			
                        $formHtml .= '<input type="hidden" id="feesFree" value="'.$feesFree.'" /> 
						<hr/>
						<p><span class="detail_totel">Total:</span> <span id="trans_total"></span></p>
					</div>
					<span class="shortNote"><sup>*</sup>conversion are just approximation and may slightly differ from total to pay</span>
                    <input type="hidden" id="trans_amount_New" value="" /> 
					 <input type="hidden" id="trans_fees_New" value="" /> 
					 <input type="hidden" id="trans_paypal_New" value="" /> 
					 <input type="hidden" id="trans_total_New" value="" />
                     <input type="hidden" id="bitcoinUrl" value="'.$bitcoin_klukt_url.'" />
                     <input type="hidden" id="bitcoinApiKey" value="'.$bitcoinApiKey.'" /> 
                     <input type="hidden" id="bitcoinClientEmail" value="'.$bitcoinClientEmail.'" />
                     <input type="hidden" id="bitcoinCurrency" value="'.$bitcoinCurrency.'" />  
				</section>
                
            </div>
            </form>
											
			<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" id="pp_Form" method="post">
  <input type="hidden" name="cmd" value="_xclick">
  <input type="hidden" name="business" value="'.$paypal_bussness_email.'">
  <input type="hidden" name="item_name" id="pp_title" value="">
  <input name="custom" type="hidden" id="custom_data" value="">
  <input type="hidden" name="amount" id="pp_amount" value="">
  
  <input type="hidden" name="return" value="'.$success_url.'">
  <input type="hidden" name="currency_code" value="EUR">
  
</form>
											
											
											
											
											
											
											
										</div></div>
		';
		
		
	$btcMsg = 'Please use your Bitcoin  wallet and scan the QR-Code from your smartphone.';		
	if(ICL_LANGUAGE_CODE == 'fr'){
		
		$btcMsg = 'Ouvrez votre application Bitcoin et scannez le QR-CODE a partir de votre t&#233;l&#233;phone';	
		
	}	
	$formHtml .= '<style>
	#tipModal .modal-dialog {
    background-color: #fff;
}
	</style>
	
	<div id="tipModal" class="tip_modal modal fade" role="dialog">
		  <div class="modal-dialog">
		
		    <div class="modal-content">
            
			  <div class="modal-body">
			      <h2 style="text-align:center;">'.$btcMsg.'</h2>
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			     <div class="bitCoinData">
														
														
				 </div>
			     
				 <div id="bitocinButton">
				 
				 </div> 
				
			  </div>
			
			 
			  
			</div>

		  </div>
	</div>';	
		
	return $formHtml;
	
}
add_shortcode('recharge_form', 'mtn_recharge_form' );





// create transfer form shortcode
function mtn_transfer_form(){
global $wpdb;
$formHtml = $msg = $msg_new = '';
$usr_fname = $usr_lname	= $usr_email = $usr_city = $usr_mobile_money_account = '' ;

if(isset($_POST['save_contact'])){
	$current_user = wp_get_current_user();

	$currency_type_amount = $_POST['transfer_amount'];
	$fullname = $_POST['usr_fname'].' '.$_POST['usr_lname'];
	
	$usr_fname = $_POST['usr_fname'];
	$usr_lname = $_POST['usr_lname'];
	
	$usr_email = $_POST['usr_email'];
	$usr_mobile_money_account = $_POST['usr_mobile_money_account'];
	$usr_coun = $_POST['usr_country'];
	$usr_city = $_POST['usr_city'];
	$recommended_answer = $_POST['recommended_answer'];
	
	$wpdb->query("INSERT INTO `wp_user_address_book` (id, user_id, usr_name, usr_email, usr_mobile_money_account, usr_country, usr_city, recommended_answer) 
				VALUES('', '".$current_user->ID."', '".$fullname."', '".$usr_email."', '".$usr_mobile_money_account."', '".$usr_coun."', '".$usr_city."', '".$recommended_answer."')");	
				
	$msg_new = 'Contact added sucessfully!.';	
	
	
	   $no_of_contact_from_transfer_page = get_option('no_of_contact_from_transfer_page');
		if(empty($no_of_contact_from_transfer_page))
		{update_option('no_of_contact_from_transfer_page', 1);}
		else
		{   $no_of_contact_from_transfer_page++;
			update_option('no_of_contact_from_transfer_page', $no_of_contact_from_transfer_page);
		}
	
	
}


if(isset($_POST['submit'])){
	
	?>
	
<script type="text/javascript">

jQuery('#resultPage').hide();
var myVar;    
function showResult(){
	var procNum = jQuery('#procNum').val();
	
    jQuery('.loading_txt').html(msg);   
	
    var msg = '';
	var url = 'http://dsp.lab.kit-services.com/wp-admin/admin-ajax.php';	
            
		 
                    jQuery.ajax({
                        url: url,
                        type: "POST",
                        data: 'action=getStatus&procNum='+procNum,
                        success: function(response) {
							var data = response.split('##');
							var status_code = data[0];
							var MSISDNNum = data[1];
							var amount = data[2];
							var receipt_link = data[3];
							
							
						 							
                            	
								
								if(status_code != '')
								{ 
							         
									    if(status_code == '1')
										{  
											msg = "We are transferring <"+amount+"><XAF> to <"+MSISDNNum+">, please wait";
											jQuery('.loading_txt').html(msg); 
											
										
										}else{
											
										if(status_code == '01'){
											
										    jQuery('#resultPage').show();
											jQuery('#processPage').hide();
											
											
											html = "<div class='overview-main1 overview-main2' id='overview' style='column-count:1;'>";
									        html += "<div class='overview-box1' id='res_data'><div class='overview-boxmain' >";
										    html += "<div class='status_icon'><span class='msg_failed_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/transactionSuccess_icon.png' title='Success'/></span><span class='newMsgData'>Transaction Successful</span></div>";
										    html += "<div class='error_msg_data'>";
										    html += "<span>We successfully credited "+amount+" XAF on following</span>";
										    html += "<span>Mobile Money Account: <b>+"+MSISDNNum+"</b></span></div>";
										    html += "<div class='transaction_accoun_field'>";
										    html += "<div><span class='account_text'>Account Detail</span><span class='account_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/user_icon_new.png' title='User Icon'/></span></div>";
										    html += "<div class='account_field'><input type='text' value='+"+MSISDNNum+"' readonly/></div>";
										    html += "</div></div></div>";
                                            html += "<div class='account_buttons'><a href='"+receipt_link+"'  class='down_recp'>Download Receipt</a><a href='http://dsp.lab.kit-services.com/mobile-money-transfer/' class='account_back'>BACK</a></div></div>";
											
											
											jQuery('#resultPage').html(html);
											stopResult();
											 
										   }else{
                                            										   
											jQuery('#resultPage').show();
											jQuery('#processPage').hide();
											
											html = "<div class='overview-main1 overview-main2' id='overview' style='column-count:1;'>";
									        html += "<div class='overview-box1' id='res_data'><div class='overview-boxmain' >";
										    html += "<div class='status_icon'><span class='msg_failed_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/transaction_icon.png' title='Error'/></span><span class='newMsgData myRed'>Transaction Failed</span></div>";
										    html += "<div class='error_msg_data'>";
										    html += "<p>Your transaction to MTN Mobile Money account <b>+"+MSISDNNum+"</b> with amount of "+amount+" XAF failed with following error code: <"+status_code+"></p>";
										    html += "<p>Please refer to our <a target='_blank' href='http://dsp.lab.kit-services.com/help-faq/'>Help & FAQ</a> or contact our <a href='http://dsp.lab.kit-services.com/contact'>Support</a> for further assistance.</p>";
										    html += "<div class='transaction_accoun_field'>";
										    html += "<div><span class='account_text'>Account Detail</span><span class='account_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/user_icon_new.png' title='User Icon'/></span></div>";
										    html += "<div class='account_field'><input type='text' value='+"+MSISDNNum+"' readonly/></div>";
										    html += "</div></div></div>";
                                            html += "<div class='account_buttons'><a class='down_recp transferDown'>Download Receipt</a><a href='http://dsp.lab.kit-services.com/mobile-money-transfer/' class='account_back'>BACK</a></div></div>";
											
											
											
											jQuery('#resultPage').html(html);
											stopResult();
										  }	
										}
										   
										   
								}
									
								
														
							
                        }            
                    });
	
	
}
function stopResult(){
    clearInterval(myVar); // stop the timer
	
	jQuery(".loading").fadeOut("slow");
	
}
jQuery(document).ready(function(){
	
    myVar = setInterval("showResult()", 10000);
});
</script>
	
	
	<?php
	
	
	$transfer_country_of_residence = $_POST['transfer_country_of_residence'];
	$rec_city = $_POST['rec_city'];
	
	$response_array = make_transfer($_POST);

	
	
	$StatusCode = $response_array['StatusCode'];
	$StatusDesc = $response_array['StatusDesc'];
	$MOMTransactionID = $response_array['MOMTransactionID'];
	$ProcessingNumber = $response_array['ProcessingNumber'];
	$SenderID = $response_array['SenderID'];
	//$MSISDNNum = $response_array['MSISDNNum'];
	$OpCoID = $response_array['OpCoID'];
	$mtn_status = '';
	
	
	
	if($StatusCode == 1000)
	{
	   $mtn_status  = 	'pending';
	 
	   $no_of_transfer_from_transfer_page = get_option('no_of_transfer_from_transfer_page');
		if(empty($no_of_transfer_from_transfer_page))
		{update_option('no_of_transfer_from_transfer_page', 1);}
		else
		{   $no_of_transfer_from_transfer_page++;
			update_option('no_of_transfer_from_transfer_page', $no_of_transfer_from_transfer_page);
		}
		
	}
	else
	{
	 $mtn_status = 	'rejected';	
	}

	$row = $wpdb->get_row("SELECT * FROM`wp_mtn_order_history` WHERE ProcessingNumber = '".$ProcessingNumber."'");
	
	$MSISDNNum = $row->MSISDNNum;
	
	$xaf_trans_amount = $row->xaf_trans_amount;
	
	$wpdb->query("UPDATE `wp_mtn_order_history` SET  mtn_status = '".$mtn_status."', MOMTransactionID = '".$MOMTransactionID."', ProcessingNumber = '".$ProcessingNumber."', SenderID = '".$SenderID."', OpCoID = '".$OpCoID."' WHERE ProcessingNumber = '".$ProcessingNumber."'");
		   
	
	
	
	
	echo $msg = "Your transaction to ".$MSISDNNum." is being processed. Please, approve it from your mobile phone to complete this transaction ".$MOMTransactionID;	
										     
	
	
	
	echo '<div role="form" class="wpcf7" id="resultPage" lang="en-US" dir="ltr">
		  </div>';
	echo '<input type="hidden" class="Hi" id="procNum" value="'.$ProcessingNumber.'" /><div class="loading"><div class="loading_txt">'.$msg.'</div></div>';	
	
}
	
		$current_user = wp_get_current_user();
		
		$first_name = get_user_meta($current_user->ID, 'first_name', true);
        $last_name = get_user_meta($current_user->ID, 'last_name', true);
		
		$checkMtnTransLimit = get_option('transfer_limit');
		
		$res = $wpdb->get_results("SELECT SUM(`xaf_trans_amount`) AS sum FROM `wp_mtn_order_history` WHERE user_id = ".$current_user->ID." and mtn_status = 'completed'");
		
		$mtnTransTotal = $res[0]->sum;
		
		$country_code = '+'.get_user_meta( $current_user->ID , 'country_flag_code', true );
		$phone = str_replace(get_user_meta( $current_user->ID , 'country_flag_code', true ), "", get_the_author_meta( 'msisdn', $current_user->ID ));


		$country_of_residence = getCountryNameToCountryCode(get_user_meta( $current_user->ID , 'country_flag_code', true ));
        $add_url = home_url('/add-edit-contact/');
        $rows = $wpdb->get_results("select * from `wp_user_address_book` WHERE user_id = '".$current_user->ID."' order by id desc");
		$ajaxurl = admin_url( 'admin-ajax.php' );
		
		$formHtml .= '<div class="modal fade popModal" id="addAddressBookPopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<span class="acct_detail"></span>
							<h2 style="text-align:center;">Add Contact</h2>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>        
						  </div>
						  <div class="modal-body">
						    <div class="contact-box">
        <form action="" method="post" id="addAddresBookForm">
          <p class="form_element">
            <label for="Firstname">First name<span class="required1" title="required">*</span></label>
            <span class="firstname">
            <input type="text" name="usr_fname" class="text_input1" value="" placeholder="Type recipient first name">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">Last name<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_lname" class="text_input1" value="" placeholder="Type recipient last name">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">Mobile Money Account<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_mobile_money_account" value="" id="usr_mobile_money_account" class="text_input1" placeholder="Type MTN Number" />
            </span> </p>   
          <p class="form_element">
            <label for="Email">Email Address</label>
            
            <span class="user-email1">
            <input type="text" name="usr_email" class="text_input1" value="" placeholder="Type recipient email address" />
            </span> </p>    
          <p class="form_element">
            <label for="Subject">Country<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
                    <select name="usr_country" id="usr_country">
					<option value="Cameroon" selected="selected">Cameroon</option>
					</select>								
												    
            </span> 
		  </p>
		  <p class="form_element">
            <label for="Subject">City<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
            
			       <select name="usr_city" id="usr_city">
					<option value="">Select City</option>
					</select>
            </span>
		  </p>
          <p class="form_element form_fullwidth">
            <label class="radio-wrapper" for="Subject">You recommended MTN Mobile Money to this contact ?<span class="required1" title="required">*</span></label>
            <span class="subject1">
              Yes <input type="radio" name="recommended_answer" value="yes"';
        if($recommended_answer == "yes")
		$formHtml .= "checked";	
	
		$formHtml .= '/> No <input type="radio" name="recommended_answer" value="no"';
		
        if($recommended_answer == "no")
		$formHtml .= "checked";	
	
		$formHtml .= '/>
            </span>
			
		  </p><p class="submit-container1">
		  
            <input type="submit" name="save_contact" value="Save" style="float: right;" class="submit1" />
         </p>
		 </form>
		</div>
						  </div>
						  <div class="popMod">
							<div class="form_element">
								
							</div>
						  </div>
						  </div>      
						</div>
					  </div>
			       ';
		
		$formHtml .= '<div class="modal fade popModal" id="fromAddressBookPopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<span class="acct_detail"></span>
							<h2 style="text-align:center;">Select contact to transfer to:</h2>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>        
						  </div>
						  <div class="modal-body">
						  
<div class="table-responsive">
          <table class="table table-bordered table_name">
            <thead>
              <tr>
			    <th>Actions</th>
                <th>Name</th>
                <th>MTN Number</th>
                <th>Email</th>
				<th>Country</th>
                <th>City</th>
              </tr>
            </thead><tbody>';
      foreach($rows as $row){
		$edit_url = $add_url.'?contact_id='.$row->id;
		$formHtml .= '
              <tr id="conId_'.$row->id.'">
			    <td scope="row" class="a_select"><button type="button" class="button btn select_rec">Select</button></td>
                <td scope="row" class="a_name">'.$row->usr_name.'</td>
                <td class="a_mm">'.$row->usr_mobile_money_account.'</td>
                <td class="a_email">'.$row->usr_email.'</td>
				<td class="a_cnty">'.$row->usr_country.'</td>
                <td class="a_city">'.$row->usr_city.'</td>
              </tr>';
	    }	

	$formHtml .= '</tbody></table>'.$pagination.'</div></div>
						  <div class="popMod">
							<div class="form_element">
								
							</div>
						  </div>
						  </div>      
						</div>
					  </div>
			        </div>';
		$title = '';
		if(ICL_LANGUAGE_CODE == "fr"){$title = 'Effectuer un Transfert � partir de votre carnet d�adresse';}else{$title = 'Initiate Transfer to a contact from your address book';}			
		$formHtml .= '<div class="">'.$msg_new.'</div><div role="form" class="" id="processPage" lang="en-US" dir="ltr">		                  
													<form action="" method="post" id="transferForm">
														
														<div class="contact-box">
														<div class="mainBox">
														  <h4 class="fulBox"><span><img src="'.get_stylesheet_directory_uri().'/img/user_icon.png" /></span>'.$first_name.',<br/>'.$last_name.'</h4>
												          <h4  class="fulBox"><span><img src="'.get_stylesheet_directory_uri().'/img/contact_icon.png" /></span> ('.$country_code.')'.$phone.'</h4>
														 </div>  
															<p class="form_fullwidth pad_rech"></p>
															
															<p class="form_element codeAcount">
																<label for="Subject">Country Code<abbr class="required" title="required">*</abbr></label><br>
																<span class="wpcf7-form-control-wrap country">
																	<span class="data">
																		<input type="text" id="country_code_mobile_money" value="+237" name="country_code_mobile_money" />
																	</span>
																</span>
															</p>
															<p class="form_element mobileAcount">
																<label for="Subject">Mobile Money Account<abbr class="required" title="required">*</abbr></label>
																<span class="wpcf7-form-control-wrap country">
																	<span class="data">
																		<input type="tel" name="mobile_money_account" value="'.$usr_mobile_money_account.'" id="mobile_money_account" Placeholder="Type MTN Number" />
																	</span>	
																</span>
															</p>
															
															<p class="form_element mobileAcount lastIcon">
																<label for="Subject">Confirm Mobile Money Account<abbr class="required" title="required">*</abbr></label>
																<span class="wpcf7-form-control-wrap country">
																	<span class="data">
																		<input type="tel" name="confirm_mobile_money_account" onpaste="return false" value="'.$usr_mobile_money_account.'" id="confirm_mobile_money_account" Placeholder="Type MTN Number" />
																	</span>	
																</span>
																<span class="cnfIcon" data-toggle="modal" data-target="#fromAddressBookPopup">
																<img src="'.get_stylesheet_directory_uri().'/img/moneyTrans-icon" title="'.$title.'" />
																</span>
															</p>
															
															<p class="form_element">
																<label for="Subject">Transfer Amount ( in XAF )<abbr class="required" title="required">*</abbr></label>
																<span class="wpcf7-form-control-wrap country">
																	<span class="data">
																		<input type="text" name="transfer_amount" id="transfer_amount" />
																	</span>	
																</span>
															</p>
															
															
															<p class="form_element">
																<label for="Subject">Sending Reason<abbr class="required" title="required">*</abbr></label><br>
																<span class="wpcf7-form-control-wrap country">
																	<select name="sending_reason">
																		<option value="Paying for Accommodation">Paying for Accommodation</option>
																		<option value="Paying medical care">Paying medical care</option>
																		<option value="Paying for work to be completed">Paying for work to be completed</option>
																		<option value="Paying bills">Paying bills</option>
																		<option value="Pension">Pension</option>
																		<option value="Tuition fees">Tuition fees</option>
																		<option value="Mortgage payments">Mortgage payments</option>
																		<option value="Friends and Family">Friends and Family</option>
																	</select>
																</span>
															</p>
															
															
															
														<input type="hidden" name="first_name" value="'.$usr_fname.'" id="first_name"  />
                                                        <input type="hidden" name="last_name" value="'.$usr_lname.'" id="last_name"  />
                                                        <input type="hidden" id="rec_email" value="'.$usr_email.'" name="rec_email"  />
														<input type="hidden" name="rec_city" value="'.$usr_city.'" id="rec_city" />	
                                                        <input type="hidden" id="ajaxUrl" value="'.$ajaxurl.'" />
														<input type="hidden" name="transfer_country_of_residence" id="transfer_country_of_residence" value="'.$country_of_residence.'" />
														<input type="hidden" id="checkMtnTransLimit" value="'.$checkMtnTransLimit.'" />
														<input type="hidden" id="mtnTransTotal" value="'.$mtnTransTotal.'" />
														
														<p class=" submit-container">
														
														
														<input type="button" data-toggle="modal" data-target="#addAddressBookPopup" value="Add Contact" id="add_contact" style="background-color:#ccc;" class="button wpcf7-form-control wpcf7-submit submit" disabled="disabled" />
														<input type="submit" name="submit" value="Next" class="wpcf7-form-control wpcf7-submit submit" />
														</p>

													</form>
												</div></div>';
				
			return $formHtml;
  	
}
add_shortcode('transfer_form', 'mtn_transfer_form' );




// create History Page Shortcode
function mtn_order_history(){
global $wpdb;
$formHtml = '';	
$siteurl = site_url('history');
$dir_url = plugin_dir_url(__FILE__) . 'img/';
$current_user = wp_get_current_user();
$country = get_the_author_meta( 'diaspo_user_country_of_origin', $current_user->ID );
$last =  '';
$where = " AND ( mtn_status = 'completed' OR refund_status = '01')";


if(!empty($_GET['last']))
{
	$last = $_GET['last'];
	$last_date = date('Y-m-d', strtotime("-".$last." days"));
	
	
	$where .= " AND date_time >='".$last_date."'";
	
}
if(!empty($_GET['filterBtnSub']))
{
	if(!empty($_GET['from_date']) AND !empty($_GET['to_date']))
	{
		$from_date = $_GET['from_date'].' 00:00:01';
		$to_date = $_GET['to_date'].' 23:59:59';
		
		$where .= " AND `date_time` BETWEEN  '".$from_date."' AND '".$to_date."'";
	}
   if(!empty($_GET['type_mode']))
	{
		$type_mode = $_GET['type_mode'];
		
		
		$where .= " AND trans_type ='".$type_mode."'";
	}
   if(!empty($_GET['search_mode']))
	{
		$search_mode = $_GET['search_mode'];
		
		
		$where .= " AND ( mtn_mobile_number ='".$search_mode."' OR full_name ='".$search_mode."')";
	}	
	
}	

$query = $wpdb->get_results("select * from `wp_mtn_order_history` WHERE user_id = ".$current_user->ID.' '.$where." order by order_id desc");
    
    $total_pages = count($query);

    $limit = 10;                                //how many items to show per page
    $page = $_GET['numPage'];

    if($page) 
        $start = ($page - 1) * $limit;          //first item to display on this page
    else
        $start = 0;                             //if no page var is given, set start to 
    

    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
    $prev = $page - 1;                          //previous page is page - 1
    $next = $page + 1;                          //next page is page + 1
    $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;                      //last page minus 1

    $pagination = "";
    if($lastpage > 1)
    {   
        $prev = $page-1;
		$next = $page+1;
        $pagination .= '<nav aria-label="Page navigation" class="pagi_name">
          	<ul class="pagination">';
        //previous button
        if ($page > 1) 
            $pagination.= '<li class="previous">
              <a href="'.$siteurl.'/?numPage='.$prev.'" aria-label="Previous">
                <img src="'.$dir_url.'img_arrowLeft.png" />
              </a>
            </li>';
        else
            $pagination.= '<li class="previous">
		      <a href="javascript:void(0);" aria-label="Previous">
			    <img src="'.$dir_url.'img_arrowLeftg.png" />
			  </a>
			  </li>'; 

        //next button
        if ($page < $lastpage) 
            $pagination.= '<li class="next">
              <a href="'.$siteurl.'/?numPage='.$next.'" aria-label="Next">
                <img src="'.$dir_url.'img_arrowRight.png" />
              </a>
            </li>';
        else
            $pagination.= '<li class="next">
		        <a href="javascript:void(0);" aria-label="Next">
		          <img src="'.$dir_url.'img_arrowRightg.png" />
				</a>
				</li>';
		
		
          $pagination.= '</ul></nav>';       
    }

$rows = $wpdb->get_results("select * from `wp_mtn_order_history` WHERE user_id = ".$current_user->ID.' '.$where." order by order_id desc LIMIT $start, $limit");

    $trans1 = 'Show filter'; 
	$trans2 = 'Last'; 
	$trans3 = 'Select Days'; 
	$trans4 = 'Days'; 
	$trans5 = 'From'; 
	$trans6 = 'To'; 
	$trans7 = 'Type'; 
	$trans8 = 'Select Type'; 
	$trans9 = 'Search'; 
	$trans10 = 'Enter MTN Number of holder Name';
	$trans11 = 'Submit'; 
	$trans12 = 'Date'; 
	$trans13 = 'Amount'; 
	$trans14 = 'Receipt';

	
if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'Montrer Filtre'; 
	$trans2 = 'Derniers'; 
	$trans3 = 'S&#233;lectionner'; 
	$trans4 = 'Jours'; 
	$trans5 = 'De'; 
	$trans6 = '&#192;'; 
	$trans7 = 'Type'; 
	$trans8 = 'S&#233;lectioner Type';
	$trans9 = 'Entrer le num&#233;ro recherch&#233;'; 
	$trans10 = 'Entrer le num&#233;ro recherch&#233;';
    $trans11 = 'Filtrer'; 
	$trans12 = 'Date';
	$trans13 = 'Montant'; 
	$trans14 = 'Re&#231;u';

}
											

$formHtml .= '<div class="mainHistory">
<button type="button" class="btn btn-info" id="filterBtn" data-toggle="collapse" data-target="#historyFilter">'.$trans1.'</button>
<div id="historyFilter" class="collapse">
<div class="box_dayDate">
  <div class="filter_days"> <span class="hd_last">'.$trans2.'</span>
   <div class="hddays">
    <form method="get" action="" id="limitRecordForm">
	
	<select name="last" id="limitRecord">
	  <option value="">'.$trans3.'</option>
      <option value="10"';
	  if($last == 10){$formHtml .= "selected";}
	  $formHtml .= '>10</option><option value="20"';
	  if($last == 20){$formHtml .= "selected";}
	  $formHtml .= '>20</option><option value="30"';
	  if($last == 30){$formHtml .= "selected";}
	  $formHtml .= '>30</option>
    </select>
	</form>
	<span class="days hd_day">'.$trans4.'</span>
   </div>
  </div>
 </div> 
 <div class="box_dayDate">
 <form method="get" action="" id="filterRecordForm">
  <div class="box_date">
    <div class="row">
      <div class="col-sm-6">
        <div id="datetimepicker2" class="input-append date">
          <label>'.$trans5.': </label>
          <input id="jquery-datepicker-from" name="from_date" type="text" />
          </input>
         </div>
      </div>
      <div class="col-sm-6">
        <div id="datetimepicker3" class="input-append date">
          <label>'.$trans6.': </label>
          <input id="jquery-datepicker-to" name="to_date" type="text" />
          </input>
          <span class="add-on"> <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i> </span>
		</div>
      </div>
    </div>
  </div>

<div class="box_typ">
    <div class="type_filter"> <span class="hd_typ">'.$trans7.'</span>
        <select name="type_mode">
          <option value="">'.$trans8.'</option>
          <option value="Recharge">Recharge</option>
          <option value="Transfer">Transfer</option>
        </select>
      </div>
    
      <div class="searchMtn">
        <label>'.$trans9.'</label>
        <input type="text" name="search_mode" placeholder="'.$trans10.'" />
      </div>
    
</div>
<div class="box_typ">
<input type="submit" name="filterBtnSub" value="'.$trans11.'" class="btn btn-info" id="filterBtnSub" />
</div>
</form>
</div>
 </div>
</div>			   
</div>			


    <div class="contact-box cont_hist">
    <div class="table_row">
		<div class="border-div table_heading">
		
		    <div class="table-format">
				<div class="view-content_form">
					'.$trans12.'
				</div>
			</div>
			
			<div class="table-format">
				<div class="view-content_form">
					'.$trans7.'
				</div>
			</div>
			
			<div class="table-format">
				<div class="view-content_form">
					Trans ID
				</div>
			</div>
			
			<div class="table-format">
				<div class="view-content_form">
					'.$trans6.'
				</div>
			</div>

			<div class="table-format">
				<div class="view-content_form">
					'.$trans13.'
				</div>
			</div>

			<div class="table-format">			
				<div class="view-view_more">
					'.$trans14.'
				</div>
			</div>
		</div>';
      foreach($rows as $row){
		  $date = date('Y-m-d', strtotime($row->date_time));
		  $receipt_link = '#';
		  $trasactionID = $row->payment_transaction_id;
		  $resStatus = '';
		  $resAmount = '';
		  
		  if($row->trans_type == 'Recharge' && $row->refund_status == '01'){
			  
			  $resStatus = $row->trans_type.' Refund';
			  
			  $resAmount = $row->refund_amount_xaf;
			  
			  
			  
		  }else{
			  
			  $resStatus = $row->trans_type; 
			  $resAmount = $row->xaf_trans_amount;
			  
		  }
		  
		  if(!empty($row->receipt_link)){
			  
			  $inv = explode("invoice_", $row->receipt_link);
			  $recieptFileName = 'invoice_'.$inv[1];
			 
			     $receipt_link = 'http://dsp.lab.kit-services.com/download.php?download_file='.$recieptFileName;
			  }
		  if($row->mtn_status == 'completed'){$trasactionID = $row->MOMTransactionID;}
		  
		$formHtml .= '<div class="border-div">
		
		    <div class="table-format">
				<div class="view-content_form">
					'.$date.'
				</div>
			</div>
			
			<div class="table-format">
				<div class="view-content_form">
					'.$resStatus.'
				</div>
			</div>

			<div class="table-format">
				<div class="view-content_form">
					'.$trasactionID.'
				</div>
			</div>

			<div class="table-format">
				<div class="view-content_form">
					'.$row->mtn_mobile_number.'
				</div>
			</div>

			<div class="table-format">
				<div class="view-content_form">
					'.$resAmount.'
				</div>
			</div>
            
			<div class="table-format">			
				<div class="view-view_more">
					<a href="'.$receipt_link.'"  title="Download"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span></a>
				</div>
			</div>
		</div>';
	  }	

	$formHtml .= '</div></div>';
	
	$formHtml .= $pagination;
		
	return $formHtml;
	
}
add_shortcode('order_history', 'mtn_order_history' );


// ajax hooks get_amountData
function get_amountData_callback(){
	
	global $wpdb;
	$fees = '';
	$amount = intval($_POST['amount']);
	$rate = get_option('currency_coversion_rate');
	$euroAmount = number_format($amount/$rate, 2, '.', '');
	
	$recharge_fees = $wpdb->get_row("SELECT recharge_fees FROM `wp_add_fees_recharge` WHERE ( amount_in_min <= '".$euroAmount."' AND amount_in_max >= '".$euroAmount."' )");
	
    if(!empty($recharge_fees->recharge_fees))
	{
		$fees = $recharge_fees->recharge_fees;
	}
	else
	{
		$newfees = $wpdb->get_row("SELECT MAX(recharge_fees) AS extra_fees FROM `wp_add_fees_recharge`");
		$fees = $newfees->extra_fees;
		
	}
	
	
	
	
	
	$finalAmount = number_format($euroAmount+$fees, 2, '.', '');
	
	
    
	
	
	
	$html = '<div class="amount-div">
				                			<div class="row">
					                			<div class="col-sm-6 col-xs-6">
					                				<h3>Send amount</h3>
					                			</div>
					                			<div class="col-sm-6 col-xs-6 text-right">
					                				<h3>EUR <span id="send_amount">'.$euroAmount.'</span></h3>
					                			</div>
				                			</div>
				                			<div class="row">
					                			<div class="col-sm-6 col-xs-6">
					                				<h3>Fees</h3>
					                			</div>
					                			<div class="col-sm-6 col-xs-6 text-right">
					                				<h3>EUR <span id="fees">'.$fees.'</span></h3>
					                			</div>
				                			</div>
				                		</div>

				                		<div class="total-pay">
				                			<div class="row">
					                			<div class="col-sm-6 col-xs-6">
					                				<h3>Total to Pay</h3>
					                			</div>
					                			<div class="col-sm-6 col-xs-6 text-right">
					                				<h3>EUR <span id="total_pay">'.$finalAmount.'</span></h3>
					                			</div>
				                			</div>
				                		 </div>';
	echo $html;
	wp_die();
	
	
	
	
	
}
add_action( 'wp_ajax_get_amountData', 'get_amountData_callback' );
add_action( 'wp_ajax_nopriv_get_amountData', 'get_amountData_callback' );



// ajax hooks xaf get_amountData xafamountData
function get_xafamountData_callback(){
	
	global $wpdb;
	
	
	
	$amount = intval($_POST['amount']);
	
	$identifier = $_POST['identifier'];
    $passpharse = $_POST['passpharse'];
	
	$address = $wallet = '';
	
	$rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);
	
	$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
	
	$tradeFees = get_option('trade_fees');
	
	$trade_fees = 0.00;
	
	if(!empty($tradeFees))
	{
		$trade_fees = number_format(($amount*$tradeFees)/100, 2, '.', '');
	
	}
	
	//calculating Network Fees
	$myAPIKEY       = get_option('blocktrail_api_key');
	$myAPISECRET    = get_option('blocktrailsecret');
	$testnet        = true; //false for bitcoin mainnet or true for testnet
	$walletIdent    = get_option('testnet_wallet_identifier');
    $walletPassword = get_option('testnet_wallet_password');
	
	if(get_option('blocktrail_mode') == 'on'){
		$testnet    = false;
		$walletIdent    =  get_option('live_wallet_identifier');
		
		$walletPassword = get_option('live_wallet_password');
		
	}

   
	$error = '';
	
	
	
	try {
		// Initialize the SDK
		 $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
	     
	  } catch (Exception $e) {
		$error .= "Initializing the SDK failed because {$e->getMessage()}";
	}
	
	try {
    // Or you can initialize an already existing wallet
       //$wallet = $client->initWallet($identifier, $passpharse);
	   $wallet = $client->initWallet($walletIdent, $walletPassword);
    } catch (Exception $e) {
      $error .= "Initializing an existing wallet failed because {$e->getMessage()}";
    }
   
   
    
	 try {
		// Create a new bitcoin address for this $wallet
		$address = $wallet->getNewAddress();
		//$addressClient = $wallet1->getNewAddress();
	  } catch (Exception $e) {
		$error .= "Creating a new bitcoin address failed because {$e->getMessage()}";
	} 
	
	//echo $error;
	
	$btc = convert_exponantial_to_decimal($btcamountRecieved);

    $toSatoshi = BlocktrailSDK::toSatoshi($btc);
	
	$outputs = array($address => $toSatoshi);
	
	
	
	
	
	$result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
	
	
    $result = $wallet->coinSelection($outputs, false, false, Wallet::FEE_STRATEGY_OPTIMAL, null);
	
	
	
	$kb = $result['size']/1000;
	
	$am = (int)round($kb*$result['fees']['optimal']);
	
	$network_fees_in_xaf = get_conversion_bitcoin_with_amount('BTC', 'XAF', BlocktrailSDK::toBTC($am));
	
	
	
	$xafFinalAmount = number_format($amount+$trade_fees+$network_fees_in_xaf, 2, '.', '');
	
	
	$wallet = $client->initWallet($identifier, $passpharse);
	$userAddress = $wallet->getNewAddress();
	
	//echo $error.'_'.$userAddress;
	echo $trade_fees."##".$network_fees_in_xaf."##".$btc."##".$xafFinalAmount."##".$rate."##".$userAddress;
	
	
	wp_die();
	
	
	
	
	
}
add_action( 'wp_ajax_get_xafamountData', 'get_xafamountData_callback' );
add_action( 'wp_ajax_nopriv_get_xafamountData', 'get_xafamountData_callback' );



// ajax hooks xaf get_amountData for Sell BTC
function get_xafamountDataSell_callback(){
	
	global $wpdb;
	$amount = $_POST['amount'];
	$btc = '';
	$xafFinalAmount = $xafRecieved = '';
	$currency_code = $_POST['currency_code'];
	$eurRate = get_option('currency_coversion_rate');
	$fees = get_option('trade_fees_xaf');
	$rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);
	
	if($currency_code == 'XAF'){
		
	
	
	$amount = intval($amount);
	
	
	$btcamountRecieved = get_conversion_bitcoin_with_amount('XAF', 'BTC', $amount);
	
	$btc = convert_exponantial_to_decimal($btcamountRecieved);
	
	

    $xafFinalAmount = number_format($amount-$fees, 2, '.', '');
	
	
	
	}else{
		
		
		
		$xafRecieved = get_conversion_bitcoin_with_amount('BTC', 'XAF', $amount);
		
		$btc = $amount;
		
		$xafFinalAmount = number_format($xafRecieved-$fees, 2, '.', '');
	}
	
	
	
	echo $btc."##".$xafFinalAmount."##".$rate."##".$fees;
	
	wp_die();
	
	
	
	
	
}
add_action( 'wp_ajax_get_xafamountDataSell', 'get_xafamountDataSell_callback' );
add_action( 'wp_ajax_nopriv_get_xafamountDataSell', 'get_xafamountDataSell_callback' );

/**
 * Add new fields above 'Update' button.
 *
 * @param WP_User $user User object.
 */
 
/*function mtn_additional_profile_fields( $user ) {

    
    $msisdn = get_the_author_meta( 'msisdn', $user->ID );
    
    ?>
<!--<h3>Edit Kit Number</h3>
<table class="form-table">
  <tr>
    <th><label for="kit_number">Edit Kit Number</label></th>
    <td><input type="text" value="<?php //echo $msisdn; ?>" name="msisdn" /></td>
  </tr>
</table>-->
<?php
/*}

add_action( 'edit_user_profile', 'mtn_additional_profile_fields' );

function mtn_save_profile_fields( $user_id ) {

    if ( ! current_user_can( 'edit_user', $user_id ) ) {
   	 return false;
    }

    if ( empty( $_POST['msisdn'] ) ) {
   	 return false;
    }

    update_usermeta( $user_id, 'msisdn', $_POST['msisdn'] );
}

add_action( 'personal_options_update', 'mtn_save_profile_fields' );
add_action( 'edit_user_profile_update', 'mtn_save_profile_fields' );*/


function getTransactionData($ID){
	
	    $customer_id = get_option('customer_id');
		
		$sofort_api_key = get_option('sofort_api_key');
		
	    $url = "https://api.sofort.com/api/xml"; 
	    $key = base64_encode($customer_id.":".$sofort_api_key);
       

        // xml post structure

           $xml_post_string = '<?xml version="1.0" encoding="UTF-8" ?>
<transaction_request version="2">
  <transaction>'.$ID.'</transaction>
</transaction_request>
';  
                
                $headers = array(
                "Authorization: Basic ".$key,
                "Content-type: application/xml;charset=\"utf-8\"",
                "Accept: application/xml;charset=\"utf-8\"",
                ); 
                
                
                
                
                
                
                // PHP cURL  for https connection with auth
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                
                // converting
                $response = curl_exec($ch); 
                curl_close($ch);
                //echo $response;
                //print_r($response);
                $xml = simplexml_load_string($response);
                $json = json_encode($xml);
                $arr = json_decode($json,true);
                
                return $arr;
                
                
                
 }
                
                
function getPaypalTransactionData($ID){
                
                
                
                
                $url = "https://www.sandbox.paypal.com/cgi-bin/webscr"; 
                
                
                
                // xml post structure
                
                $xml_post_string = array('cmd'=>'_notify-synch', 'tx'=>$ID, 'at'=>'73ZZxlSQrvO2UZMSxVTqFTqbwz8phvapB-nYw_AeBQww1ZbdshROOoMAPsS', 'submit' => 'PDT');
                
                // PHP cURL  for https connection with auth
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 100);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
                
                
                // converting
                $response = curl_exec($ch); 
				
                curl_close($ch);
                
                $lines = explode("\n", $response);
                
                $keyarray = array();
                
                if (strcmp ($lines[0], "SUCCESS") == 0) {
                
                for ($i=1; $i<count($lines);$i++){

				list($key,$val) = explode("=", $lines[$i]);

				$keyarray[urldecode($key)] = urldecode($val);

				}
			}
            return $keyarray;

					
}


function go_checkout_callback(){
	
	
	if($_POST['payment_method']== 'Sofort')
	{	
        $mtn_mobile = $_POST['mtn_mobile'];
		$trans_fees = $_POST['trans_fees'];
		
		$curreny_type_amount = $_POST['curreny_type_amount'];
		
        $amount = $_POST['amount']; 
		$title = "Recharge for: ".$mtn_mobile; 
		
		$customer_id = get_option('customer_id');
		$project_id = get_option('project_id');
		$sofort_api_key = get_option('sofort_api_key');
	
		$url = "https://api.sofort.com/api/xml"; 
		$key = base64_encode($customer_id.":".$sofort_api_key);
		$success_url = $notify_url = $notification_url = '';
		if(ICL_LANGUAGE_CODE == "fr")
		{
		  $success_url =  'http://dsp.lab.kit-services.com/success-url/?trx=-TRANSACTION-';
		  $notify_url = 'http://dsp.lab.kit-services.com/notify/?lang=fr';
		  $notification_url = 'http://dsp.lab.kit-services.com/payment-notification/?lang=fr';
		  $abort_url = 'http://dsp.lab.kit-services.com/abort-transaction/?lang=fr';
		}
		else
		{
		  $success_url =  'http://dsp.lab.kit-services.com/success-url/?trx=-TRANSACTION-';
		  $notify_url = 'http://dsp.lab.kit-services.com/notify/';
		  $notification_url = 'http://dsp.lab.kit-services.com/payment-notification/';
		  $abort_url = 'http://dsp.lab.kit-services.com/abort-transaction/';
			
		}	
		
		
       

        // xml post structure

           $xml_post_string = '<?xml version="1.0" encoding="UTF-8" ?>
<multipay>
 <project_id>'.$project_id.'</project_id>
 <interface_version>pn_test_1</interface_version>
 <amount>'.$amount.'</amount>
 <currency_code>EUR</currency_code>
 <reasons>
 <reason>Testueberweisung</reason>
 <reason>-TRANSACTION-</reason>
 </reasons>
 <user_variables>
 <user_variable>'.$title.'</user_variable>
 <user_variable>'.$mtn_mobile.'</user_variable>
 <user_variable>'.$curreny_type_amount.'</user_variable>
 <user_variable>'.$trans_fees.'</user_variable>
 </user_variables>
 <success_url>'.$success_url.'</success_url>
 <success_link_redirect>1</success_link_redirect>
 <abort_url>'.$abort_url.'</abort_url>
 <notification_urls>
 <notification_url>'.$notify_url.'</notification_url>
 <notification_url notify_on="received,loss">'.$notification_url.'</notification_url>
 </notification_urls>
 <su />
</multipay>
';  

           $headers = array(
		                "Authorization: Basic ".$key,
                        "Content-type: application/xml;charset=\"utf-8\"",
                        "Accept: application/xml;charset=\"utf-8\"",
                        ); 
					
					


            

            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch); 
            curl_close($ch);
            $xml = simplexml_load_string($response);
			$json = json_encode($xml);
			$arr = json_decode($json,true);
			$transactionId = $arr['transaction'];
			$payment_url = $arr['payment_url'];
			if(!empty($transactionId) && !empty($payment_url))
			{ 
		   
		        echo '1##'.$payment_url;
			
		     } else
				
			{
				echo '0##'.$arr['error']['message'];
				//print_r($arr);
					
			}
	
    }
	
	wp_die();
	
	
}
add_action( 'wp_ajax_go_checkout', 'go_checkout_callback' );
add_action( 'wp_ajax_nopriv_go_checkout', 'go_checkout_callback' );


function go_checkout_callback_third(){
	
	
	if($_POST['payment_method']== 'Sofort')
	{	
        $mtn_mobile = $_POST['mtn_mobile'];
		$trans_fees = $_POST['trans_fees'];
		
		$curreny_type_amount = $_POST['curreny_type_amount'];
		
        $amount = $_POST['amount']; 
		$title = "Recharge for: ".$mtn_mobile; 
		
		$customer_id = get_option('customer_id');
		$project_id = get_option('project_id');
		$sofort_api_key = get_option('sofort_api_key');
	
		$url = "https://api.sofort.com/api/xml"; 
		$key = base64_encode($customer_id.":".$sofort_api_key);
		$success_url = $notify_url = $notification_url = '';
		if(ICL_LANGUAGE_CODE == "fr")
		{
		  $success_url =  'http://dsp.lab.kit-services.com/success-url-third-party/?trx=-TRANSACTION-';
		  $notify_url = 'http://dsp.lab.kit-services.com/notify/?lang=fr';
		  $notification_url = 'http://dsp.lab.kit-services.com/payment-notification/?lang=fr';
		  $abort_url = 'http://dsp.lab.kit-services.com/abort-transaction/?lang=fr';
		}
		else
		{
		  $success_url =  'http://dsp.lab.kit-services.com/success-url-third-party/?trx=-TRANSACTION-';
		  $notify_url = 'http://dsp.lab.kit-services.com/notify/';
		  $notification_url = 'http://dsp.lab.kit-services.com/payment-notification/';
		  $abort_url = 'http://dsp.lab.kit-services.com/abort-transaction/';
			
		}	
		
		
       

        // xml post structure

           $xml_post_string = '<?xml version="1.0" encoding="UTF-8" ?>
<multipay>
 <project_id>'.$project_id.'</project_id>
 <interface_version>pn_test_1</interface_version>
 <amount>'.$amount.'</amount>
 <currency_code>EUR</currency_code>
 <reasons>
 <reason>Testueberweisung</reason>
 <reason>-TRANSACTION-</reason>
 </reasons>
 <user_variables>
 <user_variable>'.$title.'</user_variable>
 <user_variable>'.$mtn_mobile.'</user_variable>
 <user_variable>'.$curreny_type_amount.'</user_variable>
 <user_variable>'.$trans_fees.'</user_variable>
 </user_variables>
 <success_url>'.$success_url.'</success_url>
 <success_link_redirect>1</success_link_redirect>
 <abort_url>'.$abort_url.'</abort_url>
 <notification_urls>
 <notification_url>'.$notify_url.'</notification_url>
 <notification_url notify_on="received,loss">'.$notification_url.'</notification_url>
 </notification_urls>
 <su />
</multipay>
';  

           $headers = array(
		                "Authorization: Basic ".$key,
                        "Content-type: application/xml;charset=\"utf-8\"",
                        "Accept: application/xml;charset=\"utf-8\"",
                        ); 
					
					


            

            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch); 
            curl_close($ch);
            $xml = simplexml_load_string($response);
			$json = json_encode($xml);
			$arr = json_decode($json,true);
			$transactionId = $arr['transaction'];
			$payment_url = $arr['payment_url'];
			if(!empty($transactionId) && !empty($payment_url))
			{ 
		   
		        echo '1##'.$payment_url;
			
		     } else
				
			{
				echo '0##'.$arr['error']['message'];
				//print_r($arr);
					
			}
	
    }
	
	wp_die();
	
	
}
add_action( 'wp_ajax_go_checkout_third', 'go_checkout_callback_third' );
add_action( 'wp_ajax_nopriv_go_checkout_third', 'go_checkout_callback_third' );


function go_checkout_bitcoin(){
	
   
	
	global $wpdb;
	
	$amount = $_POST['amount'];
	$curreny_type_amount = $_POST['curreny_type_amount'];
	$trans_fees = $_POST['trans_fees'];
	$full_name = $_POST['full_name'];
	$mtn_mobile = $_POST['mtn_mobile'];
	date_default_timezone_set('Africa/Douala');
	$time = date('Y-m-d h:i:s');
	
	/*if(empty($trans_fees))
	{
		
		$myRaw = $wpdb->get_row("SELECT * FROM `wp_add_fees_recharge` WHERE  amount_in_max >= '".$amount."'");
		$trans_fees = $myRaw->recharge_fees;
	}*/
	
		
	$sendAmount1  = get_conversion_bitcoin_with_amount('EUR', 'BTC', $amount); 
	
    $sendAmount = convert_exponantial_to_decimal($sendAmount1);
	
	$user_id = get_current_user_id();
	
	$partner_mobile_money = get_user_meta( $user_id, 'partner_mobile_money', true );
	
	$digits = 5;

	$payment_id = rand(pow(10, $digits-1), pow(10, $digits)-1);
	
	

// Variables 
$myAPIKEY       = get_option('blocktrail_api_key');
$myAPISECRET    = get_option('blocktrailsecret');
$testnet        = true; //false for bitcoin mainnet or true for testnet
$walletIdent    = get_option('testnet_wallet_identifier');
$walletPassword = get_option('testnet_wallet_password');
if(get_option('blocktrail_mode') == 'on'){
	$testnet    = false;
	$walletIdent    = get_option('live_wallet_identifier');
    $walletPassword = get_option('live_wallet_password');
}

$callbackURL    = "http://dsp.lab.kit-services.com/blocktrail/notify.php";


$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
$wallet = $client->initWallet([
        "identifier" => $walletIdent,
        "passphrase" => $walletPassword
]);

    

    $address = $wallet->getNewAddress();
	$client->subscribeAddressTransactions("Webhook_02062018", $address);
	
	$wpdb->query("INSERT INTO `wp_mtn_order_history` (order_id, user_id, payment_transaction_id, trans_type, euro_trans_amount, xaf_trans_amount, trans_fees, full_name, date_time, mtn_mobile_number, african_mtn_regi_country, partner_mobile_money, payment_status, mtn_status, MOMTransactionID, ProcessingNumber, SenderID, MSISDNNum, OpCoID, receipt_link, status_code, error_ticket_id, sending_reason, payment_bitcoin_address, amount_in_btc) 
				 VALUES('', '".$user_id."', '".$payment_id."', 'Recharge', '".$amount."', '".$curreny_type_amount."','".$trans_fees."', '".$full_name."', '".$time."', '".$mtn_mobile."', '', '".$partner_mobile_money."', 'pending','pending', '', '', '', '', '', '', '', '', '', '".$address."', '".$sendAmount."')");	

	
	echo $address.'##'.$sendAmount.'##'.$payment_id;
	
	die(0);
}
add_action( 'wp_ajax_go_checkout_bitcoin', 'go_checkout_bitcoin' );
add_action( 'wp_ajax_nopriv_go_checkout_bitcoin', 'go_checkout_bitcoin' );


function go_checkout_bitcoin_address(){
	
   
	
global $wpdb;
$payment_id = $_POST['ProdId'];	
	

// Variables 
$myAPIKEY       = get_option('blocktrail_api_key');
$myAPISECRET    = get_option('blocktrailsecret');
$testnet        = true; //false for bitcoin mainnet or true for testnet
$walletIdent    = get_option('testnet_wallet_identifier');
$walletPassword = get_option('testnet_wallet_password');
if(get_option('blocktrail_mode') == 'on'){
	$testnet    = false;
	$walletIdent    = get_option('live_wallet_identifier');
    $walletPassword = get_option('live_wallet_password');
}

$callbackURL    = "http://dsp.lab.kit-services.com/blocktrail/notify.php";


$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
$wallet = $client->initWallet([
        "identifier" => $walletIdent,
        "passphrase" => $walletPassword
]);

    

$address = $wallet->getNewAddress();

$client->subscribeAddressTransactions("Webhook_02062018", $address);

$row = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE payment_bitcoin_address = '".$payment_id."'"); 
$euro_trans_amount = $row->euro_trans_amount;		
$sendAmount1  = get_conversion_bitcoin_with_amount('EUR', 'BTC', $euro_trans_amount); 
$sendAmount = convert_exponantial_to_decimal($sendAmount1);

$sql = "INSERT INTO `wp_all_order_address` (id, order_id, user_id, address) VALUES('', '".$row->order_id."', '".$row->user_id."', '".$address."')";
$wpdb->query($sql);	


$wpdb->query("UPDATE `wp_mtn_order_history` SET amount_in_btc = '".$sendAmount."' WHERE order_id = '".$row->order_id."'");	
	
	echo $address.'##'.$sendAmount;
	
	die(0);
}
add_action( 'wp_ajax_go_checkout_bitcoin_address', 'go_checkout_bitcoin_address' );
add_action( 'wp_ajax_nopriv_go_checkout_bitcoin_address', 'go_checkout_bitcoin_address' );


//check notification manually

function go_checkout_bitcoin_address_manually(){
	
global $wpdb;
$msg = '';
$payment_bitcoin_address = $_POST['btcAddress'];	
$date = date('Y-md h:i:s');
// Variables 
	$myAPIKEY       = get_option('blocktrail_api_key');
	$myAPISECRET    = get_option('blocktrailsecret');
	$testnet        = true; //false for bitcoin mainnet or true for testnet
	$walletIdent    = get_option('testnet_wallet_identifier');
	$walletPassword = get_option('testnet_wallet_password');
	if(get_option('blocktrail_mode') == 'on'){
		$testnet = false;
		$walletIdent    = get_option('live_wallet_identifier');
		$walletPassword = get_option('live_wallet_password');
	}


$row = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE payment_bitcoin_address = '".$payment_bitcoin_address."'");
if($row){
if($row->payment_status == 'pending'){
	
	
	
		
	
	
    $btceur = get_conversion_bitcoin('BTC', 'EUR');
	$btcxaf = get_conversion_bitcoin('BTC', 'XAF');
	$btcNetwork = 'TESTNET';
	if(get_option('blocktrail_mode') == 'on'){
		
		$btcNetwork = 'LIVENET';
		
	}
	
    

	$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);

	$data = $client->address($row->payment_bitcoin_address);
	$paid = '';
    if(!empty($data['received'])){
		
		$paid = $data['received'];
		
	}else if(!empty($data['unconfirmed_received'])){
		
	    $paid = $data['unconfirmed_received'];
    }
	else
	{
		
		echo "Recieved is Empty!";
	}
	
	
	
	
    
	if(!empty($paid)){
		
	$paidAmount = BlocktrailSDK::toBTC($paid);
	
	$email = 'votiveyogesh@gmail.com,finances@diaspo-cc.com';
	$sub = 'New Transaction Lab Yogesh';
	$body = 'Santoshi Amount: '.$paid.'-------------Amount: '.$paidAmount.'-------------Address:'.$payment_bitcoin_address;
	mail($email, $sub, $body);
	
	$euramount = get_conversion_bitcoin_with_amount('BTC', 'EUR', $paidAmount);
	
     if($paidAmount < $row->amount_in_btc){
		
		 
		$wpdb->query("UPDATE `wp_mtn_order_history` SET btc_amount = '".$paidAmount."', rate_btceur = '".$btceur."', rate_btcxaf = '".$btcxaf."', btc_network = '".$btcNetwork."',  amount_paid_btc = '".$paidAmount."', json_data = '', amount_paid_eur = '".$euramount."', payment_status = 'Completed' WHERE payment_bitcoin_address = '".$payment_bitcoin_address."'");
	 
	 }else{
		
		$wpdb->query("UPDATE `wp_mtn_order_history` SET btc_amount = '".$row->amount_in_btc."', rate_btceur = '".$btceur."', rate_btcxaf = '".$btcxaf."', btc_network = '".$btcNetwork."',  payment_status = 'Completed', json_data = '' WHERE payment_bitcoin_address = '".$payment_bitcoin_address."'");
	   
	   }
	 
	 
    if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
	   
	}else{
	 
      if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo "Votre paiement n'a pas encore &#233;t&#233; re&#231;u. Merci de patienter.";
	}else{
		echo ' Payment not yet received!';
	}		 
		
	}
   
   
} else {
	
	if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
 }
}else{
	$row1 = $wpdb->get_row("SELECT * FROM `wp_all_order_address` WHERE address = '".$payment_bitcoin_address."'");
	
	$row2 = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = '".$row1->order_id."'");
	
	$btceur = get_conversion_bitcoin('BTC','EUR');
	$btcxaf = get_conversion_bitcoin('BTC','XAF');
	
	$btcNetwork = 'TESTNET';
	
	if(get_option('blocktrail_mode') == 'on'){
		
		$btcNetwork = 'LIVENET';
		
	}
	
	
	if($row2->payment_status == 'pending'){
		
	$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);

	$data = $client->address($payment_bitcoin_address);
	$paid = '';
    if(!empty($data['received'])){
		
		$paid = $data['received'];
	}elseif(!empty($data['unconfirmed_received'])){
	    $paid = $data['unconfirmed_received'];
    }
	else
	{
		echo " Recieved is Empty";
		
	}
    
	if(!empty($paid)){
		
	$paidAmount = BlocktrailSDK::toBTC($paid);
	
	$email = 'votiveyogesh@gmail.com,finances@diaspo-cc.com';
	$sub = 'New Transaction Lab Yogesh';
	$body = 'Santoshi Amount: '.$paid.'-------------Amount: '.$paidAmount.'-------------Address:'.$payment_bitcoin_address;
	mail($email, $sub, $body);
	
	$euramount = get_conversion_bitcoin_with_amount('BTC', 'EUR', $paidAmount);
	
     if($paidAmount < $row2->amount_in_btc){
		
		 
		$wpdb->query("UPDATE `wp_mtn_order_history` SET btc_amount = '".$paidAmount."', rate_btceur = '".$btceur."', rate_btcxaf = '".$btcxaf."', btc_network = '".$btcNetwork."',  amount_paid_btc = '".$paidAmount."', json_data = '', amount_paid_eur = '".$euramount."', payment_status = 'Completed' WHERE order_id = '".$row1->order_id."'");
	 }else{
		
		$wpdb->query("UPDATE `wp_mtn_order_history` SET btc_amount = '".$row2->amount_in_btc."', rate_btceur = '".$btceur."', rate_btcxaf = '".$btcxaf."', btc_network = '".$btcNetwork."',  payment_status = 'Completed', json_data = '' WHERE order_id = '".$row1->order_id."'");
	   }
	 
	if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
	 
	}else{
	 
     
      if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo "Votre paiement n'a pas encore &#233;t&#233; re&#231;u. Merci de patienter.";
	   }else{
		 echo 'Payment not yet received!';
	  }	 
		
	 }
		
	}	
		
	
}

  die(0);
}
add_action( 'wp_ajax_go_checkout_bitcoin_address_manually', 'go_checkout_bitcoin_address_manually' );
add_action( 'wp_ajax_nopriv_go_checkout_bitcoin_address_manually', 'go_checkout_bitcoin_address_manually' );


function invoiceTemp($args)
{
        $user_id = $args['user_id'];
		$tranx_id = $args['tranx_id'];
		$date_time = $args['date_time'];
		$sender_fname = $args['sender_fname'];
		$sender_lname = $args['sender_lname'];
		$sender_residense_country = $args['sender_residense_country'];
		$sender_address = $args['sender_address'];
		$sender_zipcode_city = $args['sender_zipcode_city'];
		$sender_country = $args['sender_residense_country'];
		$sender_phone = $args['sender_phone'];
		$reciever_fname = $args['reciever_fname'];
		$reciever_lname = $args['reciever_lname'];
		$reciever_residense_country = $args['reciever_residense_country'];
		$reciever_address = $args['reciever_address'];
		$reciever_zipcode_city = $args['reciever_zipcode_city'];
		
		
		
		$reciever_country = $args['reciever_residense_country'];
		$reciever_phone = $args['reciever_phone'];
		$description = $args['trans_type'];
		$xaf_trans_amount = $args['xaf_trans_amount'];
		$euro_trans_amount = $args['euro_trans_amount'];
		$trans_fees = $args['trans_fees'];
		$description = $args['description'];
		$paypal_fees = $args['paypal_fees'];
		$exchange_rate = $args['exchange_rate'];
		$total_fees = $args['total_fees'];  
	
	
	

$html = '
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,1000,1000i" rel="stylesheet">
<style>
body {
	
	font-family: "Open Sans", sans-serif;
}
.main_wrap {
	width: 800px;
	float: left;
	margin: 0px auto;
	padding: 20px;
	
}
.head_logo {
	width: 205px;
	float: right;
	margin: 0px 0px;
	padding: 0px;
}
.invoice_one {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_two {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-top: 1px solid #5d5c5c;
	border-right: 1px solid #5d5c5c;
	border-left: 1px solid #5d5c5c;
}
.invoice_on {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_on_l {
	width: 300px;
	float: left;
	margin: 0px;
	font-size: 13px;
	padding: 5px;
	letter-spacing: 1px;
}
.invoice_on_r {
	width: 319px;
    float: left;
    margin: 0px;
    padding: 4px;
    background: #deeaf6;
    border-left: 1px solid #5d5c5c;
}
.invoice_one h1 {
	text-align: center;
	margin: 60px 0px;
}
.invoice_three_main {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}
.invoice_three {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	background: #a6a6a6;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_three_l {
	width: 300px;
	float: left;
	margin: 0px;
	padding: 5px;
}
.invoice_three_r {
	width: 200px;
	float: left;
	margin: 0px;
	padding: 5px;
	border-left: 1px solid #5d5c5c;
}
.invoice_three_bott {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_three_bott_l {
	width: 300px;
	float: left;
	margin: 0px;
	padding: 5px;
	font-size: 13px;
}
.invoice_three_bott_r {
	width: 200px;
	float: left;
	margin: 0px;
	padding: 5px;
	font-size: 14px;
	border-left: 1px solid #5d5c5c;
}
.invoice_four {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}
.invoice_four_cont {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-bottom: 1px solid #5d5c5c;
	
}
.invoice_four_cont_main {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_four_left_s {
	width: 150px;
    float: left;
    margin: 0px;
    padding: 0px;
    line-height:200px;
	height:222px;
	border-bottom: 1px solid #5d5c5c;
   
}


.invoice_four_right_s {
	width: 488px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}



.invoice_four_head {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 5px;
	background: #a6a6a6;
	border-top: 1px solid #5d5c5c;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_four_cont_l {
	width: 220px;
	float: left;
	margin: 0px;
	padding: 0px 5px;
	
}
.invoice_four_cont_c {
    width: 260px;
    float: left;
    margin: 0px;
    padding: 5px 5px;
    font-size: 10px;
    text-align: right;
  
    border-right: 1px solid #5d5c5c;
    border-left: 1px solid #5d5c5c;
	
    height: 26px;
    line-height: 18px;
}
.invoice_four_cont_r {
    width: 200px;
    float: left;
    margin: 0px;
    padding: 2px 5px;
    font-size: 10px;

    min-height: 50px;
    line-height: 31px;
}

.invoice_footer {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	margin-top: 50px;
	border-top: 1px solid #5d5c5c;
	padding-top: 15px;
}
.invoice_footer p {
	font-size: 12px;
	margin: 0;
	letter-spacing: 0px;
	line-height: 20px;
}
</style>
</head>
<body>
<div class="main_wrap">
  <div class="head_logo"><img src="'.plugin_dir_url( __FILE__ ).'img/logo.png" /> </div>
  <div class="invoice_one">
    <h1>Transaction Receipt</h1>
    <div class="invoice_two">
      <div class="invoice_on">
        <div class="invoice_on_l"> CUSTOMER NUMBER: </div>
        <div class="invoice_on_r">'.$user_id.'</div>
      </div>
      <div class="invoice_on">
        <div class="invoice_on_l"> TRANSACTION NUMBER : </div>
        <div class="invoice_on_r">'.$tranx_id.'</div>
      </div>
      <div class="invoice_on">
        <div class="invoice_on_l"> DATE : </div>
        <div class="invoice_on_r">'.$date_time.'</div>
      </div>
      <div class="invoice_three_main">
        <div class="invoice_three">
          <div class="invoice_three_l">SENDER</div>
          <div class="invoice_three_r">RECEIVER</div>
        </div>
        <div class="invoice_three_bott_m">
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> First name : '.$sender_fname.'</div>
            <div class="invoice_three_bott_r"> First name : '.$reciever_fname.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Last name : '.$sender_lname.'</div>
            <div class="invoice_three_bott_r"> Last name : '.$reciever_lname.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Country of Residence : '.$sender_residense_country.'</div>
            <div class="invoice_three_bott_r"> Country : '.$reciever_residense_country.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Address : '.$sender_address.'</div>
            <div class="invoice_three_bott_r"> Address : '.$reciever_address.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Zip Code - City : '.$sender_zipcode_city.'</div>
            <div class="invoice_three_bott_r"> Zip Code - City : '.$reciever_zipcode_city.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Tel. Number : '.$sender_phone.'</div>
            <div class="invoice_three_bott_r"> Tel. Number : '.$reciever_phone.'</div>
          </div>
        </div>
        <div class="invoice_four">
          <div class="invoice_four_head"> Description </div>
          <div class="invoice_four_cont_main">
            <div class="invoice_four_left_s">
              <div class="invoice_four_cont_l"> '.$description.' </div>
            </div>
            <div class="invoice_four_right_s">
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>MONEY RECEIVE</strong> IN XAF </div>
                <div class="invoice_four_cont_r">'.$xaf_trans_amount.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>MONEY SEND</strong> IN EURO </div>
                <div class="invoice_four_cont_r"> '.$euro_trans_amount.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> EXCHANGE RATE </div>
                <div class="invoice_four_cont_r"> '.$exchange_rate.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> FEES IN EUR </div>
                <div class="invoice_four_cont_r"> '.$trans_fees.' </div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> FEES IN XAF </div>
                <div class="invoice_four_cont_r"> '.$paypal_fees.' </div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>TOTAL IN XAF </strong></div>
                <div class="invoice_four_cont_r"> '.$total_fees.'</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="invoice_footer">
      <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
	  <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
	  <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
      
    </div>
  </div>
</div>
</body>
</html>
';

return $html;
	
	
}

//fro refund btc
function invoiceTempBTC($args)
{
        $user_id = $args['user_id'];
		$tranx_id = $args['tranx_id'];
		$date_time = $args['date_time'];
		$sender_fname = $args['sender_fname'];
		$sender_lname = $args['sender_lname'];
		$sender_residense_country = $args['sender_residense_country'];
		$sender_address = $args['sender_address'];
		$sender_zipcode_city = $args['sender_zipcode_city'];
		$sender_country = $args['sender_residense_country'];
		$sender_phone = $args['sender_phone'];
		$reciever_fname = $args['reciever_fname'];
		$reciever_lname = $args['reciever_lname'];
		$reciever_residense_country = $args['reciever_residense_country'];
		$reciever_address = $args['reciever_address'];
		$reciever_zipcode_city = $args['reciever_zipcode_city'];
		
		
		
		$reciever_country = $args['reciever_residense_country'];
		$reciever_phone = $args['reciever_phone'];
		$description = $args['trans_type'];
		$xaf_trans_amount = $args['xaf_trans_amount'];
		$euro_trans_amount = $args['euro_trans_amount'];
		$trans_fees = $args['trans_fees'];
		$description = $args['description'];
		$paypal_fees = $args['paypal_fees'];
		$exchange_rate = $args['exchange_rate'];
		$total_fees = $args['total_fees'];  
	  
	
	

$html = '
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,1000,1000i" rel="stylesheet">
<style>
body {
	
	font-family: "Open Sans", sans-serif;
}
.main_wrap {
	width: 800px;
	float: left;
	margin: 0px auto;
	padding: 20px;
	
}
.head_logo {
	width: 205px;
	float: right;
	margin: 0px 0px;
	padding: 0px;
}
.invoice_one {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_two {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-top: 1px solid #5d5c5c;
	border-right: 1px solid #5d5c5c;
	border-left: 1px solid #5d5c5c;
}
.invoice_on {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_on_l {
	width: 300px;
	float: left;
	margin: 0px;
	font-size: 13px;
	padding: 5px;
	letter-spacing: 1px;
}
.invoice_on_r {
	width: 319px;
    float: left;
    margin: 0px;
    padding: 4px;
    background: #deeaf6;
    border-left: 1px solid #5d5c5c;
}
.invoice_one h1 {
	text-align: center;
	margin: 60px 0px;
}
.invoice_three_main {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}
.invoice_three {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	background: #a6a6a6;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_three_l {
	width: 300px;
	float: left;
	margin: 0px;
	padding: 5px;
}
.invoice_three_r {
	width: 200px;
	float: left;
	margin: 0px;
	padding: 5px;
	border-left: 1px solid #5d5c5c;
}
.invoice_three_bott {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_three_bott_l {
	width: 300px;
	float: left;
	margin: 0px;
	padding: 5px;
	font-size: 13px;
}
.invoice_three_bott_r {
	width: 200px;
	float: left;
	margin: 0px;
	padding: 5px;
	font-size: 14px;
	border-left: 1px solid #5d5c5c;
}
.invoice_four {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}
.invoice_four_cont {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	border-bottom: 1px solid #5d5c5c;
	
}
.invoice_four_cont_main {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
}
.invoice_four_left_s {
	width: 150px;
    float: left;
    margin: 0px;
    padding: 0px;
    line-height:200px;
	height:222px;
	border-bottom: 1px solid #5d5c5c;
   
}


.invoice_four_right_s {
	width: 488px;
	float: left;
	margin: 0px;
	padding: 0px;
	
}



.invoice_four_head {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 5px;
	background: #a6a6a6;
	border-top: 1px solid #5d5c5c;
	border-bottom: 1px solid #5d5c5c;
}
.invoice_four_cont_l {
	width: 220px;
	float: left;
	margin: 0px;
	padding: 0px 5px;
	
}
.invoice_four_cont_c {
    width: 260px;
    float: left;
    margin: 0px;
    padding: 5px 5px;
    font-size: 10px;
    text-align: right;
  
    border-right: 1px solid #5d5c5c;
    border-left: 1px solid #5d5c5c;
	
    height: 26px;
    line-height: 18px;
}
.invoice_four_cont_r {
    width: 200px;
    float: left;
    margin: 0px;
    padding: 2px 5px;
    font-size: 10px;

    min-height: 50px;
    line-height: 31px;
}

.invoice_footer {
	width: 800px;
	float: left;
	margin: 0px;
	padding: 0px;
	margin-top: 50px;
	border-top: 1px solid #5d5c5c;
	padding-top: 15px;
}
.invoice_footer p {
	font-size: 12px;
	margin: 0;
	letter-spacing: 0px;
	line-height: 20px;
}
</style>
</head>
<body>
<div class="main_wrap">
  <div class="head_logo"><img src="'.plugin_dir_url( __FILE__ ).'img/logo.png" /> </div>
  <div class="invoice_one">
    <h1>Transaction Receipt</h1>
    <div class="invoice_two">
      <div class="invoice_on">
        <div class="invoice_on_l"> CUSTOMER NUMBER: </div>
        <div class="invoice_on_r">'.$user_id.'</div>
      </div>
      <div class="invoice_on">
        <div class="invoice_on_l"> TRANSACTION NUMBER : </div>
        <div class="invoice_on_r">'.$tranx_id.'</div>
      </div>
      <div class="invoice_on">
        <div class="invoice_on_l"> DATE : </div>
        <div class="invoice_on_r">'.$date_time.'</div>
      </div>
      <div class="invoice_three_main">
        <div class="invoice_three">
          <div class="invoice_three_l">SENDER</div>
          <div class="invoice_three_r">RECEIVER</div>
        </div>
        <div class="invoice_three_bott_m">
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> First name : '.$sender_fname.'</div>
            <div class="invoice_three_bott_r"> First name : '.$reciever_fname.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Last name : '.$sender_lname.'</div>
            <div class="invoice_three_bott_r"> Last name : '.$reciever_lname.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Country of Residence : '.$sender_residense_country.'</div>
            <div class="invoice_three_bott_r"> Country : '.$reciever_residense_country.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Address : '.$sender_address.'</div>
            <div class="invoice_three_bott_r"> Address : '.$reciever_address.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Zip Code - City : '.$sender_zipcode_city.'</div>
            <div class="invoice_three_bott_r"> Zip Code - City : '.$reciever_zipcode_city.'</div>
          </div>
          <div class="invoice_three_bott">
            <div class="invoice_three_bott_l"> Tel. Number : '.$sender_phone.'</div>
            <div class="invoice_three_bott_r"> Tel. Number : '.$reciever_phone.'</div>
          </div>
        </div>
        <div class="invoice_four">
          <div class="invoice_four_head"> Description </div>
          <div class="invoice_four_cont_main">
            <div class="invoice_four_left_s">
              <div class="invoice_four_cont_l"> '.$description.' </div>
            </div>
            <div class="invoice_four_right_s">
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>MONEY RECEIVE</strong> IN XAF </div>
                <div class="invoice_four_cont_r">'.$xaf_trans_amount.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>MONEY SEND</strong> IN mBTC </div>
                <div class="invoice_four_cont_r"> '.$euro_trans_amount.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> EXCHANGE RATE (mBTC -> XAF)</div>
                <div class="invoice_four_cont_r"> '.$exchange_rate.'</div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> FEES IN mBTC </div>
                <div class="invoice_four_cont_r"> '.$trans_fees.' </div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> FEES IN XAF </div>
                <div class="invoice_four_cont_r"> '.$paypal_fees.' </div>
              </div>
              <div class="invoice_four_cont">
                <div class="invoice_four_cont_c"> <strong>TOTAL IN XAF </strong></div>
                <div class="invoice_four_cont_r"> '.$total_fees.'</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="invoice_footer">
      <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
	  <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
	  <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
      
    </div>
  </div>
</div>
</body>
</html>
';

return $html;
	
	
}




function createPdf($html, $order_id, $type){
//ob_start();
	
include(MY_PLUGIN_PATH. 'mpdf/mpdf.php');
//
$mpdf = new mPDF('c','A4','',''); 
$mpdf->SetProtection(array('print'));
$mpdf->SetTitle("diaspoCC. - Invoice");
$mpdf->SetAuthor("diaspoCC.");
//$mpdf->SetWatermarkText("Draft");
$mpdf->showWatermarkText = true;
$mpdf->watermark_font = 'DejaVuSansCondensed';
$mpdf->watermarkTextAlpha = 0.1;
$mpdf->SetDisplayMode('fullpage');


$mpdf->WriteHTML($html);
$rand = time();
$mpdf->Output(MY_PLUGIN_PATH.'invoices/invoice_'.$order_id.$rand.'_'.$type.'.pdf','F');

$url = plugins_url('/mtn-custom-plugin/invoices/invoice_'.$order_id.$rand.'_'.$type.'.pdf');

return $url;

}




// Phone Verification Form
function phone_confirm_code(){
global $wpdb;
$language = $_GET['lang'];
			
$flag = $flag1 = 0;



if(!empty($language)){ 

$regisUrl = site_url().'/register/?lang=fr';

}
else
{

$regisUrl = site_url().'/register';	
	
}	

$formHtml = $success_message = $error_message = '';	
if(isset($_POST['submitConf']))
{
	$confirmCode = $_POST['confirmCode'];
	if(isset($_SESSION['user_list_id'])) {
	  $listId =  $_SESSION['user_list_id'];
	}
    else
    {
	
	  $listId =  $_POST['listId'];
    }

    	
	
	$results = $wpdb->get_row("SELECT * FROM `wp_before_activation_user_list` WHERE list_id = '".$listId."'");
	if($confirmCode == $results->otp_code)
	{
		    $results = $wpdb->get_row("SELECT * FROM `wp_before_activation_user_list` WHERE list_id = '".$listId."'");
		
		    //$username = $results->first_name.$results->last_name.$results->diaspo_user_country_of_residence;
			$password_decrt = base64_decode($results->password);
		    $user_id = wp_create_user($results->email , $password_decrt, $results->email );

			if ( ! $user_id || is_wp_error( $user_id ) ) {
				
			} else {

			    $password = $password_decrt;	

				update_user_meta( $user_id, 'diaspo_activation_key', wp_generate_password( 20, false ) );
				update_user_meta( $user_id, 'diaspo_user_status', 'inactive' );
				
				update_user_meta( $user_id , 'diaspo_pdf_status' , 'Start' );
				
				update_user_meta( $user_id, 'first_name', $results->first_name );
				update_user_meta( $user_id, 'last_name', $results->last_name );
				update_user_meta( $user_id, 'diaspo_user_phone', $results->diaspo_user_phone );
				update_user_meta( $user_id, 'diaspo_user_country_of_origin', $results->diaspo_user_country_of_origin );
				update_user_meta( $user_id, 'diaspo_user_country_of_residence', $results->diaspo_user_country_of_residence );
				update_user_meta( $user_id, 'diaspo_user_newsletter', $results->diaspo_user_newsletter );
				update_user_meta( $user_id, 'diaspo_user_city', $results->diaspo_user_city );
				update_user_meta( $user_id, 'diaspo_partner_mobile_money', $results->partner_mobile_money );
				update_user_meta( $user_id, 'diaspo_user_language', $results->diaspo_user_language );
				
				
				//newsletter subcription
                if($results->diaspo_user_newsletter == 'on')
				{
					$url = 'https://diaspo-cc.us15.list-manage.com/subscribe/post?u=2e0925eb2c7c58c8d1b008f86&id=25bb5e2349';
					$query_string = array('EMAIL'=> $results->email);
					$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);

					curl_setopt($ch, CURLOPT_HEADER, FALSE);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, FALSE);
					curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);

					$result = curl_exec($ch);
					
					curl_close($ch);
					
				}	
                //newsletter subcription

				$wpdb->update( $wpdb->users, array( 'user_pass' => wp_hash_password( $password ) ), array( 'ID' => $user_id ), array( '%s' ), array( '%d' ) );


				$success_message .= 'Your Phone Number has been verified successfully! Please check your email to confirm registration.';
				
				wp_new_user_notification( $user_id, null, 'both' );
			}
		
		
		
		
	}
	else
	{
		
		$flag1 = 1;
		$flag = 1;
		$error_messag = 'Your code doesn not match!, Please enter valid code.';
	}	
	
	
	
}
else
{
	$flag = 1;
	
	if(isset($_SESSION['user_list_id'])) {
    $listId = $_SESSION['user_list_id'];
	} else {
		$listId = '';
	}
	
	
	
	
	
	
}
	
if($flag == 1)
{

    $formHtml .= '<div class="php-errors">';

                      
    if ($flag1 == 1) {

     
	  $formHtml .= '<p class="error-msg">Your code doesn not match!, Please enter valid code.</p>';
	}	
    $formHtml .= '</div>';	


if(!empty($language)){ 

   $formHtml .= '<div class="container">
    <div class="row">
        <div class="box_verify">
            <h4>V&#233;rification de votre num&#233;ro de t&#233;l&#233;phone</h4>
             <h5>Merci d&#39;entrer le code de v&#233;rification re&#231;u sur votre t&#233;l&#233;phone. 
            <span>Si vous n&#39;avez pas re&#231;u de code, <a href="javascript:void()" onclick="tryAgainSms()">cliquez ici</a> pour reessayer ou <a href="'.$regisUrl.'">changer de num&#233;ro de t&#233;l&#233;phone</a></span></h5>
            <div class="loader"></div>
			<form  id="phoneConfirm"  method="post">
                <input type="text" name="confirmCode" placeholder="V&#233;rification du code" required />
				<input type="hidden" id="listId" name="listId" value="'.$listId.'" />
                <input type="submit" class="btn_submit" name="submitConf" placeholder="Envoyez" />
            </form>	           
        </div>        
          	
    </div>    
</div>';

}
else
{
	$formHtml .= '<div class="container">
    <div class="row">
        <div class="box_verify">
            <h4>We need to verify you&#39;re a human</h4>
             <h5>Please enter the verification code we sent to your phone. If you didn&#39;t 
            <span>recieve a code, you can <a href="javascript:void()" onclick="tryAgainSms()">try again</a> or you want to <a href="'.$regisUrl.'">edit your phone number?</a></span></h5>
            <div class="loader"></div>
			<form  id="phoneConfirm"  method="post">
                <input type="text" name="confirmCode" placeholder="Verification Code" required/>
				<input type="hidden" id="listId" name="listId" value="'.$listId.'" />
                <input type="submit" class="btn_submit" name="submitConf" placeholder="submit"/>
            </form>	           
        </div>        
          	
    </div>    
</div>';
	
}	

}else
{


                      
    if ( $success_message ) { 
            $formHtml .= '<script>
			 
			    jQuery(document).ready(function(){
					
					jQuery("#suceesMessageId").show();
				});
			 
			 </script>';
       
    }	
    
	
}	
		
	echo $formHtml;
	
}




function update_freshdesk_ticket_identification($id, $data)
{
	//echo $id;
	//print_r($data);
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	    
		 $url = $freshdesk_login_url."/api/v2/tickets";
		 

		
		 $header[] = "Content-type: application/json";
		 
		 $ch = curl_init($url . "/{$id}");
		// echo $ch;

         $postData = json_encode($data);

		 //print_r($postData);//die();
		 
		 
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

			// Make the REST call, returning the result
			$response = curl_exec($ch);
			if (!$response) {
				die("Connection Failure.n");
			}
		 

		$data = json_decode($response, TRUE);
		 
	
	
}

// Phone Edit Verification Form
function phone_edit_confirm_code(){
global $wpdb, $current_user;
$language = $_GET['lang'];


$flag = $flag1 = 0;

if(!empty($language))
{
$regisUrl = site_url().'/edit-profile-detail/?lang=fr';
}
else
{
$regisUrl = site_url().'/edit-profile-detail';	
}	

$formHtml = $success_message = $error_message = '';	
if(isset($_POST['submitConf']))
{
	$confirmCode = $_POST['confirmCode'];
	

    $PhoneNumber = $_SESSION['mobile_number'];
	$SessionCode = $_SESSION['session_otp'];
	
	if($confirmCode == $SessionCode)
	{
		   
		
		 update_user_meta( $current_user->ID, 'diaspo_user_phone', $PhoneNumber );
				
			
		
		$success_message .= 'Your Phone Number Verified and Updated successfully!.';
				
		
		
	}
	else
	{
		
		$flag1 = 1;
		$flag = 1;
		$error_messag = 'Your code does not match!, Please enter valid code.';
	}	
	
	
	
}
else
{
	$flag = 1;
	
	
}
	
if($flag == 1)
{

    $formHtml .= '<div class="php-errors">';

                      
    if ($flag1 == 1) {

     
	  $formHtml .= '<p class="error-msg">Your code doesn not match!, Please enter valid code.</p>';
	}	
    $formHtml .= '</div>';	
if(!empty($language))
{
$formHtml .= '<div class="container">
    <div class="row">
        <div class="box_verify">
            <h4>V&#233;rification de votre num&#233;ro de t&#233;l&#233;phone</h4>
             <h5>Merci d&#180;entrer le code de v&#233;rification re&#231;u sur votre t&#233;l&#233;phone. 
            <span>Si vous n&#180;avez pas re&#231;u de code, <a href="javascript:void()" onclick="tryAgainSms()">cliquez ici</a> pour reessayer ou <a href="'.$regisUrl.'">changer de num&#233;ro de t&#233;l&#233;phone</a></span></h5>
            <div class="loader"></div>
			<form  id="phoneConfirm"  method="post">
                <input type="text" name="confirmCode" placeholder="V&#233;rification du code" required />
				<input type="hidden" id="phoneNum" name="phoneNum" value="'.$PhoneNumber.'" />
                <input type="submit" class="btn_submit" name="submitConf" placeholder="Envoyez" />
            </form>	           
        </div>        
          	
    </div>    
</div>';
	
}
else
{
	$formHtml .= '<div class="container">
    <div class="row">
        <div class="box_verify">
            <h4>We need to verify you&#39;re a human</h4>
             <h5>Please enter the verification code we sent to your phone. If you didn&#96;t 
            <span>recieve a code, you can <a href="javascript:void()" onclick="tryAgainSms()">try again</a> or you want to <a href="'.$regisUrl.'">edit your phone number?</a></span></h5>
            <div class="loader"></div>
			<form  id="phoneConfirm"  method="post">
                <input type="text" name="confirmCode" placeholder="Verification Code" required/>
				<input type="hidden" id="phoneNum" name="phoneNum" value="'.$PhoneNumber.'" />
                <input type="submit" class="btn_submit" name="submitConf" placeholder="submit"/>
            </form>	           
        </div>        
          	
    </div>    
</div>';
	
}	



}else
{
	$formHtml .= '<div class="php-errors">';

                      
    if ( $success_message ) {

       $formHtml .= '<p class="success-msg">' . $success_message . '</p>';

    }	
    $formHtml .= '</div>';
	
}	
		
	echo $formHtml;
	
}


function sendSms($to, $from, $body){
	
	$account_sid_live = get_option('account_sid_live');
	$auth_token_live = get_option('auth_token_live');
	
	
	
	$xmlpost = [
    "To" => $to,
	"From" => $from,
	"Body" => $body
	];
$cpt = curl_init("https://api.twilio.com/2010-04-01/Accounts/".$account_sid_live."/Messages.xml");
curl_setopt_array($cpt, [
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_USERPWD => $account_sid_live.':'.$auth_token_live,
    CURLOPT_POSTFIELDS => http_build_query($xmlpost),
]);

$result = curl_exec($cpt);

curl_close($cpt);

			//print_r($response);
			$xml = simplexml_load_string($result);
			$json = json_encode($xml);
			$arr = json_decode($json,true);
			//print_r($arr);
	
}





/*add_action('wp_login', 'myEndSession');
add_action('init', 'myStartSession', 1);
function myStartSession() {
    if(!session_id()) {
        session_start();
    }
}

function myEndSession() {
    session_destroy ();
}*/

function sms_again(){
global $wpdb;
	
	if(!empty($_POST['listId']))
	{
      $listId = $_POST['listId'];	
	  
      $OTP = mt_rand(100000, 999999);
	  
	  $wpdb->query("UPDATE `wp_before_activation_user_list` SET otp_code = '".$OTP."' WHERE list_id = '".$listId."'");
	  
	  
	  $results = $wpdb->get_row("SELECT * FROM `wp_before_activation_user_list` WHERE list_id = '".$listId."'");
	
	  $toNumber = $results->diaspo_user_phone;
	  
	  $fromNumber = get_option('from_number');
	  $messageFormate = get_option('body_message');
	  $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
	  sendSms($toNumber, $fromNumber, $messageWOTP);  
	  
    }
	else
	{
		if(is_user_logged_in())
		{
			$OTP = mt_rand(100000, 999999);
	  
	        $toNumber = $_SESSION['mobile_number'];
			
			$OTP = mt_rand(100000, 999999);
			
			$_SESSION['session_otp'] = $OTP;
	  
		   $fromNumber = get_option('from_number');
		   $messageFormate = get_option('body_message');
		   $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
		   sendSms($toNumber, $fromNumber, $messageWOTP); 
			
		}	
		
	}	
	
	wp_die();
	
	
}
add_action( 'wp_ajax_sms_again', 'sms_again' );
add_action( 'wp_ajax_nopriv_sms_again', 'sms_again' );


function timezone_list(){
	
	$list = array (
    '(UTC-11:00) Midway Island' => 'Pacific/Midway',
    '(UTC-11:00) Samoa' => 'Pacific/Samoa',
    '(UTC-10:00) Hawaii' => 'Pacific/Honolulu',
    '(UTC-09:00) Alaska' => 'US/Alaska',
    '(UTC-08:00) Pacific Time (US &amp; Canada)' => 'America/Los_Angeles',
    '(UTC-08:00) Tijuana' => 'America/Tijuana',
    '(UTC-07:00) Arizona' => 'US/Arizona',
    '(UTC-07:00) Chihuahua' => 'America/Chihuahua',
    '(UTC-07:00) La Paz' => 'America/Chihuahua',
    '(UTC-07:00) Mazatlan' => 'America/Mazatlan',
    '(UTC-07:00) Mountain Time (US &amp; Canada)' => 'US/Mountain',
    '(UTC-06:00) Central America' => 'America/Managua',
    '(UTC-06:00) Central Time (US &amp; Canada)' => 'US/Central',
    '(UTC-06:00) Guadalajara' => 'America/Mexico_City',
    '(UTC-06:00) Mexico City' => 'America/Mexico_City',
    '(UTC-06:00) Monterrey' => 'America/Monterrey',
    '(UTC-06:00) Saskatchewan' => 'Canada/Saskatchewan',
    '(UTC-05:00) Bogota' => 'America/Bogota',
    '(UTC-05:00) Eastern Time (US &amp; Canada)' => 'US/Eastern',
    '(UTC-05:00) Indiana (East)' => 'US/East-Indiana',
    '(UTC-05:00) Lima' => 'America/Lima',
    '(UTC-05:00) Quito' => 'America/Bogota',
    '(UTC-04:00) Atlantic Time (Canada)' => 'Canada/Atlantic',
    '(UTC-04:30) Caracas' => 'America/Caracas',
    '(UTC-04:00) La Paz' => 'America/La_Paz',
    '(UTC-04:00) Santiago' => 'America/Santiago',
    '(UTC-03:30) Newfoundland' => 'Canada/Newfoundland',
    '(UTC-03:00) Brasilia' => 'America/Sao_Paulo',
    '(UTC-03:00) Buenos Aires' => 'America/Argentina/Buenos_Aires',
    '(UTC-03:00) Georgetown' => 'America/Argentina/Buenos_Aires',
    '(UTC-03:00) Greenland' => 'America/Godthab',
    '(UTC-02:00) Mid-Atlantic' => 'America/Noronha',
    '(UTC-01:00) Azores' => 'Atlantic/Azores',
    '(UTC-01:00) Cape Verde Is.' => 'Atlantic/Cape_Verde',
    '(UTC+00:00) Casablanca' => 'Africa/Casablanca',
    '(UTC+00:00) Edinburgh' => 'Europe/London',
    '(UTC+00:00) Greenwich Mean Time : Dublin' => 'Etc/Greenwich',
    '(UTC+00:00) Lisbon' => 'Europe/Lisbon',
    '(UTC+00:00) London' => 'Europe/London',
    '(UTC+00:00) Monrovia' => 'Africa/Monrovia',
    '(UTC+00:00) UTC' => 'UTC',
    '(UTC+01:00) Amsterdam' => 'Europe/Amsterdam',
    '(UTC+01:00) Belgrade' => 'Europe/Belgrade',
    '(UTC+01:00) Berlin' => 'Europe/Berlin',
    '(UTC+01:00) Bern' => 'Europe/Berlin',
    '(UTC+01:00) Bratislava' => 'Europe/Bratislava',
    '(UTC+01:00) Brussels' => 'Europe/Brussels',
    '(UTC+01:00) Budapest' => 'Europe/Budapest',
    '(UTC+01:00) Copenhagen' => 'Europe/Copenhagen',
    '(UTC+01:00) Ljubljana' => 'Europe/Ljubljana',
    '(UTC+01:00) Madrid' => 'Europe/Madrid',
    '(UTC+01:00) Paris' => 'Europe/Paris',
    '(UTC+01:00) Prague' => 'Europe/Prague',
    '(UTC+01:00) Rome' => 'Europe/Rome',
    '(UTC+01:00) Sarajevo' => 'Europe/Sarajevo',
    '(UTC+01:00) Skopje' => 'Europe/Skopje',
    '(UTC+01:00) Stockholm' => 'Europe/Stockholm',
    '(UTC+01:00) Vienna' => 'Europe/Vienna',
    '(UTC+01:00) Warsaw' => 'Europe/Warsaw',
    '(UTC+01:00) West Central Africa' => 'Africa/Lagos',
    '(UTC+01:00) Zagreb' => 'Europe/Zagreb',
    '(UTC+02:00) Athens' => 'Europe/Athens',
    '(UTC+02:00) Bucharest' => 'Europe/Bucharest',
    '(UTC+02:00) Cairo' => 'Africa/Cairo',
    '(UTC+02:00) Harare' => 'Africa/Harare',
    '(UTC+02:00) Helsinki' => 'Europe/Helsinki',
    '(UTC+02:00) Istanbul' => 'Europe/Istanbul',
    '(UTC+02:00) Jerusalem' => 'Asia/Jerusalem',
    '(UTC+02:00) Kyiv' => 'Europe/Helsinki',
    '(UTC+02:00) Pretoria' => 'Africa/Johannesburg',
    '(UTC+02:00) Riga' => 'Europe/Riga',
    '(UTC+02:00) Sofia' => 'Europe/Sofia',
    '(UTC+02:00) Tallinn' => 'Europe/Tallinn',
    '(UTC+02:00) Vilnius' => 'Europe/Vilnius',
    '(UTC+03:00) Baghdad' => 'Asia/Baghdad',
    '(UTC+03:00) Kuwait' => 'Asia/Kuwait',
    '(UTC+03:00) Minsk' => 'Europe/Minsk',
    '(UTC+03:00) Nairobi' => 'Africa/Nairobi',
    '(UTC+03:00) Riyadh' => 'Asia/Riyadh',
    '(UTC+03:00) Volgograd' => 'Europe/Volgograd',
    '(UTC+03:30) Tehran' => 'Asia/Tehran',
    '(UTC+04:00) Abu Dhabi' => 'Asia/Muscat',
    '(UTC+04:00) Baku' => 'Asia/Baku',
    '(UTC+04:00) Moscow' => 'Europe/Moscow',
    '(UTC+04:00) Muscat' => 'Asia/Muscat',
    '(UTC+04:00) St. Petersburg' => 'Europe/Moscow',
    '(UTC+04:00) Tbilisi' => 'Asia/Tbilisi',
    '(UTC+04:00) Yerevan' => 'Asia/Yerevan',
    '(UTC+04:30) Kabul' => 'Asia/Kabul',
    '(UTC+05:00) Islamabad' => 'Asia/Karachi',
    '(UTC+05:00) Karachi' => 'Asia/Karachi',
    '(UTC+05:00) Tashkent' => 'Asia/Tashkent',
    '(UTC+05:30) Chennai' => 'Asia/Calcutta',
    '(UTC+05:30) Kolkata' => 'Asia/Kolkata',
    '(UTC+05:30) Mumbai' => 'Asia/Calcutta',
    '(UTC+05:30) New Delhi' => 'Asia/Calcutta',
    '(UTC+05:30) Sri Jayawardenepura' => 'Asia/Calcutta',
    '(UTC+05:45) Kathmandu' => 'Asia/Katmandu',
    '(UTC+06:00) Almaty' => 'Asia/Almaty',
    '(UTC+06:00) Astana' => 'Asia/Dhaka',
    '(UTC+06:00) Dhaka' => 'Asia/Dhaka',
    '(UTC+06:00) Ekaterinburg' => 'Asia/Yekaterinburg',
    '(UTC+06:30) Rangoon' => 'Asia/Rangoon',
    '(UTC+07:00) Bangkok' => 'Asia/Bangkok',
    '(UTC+07:00) Hanoi' => 'Asia/Bangkok',
    '(UTC+07:00) Jakarta' => 'Asia/Jakarta',
    '(UTC+07:00) Novosibirsk' => 'Asia/Novosibirsk',
    '(UTC+08:00) Beijing' => 'Asia/Hong_Kong',
    '(UTC+08:00) Chongqing' => 'Asia/Chongqing',
    '(UTC+08:00) Hong Kong' => 'Asia/Hong_Kong',
    '(UTC+08:00) Krasnoyarsk' => 'Asia/Krasnoyarsk',
    '(UTC+08:00) Kuala Lumpur' => 'Asia/Kuala_Lumpur',
    '(UTC+08:00) Perth' => 'Australia/Perth',
    '(UTC+08:00) Singapore' => 'Asia/Singapore',
    '(UTC+08:00) Taipei' => 'Asia/Taipei',
    '(UTC+08:00) Ulaan Bataar' => 'Asia/Ulan_Bator',
    '(UTC+08:00) Urumqi' => 'Asia/Urumqi',
    '(UTC+09:00) Irkutsk' => 'Asia/Irkutsk',
    '(UTC+09:00) Osaka' => 'Asia/Tokyo',
    '(UTC+09:00) Sapporo' => 'Asia/Tokyo',
    '(UTC+09:00) Seoul' => 'Asia/Seoul',
    '(UTC+09:00) Tokyo' => 'Asia/Tokyo',
    '(UTC+09:30) Adelaide' => 'Australia/Adelaide',
    '(UTC+09:30) Darwin' => 'Australia/Darwin',
    '(UTC+10:00) Brisbane' => 'Australia/Brisbane',
    '(UTC+10:00) Canberra' => 'Australia/Canberra',
    '(UTC+10:00) Guam' => 'Pacific/Guam',
    '(UTC+10:00) Hobart' => 'Australia/Hobart',
    '(UTC+10:00) Melbourne' => 'Australia/Melbourne',
    '(UTC+10:00) Port Moresby' => 'Pacific/Port_Moresby',
    '(UTC+10:00) Sydney' => 'Australia/Sydney',
    '(UTC+10:00) Yakutsk' => 'Asia/Yakutsk',
    '(UTC+11:00) Vladivostok' => 'Asia/Vladivostok',
    '(UTC+12:00) Auckland' => 'Pacific/Auckland',
    '(UTC+12:00) Fiji' => 'Pacific/Fiji',
    '(UTC+12:00) International Date Line West' => 'Pacific/Kwajalein',
    '(UTC+12:00) Kamchatka' => 'Asia/Kamchatka',
    '(UTC+12:00) Magadan' => 'Asia/Magadan',
    '(UTC+12:00) Marshall Is.' => 'Pacific/Fiji',
    '(UTC+12:00) New Caledonia' => 'Asia/Magadan',
    '(UTC+12:00) Solomon Is.' => 'Asia/Magadan',
    '(UTC+12:00) Wellington' => 'Pacific/Auckland',
    '(UTC+13:00) Nuku\'alofa' => 'Pacific/Tongatapu'
);
	
	return $list;
	
}

function change_password(){
   global $wpdb, $current_user;
   $message = '';
   $status = 0;
	
  if ( isset( $_POST['change_password'] ) ) {

  $errors       = new WP_Error();
  $old_password = wp_unslash( sanitize_text_field( $_POST['old_password'] ) );
  $new_password = wp_unslash( sanitize_text_field( $_POST['new_password'] ) );
  $re_password  = wp_unslash( sanitize_text_field( $_POST['re_password'] ) );


  if ( wp_check_password( $old_password, $current_user->user_pass, $current_user->ID ) ) {

    if ( $new_password === $re_password ) {
      wp_update_user( array( 'ID' => $current_user->ID, 'user_pass' => esc_attr( $new_password ) ) );
    } else {
      $errors->add( 'confirm_password',  esc_html__( 'The passwords you entered do not match.  Your password was not updated.', 'diaspo-cc' ) );
    }

  } else {
    $errors->add( 'invalid_current_password',  esc_html__( 'Current password you entered do not match.  Your password was not updated.', 'diaspo-cc' ) );
  }

  if ( ! $errors->get_error_message() ) {
    $message = sprintf( esc_html__( '%1$s Your profile updated successfully! %2$s', 'diaspo-cc' ), '<p class="success-msg">', '</p>' );
	$status = 1;
  } else {
    $message = '<p class="error-msg">' . $errors->get_error_message() . '</p>';
	$status = 0;
  }
}
	$return = array(
			'message'	=> $message,
			'state'	=> $status
	);

wp_send_json($return);
	
	
}
add_action( 'wp_ajax_changePassword', 'change_password' );
add_action( 'wp_ajax_nopriv_changePassword', 'change_password' );



function change_profile(){
   global $wpdb, $current_user;
   $message = '';
   $status = 0;   
  if ( isset( $_POST['edit_profile'] ) ) {

    
	
	$errors          = new WP_Error();
	$first_name      = wp_unslash( sanitize_text_field( $_POST['first_name'] ) );
	$last_name       = wp_unslash( sanitize_text_field( $_POST['last_name'] ) );
	$partner_mobile_money = wp_unslash( sanitize_text_field( $_POST['partner_mobile_money'] ));
	

	if ( empty( $first_name ) ) {
		$errors->add( 'empty_firstname', __( '<strong>ERROR</strong>: Please enter First Name.', 'diaspo-cc' ) );
	}

	if ( empty( $last_name ) ) {
		$errors->add( 'empty_lasttname', __( '<strong>ERROR</strong>: Please enter Last Name.', 'diaspo-cc' ) );
	}

	

	if ( ! $errors->get_error_message() ) {
		update_user_meta( $current_user->ID , 'first_name', $first_name );
		update_user_meta( $current_user->ID , 'last_name', $last_name );
		
		
		$user_partner_mobile_money = get_user_meta( $current_user->ID, 'diaspo_partner_mobile_money', true );
		if($partner_mobile_money != $user_partner_mobile_money){
		    update_user_meta( $current_user->ID , 'diaspo_partner_mobile_money', $partner_mobile_money );
		    $to = $current_user->user_email;
			$subject = 'Notification: Recommendation afffiliation has changed!';
			
			$message  .= "<p>Dear ".$first_name.",</p>"."\r\n";
			
			$message  .= "<p>Your have changed you recommendation settings from &lt;".$user_partner_mobile_money."&gt; to &lt;".$partner_mobile_money."&gt;.</p>". "\r\n";
			
			$message  .= "<p>If this change hasn�t been done by you, please contact our support team: support@diaspo-cc.com.</p>". "\r\n";
            
			$message  .= "<p>Thanks for trusting us.</p>"."\r\n";
			$message  .= "<p>diaspoCC Team.</p>". "\r\n";
            
			
			// To send HTML mail, the Content-type header must be set
			$headers = 'From: DiaspoCC <no-reply@diaspo-cc.com>'."\r\n";
			
			//$headers .= 'Bcc: finances@diaspo-cc.com'. "\r\n";
			
			$headers .= 'MIME-Version: 1.0' . "\r\n";
			
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			
			                   
			 
			// Create email headers
			
			 
			// Sending email
			mail($to, $subject, $message, $headers);			
			
		}

        unset($current_user);
        get_currentuserinfo(); //just in case
		$message = 'Profile Updated Successfully!';
		$status = 1;

	} else {
		$message = '<p class="error-msg">' . $errors->get_error_message() . '</p>';
		$status = 0;
	}
  }
	
	
	$return = array(
			'message'	=> $message,
			'state'	=> $status
	);

wp_send_json($return);
	
	
}
add_action( 'wp_ajax_profileUpdate', 'change_profile' );
add_action( 'wp_ajax_nopriv_profileUpdate', 'change_profile' );



//change bitcoin address
function change_bitcoin_address(){
   global $wpdb, $current_user;
   $message = '';
   $status = 0;   
  if ( isset( $_POST['bitcoin_user_address'] ) ) {

    
	
	$errors          = new WP_Error();
	$bitcoin_user_address      = wp_unslash( sanitize_text_field( $_POST['bitcoin_user_address'] ) );
	
	

	if ( empty( $bitcoin_user_address ) ) {
		$errors->add( 'empty_bitcoinaddress', __( '<strong>ERROR</strong>: Please enter Bitcoin Address.', 'diaspo-cc' ) );
	}

	

	if ( ! $errors->get_error_message() ) {
		update_user_meta( $current_user->ID , 'bitcoin_user_address', $bitcoin_user_address );
		
		

    unset($current_user);
        get_currentuserinfo(); //just in case
		$message = 'Address Updated Successfully!';
		$status = 1;

	} else {
		$message = '<p class="error-msg">' . $errors->get_error_message() . '</p>';
		$status = 0;
	}
  }
	
	
	$return = array(
			'message'	=> $message,
			'state'	=> $status
	);

wp_send_json($return);
	
	
}
add_action( 'wp_ajax_bitcoinAddressprofileUpdate', 'change_bitcoin_address' );
add_action( 'wp_ajax_nopriv_bitcoinAddressprofileUpdate', 'change_bitcoin_address' );

//change address

function change_address(){
   global $wpdb, $current_user;
  
    $message = '';
    if ( isset( $_POST['change_address'] ) ) {

  
  
  $errors               = new WP_Error();
  //$country_of_origin    = wp_unslash( sanitize_text_field( $_POST['country_of_origin'] ) );
  $country_of_residence = wp_unslash( sanitize_text_field( $_POST['country_of_residence'] ) );
  $city_of_residence    = wp_unslash( sanitize_text_field( $_POST['city'] ) );
  
  $user_street    = wp_unslash( sanitize_text_field( $_POST['user_street'] ) );
  $user_zipcode    = wp_unslash( sanitize_text_field( $_POST['user_zipcode'] ) );
  $user_house_no    = wp_unslash( sanitize_text_field( $_POST['user_house_no'] ) );

  /*if ( empty( $country_of_origin ) ) {
      $errors->add( 'empty_country_of_origin',  esc_html__( 'Please Select Country of Origin', 'diaspo-cc' ) );
  }*/

  if ( empty( $country_of_residence ) ) {
      $errors->add( 'empty_country_of_residence',  esc_html__( 'Please Select Country of Residence', 'diaspo-cc' ) );
  }

  if ( empty( $city_of_residence ) ) {
      $errors->add( 'empty_city_of_residence',  esc_html__( 'Please Select City of Residence', 'diaspo-cc' ) );
  }

  if ( ! $errors->get_error_message() ) {

    //update_user_meta( $current_user->ID , 'diaspo_user_country_of_origin' , $country_of_origin );
    update_user_meta( $current_user->ID , 'diaspo_user_country_of_residence' , $country_of_residence );
    update_user_meta( $current_user->ID , 'diaspo_user_city' , $city_of_residence );
	
	update_user_meta( $current_user->ID , 'street' , $user_street );
    update_user_meta( $current_user->ID , 'zip_code' , $user_zipcode );
    update_user_meta( $current_user->ID , 'house_number' , $user_house_no );

    $message = 'Address changed successfully!';
	$status = 1;
  } else {
  	$message = $errors->get_error_messages();
	$status = 0;
  }
}
  
    $return = array(
			'message'	=> $message,
			'state'	=> $status
			
	);
  
 	

wp_send_json($return);
	
	
}
add_action( 'wp_ajax_changeAddress', 'change_address' );
add_action( 'wp_ajax_nopriv_changeAddress', 'change_address' );


function checkUniqueVal(){
   global $wpdb, $current_user;
   $flag = 1;
   
    if ( isset( $_POST['kit_number'] ) ) {

      
	       $kit_number = $_POST['kit_number'];
	       $blogusers = get_users( 'blog_id=1&orderby=nicename' );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				if($user->ID != $current_user->ID)
				{
				  
				  $kitNumber = get_user_meta( $user->ID, 'kit_number', true );
				  
				  if($kitNumber == $kit_number)
			      {
					
					$flag = 0;  
				  }		  
				  
				}	
				
			}
	  
  
   }
   
   if(isset($_POST['msisdn']))
   {
	       $msisdn = $_POST['msisdn'];
	       $blogusers = get_users( 'blog_id=1&orderby=nicename' );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				if($user->ID != $current_user->ID)
				{
				  
				  $msISD = get_user_meta( $user->ID, 'msisdn', true );
				  
				  if($msISD == $msisdn)
			      {
					
					$flag = 0;  
				  }		  
				  
				}	
				
			}   
	   
   }
   
  
    $return = array(
			'state'	=> $flag
			
	);
  
 	

wp_send_json($return);
	
	
}
add_action( 'wp_ajax_checkUniqueKit', 'checkUniqueVal' );
add_action( 'wp_ajax_nopriv_checkUniqueKit', 'checkUniqueVal' );

function mtn_user_profile_update_email( $user_id, $old_user_data ) {
 
  //$user = get_userdata( $user_id );
  $status = get_user_meta( $user_id , 'diaspo_pdf_status' , true );
  if($status == 'SIM Card shipped') {
       // Send E-mail to User.
                          

                          if ( ! get_user_meta( $user_id, 'shipped_mail_send' ) ) {

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));
                            // $user_id  = get_current_user_id();
                          	$user_meta= get_userdata( $user_id );
                          	$to 			= $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
							
                          	$subject 	= get_option('subject_sim_card');                                                        
                            $sim_card_has_been_shipped = get_option('sim_card_has_been_shipped');
                            $sim_card_has_been_shipped1 = str_replace("#USER#",$name, $sim_card_has_been_shipped);
                            $sim_card_has_been_shipped2 = str_replace("#EMAIL#",$to, $sim_card_has_been_shipped1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $sim_card_has_been_shipped2));
                            
							$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	//wp_mail( $to, $subject, $mailMessage, $headers );

                            update_user_meta( $user_id , 'shipped_mail_send', 'send' );
							
							$shipped_simcard_date = date('Y-m-d');
							
							update_user_meta( $user_id , 'shipped_simcard_date', $shipped_simcard_date);
                          }
  }
  
  if($status == 'Register your SIM Card')
  {
	// Send E-mail to User.
                         

                          if ( ! get_user_meta( $user_id, 'Register_mail_send' ) ) {

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

                          	$user_meta     = get_userdata( $user_id );
                          	$to 			    = $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
                            $subject  = get_option('subject_register_sim');
                            $register_your_sim_card = get_option('register_your_sim_card');
                            $register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
                            $register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

                          	$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	//wp_mail( $to, $subject, $mailMessage, $headers );

                            update_user_meta( $user_id , 'Register_mail_send', 'send' );
                          }  
	  
	  
	  
  }

  if($status == 'SIM Card Registered')
  {
	// Send E-mail to User.
                         

                          if ( ! get_user_meta( $user_id, 'sim_card_has_been_mail_send' ) ) {

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

                          	$user_meta     = get_userdata( $user_id );
                          	$to 		   = $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
                            $subject  = get_option('subject_register_has');
                            $register_your_sim_card = get_option('sim_card_has_been_registered_successfully');
                            $register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
                            $register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

                          	$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	//wp_mail( $to, $subject, $mailMessage, $headers );

                            update_user_meta( $user_id , 'sim_card_has_been_mail_send', 'send' );
                          }  
	  
	  
	  
  }	

  if($status == 'Complete Registration')
  {
	// Send E-mail to User.
                         

                          if ( ! get_user_meta( $user_id, 'registration_successfully_completed_mail_send' ) ) {

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

                          	$user_meta     = get_userdata( $user_id );
                          	$to 			    = $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
                            $subject  = get_option('subject_register_sim');
                            $register_your_sim_card = get_option('registration_successfully_completed');
                            $register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
                            $register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

                          	$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	//wp_mail( $to, $subject, $mailMessage, $headers );

                            update_user_meta( $user_id , 'registration_successfully_completed_mail_send', 'send' );
                          }  
	  
	  
	  
  }	

    
  if($status == 'Rejected')
  {
	// Send E-mail to User.
	    $rejectMessage = get_user_meta( $user_id , 'select_reject_message' , true );
        if($rejectMessage == 'Wrong SIM Card Data')
        {			

                        

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

                          	$user_meta     = get_userdata( $user_id );
                          	$to 			    = $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
                            $subject  = get_option('subject_wrong_simcard');
                            $register_your_sim_card = get_option('wrong_sim_card_data');
                            $register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
                            $register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

                          	$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	wp_mail( $to, $subject, $mailMessage, $headers );
							
							
							update_user_meta( $user_id , 'diaspo_pdf_status' , 'SIM Card shipped' );

        }
        if($rejectMessage == 'Form not signed')
        {			

                        

                          	add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

                          	$user_meta     = get_userdata( $user_id );
                          	$to 			    = $user_meta->user_email;
                            $name     = $user_meta->first_name;
                            $link    = 'http://dsp.lab.kit-services.com/';
                            $subject  = get_option('subject_form_not_signed');
                            $register_your_sim_card = get_option('form_not_signed');
                            $register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
                            $register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
                            $mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

                          	$sender_name = get_option('sender_name');
							$sender_email = get_option('sender_email');
                          	$headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

                          	wp_mail( $to, $subject, $mailMessage, $headers );
							
							update_user_meta( $user_id , 'diaspo_pdf_status' , 'Pending' );

        }
        		
	  
	  
	  
  }	
  


    
 
}

add_action( 'profile_update', 'mtn_user_profile_update_email', 10, 2 );


register_activation_hook(__FILE__, 'my_mtn_activation');

function my_mtn_activation() {
    if (! wp_next_scheduled ( 'my_daily_event' )) {
	wp_schedule_event(time(), 'daily', 'my_daily_event');
    }
}

add_action('my_daily_event', 'do_this_daily');

function do_this_daily() {
	
	$blogusers = get_users( 'blog_id=1&orderby=nicename&role=subscriber' );
	// Array of WP_User objects.
	foreach ( $blogusers as $user ) {
		
	     $user_id = $user->ID;
		 $status = get_user_meta( $user_id , 'diaspo_pdf_status' , true );
		 $shipped_simcard_date = get_user_meta( $user_id , 'shipped_simcard_date' , true );
		 $date = strtotime("+2 days", strtotime($shipped_simcard_date));
		 $after_two_days = date("Y-m-d", $date);
		 $current_date = date('Y-m-d');
		 if($status == 'SIM Card shipped' && $current_date > $after_two_days) { 
		 
			update_user_meta( $user_id , 'diaspo_pdf_status' , 'Register your SIM Card');
			
			

			if ( ! get_user_meta( $user_id, 'Register_mail_send' ) ) {

				add_filter('wp_mail_content_type',create_function('', 'return "text/html"; '));

				$user_meta     = get_userdata( $user_id );
				$to 			    = $user_meta->user_email;
				$name     = $user_meta->first_name;
				$link    = 'http://dsp.lab.kit-services.com/';
				$subject  = get_option('subject_register_sim');
				$register_your_sim_card = get_option('register_your_sim_card');
				$register_your_sim_card1 = str_replace("#USER#",$name, $register_your_sim_card);
				$register_your_sim_card2 = str_replace("#EMAIL#",$to, $register_your_sim_card1);
				$mailMessage = stripcslashes(str_replace("#LINK#",$link, $register_your_sim_card2));                            

				$sender_name = get_option('sender_name');
				$sender_email = get_option('sender_email');
                $headers = 'From: '.$sender_name.' <'.$sender_email.'>' . "\r\n";

				wp_mail( $to, $subject, $mailMessage, $headers );

				update_user_meta( $user_id , 'Register_mail_send', 'send' );
			}  
			 
		}
		
	} 	
}


register_deactivation_hook(__FILE__, 'my_mtn_deactivation');

function my_mtn_deactivation() {
	wp_clear_scheduled_hook('my_daily_event');
}


function mail_settings_menu() {
    
  add_submenu_page( 'options-general.php', 'Mail Settings', 'Mail Settings', 'manage_options','mail-settings-page', 'mail_settings_function' );
}

add_action( 'admin_menu', 'mail_settings_menu' );

function mail_settings_function(){
  if(isset($_POST['submit']))
  {
	$sender_name = $_POST['sender_name']; 
    $sender_email = $_POST['sender_email'];
    $subject_sim_card = $_POST['subject_sim_card'];	
	$subject_register_sim = $_POST['subject_register_sim'];
	$subject_simcard_reg = $_POST['subject_simcard_reg'];
	$subject_simcard_has = $_POST['subject_simcard_has'];
	$subject_reg_succ = $_POST['subject_reg_succ'];
	$subject_wrong_simcard = $_POST['subject_wrong_simcard'];
	$subject_form_not_signed = $_POST['subject_form_not_signed'];
	
	
	  
    $sim_card_has_been_shipped = $_POST['sim_card_has_been_shipped']; 
    $register_your_sim_card = $_POST['register_your_sim_card'];
    $sim_card_registration_pending = $_POST['sim_card_registration_pending'];
    $sim_card_has_been_registered_successfully = $_POST['sim_card_has_been_registered_successfully']; 
    $registration_successfully_completed = $_POST['registration_successfully_completed'];
    $wrong_sim_card_data = $_POST['wrong_sim_card_data'];
    $form_not_signed = $_POST['form_not_signed'];
	
	
	update_option('sender_name', $sender_name);
	update_option('sender_email', $sender_email);
    update_option('subject_sim_card', $subject_sim_card);
    update_option('subject_register_sim', $subject_register_sim);
	update_option('subject_simcard_reg', $subject_simcard_reg);
	update_option('subject_simcard_has', $subject_simcard_has);
    update_option('subject_reg_succ', $subject_reg_succ);
    update_option('subject_register_sim', $subject_register_sim);
	update_option('subject_wrong_simcard', $subject_wrong_simcard);
	update_option('subject_form_not_signed', $subject_form_not_signed);
   
    
    update_option('sim_card_has_been_shipped', $sim_card_has_been_shipped);
    update_option('register_your_sim_card', $register_your_sim_card);
    update_option('sim_card_registration_pending', $sim_card_registration_pending);
    update_option('sim_card_has_been_registered_successfully', $sim_card_has_been_registered_successfully);
    update_option('registration_successfully_completed', $registration_successfully_completed);
    update_option('wrong_sim_card_data', $wrong_sim_card_data);
    update_option('form_not_signed', $form_not_signed); 
  }
    
	$sender_name = get_option('sender_name'); 
    $sender_email = get_option('sender_email'); 
	$subject_sim_card = get_option('subject_sim_card');	
	$subject_register_sim = get_option('subject_register_sim');
	$subject_simcard_reg = get_option('subject_simcard_reg');
	$subject_simcard_has = get_option('subject_simcard_has');
	$subject_reg_succ = get_option('subject_reg_succ');
	$subject_wrong_simcard = get_option('subject_wrong_simcard');
	$subject_form_not_signed = get_option('subject_form_not_signed');
	
	
    $sim_card_has_been_shipped = get_option('sim_card_has_been_shipped'); 
    $register_your_sim_card = get_option('register_your_sim_card');
    $sim_card_registration_pending = get_option('sim_card_registration_pending');
    $sim_card_has_been_registered_successfully = get_option('sim_card_has_been_registered_successfully'); 
    $registration_successfully_completed = get_option('registration_successfully_completed');
    $wrong_sim_card_data = get_option('wrong_sim_card_data');
    $form_not_signed = get_option('form_not_signed');
?>  
<div class="wrap"><div id="icon-tools" class="icon32"></div>
  <h2>Email Settings</h2>
  <form method="post" action="">
    
    <table class="form-table">
	
	  <tr valign="top">
        <th scope="row">Sender Name</th>
        <td><input type="text" name="sender_name" style="width: 50%;" value="<?php echo $sender_name; ?>" /></td>
      </tr>
	  
	  <tr valign="top">
        <th scope="row">Sender Email</th>
        <td><input type="text" name="sender_email" style="width: 50%;" value="<?php echo $sender_email; ?>" /></td>
      </tr>

      <tr>
        <th scope="row">NOTE :- </th>
        <td>If you want to add Name, Email and Link then use these symbols - <b>#USER#</b>, <b>#EMAIL#</b> and <b>#LINK#</b>.</td>
      </tr>
	  
	  
	  
	  <tr valign="top">
	    
        <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_sim_card" style="width: 50%;" value="<?php echo $subject_sim_card; ?>" /></td>
      </tr>

      <tr valign="top">
        <th scope="row">SIM Card has been shipped</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'sim_card_has_been_shipped', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('sim_card_has_been_shipped'))), 'terms_wp_content', $settings);?>
        </td>
      </tr>
	  
	  
	  
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_register_sim" style="width: 50%;" value="<?php echo $subject_register_sim; ?>" /></td>
      </tr>

      <tr valign="top">
        <th scope="row">Register your SIM Card</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'register_your_sim_card', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('register_your_sim_card'))), 'terms_wp_content1', $settings);?>
        </td>
      </tr>
	  
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_simcard_reg" style="width: 50%;" value="<?php echo $subject_simcard_reg; ?>" /></td>
      </tr>
      <tr valign="top">
        <th scope="row">SIM Card Registration Pending</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'sim_card_registration_pending', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('sim_card_registration_pending'))), 'terms_wp_content2', $settings);?>
        </td>
      </tr>

      
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_simcard_has" style="width: 50%;" value="<?php echo $subject_simcard_has; ?>" /></td>
      </tr>
	  <tr valign="top">
        <th scope="row">SIM Card has been registered successfully</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'sim_card_has_been_registered_successfully', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('sim_card_has_been_registered_successfully'))), 'terms_wp_content3', $settings);?>
        </td>
      </tr>

      
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_reg_succ" style="width: 50%;" value="<?php echo $subject_reg_succ; ?>" /></td>
      </tr>
	  <tr valign="top">
        <th scope="row">Registration successfully completed</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'registration_successfully_completed', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('registration_successfully_completed'))), 'terms_wp_content4', $settings);?>
        </td>
      </tr>

      
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_wrong_simcard" style="width: 50%;" value="<?php echo $subject_wrong_simcard; ?>" /></td>
      </tr>
	  <tr valign="top">
        <th scope="row">Wrong SIM Card Data</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'wrong_sim_card_data', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('wrong_sim_card_data'))), 'terms_wp_content5', $settings);?>
        </td>
      </tr>

      
	  <tr valign="top">
	    <th scope="row">Email Subject</th>
        <td><input type="text" name="subject_form_not_signed" style="width: 50%;" value="<?php echo $subject_form_not_signed; ?>" /></td>
      </tr>
	  <tr valign="top">
        <th scope="row">Form not signed</th>
        <td><?php $settings = array('teeny' => true, 'textarea_rows' => 15, 'media_buttons' => true, 'textarea_name' => 'form_not_signed', 'tabindex' => 1);
          wp_editor(html_entity_decode(stripcslashes(get_option('form_not_signed'))), 'terms_wp_content6', $settings);?>
        </td>
      </tr>

    </table>
    
    <?php submit_button(); ?>

  </form>
</div>
<?php
}


add_filter('wp_mail_from', 'new_mail_from');
add_filter('wp_mail_from_name', 'new_mail_from_name');
 
function new_mail_from($old) {
 if(empty($old))	
  return 'noreply@diaspo-cc.com';
 else
  return $old; 

}
function new_mail_from_name($old) {
	
 if($old == 'WordPress'){
	$old = 'diaspoCC';
 }	
	
 if(empty($old))	
  return 'diaspoCC';
 else
  return $old; 	
 }

function checkUniqueValAdmin(){
   global $wpdb;
   $flag = 1;
   
    if ( isset( $_POST['kit_number'] ) ) {

      
	       $kit_number = $_POST['kit_number'];
		   $currentUId = $_POST['currentUId'];
		   
	       $blogusers = get_users( 'blog_id=1&orderby=nicename' );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				if($user->ID != $currentUId)
				{
				  
				  $kitNumber = get_user_meta( $user->ID, 'kit_number', true );
				  
				  if($kitNumber == $kit_number)
			      {
					
					$flag = 0;  
				  }		  
				  
				}	
				
			}
	  
  
   }
   
   if(isset($_POST['msisdn']))
   {
	       $msisdn = $_POST['msisdn'];
		   $currentUId = $_POST['currentUId'];
		   
	       $blogusers = get_users( 'blog_id=1&orderby=nicename' );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				if($user->ID != $currentUId)
				{
				  
				  $msISD = get_user_meta( $user->ID, 'msisdn', true );
				  
				  if($msISD == $msisdn)
			      {
					
					$flag = 0;  
				  }		  
				  
				}	
				
			}   
	   
   }
   
  
    $return = array(
			'state'	=> $flag
			
	);
  
 	

wp_send_json($return);
	
	
}


function admin_plugin_custom(){
add_action( 'wp_ajax_checkUniqueKitAdmin', 'checkUniqueValAdmin' );
add_action( 'wp_ajax_nopriv_checkUniqueKitAdmin', 'checkUniqueValAdmin' );	
	
}
add_action( 'admin_init', 'admin_plugin_custom');



function make_deposit($order_id){
	global $wpdb;
	$user_id = get_current_user_id();
	$msisdn = get_user_meta( $user_id, 'msisdn', true );
	$Narration = '';
	//$number_recharge_get_reward = get_option('number_recharge_get_reward');
	//$ResCount = get_user_meta($user_id, 'reward_points', true);
	$left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
	
	$lang = get_user_meta( $user_id, 'diaspo_user_language', true );
	if($lang == ''){
		if ( ICL_LANGUAGE_CODE == "fr" ) {
		  if($left_reward_points == 1){
			$Narration = 'MERCI POUR VOTRE FIDELITE. VOTRE PROCHAINE RECHARGE SUR diaspoCC EST GRATUITE!';   
		  }else{	
	        $Narration = 'Deposit: MERCI D UTILISER www.diaspoCC.com POUR VOS RECHARGES MTN MOBILE MONEY. ENVOYEZ FACILEMENT DE L ARGENT A PARTIR DE VOTRE CARNET D ADRESSE SUR www.diaspoCC.com. ESSAYEZ MAINTENANT!';   
		  }
		}else
		{ 
	      if($left_reward_points == 1){
			$Narration = 'YOUR NEXT RECHARGE ON diaspoCC WILL BE FREE. THANKS FOR YOUR FIDELITY.';   
		  }else{
		    $Narration = 'Deposit: THANK YOU FOR USING www.diaspoCC.com TO RECHARGE YOUR MTN MOBILE MONEY. YOU CAN ALSO EASILY SEND MONEY ON www.diaspoCC.com FROM YOUR ADDRESS BOOK. TRY IT NOW!'; 
		  }
		}
	}
    else if($lang == 'fr')
    {
		 if($left_reward_points == 1){
			$Narration = 'MERCI POUR VOTRE FIDELITE. VOTRE PROCHAINE RECHARGE SUR diaspoCC EST GRATUITE!';   
		  }else{	
	        $Narration = 'Deposit: MERCI D UTILISER www.diaspoCC.com POUR VOS RECHARGES MTN MOBILE MONEY. ENVOYEZ FACILEMENT DE L ARGENT A PARTIR DE VOTRE CARNET D ADRESSE SUR www.diaspoCC.com. ESSAYEZ MAINTENANT!';   
		  }
	}
    else
	{
		  if($left_reward_points == 1){
			$Narration = 'YOUR NEXT RECHARGE ON diaspoCC WILL BE FREE. THANKS FOR YOUR FIDELITY.';   
		  }else{
		     $Narration = 'Deposit: THANK YOU FOR USING www.diaspoCC.com TO RECHARGE YOUR MTN MOBILE MONEY. YOU CAN ALSO EASILY SEND MONEY ON www.diaspoCC.com FROM YOUR ADDRESS BOOK. TRY IT NOW!'; 
		  }
	}
		 
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = ".$order_id);
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');	
	if($rowdata->trans_type == 'Recharge')
	{	
	  $amount = $rowdata->xaf_trans_amount;
	}
	else{
		
	  $amount = $rowdata->xaf_trans_amount;
	}
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
	
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		$password = $sp_password;	
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>diaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>'.$Narration.'</value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';




       
       /*$pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';*/

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;
}


function make_deposit_third($order_id){
	global $wpdb;
	
	$user_id = get_current_user_id();
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = ".$order_id);
	
	$country_code = get_user_meta( $user_id , 'country_flag_code', true );

	$msisdn = $country_code.$rowdata->mtn_mobile_number;
	
	$Narration = '';
	
	$left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
	
	$lang = get_user_meta( $user_id, 'diaspo_user_language', true );
	
$message = '';
$subject = ''; 
$user_info = get_userdata($user_id);
$to = $user_info->user_email; 


  
if($lang == ''){
    if ( ICL_LANGUAGE_CODE == "fr" ) {
      if($left_reward_points == 1){
       
	   $message = '<p>MERCI POUR VOTRE FIDELITE. VOTRE PROCHAINE RECHARGE SUR diaspoCC EST GRATUITE!</p>';
       $subject = 'BONUS de diaspoCC';
           
     } 
        $Narration = "UN PROCHE A PU CREDITER VOTRE COMPTE EN UTILISANT www.diaspoCC.com. DITES MERCI EN DONNANT UN J AIME SUR NOTRE PAGE FACEBOOK."; 
          
     
    }
   else
   { 
       if($left_reward_points == 1){
          
	       $message = '<p>YOUR NEXT RECHARGE ON diaspoCC WILL BE FREE. THANKS FOR YOUR FIDELITY</p>';
           $subject = 'REWARD from diaspoCC';
      }
	    $Narration = "SOMEONE WHO CARES ABOUT YOU JUST USED www.diaspoCC.com TO SEND YOU MONEY. LIKE OUR FACEBOOK PAGE TO SAY THANK YOU!";   
     
   }
}
else if($lang == 'fr')
{
   if($left_reward_points == 1){
   
   $message = '<p>MERCI POUR VOTRE FIDELITE. VOTRE PROCHAINE RECHARGE SUR diaspoCC EST GRATUITE!</p>';
   $subject = 'BONUS de diaspoCC';
    }
        $Narration = "UN PROCHE A PU CREDITER VOTRE COMPTE EN UTILISANT www.diaspoCC.com. DITES MERCI EN DONNANT UN J AIME SUR NOTRE PAGE FACEBOOK.";   
    
 }
    else
 {
    if($left_reward_points == 1){
     
     $message = '<p>YOUR NEXT RECHARGE ON diaspoCC WILL BE FREE. THANKS FOR YOUR FIDELITY</p>';
     $subject = 'REWARD from diaspoCC';   
    }
	
	$Narration = "SOMEONE WHO CARES ABOUT YOU JUST USED www.diaspoCC.com TO SEND YOU MONEY. LIKE OUR FACEBOOK PAGE TO SAY THANK YOU!";   
    //(".$msisdn.")
 } 
 if($left_reward_points == 1){
             
 // To send HTML mail, the Content-type header must be set
 $headers  = 'MIME-Version: 1.0' . "\r\n";
 $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  
 // Create email headers
 $headers .= 'From: diaspoCC <noreply@mail.diaspo-cc.com>'."\r\n";
  
 // Sending email
 mail($to, $subject, $message, $headers);
 }
 
 
 
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');	
	
	$amount = $rowdata->xaf_trans_amount;
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
	
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		$password = $sp_password;	
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>diaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>'.$Narration.'</value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';




       
        /*$pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';*/

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;
}

// Make trade recharge

function make_deposit_third_trade($order_id, $amount){
	global $wpdb;
	
	$user_id = get_current_user_id();
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE order_id = ".$order_id);
	
	$country_code = get_user_meta( $user_id , 'country_flag_code', true );
    if(empty($country_code)){$country_code = '237';}
	$msisdn = $country_code.$rowdata->mtn_number;
	
	$Narration = '';
	
	
	
	$lang = get_user_meta( $user_id, 'diaspo_user_language', true );
	
$message = '';
$subject = ''; 
$user_info = get_userdata($user_id);
$to = $user_info->user_email; 


  
if($lang == ''){
    if ( ICL_LANGUAGE_CODE == "fr" ) {
      
        $Narration = "UN PROCHE A PU CREDITER VOTRE COMPTE EN UTILISANT www.diaspoCC.com. DITES MERCI EN DONNANT UN J AIME SUR NOTRE PAGE FACEBOOK."; 
          
     
    }
   else
   { 
       
	    $Narration = "SOMEONE WHO CARES ABOUT YOU JUST USED www.diaspoCC.com TO SEND YOU MONEY. LIKE OUR FACEBOOK PAGE TO SAY THANK YOU!";   
     
   }
}
else if($lang == 'fr')
{
   
        $Narration = "UN PROCHE A PU CREDITER VOTRE COMPTE EN UTILISANT www.diaspoCC.com. DITES MERCI EN DONNANT UN J AIME SUR NOTRE PAGE FACEBOOK.";   
    
 }
    else
 {
    
	
	$Narration = "SOMEONE WHO CARES ABOUT YOU JUST USED www.diaspoCC.com TO SEND YOU MONEY. LIKE OUR FACEBOOK PAGE TO SAY THANK YOU!";   
    
 } 

 
 
 
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');	
	
	
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
	
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		$password = $sp_password;	
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>diaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>'.$Narration.'</value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';


		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;
}




function make_transfer($data)
{
	global $wpdb;
	$user_id = get_current_user_id();
	date_default_timezone_set('Africa/Douala');
	$currency_type_amount = $data['transfer_amount'];
	$sending_reason = $data['sending_reason'];
	$fullname = $data['first_name'].' '.$data['last_name'];
	$time = date('Y-m-d h:i:s');
	$country_code = $data['country_code_mobile_money'];
	$mtn_mobile = $data['mobile_money_account'];
    $msisdnNo = str_replace('+', '', $country_code).$mtn_mobile;
	$nonce = rand();
	
	$senderMsisdn = get_user_meta( $user_id, 'msisdn', true );
	
	$partner_mobile_money = get_user_meta( $user_id, 'partner_mobile_money', true );
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');
	$service_id = get_option('service_id');
	
	$country_name = $data['country_name'];
	
	$wpdb->query("INSERT INTO `wp_mtn_order_history` (order_id, user_id, payment_transaction_id, trans_type , euro_trans_amount, xaf_trans_amount, trans_fees, full_name, date_time, mtn_mobile_number, african_mtn_regi_country, partner_mobile_money, payment_status, mtn_status, MOMTransactionID, ProcessingNumber, SenderID, MSISDNNum, OpCoID, receipt_link, status_code, error_ticket_id, sending_reason) 
				VALUES('', '".$user_id."', '', 'Transfer', '', '".$currency_type_amount."', '', '".$fullname."', '".$time."', '".$mtn_mobile."', '".$country_name."', '".$partner_mobile_money."', 'pending', 'pending', '', '".$nonce."', 'DiaspoCC', '".$msisdnNo."', '', '', '', '', '".$sending_reason."')");	
														 
	$order_id = $wpdb->insert_id;
	
	
    $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
	
		
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		
		$spID = $sp_id;
		
		$password = $sp_password;
        		
	    $PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 

$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
   <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
         <spId>'.$spID.'</spId>
         <spPassword>'.$PasswordDigest.'</spPassword>
         
         <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
   </soap:Header>
   <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
         <serviceId>DiaspoCC</serviceId>
         <parameter>
            <name>DueAmount</name>
            <value>'.$currency_type_amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$senderMsisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>CurrCode</name>
            <value>XAF</value>
         </parameter>
         <parameter>
            <name>SenderID</name>
            <value>DiaspoCC</value>
         </parameter>
      </ns3:processRequest>
   </soap:Body>
</soap:Envelope>';



       
        $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	$caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	   
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			
			
            $xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));

if(count($arr) != count($arr1))
{	
 $arr1[] = '';
}


$arr2 = array_combine($arr, $arr1);

return $arr2;
	
	
	
	
}


function sentOTP_number(){
	global $wpdb;
	$OTP = '';
	if(!empty($_POST['mtnNum']))
	{
      $toNumber = $_POST['mtnNum'];	
	  
      $OTP = mt_rand(100000, 999999);
	  
	 
	  $fromNumber = get_option('from_number');
	  $messageFormate = get_option('body_message');
	  $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$OTP;
	  sendSms($toNumber, $fromNumber, $messageWOTP);  
	  
    }
	
	echo $OTP;
	wp_die();
	
}

add_action( 'wp_ajax_sentOTP', 'sentOTP_number' );
add_action( 'wp_ajax_nopriv_sentOTP', 'sentOTP_number' );




//mtn phone number
function changeMtn_Number(){
	global $wpdb;
	$user_id = get_current_user_id();
	if(!empty($_POST['mtnNum'])){
		
		$phone = '+'.str_replace(" ","",$_POST['mtnNum']);
		
		update_user_meta($user_id, 'diaspo_user_mtn_phone', $phone);
		
		$msisdn =  str_replace("+", "", $phone);
		update_user_meta($user_id, 'msisdn', $msisdn);
		
	}
		
    
	echo $phone;
	
	die();
	
}
add_action( 'wp_ajax_changeMtnNumber1', 'changeMtn_Number' );
add_action( 'wp_ajax_nopriv_changeMtnNumber1', 'changeMtn_Number' );

//phone number
function change_number(){
    global $wpdb;
	
	$user_id = get_current_user_id();
	if(!empty($_POST['phoneNum'])){
		
		$phone = '+'.str_replace(" ","",$_POST['phoneNum']);
		
		update_user_meta($user_id, 'diaspo_user_phone', $phone);
		
	}
		
    
	echo $phone;
	
	die();
	
	
}
add_action( 'wp_ajax_changeNumber', 'change_number' );
add_action( 'wp_ajax_nopriv_changeNumber', 'change_number' );

function getCountryNameToCountryCode($country_code){
	
	$url = get_stylesheet_directory_uri() .'/lib/CountryCodes.json';
	
	$results = json_decode(file_get_contents($url));
	
	
	foreach($results as $res)
	{
		
		if($res->dial_code == $country_code)
		{
			
			return $res->name;
		}	
		
	}
	
	
}


function getStatus(){
	
	global $wpdb;
	$res = '';
	if(!empty($_POST['procNum']))
	{
	  $ProcessingNumber = $_POST['procNum'];
      $row = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE ProcessingNumber = '".$ProcessingNumber."'");
	  
	  $status_code = $row->status_code;
	  $MSISDNNum = $row->MSISDNNum;
	  $amount = $row->xaf_trans_amount;
	  
	  if(!empty($row->receipt_link)){
			  
		$inv = explode("invoice_", $row->receipt_link);
		$recieptFileName = 'invoice_'.$inv[1];
			 
		$receipt_link = 'http://dsp.lab.kit-services.com/download.php?download_file='.$recieptFileName;
	   }
	  else{
	  $receipt_link ='';
	  }
	  
	  $res = $status_code.'##'.$MSISDNNum.'##'.$amount.'##'.$receipt_link;
    }
	
	echo $res;
	wp_die();
	
	
}
add_action( 'wp_ajax_getStatus', 'getStatus' );
add_action( 'wp_ajax_nopriv_getStatus', 'getStatus' );	



// Address book listing page shortcode
function mtn_address_book(){    
global $wpdb;
$current_user = wp_get_current_user();
$formHtml = '';	

if(isset($_POST['submit'])){

?>
<script type="text/javascript">
jQuery('#resultPage').hide();
var myVar;    
function showResult(){
	var procNum = jQuery('#procNum').val();
	
    jQuery('.loading_txt').html(msg);   
	
    var msg = '';
	var url = 'http://dsp.lab.kit-services.com/wp-admin/admin-ajax.php';	
            
		 
                    jQuery.ajax({
                        url: url,
                        type: "POST",
                        data: 'action=getStatus&procNum='+procNum,
                        success: function(response) {
							var data = response.split('##');
							var status_code = data[0];
							var MSISDNNum = data[1];
							var amount = data[2];
							var receipt_link = data[3];
							
							   if(status_code != '')
								{ 
							           if(status_code == 1)
										{
											msg = "We are transferring <"+amount+"><XAF> to <"+MSISDNNum+">, please wait";
											jQuery('.loading_txt').html(msg); 
											
											
										}else{
											
										if(status_code == 01){
											
										     jQuery('#resultPage').show();
											jQuery('#processPage').hide();
											
											
											html = "<div class='overview-main1 overview-main2' id='overview' style='column-count:1;'>";
									        html += "<div class='overview-box1' id='res_data'><div class='overview-boxmain' >";
										    html += "<div class='status_icon'><span class='msg_failed_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/transactionSuccess_icon.png' title='Success'/></span><span class='newMsgData'>Transaction Successful</span></div>";
										    html += "<div class='error_msg_data'>";
										    html += "<span>We successfully credited "+amount+" XAF on following</span>";
										    html += "<span>Mobile Money Account: <b>+"+MSISDNNum+"</b></span></div>";
										    html += "<div class='transaction_accoun_field'>";
										    html += "<div><span class='account_text'>Account Detail</span><span class='account_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/user_icon_new.png' title='User Icon'/></span></div>";
										    html += "<div class='account_field'><input type='text' value='+"+MSISDNNum+"' readonly/></div>";
										    html += "</div></div></div>";
                                            html += "<div class='account_buttons'><a href='"+receipt_link+"'  class='down_recp'>Download Receipt</a><a href='http://dsp.lab.kit-services.com/mobile-money-transfer/' class='account_back'>BACK</a></div></div>";
											
											
											jQuery('#resultPage').html(html);
											stopResult();
											 
										   }else{	
											jQuery('#resultPage').show();
											jQuery('#processPage').hide();
											
											html = "<div class='overview-main1 overview-main2' id='overview' style='column-count:1;'>";
									        html += "<div class='overview-box1' id='res_data'><div class='overview-boxmain' >";
										    html += "<div class='status_icon'><span class='msg_failed_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/transaction_icon.png' title='Error'/></span><span class='newMsgData myRed'>Transaction Failed</span></div>";
										    html += "<div class='error_msg_data'>";
										    html += "<p>Your transaction to MTN Mobile Money account <b>+"+MSISDNNum+"</b> with amount of "+amount+" XAF failed with following error code: <"+status_code+"></p>";
										    html += "<p>Please refer to our <a target='_blank' href='http://dsp.lab.kit-services.com/help-faq/'>Help & FAQ</a> or contact our <a href='http://dsp.lab.kit-services.com/contact'>Support</a> for further assistance.</p>";
										    html += "<div class='transaction_accoun_field'>";
										    html += "<div><span class='account_text'>Account Detail</span><span class='account_icon'><img src='http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/user_icon_new.png' title='User Icon'/></span></div>";
										    html += "<div class='account_field'><input type='text' value='+"+MSISDNNum+"' readonly/></div>";
										    html += "</div></div></div>";
                                            html += "<div class='account_buttons'><a class='down_recp transferDown'>Download Receipt</a><a href='http://dsp.lab.kit-services.com/mobile-money-transfer/' class='account_back'>BACK</a></div></div>";
											
											
											
											jQuery('#resultPage').html(html);
											stopResult();
										  }	
										}
										
										
										
										
										   
										   
								}
									
								
														
							
                        }            
                    });
	
	
}
function stopResult(){
    clearInterval(myVar); // stop the timer
	
	jQuery(".loading").fadeOut("slow");
	
}
jQuery(document).ready(function(){
	
    myVar = setInterval("showResult()", 1000);
});
</script>
<?php 

    $transfer_country_of_residence = $_POST['country_name'];
	$rec_city = $_POST['a_city'];
	
	$response_array = make_transfer($_POST);
	
	
	$StatusCode = $response_array['StatusCode'];
	$StatusDesc = $response_array['StatusDesc'];
	$MOMTransactionID = $response_array['MOMTransactionID'];
	$ProcessingNumber = $response_array['ProcessingNumber'];
	$SenderID = $response_array['SenderID'];
	//$MSISDNNum = $response_array['MSISDNNum'];
	$OpCoID = $response_array['OpCoID'];
	$mtn_status = '';
	
	
	
	if($StatusCode == 1000)
	{
	   $mtn_status = 	'pending';
	 
	    $no_of_transfer_from_address_book = get_option('no_of_transfer_from_address_book');
		if(empty($no_of_transfer_from_address_book))
		{update_option('no_of_transfer_from_address_book', 1);}
		else
		{   $no_of_transfer_from_address_book++;
			update_option('no_of_transfer_from_address_book', $no_of_transfer_from_address_book);
		}
		
	}
	else
	{
	  $mtn_status = 	'rejected';	
	}

	$row = $wpdb->get_row("SELECT * FROM`wp_mtn_order_history` WHERE ProcessingNumber = '".$ProcessingNumber."'");
	
	$MSISDNNum = $row->MSISDNNum;
	$xaf_trans_amount = $row->xaf_trans_amount;
	$wpdb->query("UPDATE `wp_mtn_order_history` SET  mtn_status = '".$mtn_status."', MOMTransactionID = '".$MOMTransactionID."', ProcessingNumber = '".$ProcessingNumber."', SenderID = '".$SenderID."', OpCoID = '".$OpCoID."' WHERE ProcessingNumber = '".$ProcessingNumber."'");
		   
	
			
	
	
	
	
	
	$msg = "Your transaction to ".$MSISDNNum." is being processed. Please, approve it from your mobile phone to complete this transaction (".$ProcessingNumber.").";	
										     
	
	
	
	echo '<div role="form" class="wpcf7" id="resultPage" lang="en-US" dir="ltr"></div>';
	echo '<input type="hidden" id="procNum" value="'.$ProcessingNumber.'" /><div class="loading"><div class="loading_txt">'.$msg.'</div></div>';	
	

}



$checkMtnTransLimit = get_option('transfer_limit');
$res = $wpdb->get_results("SELECT SUM(`xaf_trans_amount`) AS sum FROM `wp_mtn_order_history` WHERE user_id = ".$current_user->ID." and mtn_status = 'completed'");
$mtnTransTotal = $res[0]->sum;


$dir_url = plugin_dir_url(__FILE__) . 'img/';
$siteurl = site_url('address-book');
   $query = $wpdb->get_results("select * from `wp_user_address_book` WHERE user_id = '".$current_user->ID."' order by id desc");
    
    $total_pages = count($query);

    $limit = 10;                                //how many items to show per page
    $page = $_GET['numPage'];

    if($page) 
        $start = ($page - 1) * $limit;          //first item to display on this page
    else
        $start = 0;                             //if no page var is given, set start to 
    

    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
    $prev = $page - 1;                          //previous page is page - 1
    $next = $page + 1;                          //next page is page + 1
    $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;                      //last page minus 1

    $pagination = "";
    if($lastpage > 1)
    {   
        $prev = $page-1;
		$next = $page+1;
        $pagination .= '<nav aria-label="Page navigation" class="pagi_name">
          	<ul class="pagination">';
        //previous button
        if ($page > 1) 
            $pagination.= '<li class="previous">
              <a href="'.$siteurl.'/?numPage='.$prev.'" aria-label="Previous">
                <img src="'.$dir_url.'img_arrowLeft.png" />
              </a>
            </li>';
        else
            $pagination.= '<li class="previous">
		      <a href="javascript:void(0);" aria-label="Previous">
			    <img src="'.$dir_url.'img_arrowLeftg.png" />
			  </a>
			  </li>'; 

        //next button
        if ($page < $lastpage) 
            $pagination.= '<li class="next">
              <a href="'.$siteurl.'/?numPage='.$next.'" aria-label="Next">
                <img src="'.$dir_url.'img_arrowRight.png" />
              </a>
            </li>';
        else
            $pagination.= '<li class="next">
		        <a href="javascript:void(0);" aria-label="Next">
		          <img src="'.$dir_url.'img_arrowRightg.png" />
				</a>
				</li>';
		
		
          $pagination.= '</ul></nav>';       
    }

$rows = $wpdb->get_results("select * from `wp_user_address_book` WHERE user_id = '".$current_user->ID."' order by id desc LIMIT $start, $limit");

$status_1 = get_user_meta( $current_user->ID , 'diaspo_pdf_status', true );

    $trans1 = 'NAME'; 
	$trans2 = 'MTN Number'; 
	$trans3 = 'EMAIL'; 
	$trans4 = 'COUNTRY'; 
	$trans5 = 'CITY'; 
	$trans6 = 'ACTIONS'; 
	$trans7 = '3rd party recharge';
    $trans8 = 'Edit'; 
	$trans9 = 'Delete';	
	
	
$add_url = home_url('/add-edit-contact/?');
$view_url = home_url('/add-edit-contact/');
if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'NOM'; 
	$trans2 = 'NUMERO MTN'; 
	$trans3 = 'E-MAIL'; 
	$trans4 = 'PAYS'; 
	$trans5 = 'VILLE'; 
	$trans6 = 'OPTION'; 
	$trans7 = 'Recharge tiers'; 
	$trans8 = 'Editer'; 
	$trans9 = 'Supprimer';	
	
	$add_url = home_url('/add-edit-contact/?lang=fr&');
	$view_url = home_url('/add-edit-contact/?lang=fr');
}	

$formHtml .= '<div id="processPage"><div class="box_user">
        	<a href="'.$view_url.'"><img src="'.$dir_url.'img_userPlus.png"/></a>        
        </div>
    	<div class="table-responsive">
          <table class="table table-bordered table_name">
            <thead>
              <tr>
                <th>'.$trans1.'</th>
                <th>'.$trans2.'</th>
                <th>'.$trans3.'</th>
				<th>'.$trans4.'</th>
                <th>'.$trans5.'</th>
                <th>'.$trans6.'</th>
                <th>&nbsp;</th>
              </tr>
            </thead><tbody>';
		
		
			
      foreach($rows as $row){
		$edit_url = $add_url.'contact_id='.$row->id;
		$formHtml .= '
              <tr id="conId_'.$row->id.'">
                <td scope="row" class="a_name">'.$row->usr_name.'</td>
                <td class="a_mm">'.$row->usr_mobile_money_account.'</td>
                <td class="a_email">'.$row->usr_email.'</td>
				<td class="a_cnty">'.$row->usr_country.'</td>
                <td class="a_city">'.$row->usr_city.'</td>
                <td>
                	<div class="box_edit">
                	<span class="bg_edit"><a href="'.$edit_url.'" title="'.$trans8.'"></a></span>
                    <span class="bg_edit1"><a id="'.$row->id.'" class="deleteRec" href="javascript:void(0);"  title="'.$trans9.'"></a></span>
                    </div>
                </td>
                <td><span class="bg_arrow">';
				
			
			if($status_1 == 'Registration successfully completed'){
				
				$formHtml .= '<a href="javascript:void(0);" data-id="'.$row->id.'"  class="transferAddress" title="Transfer"></a>';
				
			}else{
				$str = $row->id;
                $encode_id =  base64_encode($str);
				
				$url_rec = "http://dsp.lab.kit-services.com/recharge-third-party/?address_id=".$encode_id;
				if(ICL_LANGUAGE_CODE == "fr")
                 {  $url_rec = "http://dsp.lab.kit-services.com/recharge-third-party/?lang=fr&address_id=".$encode_id;  }            
				$formHtml .= '<a href="'.$url_rec.'" style="background-position: 0px -37px; !important;" class="transferAddress" title="'.$trans7.'"></a>';
			}	
			
				
			$formHtml .= '</span></td>
              </tr>';
	    }	

	$formHtml .= '</tbody></table>'.$pagination.'</div></div>';
	
	$formHtml .= '<div class="modal fade popModal" id="AddressBookPopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
	    <span class="acct_detail"></span>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>        
      </div>
      <div class="modal-body">
      
      <div class="popMod">
      	<div class="form_element">
		  <form action="" method="post" id="addBooKTransForm">
            <label>Type in amount to transfer</label>            
            <span class="box_typInput">
        	    <input type="text" name="transfer_amount" id="transfer_amount" placeholder="Enter value" />
            </span> 
            <span class="box_typSub">
			   <input type="hidden" id="checkMtnTransLimit" value="'.$checkMtnTransLimit.'" />
               <input type="hidden" id="mtnTransTotal" value="'.$mtnTransTotal.'" />
			   <input type="hidden" name="first_name" id="a_fname" value="" />
			   <input type="hidden" name="last_name" id="a_lname" value="" />
			   <input type="hidden" name="a_email" id="a_email" value="" />
			   <input type="hidden" name="country_code_mobile_money" id="a_email" value="+237" />
			   <input type="hidden" name="mobile_money_account" id="a_mm" value="" />
			   <input type="hidden" name="a_city" id="a_city" value="" />
			   <input type="hidden" name="country_name" id="a_country" value="" />
         	   <input type="submit" value="TRANSFER" name="submit" class="submit1" />
         	</span>
		  </form>	
            <p class="txtRed"><span>CAUTION:</span> It is your responsibility to ensure that you are transferring fund to the correct Mobile Money Account.</p>
        </div>
      </div>
      
      </div>      
    </div>
  </div>
</div>';
		
	return $formHtml;
	
}
add_shortcode('address_book', 'mtn_address_book' );

// Address book listing page shortcode
function mtn_add_edit_contact(){
global $wpdb;
$formHtml = '';	

$current_user = wp_get_current_user();
$dir_url = plugin_dir_url(__FILE__) . 'img/';
$btn = 'Save';
if(ICL_LANGUAGE_CODE == "fr")
{
$btn = 'Enr&#233;gistrer';
}

$msg = $usr_country = '';
$contact_id = $_GET['contact_id'];
$fullname = '';
$usr_email = '';
$usr_mobile_money_account = '';
$usr_coun = '';
$usr_city = '';
$recommended_answer = '';
if(!empty($contact_id))
{
    
	$btn = 'Update';
	$contact_id = $_GET['contact_id'];
	$row = $wpdb->get_row("SELECT * FROM `wp_user_address_book` WHERE id = '".$contact_id."' AND user_id = '".$current_user->ID."'");
	
	$fullname = explode(" ", $row->usr_name);
	$usr_fname = $fullname[0];
	$usr_lname = $fullname[1];
	$usr_email = $row->usr_email;
	$usr_mobile_money_account = $row->usr_mobile_money_account;
	$usr_country = $row->usr_country;
	$usr_city = $row->usr_city;
	$recommended_answer = $row->recommended_answer;
}
if(isset($_POST['add_contact']))	
{
	$fullname = $_POST['usr_fname']." ".$_POST['usr_lname'];
	$usr_email = $_POST['usr_email'];
	$usr_mobile_money_account = $_POST['usr_mobile_money_account'];
	$usr_coun = $_POST['usr_country'];
	$usr_city = $_POST['usr_city'];
	$recommended_answer = $_POST['recommended_answer'];
	$url = site_url('address-book'); 

	
	if(!empty($_POST['contact_id']))
	{
		$contact_id = $_POST['contact_id'];
		$wpdb->query("UPDATE `wp_user_address_book` SET usr_name = '".$fullname."', usr_email = '".$usr_email."', usr_mobile_money_account = '".$usr_mobile_money_account."', usr_country = '".$usr_coun."', usr_city = '".$usr_city."',  recommended_answer = '".$recommended_answer."' WHERE id = '".$contact_id."'");
		$msg = 'Contact updated sucessfully!, We are redirecting to address book page.';
		echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
	}
	else
	{
		$no_of_contact_from_add_contact = get_option('no_of_contact_from_add_contact');
		if(empty($no_of_contact_from_add_contact))
		{update_option('no_of_contact_from_add_contact', 1);}
		else
		{   $no_of_contact_from_add_contact++;
			update_option('no_of_contact_from_add_contact', $no_of_contact_from_add_contact);
		}
		
		
		$wpdb->query("INSERT INTO `wp_user_address_book` (id, user_id, usr_name, usr_email, usr_mobile_money_account, usr_country, usr_city, recommended_answer) 
				VALUES('', '".$current_user->ID."', '".$fullname."', '".$usr_email."', '".$usr_mobile_money_account."', '".$usr_coun."', '".$usr_city."', '".$recommended_answer."')");	
				
		$msg = 'Contact added sucessfully!, We are redirecting to address book page.';
		echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
	}	
	
}
    $trans1 = 'Add/Edit contact'; 
	$trans2 = 'First name'; 
	$trans3 = 'Last name'; 
	$trans4 = 'Mobile Money Account'; 
	$trans5 = 'Email Address'; 
	$trans6 = 'Country'; 
	$trans7 = 'City'; 
	$trans8 = 'You recommended MTN Mobile Money to this contact?'; 
	$trans9 = 'Yes'; 
	$trans10 = 'No';
	$trans11 = 'Type recipient first name'; 
	$trans12 = 'Type recipient last name';
	$trans13 = 'Type recipient phone number'; 
	$trans14 = 'Type recipient email address';

if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'Ajoutez/Editez Contact'; 
	$trans2 = 'Pr&#233;nom'; 
	$trans3 = 'Nom'; 
	$trans4 = 'Compte Mobile Money'; 
	$trans5 = 'Adresse E-Mail'; 
	$trans6 = 'Pays'; 
	$trans7 = 'Ville'; 
	$trans8 = 'Avez-vous recommand&#233; MTN Mobile Money &#224; ce contact?'; 
	$trans9 = 'Oui'; 
	$trans10 = 'Non';
	$trans11 = 'Entrez pr&#233;nom b&#233;n&#233;ficiaire'; 
	$trans12 = 'Entrez nom b&#233;n&#233;ficiaire';
	$trans13 = 'Entrez num&#233;ro b&#233;n&#233;ficiaire'; 
	$trans14 = 'Entrez email b&#233;n&#233;ficiaire';
	
}	

   $formHtml = '<div class="box_user">'.$msg.'</div><div class="box_user">
        	<a><img src="'.$dir_url.'img_userPlus.png" /> </a>      
            <h4>'.$trans1.'</h4>
        </div>
		
        <div class="row">
        <div class="col-md-offset-1 col-md-10">
    	<div class="box_editContact">
        <form action="" method="post" id="addresBookForm">
          <p class="form_element">
            <label for="Firstname">'.$trans2.'<span class="required1" title="required">*</span></label>
            <span class="firstname">
            <input type="text" name="usr_fname" class="text_input1" value="'.$usr_fname.'" placeholder="'.$trans11.'">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">'.$trans3.'<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_lname" class="text_input1" value="'.$usr_lname.'" placeholder="'.$trans12.'">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">'.$trans4.'<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_mobile_money_account" value="'.$usr_mobile_money_account.'" id="usr_mobile_money_account" class="text_input1" placeholder="'.$trans13.'" />
            </span> </p>   
          <p class="form_element">
            <label for="Email">'.$trans5.'</label>
            
            <span class="user-email1">
            <input type="text" name="usr_email" class="text_input1" value="'.$usr_email.'" placeholder="'.$trans14.'" />
            </span> </p>    
          <p class="form_element">
            <label for="Subject">'.$trans6.'<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
                    <select name="usr_country" id="usr_country">
					<option value="Cameroon" selected="selected">Cameroon</option>
					</select>								
												    
            </span> 
		  </p>
		  <p class="form_element">
            <label for="Subject">'.$trans7.'<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
            
			       <select name="usr_city" id="usr_city">
					<option value="">Select '.$trans7.'</option>
					</select>
            </span>
		  </p>
          <p class="form_element form_fullwidth">
            <label class="radio-wrapper" for="Subject">'.$trans8.'<span class="required1" title="required">*</span></label>
            <span class="subject1">
              '.$trans9.' <input type="radio" name="recommended_answer" value="yes"';
        if($recommended_answer == "yes")
		$formHtml .= "checked";	
	
		$formHtml .= '/> '.$trans10.' <input type="radio" name="recommended_answer" value="no"';
		
        if($recommended_answer == "no")
		$formHtml .= "checked";	
	
		$formHtml .= '/>
            </span>
			
		  </p> 		  
          <p class="submit-container1">
		    <input type="hidden" name="contact_id" id="contact_id" value="'.$contact_id.'" />
			<input type="hidden" id="usr_old_city" name="usr_old_city" value="'.$usr_city.'" />
            <input type="submit" name="add_contact" value="'.$btn.'" class="submit1" />
         </p>
		 </form>
		</div>
		
        </div>
        </div>';
	 

	
		
	return $formHtml;
	
}
add_shortcode('add_edit_contact', 'mtn_add_edit_contact' );

//delete contact of address book
function deleteContact(){
	global $wpdb;
	
	if(!empty($_POST['contact_id'])){
		
		$contact_id = $_POST['contact_id'];
		$wpdb->query("DELETE FROM `wp_user_address_book` WHERE id = '".$contact_id."'");
		echo "success";
	}
		
    die();
	
}
add_action( 'wp_ajax_deleteContact', 'deleteContact' );
add_action( 'wp_ajax_nopriv_deleteContact', 'deleteContact' );

//cronjob create for freshdesk status
register_activation_hook(__FILE__, 'my_freshdesk_activation');

function my_freshdesk_activation() {
	
	date_default_timezone_set('Africa/Douala');
	
	
    if (! wp_next_scheduled ( 'my_daily_event_1' )) {
		
		
		
		  $time == '09:00:00';
		  $time1 = strtotime($time);
	      wp_schedule_event(strtotime('09:00:00'), 'daily', 'my_daily_event_1');
		
		
		  $time == '13:00:00';
		  $time2 = strtotime($time);
	      wp_schedule_event(strtotime('13:00:00'), 'daily', 'my_daily_event_1');
		
		
		  $time == '19:00:00';
		  $time3 = strtotime($time);
	      wp_schedule_event(strtotime('19:00:00'), 'daily', 'my_daily_event_1');
		
		
		
    }
	
	if (! wp_next_scheduled ( 'my_daily_event_2' )) {
		
		  $time == '08:00:00';
		  $time1 = strtotime($time);
	      wp_schedule_event(strtotime('08:00:00'), 'daily', 'my_daily_event_2');
		
		
		  $time == '12:00:00';
		  $time2 = strtotime($time);
	      wp_schedule_event(strtotime('12:00:00'), 'daily', 'my_daily_event_2');
		
		
		  $time == '18:00:00';
		  $time3 = strtotime($time);
	      wp_schedule_event(strtotime('18:00:00'), 'daily', 'my_daily_event_2');
		
		
    }
}

add_action('my_daily_event_1', 'do_this_daily_1');

function do_this_daily_1() {
	   $blogusers = get_users( 'blog_id=1&orderby=nicename' );
		// Array of WP_User objects.
		foreach ( $blogusers as $user ) {
		 $currntStatus = get_user_meta($user->ID, 'diaspo_pdf_status', true);	
		 if($currntStatus == 'Submitted')	
		  {
			$status = get_freshdeck_status($user->user_email, 'MTN SIM Card Shipping Request');
			if($status == 4 || $status == 5)
			{
				update_user_meta($user->ID, 'diaspo_pdf_status', 'SIM Card has been shipped');
				date_default_timezone_set('CET');
                update_user_meta($user->ID , 'status_change_date', 'Y/m/d' );
			} 	
		  }
         		  
		
		}
}

add_action('my_daily_event_2', 'do_this_daily_2');

function do_this_daily_2() {
	   $blogusers = get_users( 'blog_id=1&orderby=nicename' );
		// Array of WP_User objects.
		foreach ( $blogusers as $user ) {
		 $currntStatus = get_user_meta($user->ID, 'diaspo_pdf_status', true);	
		
          if($currntStatus == 'SIM Card Pending')
		  {
			$status = get_freshdeck_status($user->user_email, 'New MTN Registration Request');
			if($status == 4 || $status == 5)
			{
				update_user_meta($user->ID, 'diaspo_pdf_status', 'SIM Card Registered');
			}  
			  
		  }
         		  
		
		}
}

//cronjob end for freshdesk status
register_deactivation_hook(__FILE__, 'my_freshdesk_deactivation');

function my_freshdesk_deactivation() {
	wp_clear_scheduled_hook('my_daily_event_1');
	wp_clear_scheduled_hook('my_daily_event_2');
}

function  get_freshdeck_status($email, $subject){
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $return = 0;
		 $url = $freshdesk_login_url."/api/v2/tickets?email=".$email;

		 //print "REST URL: " . $url . "\n";
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
		 //curl_setopt ($ch, CURLOPT_POSTFIELDS, $postData);



		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 /*if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }*/

		 
		 
		 $data = json_decode($returndata, TRUE);
		
		foreach($data as $currentData){ 
		  
		if($currentData['subject'] == $subject) 
		 {
			echo $return = $currentData['status'];
		 }
        
		}
		
	return $return;
}



function  get_freshdeck_all_status_counts(){
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $return = '';
		 $url = $freshdesk_login_url."/api/v2/tickets";

		 //print "REST URL: " . $url . "\n";
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
		 curl_setopt ($ch, CURLOPT_POSTFIELDS, $postData);



		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		 $return = json_decode($returndata, TRUE);
		 
		 
		 		
	return $return;
}

//Password verification
function pass_verified() {

       $password = $_POST['passVerified'];
       $user = get_user_by( 'ID', get_current_user_id());
		if ( $user && wp_check_password( $password, $user->data->user_pass, $user->ID) )
		   $error = 0;
		else
		   $error = 1; 
   
   echo $error;

die(0);
}
add_action("wp_ajax_password_action", "pass_verified");
add_action("wp_ajax_nopriv_password_action", "pass_verified");

function mtn_unique() {
    global $wpdb;
       $mtnUnique = $_POST['mtnUnique'];
	   $contact_id = $_POST['contact_id'];
	   
       $row = $wpdb->get_row("SELECT * FROM `wp_user_address_book` WHERE usr_mobile_money_account = '".$mtnUnique."' AND user_id = '".get_current_user_id()."'");
	  
		if($row){
			if(!empty($contact_id) && $row->id == $contact_id){
				
				$error = 0;

			}else{
		        $error = 1;
			}
		}
		else {
		   $error = 0;
		}
         
   
   
echo  $error;
die(0);
}
add_action("wp_ajax_mtn_unique", "mtn_unique");
add_action("wp_ajax_nopriv_mtn_unique", "mtn_unique");

function get_conversion_bitcoin($bitcoin_from, $bitcoin_to)
{
	$secretKey = get_option('bitcoin_secret_key');
	$publicKey = get_option('bitcoin_public_key');
	$timestamp = time();
	$payload = $timestamp . '.' . $publicKey;
	$hash = hash_hmac('sha256', $payload, $secretKey, true);
	$keys = unpack('H*', $hash);
	$hexHash = array_shift($keys);

	$signature = $payload . '.' . $hexHash;
	
	$url = "https://apiv2.bitcoinaverage.com/convert/global?from=".$bitcoin_from."&to=".$bitcoin_to."&amount=1"; 

	$headers = array("X-Signature: " . $signature);
	$ch = curl_init();
				
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           
            curl_setopt($ch, CURLOPT_POST, false);
            
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);


	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			$decode = json_decode($response);
	
	return $decode->price;
}


function get_conversion_bitcoin_with_amount($bitcoin_from, $bitcoin_to, $amount)
{
	$secretKey = get_option('bitcoin_secret_key');
	$publicKey = get_option('bitcoin_public_key');
	$timestamp = time();
	$payload = $timestamp . '.' . $publicKey;
	$hash = hash_hmac('sha256', $payload, $secretKey, true);
	$keys = unpack('H*', $hash);
	$hexHash = array_shift($keys);

	$signature = $payload . '.' . $hexHash;
	
	$url = "https://apiv2.bitcoinaverage.com/convert/global?from=".$bitcoin_from."&to=".$bitcoin_to."&amount=".$amount; 

	$headers = array("X-Signature: " . $signature);
	$ch = curl_init();
				
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           
            curl_setopt($ch, CURLOPT_POST, false);
            
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);


	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			$decode = json_decode($response);
	
	return $decode->price;
}


function convert_currency() {
    global $wpdb;
	
	$from_curr = $_POST['from_curr'];
	$to_curr = $_POST['to_curr'];
	$amount = $_POST['amount'];
	$fees = $_POST['fees'];
	$addFees = $_POST['addFees'];
	$totalAmount = $_POST['totalAmount'];
	
    if($to_curr == 'mBTC')
	{
		$rate = get_conversion_bitcoin($from_curr, 'BTC');
		
	    $amount = round($amount*$rate*1000,4);
	    $fees = round($fees*$rate*1000,4);
	    $addFees = round($addFees*$rate*1000,4);
	    $totalAmount = round($totalAmount*$rate*1000,4);
		
		
	}
	else if($to_curr == 'XAF')
	{
	      $rate = get_option('currency_coversion_rate');
		  
		  $amount = round($amount*$rate);
		  $fees = round($fees*$rate);
		  $addFees = round($addFees*$rate);
		  $totalAmount = round($totalAmount*$rate);
		      
		  
          		  
		  
	}
    else
	{
	          $rate = get_option('currency_coversion_rate1');
		  
			  $amount = round($amount*$rate,2);
		      $fees = round($fees*$rate,2);
		      $addFees = round($addFees*$rate,2);
		      $totalAmount = round($totalAmount*$rate,2);
		 
        
	}
   		
   
   
echo  $amount.'##'.$fees.'##'.$addFees.'##'.$totalAmount.'##'.$from_curr.'##'.$to_curr.'##'.$rate;
die(0);
}
add_action("wp_ajax_convertCurrency", "convert_currency");
add_action("wp_ajax_nopriv_convertCurrency", "convert_currency");

function get_notify() {
	
    global $wpdb;
	
	$user_info = get_userdata(get_current_user_id());
	$user_email = $user_info->user_email;
	$username = $user_info->first_name;
	
	update_user_meta(get_current_user_id(), 'notifiedMe', 1);

	$site_url = 'http://dsp.lab.kit-services.com/';
	$to = 'support@diaspo-cc.com';
	$subject = 'Notify me when Recharge service back online';
	$datetime = date('Y-m-d h:i:s');
	
	$message  = '&lt;'.$username.'&gt; tried to use recharge Mobile Money service at &lt;'.$datetime.'&gt;. We will notify when service back online. Thanks for your understanding, diaspoCC Support Team'. "\r\n";
	
	
	
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	 
	// Create email headers
	$headers .= 'From: '.$username.' <'.$user_email.'>'."\r\n";
	 
	// Sending email
	mail($to, $subject, $message, $headers);
	
	
	

echo  "success";
die(0);
}
add_action("wp_ajax_getNotify", "get_notify");
add_action("wp_ajax_nopriv_getNotify", "get_notify");


function get_mtn_notify() {
	
    global $wpdb;
	
	$user_info = get_userdata(get_current_user_id());
	$user_email = $user_info->user_email;
	$username = $user_info->first_name;
	
	update_user_meta(get_current_user_id(), 'mtnNotifiedMe', 1);

	$site_url = 'http://dsp.lab.kit-services.com/';
	$to = 'support@diaspo-cc.com';
	$subject = 'Notify me when next MTN Registration slot is available';
	$datetime = date('Y-m-d h:i:s');
	
	$message  = '&lt;'.$username.'&gt; tried to use recharge Mobile Money service at &lt;'.$datetime.'&gt;. We will notify when next registration slot is available. Thanks for your understanding, diaspoCC Support Team'. "\r\n";
	
	
	
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	 
	// Create email headers
	$headers .= 'From: '.$username.' <'.$user_email.'>'."\r\n";
	 
	// Sending email
	mail($to, $subject, $message, $headers);
	
	
	

echo  "success";
die(0);
}
add_action("wp_ajax_getMtnNotify", "get_mtn_notify");
add_action("wp_ajax_nopriv_getMtnNotify", "get_mtn_notify");

function get_fresdesk_open_tickets($subject){
	
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $return = 0;
		 $url = $freshdesk_login_url."/api/v2/tickets?filter=new_and_my_open";
		 //$url = $freshdesk_login_url."/api/v2/tickets";

		 //print "REST URL: " . $url . "\n";
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
		



		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		 $data = json_decode($returndata, TRUE);
		 
		 
		 
		 
		 
		foreach($data as $ticket) 
		{
		 
		 
		  if($ticket['subject'] == $subject && $ticket['status'] == 2)
		  {
			   
			  update_freshdesk_ticket($ticket['id']);
          }			  
			
		}
}

function update_freshdesk_ticket($id)
{
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	    
		 $url = $freshdesk_login_url."/api/v2/tickets";
		 

		
		 $header[] = "Content-type: application/json";
		 
		 $ch = curl_init($url . "/{$id}");
		

         $postData = json_encode(array('status' => 4));

		 
		 
		 
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

			// Make the REST call, returning the result
			$response = curl_exec($ch);
			if (!$response) {
				die("Connection Failure.n");
			}
		 

		$data = json_decode($response, TRUE);
		 
	
	
}



function COUNTRYCODE_func() {
	$country_code = get_user_meta( get_current_user_id() , 'country_flag_code', true );
	return $country_code;
}
add_shortcode( 'COUNTRYCODE', 'COUNTRYCODE_func' );

function MSISDN_func() {
	
	$msisdn = get_user_meta(get_current_user_id(), 'msisdn', true);
	return $msisdn;
}
add_shortcode( 'MSISDN', 'MSISDN_func' );


function go_track_bitcoin(){
	
	global $wpdb;
	$ProdId = $_POST['ProdId'];
	
	
	$res = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE payment_transaction_id = '".$ProdId."'");	
    if($res->payment_status == 'Completed'){
		echo $ProdId;
	}else
	{
		echo '';
	}	
	
	
	die(0);
}
add_action( 'wp_ajax_go_track_bitcoin', 'go_track_bitcoin' );
add_action( 'wp_ajax_nopriv_go_track_bitcoin', 'go_track_bitcoin' );

//Trade Sell
function go_track_bitcoin_sell(){
	
	global $wpdb;
	$ProdId = $_POST['ProdId'];
	
	
	$res = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE order_id = '".$ProdId."'");	
    if(( $res->payment_status == 'Completed' || $res->payment_status == 'Rejected' ) && $res->btc_status == 'Completed'){
		echo $res->order_id;
	}else
	{
		echo '';
	}	
	
	
	die(0);
}
add_action( 'wp_ajax_go_track_bitcoin_sell', 'go_track_bitcoin_sell' );
add_action( 'wp_ajax_nopriv_go_track_bitcoin_sell', 'go_track_bitcoin_sell' );

//Trade Buy
function go_track_bitcoin_buy(){
	
	global $wpdb;
	$ProdId = $_POST['ProdId'];
	
	
	$res = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE order_id = '".$ProdId."'");	
    if(( $res->payment_status == 'Completed' || $res->payment_status == 'Rejected' ) && ( $res->btc_status == 'Completed' || $res->status_code != '')){
		echo $res->order_id;
	}else
	{
		echo '';
	}	
	
	
	die(0);
}


add_action( 'wp_ajax_go_track_bitcoin_buy', 'go_track_bitcoin_buy' );
add_action( 'wp_ajax_nopriv_go_track_bitcoin_buy', 'go_track_bitcoin_buy' );
function make_deposit_after_request_527($order_id){
	
	global $wpdb;
	
	$user_id = get_current_user_id();
	
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = '".$order_id."'");
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');
	
	$amount = $rowdata->xaf_trans_amount;
	$msisdn = $rowdata->MSISDNNum;
	
	
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
	
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		
		$password = $sp_password;
		
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>DiaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>TRANSFER PROCESSED on www.diaspoCC.com THE DIASPORA COMMUNITY CENTER. </value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';




       
       $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;
	
}


function create_freshdesk_ticket_for_527_error($data){
	
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $postData = json_encode($data);
		 
		 $url = $freshdesk_login_url."/api/v2/tickets";
		
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt( $ch, CURLOPT_POSTFIELDS, $postData);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		$result = json_decode($returndata, TRUE);
		
		 
		 
		
		 
		
	return	$result;
}

function get_fresdesk_open_tickets_527(){
	
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $return = 0;
		 $url = $freshdesk_login_url."/api/v2/tickets?filter=new_and_my_open";
		 //$url = $freshdesk_login_url."/api/v2/tickets";

		 //print "REST URL: " . $url . "\n";
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
		



		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		 $data = json_decode($returndata, TRUE);
		 
		 
		 
		 
		return $data; 
		
}

function get_fresdesk_contact_detail_for_527($id){
	
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $return = 0;
		 $url = $freshdesk_login_url."/api/v2/contacts/".$id;
		 
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
		



		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		 $data = json_decode($returndata, TRUE);
		 
		 
		return $data;
}



// Adding Custom Post Type for Hotspot Listing
    
function create_identification_hotspots_post_type() {
 
   //labels array added inside the function and precedes args array
 
   $labels = array(
    'name'               => _x( 'Hotspot/ Partners', 'post type general name' ),
    'singular_name'      => _x( 'Hotspot / Partner', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'Hotspot' ),
    'add_new_item'       => __( 'Add New Hotspot' ),
    'edit_item'          => __( 'Edit Hotspot' ),
    'new_item'           => __( 'New Hotspot' ),
    'all_items'          => __( 'All Hotspots' ),
    'view_item'          => __( 'View Hotspot' ),
    'search_items'       => __( 'Search hotspot' ),
    'not_found'          => __( 'No hotspot found' ),
    'not_found_in_trash' => __( 'No hotspot found in the Trash' ),
    'parent_item_colon'  => '',
    'menu_name'          => 'Identification Hotspot / Partners'
  );
 
         // args array
 
   $args = array(
    'labels'        => $labels,
    'description'   => 'Displays identification hotspot / partners',
    'public'        => true,
    'menu_position' => 4,
    'supports'      => array( 'title'),
    'has_archive'   => true,
  );
 
  register_post_type( 'hotspot', $args );
  
  
  
   //labels array added inside the function and precedes args array
 
   $labels1 = array(
    'name'               => _x( 'Event Tickets', 'post type general name' ),
    'singular_name'      => _x( 'Event Ticket', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'Event Ticket' ),
    'add_new_item'       => __( 'Add New Event Ticket' ),
    'edit_item'          => __( 'Edit Event Ticket' ),
    'new_item'           => __( 'New Event Ticket' ),
    'all_items'          => __( 'All Event Tickets' ),
    'view_item'          => __( 'View Event Ticket' ),
    'search_items'       => __( 'Search Event Ticket' ),
    'not_found'          => __( 'No Event Ticket found' ),
    'not_found_in_trash' => __( 'No Event Ticket found in the Trash' ),
    'parent_item_colon'  => '',
    'menu_name'          => 'Event Ticket to Sell'
  );
 
         // args array
 
   $args1 = array(
    'labels'        => $labels1,
    'description'   => 'Displays Event Tickets',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title'),
    'has_archive'   => true,
  );
 
  register_post_type( 'event_ticket', $args1 );
}
add_action( 'init', 'create_identification_hotspots_post_type' );


function wpb_change_title_text_hotspot( $title ){
     $screen = get_current_screen();
  
     if  ( 'hotspot' == $screen->post_type ) {
          $title = 'Enter Company Name';
     }
  
     return $title;
}
  
add_filter( 'enter_title_here', 'wpb_change_title_text_hotspot' );


function get_hotspot_distance($source, $destination){
	
	$distance_key = get_option('distance_key');
	
	
	    $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?origins='.urlencode($source).'&destinations='.urlencode($destination).'&key='.$distance_key;

		 
		 $string .= file_get_contents($url); // get json content
         $result = json_decode($string, true); //json decoder
   
	
	$rows = $result['rows'];
    $elements = $rows[0]['elements'];
    $distance = explode(' ', $elements[0]['distance']['text']);
	
    return $distance[0];
	
	
	
    
}



function sent_email_notification(){
	
	$user_id = get_current_user_id();
	$user_info = get_userdata($user_id);
    $first_name = $user_info->first_name;
	
	
	$to = $_POST['email'];
	$company_name = $_POST['company_name'];
	
	
	$subject = 'OTP for Hotspots identification: '.$first_name;
	
	$OTP = mt_rand(100000, 999999);	
	
	$message  = '<p>Hello <b>'.$company_name.'</b>,</p>'. "\r\n";
	
	$message  .= '<p>Here the OTP for identifying <b>'.$first_name.'</b> on www.diaspo-cc.com: <b>'.$OTP.'</b></p>'. "\r\n";
	
	$message  .= '<p>Regards,</p>'. "\r\n";
	
	$message  .= 'diaspoCC Team'. "\r\n";


    // To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	 
	// Create email headers
	$headers .= 'From: diaspoCC <noreply@mail.diaspo-cc.com>'."\r\n";
	// mails to be delivered to
    $headers .= 'Bcc: noreply@mail.diaspo-cc.com' . "\r\n";
	 
	// Sending email
	if(mail($to, $subject, $message, $headers)){
		
		echo $to.'##'.$OTP.'##'.$company_name;
	}
		
	
	
	die(0);
}
add_action( 'wp_ajax_sent_email_notification', 'sent_email_notification' );
add_action( 'wp_ajax_nopriv_sent_email_notification', 'sent_email_notification' );

function update_hotspot_status(){
	
	$user_id  = get_current_user_id();
	
	update_user_meta($user_id, 'diaspo_pdf_status', 'SIM Card registration pending');
	echo "success";
	die(0);
}



add_action('save_post','save_hotspot_callback');
function save_hotspot_callback($post_id){
    global $post; 
    if ($post->post_type == 'hotspot'){
		
       $company_name = get_the_title($post_id);
	   $phone_number = get_field('phone_number', get_the_ID());
	   $opening_hours = get_field('opening_hours', get_the_ID());
	   $company_address_1 = get_field('street_name', get_the_ID()).', '.get_field('zipcode', get_the_ID()).', '.get_field('city', get_the_ID()).', '.get_field('country', get_the_ID());

       	   
	   $allUsers = get_users();
	   foreach($allUsers as $user){
						
		$to_user = $user->user_email;
		$first_name = $user->first_name;
		$diaspo_pdf_status = get_user_meta($user->ID, 'diaspo_pdf_status', true);
	    $hotspot_shortest_distance = get_user_meta($user->ID, 'hotspot_shortest_distance', true);

        $country_of_residence = get_user_meta( $user->ID , 'diaspo_user_country_of_residence', true );
		
		$city_of_residence    = get_user_meta( $user->ID , 'diaspo_user_city', true );
		$diaspo_user_street    = get_user_meta( $user->ID , 'diaspo_user_street', true );
		$diaspo_user_zipcode = get_user_meta( $user->ID , 'diaspo_user_zipcode', true );
		$diaspo_user_house_no    = get_user_meta( $user->ID , 'diaspo_user_house_no', true );
		$user_address = '';

		if(!empty($diaspo_user_house_no)){
		$user_address .= $diaspo_user_house_no.', ';	
		}
		if(!empty($diaspo_user_street)){
		$user_address .= $diaspo_user_street.', ';	
		}
		if(!empty($diaspo_user_zipcode)){
		$user_address .= $diaspo_user_zipcode.', ';	
		}
		if(!empty($city_of_residence)){
		$user_address .= $city_of_residence.', ';	
		}
		if(!empty($country_of_residence)){
		$user_address .= $country_of_residence.', ';	
		}
		$distance_limit = get_option('distance_limit');
		$user_address = $diaspo_user_house_no.$diaspo_user_street.$city_of_residence.$diaspo_user_zipcode.$country_of_residence;

        $value = get_hotspot_distance($user_address, $company_address_1);	
		if(empty($hotspot_shortest_distance)){
			
		    if($diaspo_pdf_status != 'Registration successfully completed' && $value <= $distance_limit){
				
		        //user email
				$to_user = $_POST['email'];
				
				
				$subject = 'New hotspot near to you';
				
				$message  = '<p>Dear &lt;'.$first_name.'&gt;,</p>'. "\r\n";
				
				$message  .= '<p>We just want to notifiy you that we have new hotspot(s) location(s) close to your place. Here their location(s):</p>'. "\r\n";
				
				$message  .= '<p>Company Name: <b>'.$company_name.'</b></p>'. "\r\n";
				$message  .= '<p>Company Address: <b>'.$company_address_1.'</b></p>'. "\r\n";
				$message  .= '<p>Company Phone number: <b>'.$phone_number.'</b></p>'. "\r\n";
				$message  .= '<p>Company opening hours: <b>'.$opening_hours.'</b></p>'. "\r\n";
				
				
				$message  .= '<p>Regards,</p>'. "\r\n";
				
				$message  .= 'diaspoCC Team'. "\r\n";


				// To send HTML mail, the Content-type header must be set
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				 
				// Create email headers
				$headers .= 'From: diaspoCC <noreply@diaspo-cc.com>'."\r\n";
				// mails to be delivered to
				
				 
				// Sending email
				mail($to, $subject, $message, $headers);
		      
				//store hotspot_shortest_distance
				update_user_meta($user->ID, 'hotspot_shortest_distance', $value);		  
		    }
				
		 }
         else
         {
			if($diaspo_pdf_status != 'Registration successfully completed' && $value <= $hotspot_shortest_distance){
		
				 //user email
				$to_user = $_POST['email'];
				
				
				$subject = 'New hotspot near to you';
				
				$message  = '<p>Dear &lt;'.$first_name.'&gt;,</p>'. "\r\n";
				
				$message  .= '<p>We just want to notifiy you that we have new hotspot(s) location(s) even closer to your place. Here their location(s):</p>'. "\r\n";
				
				$message  .= '<p>Company Name: <b>'.$company_name.'</b></p>'. "\r\n";
				$message  .= '<p>Company Address: <b>'.$company_address_1.'</b></p>'. "\r\n";
				$message  .= '<p>Company Phone number: <b>'.$phone_number.'</b></p>'. "\r\n";
				$message  .= '<p>Company opening hours: <b>'.$opening_hours.'</b></p>'. "\r\n";
				
				
				$message  .= '<p>Regards,</p>'. "\r\n";
				
				$message  .= 'diaspoCC Team'. "\r\n";


				// To send HTML mail, the Content-type header must be set
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				 
				// Create email headers
				$headers .= 'From: diaspoCC <noreply@diaspo-cc.com>'."\r\n";
				// mails to be delivered to
				
				 
				// Sending email
				mail($to, $subject, $message, $headers);
		      
				//store hotspot_shortest_distance
				update_user_meta($user->ID, 'hotspot_shortest_distance', $value);	  
		    }
            			
		 }			 
						  
	   }  
	   
	   
	   
		
    }
   
}



// create recharge third party form shortcode
function mtn_thirdparty_recharge(){

global $wpdb;
$formHtml = '';	
$rate = get_option('currency_coversion_rate');
$recharge_limit = get_option('without_identification_recharge_limit');

$tax_fees = get_option('tax_fees');
$extra_fees = get_option('extra_fees');	
	
$current_user = wp_get_current_user();

$country = get_the_author_meta( 'diaspo_user_country_of_residence', $current_user->ID );
$first_name = get_user_meta($current_user->ID, 'first_name', true);
$last_name = get_user_meta($current_user->ID, 'last_name', true);


$country_code = '+'.get_user_meta( $current_user->ID , 'country_flag_code', true );


$addresses = $wpdb->get_results("select * from `wp_user_address_book` WHERE user_id = '".$current_user->ID."' order by id desc");

if(strlen($phone) != 9)
{
	
	$phone = substr($phone,-9); 
}
$method1 = $method2 = $method3 = '';
$methods = explode(',',get_option('payment_methods'));
$success_url = '';
if(ICL_LANGUAGE_CODE == "fr")
{$success_url = 'http://dsp.lab.kit-services.com/success-url-third-party/?lang=fr';}else{$success_url = 'http://dsp.lab.kit-services.com/success-url-third-party/';}
	
$dir_url = plugin_dir_url(__FILE__) . 'img/';	

foreach($methods as $method)
{
	    if($method == 'paypal')
	    {
			$method1 = 'yes';
	    }
		elseif($method == 'sofort')	
		{
			$method2 = 'yes';
		}
		else
		{
			$method3 = 'yes';
		}						
				  				   
}	
$dir_url_image = plugin_dir_url(__FILE__) . 'images/';
$ajaxurl = admin_url( 'admin-ajax.php' );


$fullname = '';
$usr_mobile_money_account = '';


@$address_id =  base64_decode($_GET['address_id']); 
if(!empty($address_id))
{
	global $wpdb;
   
    $current_user = wp_get_current_user();


	$res = $wpdb->get_row("SELECT * FROM `wp_user_address_book` WHERE id = '".$address_id."' AND user_id = '".$current_user->ID."'");
	
	$fullname = $res->usr_name;
	$usr_mobile_money_account = $res->usr_mobile_money_account;
	
	
	
	
}
    $trans1 = 'Basic Detail'; 
	$trans2 = 'Country Code'; 
	$trans3 = 'Recipient Name'; 
	$trans4 = 'Enter Full Name'; 
	$trans5 = 'Currency Type'; 
	$trans6 = 'Amount'; 
	$trans7 = 'Recipient Phone No.'; 
	$trans8 = 'Confirm Recipient Phone No.'; 
	$trans9 = 'Enter Phone No.'; 
	$trans10 = 'Recipient already added to Address Book ?';
	$trans11 = 'NO'; 
	$trans12 = 'Yes'; 
	$trans13 = 'Send amount'; 
	$trans14 = 'Fees';
	$trans15 = 'Total to Pay'; 
	$trans16 = 'Exchange rate'; 
	$trans17 = 'Payment';
	$trans18 = 'Choose Payment Method'; 
	$trans19 = 'Transaction Details'; 
	$trans20 = 'TRANSACTION DETAILS'; 
    $trans21 = 'Amount to recharge'; 
	$trans22 = 'Rewards'; 
	$trans23 = 'Total'; 
	$trans24 = 'conversion are just approximation and may slightly differ from total to pay';
	$trans25 = 'You are about to recharge'; 
	$trans26 = 'on'; 
	$trans27 = 'Mobile Money account';
	
	$trans28 = 'Did you make payment?';
	$trans29 = 'Yes';
	$trans30 = 'No';
	
	
	

	
if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'Detail B&#233;n&#233;ficiaire  '; 
	$trans2 = 'Code pays'; 
	$trans3 = 'Nom b&#233;n&#233;ficiaire'; 
	$trans4 = 'Entrez Nom B&#233;n&#233;ficiaire'; 
	$trans5 = 'Monnaie locale'; 
	$trans6 = 'Montant'; 
	$trans7 = 'T&#233;l&#233;phone B&#233;n&#233;ficiaire'; 
	$trans8 = 'Confirmation T&#233;l&#233;phone B&#233;n&#233;ficiaire'; 
	$trans9 = 'Entrez Num&#233;ro'; 
	$trans10 = 'B&#233;n&#233;ficiaire d&#233;j&#224; ajout&#233; &#224; vos contacts?';
	$trans11 = 'Non'; 
	$trans12 = 'Oui'; 
	$trans13 = 'Montant &#224; envoyer'; 
	$trans14 = 'Frais';
	$trans15 = 'Total &#224; envoyer'; 
	$trans16 = 'Taux de change'; 
	$trans17 = 'Paiement';
	$trans18 = 'Selectionnez le mode de paiement'; 
	$trans19 = 'R&#233;sum&#233; transaction'; 
	$trans20 = 'DETAIL DE LA TRANSACTION'; 
	$trans21 = 'Montant &#224; cr&#233;diter'; 
	$trans22 = 'Bonus'; 
	$trans23 = 'Total'; 
	$trans24 = 'Les convertions telles que indiqu&#233;es sur cette page sont juste &#224; titre indicatif et peuvent avoir un l&#233;ger &#233;cart au montant final';
	$trans25 = 'Vous allez cr&#233;diter le montant de'; 
	$trans26 = 'sur le compte'; 
	$trans27 = '';
	
	$trans28 = 'Avez-vous d&#233;j&#224; effectu&#233; le paiement?';
	$trans29 = 'Oui';
	$trans30 = 'Non';
	
}	

$formHtml .= '<div role="form" class="" lang="en-US" dir="ltr">		                  
											<form action="#" method="post" id="singupForm_next" class="singupForm_next_lev">
												
												
												<div id="wizardNext">
												<h2 class="headTab">'.$trans1.'</h2>
												<section>
                                                   <div class="contact-box">
												   
													
													<input type="hidden" id="countryCode" value="'.$country_code.'" />
													
													<div class="form_element codeAcount" style="width:20%;"><label for="Subject">'.$trans2.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<span class="data"><input type="text" id="country_code_mobile_money" value="+237" name="country_code_mobile_money" />
															</span>
														</span>
													</div>
													
													
													<p class="form_element cod_ico">
														<span class="cnfIcon" data-toggle="modal" data-target="#fromAddressBookPopup" style="cursor:pointer;">
														<img src="'.get_stylesheet_directory_uri().'/img/moneyTrans-icon" title="Add Address from Address Book" />
														</span>
														
													</p>
													<p class="form_element cod_ic_tw">
													<label for="Subject"><img src="http://dsp.lab.kit-services.com/wp-content/themes/diaspo/img/user_icon.png">&nbsp;&nbsp;'.$trans3.' <abbr class="required" title="required">*</abbr></label>
													<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="text" name="full_name" value="'.$fullname.'" id="full_name" Placeholder="'.$trans4.'" />
															</span>	
														</span>
													</p>
													
													

													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans5.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<select name="currency_code" id="currency_code">
																<option value="XAF">XAF</option>
															</select>
														</span>
													</p>

													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans6.'<abbr class="required" title="required">*</abbr></label><br>
														<input type="text" class="required payment amount" value=""  id="amount" name="recharge_amount" value="" placeholder="'.$trans6.'" />
													</p>
													
													<p class="form_element mobileAcount">
														<label for="Subject">'.$trans7.'<abbr class="required" title="required">*</abbr></label>
														<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="tel" name="mobile_money_account" value="'.$usr_mobile_money_account.'"  id="mobile_money_account" Placeholder="'.$trans9.'" />
															</span>	
														</span>
													</p>
															
													<p class="form_element mobileAcount lastIcon">
														<label for="Subject">'.$trans8.'<abbr class="required" title="required">*</abbr></label>
														<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="tel" name="confirm_mobile_money_account" value="'.$usr_mobile_money_account.'" onpaste="return false"  id="confirm_mobile_money_account" Placeholder="'.$trans9.'" />
															</span>	
														</span>
														
													</p>
													
													
													
													
													
												<p class="form_element radio_but">	
												
												<span class="rad_lef">'.$trans10.'</span>	
													
                                                <span class="rad_lef_tw maxl"> 
												 <label class="radio inline"> 
													  <input type="radio" name="add_recepient_address" id="add_recepient_address" onClick="add_in_address_book();" value="yes" />
													  <span>'.$trans11.' </span> 
												   </label>
												  <label class="radio inline"> 
													  <input type="radio" name="add_recepient_address" value="no" checked />
													  <span>'.$trans12.' </span> 
												  </label>    
													                                              
												</span>	
												
												</p>					
													
													
												<p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>	
													

												<div class="col-sm-12 mt-20">
							                		<div class="form-save">
							                			<div class="amount-div">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans13.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans14.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                		</div>
                                                        <br/>
								                		<div class="total-pay">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans15.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>EUR 0.00</h3>
									                			</div>
								                			</div>
								                			<div class="row" style="display:none">
									                			<div class="col-sm-8 col-xs-8">
									                				<h3>Your account gets</h3>
																	<p>&lt;users MTN phone number = Kit Number&gt;
																	will be credited with &lt;amount in currency of country where member registered for MoMo&gt;</p>
									                			</div>
									                			<div class="col-sm-4 col-xs-4 text-right">
									                				<h3>XAF 0.00</h3>
									                			</div>
								                			</div>
								                		</div>
							                		</div>
							                	</div>		
                                                <br/>
							                	<div class="col-sm-12 text-center">
							                		<h4>'.$trans16.' EUR 1 = XAF '.$rate.'</h4>
							                	</div>
												
                                                <input type="hidden" id="ajaxUrl" value="'.$ajaxurl.'" />
							                	<input type="hidden" id="recharge_limit" value="'.$recharge_limit.'" />
												<input type="hidden" id="paypal_tax_fees" value="'.$tax_fees.'" />
							                	<input type="hidden" id="paypal_extra_fees" value="'.$extra_fees.'" />
												
                </section>

                <h2 class="headTab">'.$trans17.'</h2>
                <section>
                   <div class="contact-box"><h2>'.$trans18.' :</h2>
				   <div class="row pay_spaceing">';
		    $addi = '';	
			
               			
			if($method2 == 'yes'){	
                if($method1 != 'yes' && $method3 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="without_extra">
							<input type="radio" class="required" name="payment_method" value="Sofort" id="Sofort" checked/><label for="Sofort" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/sofort-logo.jpg" /></label>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="without_extra">
							<input type="radio" class="required" name="payment_method" value="Sofort" id="Sofort" /><label for="Sofort" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/sofort-logo.jpg" /></label>
						</div>';
					
				}
			    
			}
            if($method1 == 'yes'){	

            
						
				if($method2 != 'yes' && $method3 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="extra_fee">
							<input type="radio" class="required" name="payment_method" value="Paypal" id="Paypal" checked/><label for="Paypal" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/paypal-logo.jpg" /></label>
							<span id="with_fee" style="font-weight: 600;padding: 10px 0 0 40px;">(With Additional Fees)</span>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="extra_fee">
							<input type="radio" class="required" name="payment_method" value="Paypal" id="Paypal" /><label for="Paypal" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/paypal-logo.jpg" /></label>
							<span id="with_fee" style="display:none;font-weight: 600;padding: 10px 0 0 40px;">(With Additional Fees)</span>
						</div>';
					
				}		
						
						
						
			}
            if($method3 == 'yes'){			
            
						
				if($method2 != 'yes' && $method1 != 'yes')
			    {
					$formHtml .= '<div class="col-sm-6" id="without_extra_bitcoin">
							<input type="radio" class="required" name="payment_method" value="Bitcoin" id="Bitcoin" checked/><label for="Bitcoin" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/bitcoin-logo.png" /></label>
						</div>';
					
				}else{
					$formHtml .= '<div class="col-sm-4" id="without_extra_bitcoin">
							<input type="radio" class="required" name="payment_method" value="Bitcoin" id="Bitcoin" /><label for="Bitcoin" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/bitcoin-logo.png" /></label>
						</div>';
					
				}		
					
						
            }
            
			$dir_url_image = plugin_dir_url(__FILE__) . 'images/';
			 
			$formHtml .= '</div>
				   </div>
                </section>
                
                <h2 class="headTab">'.$trans19.'</h2>
				
                <section>
				   
                   <div class="contact-box" style="padding-top:10px;"><div class="tranSecDetail"><h2>'.$trans20.' :</h2>
				   
				   <span class="currTran"><select id="currencySecDetail">
				   <option value="EUR">EUR</option>
				   <option value="XAF">XAF<sup>*</sup></option>
				   <option value="mBTC">mBTC<sup>*</sup></option>
				   <option value="USD">USD<sup>*</sup></option>
				   </select></span></div>
						<p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>							
                        <p><span class="detail_one">'.$trans25.'</span><span id="foreign_currency"></span> <span id="amount_to_recharge">  </span> <span class="detail_one">'.$trans26.'</span> <span id="mtn_number_to_recharge"></span> <span class="detail_one">'.$trans27.':</span></p>
                        <br>
						<div class="clearfix"></div>
                        <p><span class="detail_one">'.$trans21.':</span> <span id="trans_amount"></span></p>
						<div class="clearfix"></div>
						<p><span class="detail_one">'.$trans14.':</span><span id="trans_fees"></span></p>
						<div class="clearfix"></div>
						<p class="addFeesMargin"><span class="detail_one additinalDetail">Additional Fees: </span><span id="trans_paypal" class="additinalDetail"></span></p>
						<div class="clearfix additinalDetail"></div>';
						
						
		
			$rewards_activate = get_option('rewards_activate');
			$number_recharge_get_reward = get_option('number_recharge_get_reward');
			$validityYearSet = get_option('validity_default_year');
            $ResCount = get_user_meta($current_user->ID, 'reward_points', true);
            
                            			
			$imgHtml  = $resHtml = $imgsmall =  $feesFree = '';
			
			if($rewards_activate == 'yes')
			{
				if($ResCount == ''){ $ResCount = 0; }
			    
				
				if($ResCount >= $number_recharge_get_reward ){
					
					$reward_year_cycle  =  get_user_meta($current_user->ID, 'reward_year_cycle', true);
                    $validityYear = date('Y-m-d', strtotime("+".$validityYearSet." months", strtotime($reward_year_cycle)));
					//$mydata = $reward_year_cycle.'_'.$validityYear.'_'.date('Y-m-d');
				  if($validityYear > date('Y-m-d')){ 	
					  $feesFree = 0.00;
					  $ResCount = $number_recharge_get_reward;
				    }else{
						
					   $ResCount =  0;
					}  
				}
				
			    for($i=0;$i<$number_recharge_get_reward;$i++){
				 if($ResCount == 0){
					 $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargGray_icon.png" />';
					 $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmall_icon.png" />';
					 
				 }else{	
					  if($i < $ResCount){	
					   $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/recharg_icon.png" />';
					   $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmalGreen_icon.png" />';
					   
					  }else{
					   $imgHtml  .= '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargGray_icon.png" />';
					   $imgsmall = '<img src="http://dsp.lab.kit-services.com/wp-content/plugins/mtn-custom-plugin/img/rechargSmall_icon.png" />';
					  }
				  }
				}
				
				$resHtml .= $ResCount.'/'.$number_recharge_get_reward.'<br><span>'.$imgsmall.'</span>';
				
				$paypal_bussness_email = get_option('paypal_bussness_email');
				
				$formHtml .= '
				<p><span class="detail_one">'.$trans22.' : '.$imgHtml.'</span><span class="fees_ffr">'.$resHtml.'</span></p>
						        <div class="clearfix"></div>';
			}
			         $bitcoin_klukt_url = get_option('bitcoin_klukt_url');	
					 $bitcoinApiKey = get_option('bitcoinApiKey');
					 $bitcoinClientEmail = $current_user->user_email;
					 $bitcoinCurrency = get_option('bitcoinCurrency');
			
                        $formHtml .= '<input type="hidden" id="feesFree" value="'.$feesFree.'" /> 
						<hr/>
						<p><span class="detail_totel">'.$trans23.':</span> <span id="trans_total"></span></p>
					</div>
					<span class="shortNote"><sup>*</sup>'.$trans24.'</span>
                    <input type="hidden" id="trans_amount_New" value="" /> 
					 <input type="hidden" id="trans_fees_New" value="" /> 
					 <input type="hidden" id="trans_paypal_New" value="" /> 
					 <input type="hidden" id="trans_total_New" value="" />
                     <input type="hidden" id="bitcoinUrl" value="'.$bitcoin_klukt_url.'" />
                     <input type="hidden" id="bitcoinApiKey" value="'.$bitcoinApiKey.'" /> 
                     <input type="hidden" id="bitcoinClientEmail" value="'.$bitcoinClientEmail.'" />
                     <input type="hidden" id="bitcoinCurrency" value="'.$bitcoinCurrency.'" />
				</section>
               
            </div>
            </form>
											
			<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" id="pp_Form" method="post">
			  <input type="hidden" name="cmd" value="_xclick">
			  <input type="hidden" name="business" value="'.$paypal_bussness_email.'">
			  <input type="hidden" name="item_name" id="pp_title" value="">
			  <input name="custom" type="hidden" id="custom_data" value="">
			  <input type="hidden" name="amount" id="pp_amount" value="">
			  
			  <input type="hidden" name="return" value="'.$success_url.'">
			  <input type="hidden" name="currency_code" value="EUR">
  
            </form>
											
			</div></div>';
	$btcMsg = 'Please use your Bitcoin  wallet and scan the QR-Code from your smartphone.';		
	if(ICL_LANGUAGE_CODE == 'fr'){
		
		$btcMsg = 'Ouvrez votre application Bitcoin et scannez le QR-CODE a partir de votre t&#233;l&#233;phone';	
		
	}		
			
		$formHtml .= '<style>
	#tipModal .modal-dialog {
    background-color: #fff;
}
	</style>
	
	<div id="tipModal" class="tip_modal modal fade" role="dialog">
		  <div class="modal-dialog">
		
		    <div class="modal-content">
            
			  <div class="modal-body">
			      <h2 style="text-align:center;">'.$btcMsg.'</h2>
				  <div class="countdownAddress"></div>
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			     
				 <div class="bitCoinData"> </div>
				 <div class="bitCoinDataWalletButton"></div>
				 <div class="bitCoinDataAddress"></div>
				 
			     
				  
				
			  </div>
			
			 
			  
			</div>

		  </div>
	</div>
	
	<div class="modal fade" id="getjsonRequest" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                              <div class="modal-dialog" role="document">
							 
                                <div class="modal-content">
								
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    
									
                                  </div>
								  <div class="modal-body">

	
       
            <h4>'.$trans28.'</h4>
			
            <input type="button"  id="yes_done" value="'.$trans29.'" />
            <input type="button"  id="no_done" value="'.$trans30.'" />			

								  </div>
								 
								</div>
							  </div>
    </div>


     <div class="modal fade" id="alertDataGetJson" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                              <div class="modal-dialog" role="document">
							 
                                <div class="modal-content">
								
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    
									
                                  </div>
								  <div class="modal-body">
                                          <h4 class="alertDataGetJson"></h4>
										  
										  <input type="button"  id="ok_done" value="OK" class="close" data-dismiss="modal" aria-label="Close"/>
			
           		                  </div>
								 
								</div>
							  </div>
    </div> 	
    <script>
	jQuery(document).ready(function(){
		jQuery("#ok_done").click(function(){
		 
		 
		 jQuery("#getjsonRequest").modal("hide");
	});
		
	});
	</script>
';
	
    $trans1 = 'Add Contact';
	$trans2 = 'First name';
	$trans3 = 'Last name'; 
	$trans4 = 'Mobile Money Account';
	$trans5 = 'Email Address';
	$trans6 = 'Country';
	$trans7 = 'City';
    $trans8 = 'You recommended MTN Mobile Money to this contact?';
	$trans9 = 'Yes';
	$trans10 = 'NO';
	$trans11 = 'Type your first name';
	$trans12 = 'Type your last name';
	$trans13 = 'Type your phone number';
	$trans14 = 'Type your email address';
	$trans15 = 'SAVE';
	

	if ( ICL_LANGUAGE_CODE == "fr" ) {

	$trans1 = 'Ajoutez un contact';
	$trans2 = 'Pr&#233;nom';
	$trans3 = 'Nom'; 
	$trans4 = 'Compte Mobile Money';
	$trans5 = 'Adresse E-Mail';
	$trans6 = 'Pays';
	$trans7 = 'Ville';	
    $trans8 = 'Avez-vous recommand&#233; MTN Mobile Money &#224; ce contact?';
	$trans9 = 'Oui';
	$trans10 = 'Non';
	$trans11 = 'Entrez pr&#233;nom b&#233;n&#233;ficiaire';
	$trans12 = 'Entrez nom b&#233;n&#233;ficiaire';
	$trans13 = 'Entrez num&#233;ro b&#233;n&#233;ficiaire';
	$trans14 = 'Entrez email b&#233;n&#233;ficiaire';
	$trans15 = 'Enr&#233;gistrer';

	}
		$formHtml .= '
		<div class="modal fade popModal" id="addInAddressBook" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						   <div class="modal-header">
							<span class="acct_detail"></span>
							<h2 style="text-align:center;">'.$trans1.':</h2>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>
                              							
						   </div>
						   <div class="modal-body">
						    <form action="" method="post" id="addresBookFormThird" class="submit-container1">
          <p class="form_element">
            <label for="Firstname">'.$trans2.'<span class="required1" title="required">*</span></label>
            <span class="firstname">
            <input type="text" name="usr_fname" id="addresBookForm_fname" class="text_input1" value="" placeholder="'.$trans11.'">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">'.$trans3.'<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_lname" id="addresBookForm_lname" class="text_input1" value="" placeholder="'.$trans12.'">
            </span> </p>    
          <p class="form_element">
            <label for="Lastname">'.$trans4.'<span class="required1" title="required">*</span></label>
           
            <span class="lastname">
            <input type="text" name="usr_mobile_money_account" value="" id="usr_mobile_money_account" class="text_input1" placeholder="'.$trans13.'" />
            </span> </p>   
          <p class="form_element">
            <label for="Email">'.$trans5.'</label>
            
            <span class="user-email1">
            <input type="text" name="usr_email" id="addresBookForm_email" class="text_input1" value="" placeholder="'.$trans14.'" />
            </span> </p>    
          <p class="form_element">
            <label for="Subject">'.$trans6.'<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
                    <select name="usr_country" id="usr_country_1">
					<option value="Cameroon" selected="selected">Cameroon</option>
					</select>								
												    
            </span> 
		  </p>
		  <p class="form_element">
            <label for="Subject">'.$trans7.'<span class="required1" title="required">*</span></label>
            
            <span class="subject1">
            
			       <select name="usr_city" id="usr_city_1">
					<option value="">Select '.$trans7.'</option>
					</select>
            </span>
		  </p>
          <p class="form_element form_fullwidth">
            <label class="radio-wrapper" for="Subject" style="font-size:16px;">'.$trans8.'<span class="required1" title="required">*</span></label>
            <span class="subject1">
              '.$trans9.' <input type="radio" name="recommended_answer" value="yes" /> '.$trans10.' <input type="radio" name="recommended_answer" value="no" />
            </span>
			
		  </p> 
         <p class="form_element">
            
		  </p>
          <p class="form_element" style="float: right;width: 25%;">
             <input type="hidden" name="contact_id" id="contact_id" value="" />
			<input type="submit" name="add_contact" value="'.$trans15.'" class="submit1" />
		  </p>			  
         
</form>
						   
						   
						   </div>
						</div>
                      </div>
</div>';
	
    $trans1 = 'Select contact to transfer to'; 
	$trans2 = 'Action'; 
	$trans3 = 'Select'; 
	$trans4 = 'Name'; 
	$trans5 = 'MTN Number'; 
	$trans6 = 'EMAIL'; 
	$trans7 = 'COUTRY'; 
	$trans8 = 'CITY'; 
			
if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'Selectionner votre b&#233;n&#233;ficiaire'; 
	$trans2 = 'Selectionnez'; 
	$trans3 = 'Choisir'; 
	$trans4 = 'Nom'; 
	$trans5 = 'N&#176; MTN'; 
	$trans6 = 'E-MAIL'; 
	$trans7 = 'PAYS'; 
	$trans8 = 'VILLE';
}	
	
		
		$formHtml .= '<div class="modal fade popModal" id="fromAddressBookPopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <div class="modal-dialog" role="document">
						<div class="modal-content">
						  <div class="modal-header">
							<span class="acct_detail"></span>
							<h2 style="text-align:center;">'.$trans1.'</h2>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							
						  </div>
						  <div class="modal-body">
						  
<div class="table-responsive">
          <table class="table table-bordered table_name">
            <thead>
              <tr>
			    <th>'.$trans2.'</th>
                <th>'.$trans4.'</th>
                <th>'.$trans5.'</th>
                <th>'.$trans6.'</th>
				<th>'.$trans7.'</th>
                <th>'.$trans8.'</th>
              </tr>
            </thead><tbody>';
      foreach($addresses as $row){
		$edit_url = $add_url.'?contact_id='.$row->id;
		$formHtml .= '
              <tr id="conId_'.$row->id.'">
			    <td scope="row" class="a_select"><button type="button" class="button btn select_rec_third">'.$trans3.'</button></td>
                <td scope="row" class="a_name">'.$row->usr_name.'</td>
                <td class="a_mm">'.$row->usr_mobile_money_account.'</td>
                <td class="a_email">'.$row->usr_email.'</td>
				<td class="a_cnty">'.$row->usr_country.'</td>
                <td class="a_city">'.$row->usr_city.'</td>
              </tr>';
	    }	

	$formHtml .= '</tbody></table>'.$pagination.'</div></div>
						  <div class="popMod">
							<div class="form_element">
								
							</div>
						  </div>
						  </div>      
						</div>
					  </div>
			        </div>';	
			
													
												
												
				
			return $formHtml;
  	
}

add_shortcode('thirdparty_recharge', 'mtn_thirdparty_recharge');





function add_third_user_address_book(){
	global $wpdb;
	$user_id  = get_current_user_id();
	$full_name = $_POST['full_name'];
	$mtn_mobile = $_POST['mtn_mobile'];
	$user_info = get_userdata($user_id);
    $to = $user_info->user_email; 
	$subject = '';
	$message = '';
	
	$wpdb->query("INSERT INTO `wp_user_address_book` (id, user_id, usr_name, usr_mobile_money_account) VALUES('', '".$user_id."', '".$full_name."', '".$mtn_mobile."'");
	
	
	
	
	if ( ICL_LANGUAGE_CODE == "fr" ) {
		$subject = $full_name.' - Information manquante';
		$message .= "Merci d'utilsier notre service Mobile Money."."\r\n";
		$message .= 'Votre contact '.$full_name.' a �t� sauvegard� avec succ�s dans votre Carnet de contact.'."<br>";
		$message .= '<p>Merci de termin� en compl�tant les informations manquantes:</p>'."<br>";
		$message .= '<ul><li>User Email</li>';
		$message .= '<li>User Country</li>';
		$message .= '<li>User City</li></ul><br>';
		$message .= "Editez tout simplement ce contact � partir de votre Carnet d'Adresse ( (http://dsp.lab.kit-services.com/address-book/)"."<br>";
        $message .= "Merci de nous aider � davantage am�liorer nos services."."<br>";
        $message .= "L'Equipe diaspoCC"."<br>";
		
	}else
    {
		
		$subject = $full_name.' - Missing additional info';
		$message .= "Thank you for using our Mobile Money service."."<br>";
		$message .= 'We successfully added '.$full_name.' to your adress book.'."<br>";
		$message .= '<p>Following information are missing still:</p>'."\r\n";
		$message .= '<ul><li>User Email</li>';
		$message .= '<li>User Country</li>';
		$message .= '<li>User City</li></ul><br>';
		$message .= 'Please Edit this contact from your Address Book (http://dsp.lab.kit-services.com/address-book/) to complete those missing information.'."<br>";
        $message .= 'Thanks for helping us enhacing our services.'."<br>";
        $message .= 'diaspoCC Team'."<br>";



	}		
	
	// To send HTML mail, the Content-type header must be set
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	 
	// Create email headers
	$headers .= 'From: diaspoCC <noreply@mail.diaspo-cc.com>'."\r\n";
	 
	// Sending email
	mail($to, $subject, $message, $headers);
	
	
	echo "success";
	die(0);
}
add_action( 'wp_ajax_add_third_user_address_book', 'add_third_user_address_book' );
add_action( 'wp_ajax_nopriv_add_third_user_address_book', 'add_third_user_address_book' );


function saveInAddresBook(){
    global $wpdb;
   
    $current_user = wp_get_current_user();

	
	$fullname = $_POST['usr_fname'].' '.$_POST['usr_lname'];
	
	
	$usr_email = $_POST['usr_email'];
	
	$usr_mobile_money_account = $_POST['u_mtn_number'];
	
	$usr_coun = $_POST['usr_country'];
	
	$usr_city = $_POST['usr_city'];
	
	$recommended_answer = $_POST['recommended_answer'];
	
	$wpdb->query("INSERT INTO `wp_user_address_book` (id, user_id, usr_name, usr_email, usr_mobile_money_account, usr_country, usr_city, recommended_answer) 
				VALUES('', '".$current_user->ID."', '".$fullname."', '".$usr_email."', '".$usr_mobile_money_account."', '".$usr_coun."', '".$usr_city."', '".$recommended_answer."')");	
				
	$msg_new = 'Contact added sucessfully!.';	


    echo $msg_new;
	die(0);
}

function makeBitCoinPayment(){
    global $wpdb;
   
   
	$address = $_POST['addressVal'];
	$bitcoinApiKey = get_option('bitcoinApiKey');
	 
	
	$url = 'https://api.klukt.com/verify?apikey='.$bitcoinApiKey.'&address='.$address;
		
	$data = file_get_contents($url);
	
	$res = json_decode($data);
	
	$payment_id = $res->payment->metadata->id;
	
	
	$expected_euro_amount = $res->payment->expected_amount_curr;
	
	
	$paidAmount = $res->payment->metadata->amount;
	
	
	
	if(!empty($payment_id)){
		
		  if($paidAmount < $expected_euro_amount)
		  { 
		      
			 
			 $query = "UPDATE `wp_mtn_order_history` SET  amount_paid_eur = '".$paidAmount."', payment_status = 'Completed',  payment_bitcoin_address = '".$address."' WHERE payment_transaction_id = '".$payment_id."'";
		  
		  }
		 else {
			  
			$query = "UPDATE `wp_mtn_order_history` SET payment_status = 'Completed', payment_bitcoin_address = '".$address."' WHERE payment_transaction_id = '".$payment_id."'";
		      
		  }
		   
          $wpdb->query($query);
		  
          echo $address.'##'.$bitcoinApiKey;
	      die(0);		   
		   
    }		


    
}
add_action( 'wp_ajax_makeBitCoinPayment', 'makeBitCoinPayment' );
add_action( 'wp_ajax_nopriv_makeBitCoinPayment', 'makeBitCoinPayment' );

//convert_exponantial_to_decimal
function convert_exponantial_to_decimal($x){
	$strfloat = strtolower((string)($x));
    $nodec = str_replace(".", "", $strfloat);

	list($num, $exp) = explode("e", $nodec);
	
	
    $exp = intval($exp);
	
	if($exp < 0) {
		
		$total = -($exp + 1);
		$myval = '';
		for($i=0;$i<$total;$i++)
		{
			
			$myval .= "0";
		}
		return "0.".$myval. $num;
		
		}
    if($exp == 0) { 
	
	return (string)$x;
	
	}
    if($exp > 0) {
		return $num . ("0" * $exp);
		
		
		}
	
}



// create trade bitcoin for buy shortcode
function mtn_trade_bitcoin_form(){

global $wpdb;
$formHtml = '';	
$rate = get_conversion_bitcoin_with_amount('BTC', 'XAF', 1);
$fees = get_option('trade_fees_xaf');
$trade_btcamount_xaf_limit = get_option('trade_btcamount_xaf_limit')+$fees;
	
$current_user = wp_get_current_user();

$country = get_the_author_meta( 'diaspo_user_country_of_residence', $current_user->ID );
$first_name = get_user_meta($current_user->ID, 'first_name', true);
$last_name = get_user_meta($current_user->ID, 'last_name', true);
$phone = str_replace(get_user_meta( $current_user->ID , 'country_flag_code', true ), "", get_the_author_meta( 'msisdn', $current_user->ID ));
$recipient_address = get_user_meta( $current_user->ID , 'bitcoin_user_address', true );

$country_code = '+'.get_user_meta( $current_user->ID , 'country_flag_code', true );


if(strlen($phone) != 9)
{
	
	$phone = substr($phone,-9); 
}

$fullname = $first_name.' '.$last_name;
$usr_mobile_money_account = $phone;

$success_url = '';
if(ICL_LANGUAGE_CODE == "fr")
{$success_url = 'http://dsp.lab.kit-services.com/success-url-third-party/?lang=fr';}else{$success_url = 'http://dsp.lab.kit-services.com/success-url-third-party/';}
	
$dir_url = plugin_dir_url(__FILE__) . 'img/';	
$ajaxurl = admin_url( 'admin-ajax.php' );
	
$dir_url_image = plugin_dir_url(__FILE__) . 'images/';

$wallets = $wpdb->get_results("SELECT * FROM `wp_user_wallets` WHERE user_id = '".$current_user->ID."'");
$walletData = '';
foreach($wallets as $wallet){

    $walletData .= '<option>'.$wallet->wallet_identifier.'</option>';
                                                            
}	


    $trans1 = 'Buy Bitcoin from MoMo';
	$trans2 = 'Sell Bitcoin to MoMo';
	$trans3 = 'Transaction Details';
	$trans4 = 'Recipient Name';
	$trans5 = 'Country Code'; 
	$trans6 = 'MoMo number to debit';
	$trans7 = 'Recipient bitcoin address to credit';
	$trans8 = 'Currency Type'; 
	$trans9 = 'Amount';
	$trans10 = 'Our Fees';
	$trans11 = 'Bitcoin Network Fees';
	$trans12 = 'Bitcoin Amount to Receive';
	$trans13 = 'Total to Pay';
	$trans14 = 'Waiting for payment';
	$trans15 = 'Exchange rate';
	
	$trans16 = 'Sender Name';
	$trans17 = 'MoMo number to credit';
	$trans18 = 'Bitcoin Amount to Sell';
	$trans19 = 'Total to Receive';
	
	
	
	
	
if(ICL_LANGUAGE_CODE == "fr")
{
	$trans1 = 'Achat bitcoin avec MoMo'; 
	$trans2 = 'Convertir bitcoin vers MoMo'; 
	$trans3 = 'R&#233;sum&#233; transaction';  
	$trans4 = 'Nom b&#233;n&#233;ficiaire'; 
	$trans5 = 'Code Pays';
	$trans6 = 'Compte MoMo &#224; d&#233;biter';  
	$trans7 = 'Adresse bitcoin &#224; cr&#233;diter'; 
	$trans8 = 'Monnaie locale';
	$trans9 = 'Montant'; 
	$trans10 = 'Nos Frais';
	$trans11 = 'Frais du r&#233;seau Bitcoin'; 
	$trans12 = 'Montant Bitcoin &#224; cr&#233;diter';  
	$trans13 = 'Total &#224; payer';  
	$trans14 = 'En attente du paiement';
	$trans15 = 'Taux de change'; 
	
	$trans16 = 'Sender Name';
	$trans17 = 'MoMo number to credit';
	$trans18 = 'Montant Bitcoin &#224; payer';
	$trans19 = 'Total &#224; cr&#233;diter';
	
}	

$formHtml .= '<div class="tabTrade"><span  class="tabSec tabActive" id="tradebitcoin">Buy bitcoin from MoMo</span><span class="tabSec tabCom" id="tradebitcoinSell">Sell Bitcoin to MoMo</span></div><div role="form" class="" lang="en-US" dir="ltr">		                  
											
											
									<form action="#" method="post" id="singupForm_tradebitcoin" class="singupForm_tradebitcoin">
												 <div id="wizardNextTradebitcoin">
												
												<section>
                                                   <div class="contact-box">
												    <h2 class="headTab">'.$trans3.'</h2>
													<p class="form_element cod_ic_tw" style="width:100%;">
													<label for="Subject"><img src="http://dsp.lab.kit-services.com/wp-content/themes/diaspo/img/user_icon.png">&nbsp;&nbsp;'.$trans4.' <abbr class="required" title="required">*</abbr></label>
													<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="text" name="recipient_name" value="'.$fullname.'" id="recipient_name" Placeholder="'.$trans4.'" />
															</span>	
														</span>
													</p>
													
													<input type="hidden" id="countryCode" value="'.$country_code.'" />
													<div class="form_element codeAcount" style="width:20%;">
													<label for="Subject">'.$trans5.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<span class="data"><input type="text" id="country_code_mobile_money" value="+237" name="country_code_mobile_money" />
															</span>
														</span>
													</div>
													
													<p class="form_element mobileAcount" style="width: 80%;">
														<label for="Subject">'.$trans6.'<abbr class="required" title="required">*</abbr></label>
														<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="tel" name="mobile_money_account" value="'.$usr_mobile_money_account.'"  id="mobile_money_account" Placeholder="'.$trans9.'" />
															</span>	
														</span>
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">Wallet Friednly Name<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap wallet_name">
															<select name="wallet_name" id="wallet_name">
																<option value="">Wallet Name</option>
																'.$walletData.'
														    </select>
														</span>
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">Passpharse<abbr class="required" title="required">*</abbr></label><br>
														<input type="password" class="required Passpharse" id="passpharse" name="passpharse"  placeholder="" />
													
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans8.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<select name="currency_code" id="currency_code">
																<option value="XAF">XAF</option>
															</select>
														</span>
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans9.'<abbr class="required" title="required">*</abbr></label><br>
														<input type="text" class="required payment xafamount" value=""  id="xafamount" name="xafamount" value="" placeholder="'.$trans9.'" />
													
													</p>
													
												
													
													
												<p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>	
													

												<div class="col-sm-12 mt-20">
							                		<div class="form-save">
							                			<div class="amount-div">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans10.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>XAF <span class="ourFees">0.00</span></h3>
									                			</div>
								                			</div>
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans11.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>XAF <span class="netFees">0.00</span></h3>
									                			</div>
								                			</div>
															<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans12.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>BTC <span class="ttlBTC">0.00</span></h3>
									                			</div>
								                			</div>
								                		</div>
                                                        <br/>
								                		<div class="total-pay">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans13.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>XAF <span class="ttlXAF">0.00</span></h3>
									                			</div>
								                			</div>
								                			
								                		</div>
							                		</div>
							                	</div>		
                                                <br/>
							                	<div class="col-sm-6">
							                		<h4 style="font-size: 15px;">'.$trans14.' <span class="countdownTradeAddress"> 00:00</span></h4>
							                	</div>
												<div class="col-sm-6">
							                		<h4 style="font-size: 16px;">'.$trans15.' BTC 1 = XAF <span class="xafRate">'.$rate.'</span></h4>
							                	</div>
												
                                                <input type="hidden" id="ajaxUrl" value="'.$ajaxurl.'" />
												<input type="hidden" id="xaf_limit" value="'.$trade_btcamount_xaf_limit.'" />
							                	
												<p class=" submit-container">
                                                      <input type="submit" value="BUY" class="wpcf7-form-control wpcf7-submit submit">
													  <input type="hidden" class="required" id="recipient_address" name="recipient_address" value="" />
												
												
                                                </p>
												
                                            </section>

                                         </div>
                                    </form>
									
									<form action="#" method="post" id="singupForm_tradebitcoin_sell" class="singupForm_tradebitcoin_sell" style="display:none;">
											<div id="wizardNextTradebitcoin_sell">
												
												<section>
                                                   <div class="contact-box">
												    <h2 class="headTab">'.$trans3.'</h2>
													<p class="form_element cod_ic_tw" style="width:100%;">
													<label for="Subject"><img src="http://dsp.lab.kit-services.com/wp-content/themes/diaspo/img/user_icon.png">&nbsp;&nbsp;'.$trans16.' <abbr class="required" title="required">*</abbr></label>
													<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="text" name="sender_name" value="'.$fullname.'" id="sender_name_sell" Placeholder="'.$trans4.'" />
															</span>	
														</span>
													</p>
													
													<input type="hidden" id="countryCode_sell" value="'.$country_code.'" />
													<div class="form_element codeAcount" style="width:20%;">
													<label for="Subject">'.$trans5.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<span class="data"><input type="text" id="country_code_mobile_money_sell" value="+237" name="country_code_mobile_money" />
															</span>
														</span>
													</div>
													
													<p class="form_element mobileAcount" style="width: 80%;">
														<label for="Subject">'.$trans17.'<abbr class="required" title="required">*</abbr></label>
														<span class="wpcf7-form-control-wrap country">
															<span class="data">
																<input type="tel" name="mobile_money_account" value="'.$usr_mobile_money_account.'"  id="mobile_money_account_sell" Placeholder="'.$trans9.'" />
															</span>	
														</span>
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans8.'<abbr class="required" title="required">*</abbr></label><br>
														<span class="wpcf7-form-control-wrap country">
															<select name="currency_code" id="currency_code_sell">
															    <option value="BTC">BTC</option>
																<option value="XAF">XAF</option>
															</select>
														</span>
													</p>
													
													<p class="form_element cod_ic_thr">
														<label for="Subject">'.$trans9.'<abbr class="required" title="required">*</abbr></label><br>
														<input type="text" class="required payment xafamount" value=""  id="xafamount_sell" name="xafamount_sell" value="" placeholder="'.$trans9.'" />
													
													</p>
													
													
													
												<p class="LoadingText" style="display:none;"><img src="'.$dir_url_image.'DiaspoCC-gif-64x64.gif" /></p>	
													

												<div class="col-sm-12 mt-20">
							                		<div class="form-save">
							                			<div class="amount-div">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans18.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>BTC <span class="ttlBTCSell">0.00</span></h3>
									                			</div>
								                			</div>
															<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans10.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3> -  XAF <span class="ourFeesSell">0.00</span></h3>
									                			</div>
								                			</div>
								                		</div>
                                                        <br/>
								                		<div class="total-pay">
								                			<div class="row">
									                			<div class="col-sm-6 col-xs-6">
									                				<h3>'.$trans19.'</h3>
									                			</div>
									                			<div class="col-sm-6 col-xs-6 text-right">
									                				<h3>XAF <span class="ttlXAFSell">0.00</span></h3>
									                			</div>
								                			</div>
								                			
								                		</div>
							                		</div>
							                	</div>		
                                                <br/>
							                	<div class="col-sm-6">
							                		
							                	</div>
												<div class="col-sm-6">
							                		<h4 style="font-size: 16px;">'.$trans15.' BTC 1 = XAF <span class="xafRateSell">'.$rate.'</span></h4>
							                	</div>
												
                                                <input type="hidden" id="ajaxUrl_sell" value="'.$ajaxurl.'" />
												<input type="hidden" id="xaf_limit_sell" value="'.$trade_btcamount_xaf_limit.'" />
							                	
												<p class=" submit-container">
                                                      <input type="submit" value="SELL" class="wpcf7-form-control wpcf7-submit submit">
                                                </p>
												
                                            </section>

                                         </div>
                                    </form>
			
			
			
			
			
			
			</div>';
    $btcMsg = 'Please use your Bitcoin  wallet and scan the QR-Code from your smartphone.';		
	if(ICL_LANGUAGE_CODE == 'fr'){
		
		$btcMsg = 'Ouvrez votre application Bitcoin et scannez le QR-CODE a partir de votre t&#233;l&#233;phone';	
		
	}
            $formHtml .= '<style>
	#tipModal .modal-dialog {
    background-color: #fff;
}
	</style>
	
	<div id="tipModal" class="tip_modal modal fade" role="dialog">
		  <div class="modal-dialog">
		
		    <div class="modal-content">
            
			  <div class="modal-body">
			      <h2 style="text-align:center;">'.$btcMsg.'</h2>
				  <div class="countdownAddress"></div>
				  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			     
				 <div class="bitCoinData"> </div>
				 <div class="bitCoinDataWalletButton"></div>
				 <div class="bitCoinDataAddress"></div>
				 
			     
				  
				
			  </div>
			
			 
			  
			</div>

		  </div>
	</div>';
			
													
												
												
				
			return $formHtml;
  	
}

add_shortcode('mtn_trade_bitcoin', 'mtn_trade_bitcoin_form');


// ajax hooks xaf get_amountData
function make_payment_trade_buy(){
	
	global $wpdb;
	
	$recipient_name = $_POST['recipient_name'];
	$payamount = $_POST['payamount'];
	$ourfees = $_POST['ourfees'];
	$netfees = $_POST['netfees'];
	$BTCamountRec = $_POST['BTCamountRec'];
	$BTCaddress = $_POST['BTCaddress'];
	$momoNum = $_POST['momoNum'];
	$convRate = $_POST['convRate'];
	$xafamount = $_POST['xafamount'];
	$user_id  = get_current_user_id();
	$country_code = str_replace('+', '', get_user_meta( $user_id , 'country_flag_code', true ));
	
	$sql = "INSERT INTO `wp_trade_order_history` (order_id, user_id, mtn_number, type, recipient_name, our_fees_in_xaf, network_fees_in_xaf, amount_in_xaf, total_amount_in_xaf, btc_amount_to_rec, conversion_rate, payment_status, btc_status, recipient_address) 
				VALUES('', '".$user_id."', '".$momoNum."', 'Buy', '".$recipient_name."', '".$ourfees."', '".$netfees."', '".$xafamount."', '".$payamount."', '".$BTCamountRec."', '".$convRate."', 'pending', 'pending', '".$BTCaddress."')";
	
	$wpdb->query($sql);	
	
	$order_id  = $wpdb->insert_id;
	
	$data = array();
	
	$data['transfer_amount'] = $payamount;
	$data['fullname'] = $recipient_name;
	if(empty($country_code)){
		$data['senderMsisdn'] = '237'.$momoNum;
	}else{
		$data['senderMsisdn'] = $country_code.$momoNum;
	}
	
	
	
	$response_array = make_transfer_btc($data);
	
	
	$StatusCode = $response_array['StatusCode'];
	$StatusDesc = $response_array['StatusDesc'];
	$MOMTransactionID = $response_array['MOMTransactionID'];
	$ProcessingNumber = $response_array['ProcessingNumber'];
	$OpCoID = $response_array['OpCoID'];
	
	$json = json_encode($response_array);
	
	
	if($StatusCode == 1000)
	{
		$sql1 = "UPDATE `wp_trade_order_history` SET OpCoID = '".$OpCoID."', ProcessingNumber = '".$ProcessingNumber."', MOMTransactionID = '".$MOMTransactionID."' WHERE order_id = '".$order_id."'";
	    $wpdb->query($sql1);
		
		
	}else{
		
		$sql1 = "UPDATE `wp_trade_order_history` SET payment_status = 'Rejected' WHERE order_id = '".$order_id."'";
	    $wpdb->query($sql1);
	}	
	
	echo $StatusCode.'##'.$order_id.'##'.$json;
		
	
	
	
    wp_die();
	
	
}
add_action( 'wp_ajax_makePaymentForTradeBuy', 'make_payment_trade_buy' );
add_action( 'wp_ajax_nopriv_makePaymentForTradeBuy', 'make_payment_trade_buy' );


// ajax hooks xaf Trade Sell
function make_payment_trade_sell(){
	
	global $wpdb;
	
	$sender_name = $_POST['sender_name'];
	$payamount = $_POST['payamount'];
	$BTCamountRec = $_POST['BTCamountRec'];
	$momoNum = $_POST['momoNum'];
	$ourFeesSell = $_POST['ourFeesSell'];
	$convRate = $_POST['convRate'];
	$xafamount = $_POST['xafamount'];
	$user_id  = get_current_user_id();
	$country_code = str_replace('+', '', get_user_meta( $user_id , 'country_flag_code', true ));
	
	
	//calculating Network Fees
	$myAPIKEY       = get_option('blocktrail_api_key');
	$myAPISECRET    = get_option('blocktrailsecret');
	$testnet        = true; //false for bitcoin mainnet or true for testnet
	$walletIdent    = get_option('testnet_wallet_identifier');
	$walletPassword = get_option('testnet_wallet_password');
	if(get_option('blocktrail_mode') == 'on'){
		$testnet    = false;
		$walletIdent    = get_option('live_wallet_identifier');
		$walletPassword = get_option('live_wallet_password');
	}

    $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
	$wallet = $client->initWallet([
			"identifier" => $walletIdent,
			"passphrase" => $walletPassword
	]);
	
	$BTCaddress = $wallet->getNewAddress();
	
	
	$sql = "INSERT INTO `wp_trade_order_history` (order_id, user_id, mtn_number, type, recipient_name, our_fees_in_xaf, amount_in_xaf, total_amount_in_xaf, btc_amount_to_rec, conversion_rate, payment_status, btc_status, recipient_address) 
				VALUES('', '".$user_id."', '".$momoNum."', 'Sell', '".$sender_name."', '".$ourFeesSell."', '".$xafamount."', '".$payamount."', '".$BTCamountRec."', '".$convRate."', 'pending', 'pending', '".$BTCaddress."')";
	
	$wpdb->query($sql);	
	
	$order_id  = $wpdb->insert_id;
	
    echo $BTCaddress.'##'.$order_id;

	wp_die();
	
	
}
add_action( 'wp_ajax_makePaymentForTradeSell', 'make_payment_trade_sell' );
add_action( 'wp_ajax_nopriv_makePaymentForTradeSell', 'make_payment_trade_sell' );

//Cretae nonce signature
function get_signature($nonce){
	
	  $customer_id = get_option('bitstamp_client_id');
	  $key = get_option('bitstamp_key');
	  $secret = get_option('bitstamp_secret');
	  
	  $message = $nonce.$customer_id.$key;
	  
	  return strtoupper(hash_hmac('sha256', $message, $secret));
}

function get_bitstamp_address($key){
	$url = 'https://www.bitstamp.net/api/bitcoin_deposit_address/';


date_default_timezone_set('Africa/Douala');


 
// generate a nonce as microtime, with as-string handling to avoid problems with 32bits systems
$mt = explode(' ', microtime());
$req['nonce'] = $mt[1] . substr($mt[0], 2, 6);
$req['key'] = $key;
$req['signature'] = get_signature($req['nonce']);

    $ch = curl_init();
	curl_setopt($ch, CURLOPT_VERBOSE, true);
	
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	//curl_setopt($ch, CURLOPT_TIMEOUT, 120);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
           

	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);

    return json_decode($response);
	
}

function make_transfer_btc($data)
{
	global $wpdb;
	$user_id = get_current_user_id();
	date_default_timezone_set('Africa/Douala');
	
	$time = date('Y-m-d h:i:s');
	
	$nonce = rand();
	
	$currency_type_amount = $data['transfer_amount'];
	$fullname = $data['fullname'];
	$senderMsisdn = $data['senderMsisdn'];
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');
	$service_id = get_option('service_id');
	
	//$country_name = $data['country_name'];
	
	
	
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";

	
		
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
	    $spID = $sp_id;
		$password = $sp_password;			
	    $PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 

$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
   <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
         <spId>'.$spID.'</spId>
         <spPassword>'.$PasswordDigest.'</spPassword>
         
         <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
   </soap:Header>
   <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
         <serviceId>DiaspoCC</serviceId>
         <parameter>
            <name>DueAmount</name>
            <value>'.$currency_type_amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$senderMsisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>CurrCode</name>
            <value>XAF</value>
         </parameter>
         <parameter>
            <name>SenderID</name>
            <value>DiaspoCC</value>
         </parameter>
      </ns3:processRequest>
   </soap:Body>
</soap:Envelope>';



$to = "test5@kit-services.com,votiveyogesh@gmail.com";
        		$subject = "TESTBED URL - Send Request";
        		$txt = $xml_post_string;
        		$headers = "From: info@diaspo-cc.com" . "\r\n";
        		mail($to,$subject,$txt,$headers);


       
        $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	   
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			
			
            $xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));

if(count($arr) != count($arr1))
{	
 $arr1[] = '';
}


$arr2 = array_combine($arr, $arr1);

return $arr2;
	
}

function make_recharge_refund($amount, $order_id){
	
	//return $amount.'##'.$MTN;
	
	global $wpdb;
	
	$user_id = get_current_user_id();
	
	$Narration = 'Refund Amount';
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_mtn_order_history` WHERE order_id = '".$order_id."'");
	
	
	
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');
	
	
	$msisdn = '237'.$rowdata->mtn_mobile_number;
	
	
	
	//$lang = get_user_meta( $user_id, 'diaspo_user_language', true );
	
	
	 
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		$password = $sp_password;	
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>DiaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>'.$Narration.'</value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';




       
        $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;

}




/*---------------------------Survey Form Functions----------------------*/
function save_survey_data(){
  global $wpdb;
  
  $survey_form_id = $_POST['survey_form_id']; 
  $category_id = $_POST['category_id']; 
  $family_members = $_POST['family_members']; 
  $internet_phone = $_POST['internet_phone'];
  $rent = $_POST['rent']; 
  $food = $_POST['food']; 
  $insurance_tution_fees = $_POST['insurance_tution_fees']; 
  $mobility = $_POST['mobility']; 
  $utility_costs = $_POST['utility_costs']; 
  $cleaning_lady_babysister = $_POST['cleaning_lady_babysister']; 
  $security_guard = $_POST['security_guard']; 
  $driver = $_POST['driver'];
  $vacation = $_POST['vacation']; 
  $social_help = $_POST['social_help']; 
  $savings = $_POST['savings']; 
  $survey_country_of_residence = $_POST['survey_country_of_residence']; 
  $survey_date = date('Y-m-d');  
  
  $sql = "INSERT INTO `wp_survey_forms_data` (survey_id, survey_form_id, category_id, survey_date, family_members, internet_phone, cleaning_lady_babysister, rent, security_guard, driver, food, vacation, insurance_tution_fees, social_help, mobility, savings, utility_costs, survey_country_of_residence) 
				VALUES('', '".$survey_form_id."', '".$category_id."', '".$survey_date."', '".$family_members."', '".$internet_phone."', '".$cleaning_lady_babysister."', '".$rent."', '".$security_guard."', '".$driver."', '".$food."', '".$vacation."', '".$insurance_tution_fees."', '".$social_help."', '".$mobility."', '".$savings."', '".$utility_costs."', '".$survey_country_of_residence."')";
  
  $wpdb->query($sql);
  
  echo $survey_id = $wpdb->insert_id;	
 
  wp_die();
	
	
}
add_action( 'wp_ajax_SaveSurveyData', 'save_survey_data' );
add_action( 'wp_ajax_nopriv_SaveSurveyData', 'save_survey_data' );

/*---------------------------Survey Form Functions----------------------*/


function make_deposit_after_request_527_trade($order_id, $amount){
	
	global $wpdb;
	
	$user_id = get_current_user_id();
	
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_trade_order_history` WHERE order_id = '".$order_id."'");
	
	$sp_id = get_option('sp_id');	
    $sp_password = get_option('sp_password');
	$testbed_ip = get_option('testbed_ip');	
	$service_id = get_option('service_id');
	
	
	$msisdn = '237'.$rowdata->mtn_number;
	
	
	$url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17"; 
	
     

		$nonce = rand();
		$rand = rand(3, 4);
		date_default_timezone_set('Africa/Douala');
		$createdDate = date('Ymd');
		$createdTime = date('His');
		$created = $createdDate.$createdTime;
		$spID = $sp_id;
		
		$password = $sp_password;
		
	    
		
		$PasswordDigest = md5($spID.$password.$createdDate);
		

		
$headers = array(
"Content-type: text/xml;charset=\"utf-8\"",
"Content-Length:569",
"Host:127.0.0.1",
"Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
); 



$xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
         <ns1:spId>'.$spID.'</ns1:spId>
         <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
         <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
         <serviceId>DiaspoCC</serviceId>
         <parameter>
            <name>Amount</name>
            <value>'.$amount.'</value>
         </parameter>
         <parameter>
            <name>MSISDNNum</name>
            <value>'.$msisdn.'</value>
         </parameter>
         <parameter>
            <name>ProcessingNumber</name>
            <value>'.$nonce.'</value>
         </parameter>
         <parameter>
            <name>serviceId</name>
            <value>'.$service_id.'</value>
         </parameter>
         <parameter>
            <name>appVersion</name>
            <value>1.7</value>
         </parameter>
         <parameter>
            <name>Narration</name>
            <value>TRANSFER PROCESSED on www.diaspoCC.com THE DIASPORA COMMUNITY CENTER. </value>
         </parameter>
         <parameter>
            <name>PrefLang</name>
            <value>en</value>
         </parameter>
         <parameter>
            <name>OpCoID</name>
            <value>23701</value>
         </parameter>
      </ns1:processRequest>
   </soapenv:Body>
</soapenv:Envelope>
';




       
       $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
        $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
	    $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
        $certPass = 'ZHDqdw7y243zpDD';

		
			   
		//print_r($headers);
		
        // PHP cURL  for https connection with auth
            $ch = curl_init();
	//Added on 07.04.17 for logging

            curl_setopt($ch, CURLOPT_VERBOSE, true);
	    $curl_log = fopen("curl.txt", 'w+');
   	    curl_setopt($ch, CURLOPT_STDERR, $curl_log);
	//Logging Partially End
 
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
          curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
          curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
          curl_setopt($ch, CURLOPT_CAINFO, $caFile);
	  curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
          curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);			
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	//Added on 10.04.17 for handling error "100-continue"
           curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
	   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	  
        
        // converting
            $response = curl_exec($ch);
            curl_close($ch);
			

$xml = simplexml_load_string($response);



$xml_parser = xml_parser_create();
xml_parse_into_struct($xml_parser, $response, $vals, $index);
xml_parser_free($xml_parser);



$arr_name =  array();
$arr_val =  array();
$i=0;
$j = 0;
foreach ($vals as $key => $value) {
  foreach ($value as $key_1 => $value_val) {

if($key_1 == "tag" || $key_1 == "value")
{


if($value['tag'] == 'NAME')
{
$arr_name[$i++] = $value['value'];
}

if($value['tag'] == 'VALUE')
{
$arr_val[$j++] = $value['value'];
}

}
}
}

$arr = array_values(array_unique($arr_name));
$arr1 = array_values(array_unique($arr_val));



$arr2 = array_combine($arr, $arr1);

return $arr2;
	
}

//license string
function generate_license($suffix = null) {
    // Default tokens contain no "ambiguous" characters: 1,i,0,o
    if(isset($suffix)){
        // Fewer segments if appending suffix
        $num_segments = 3;
        $segment_chars = 6;
    }else{
        $num_segments = 4;
        $segment_chars = 4;
    }
    $tokens = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $license_string = '';
    // Build Default License String
    for ($i = 0; $i < $num_segments; $i++) {
        $segment = '';
        for ($j = 0; $j < $segment_chars; $j++) {
            $segment .= $tokens[rand(0, strlen($tokens)-1)];
        }
        $license_string .= $segment;
        if ($i < ($num_segments - 1)) {
            $license_string .= '-';
        }
    }
    // If provided, convert Suffix
    if(isset($suffix)){
        if(is_numeric($suffix)) {   // Userid provided
            $license_string .= '-'.strtoupper(base_convert($suffix,10,36));
        }else{
            $long = sprintf("%u\n", ip2long($suffix),true);
            if($suffix === long2ip($long) ) {
                $license_string .= '-'.strtoupper(base_convert($long,10,36));
            }else{
                $license_string .= '-'.strtoupper(str_ireplace(' ','-',$suffix));
            }
        }
    }
    return $license_string;
}

// Adding custom js in admin area
function add_script_to_menu_page_custom_plugin()
{
    // $pagenow, is a global variable referring to the filename of the current page, 
    // such as �admin.php�, �post-new.php�
    global $pagenow;
 
    if ($pagenow != 'post-new.php') {
        return;
    }
    
	if($_GET['post_type'] == 'hotspot'){
    // loading js
     wp_register_script('custom-admin', plugin_dir_url(__FILE__).'/js/custom-admin.js');
     wp_enqueue_script('custom-admin');
	}
}
 
add_action( 'admin_enqueue_scripts', 'add_script_to_menu_page_custom_plugin' );


//Event Tickets Shortcode
function mtn_show_events(){
	
if(is_user_logged_in()){	
	
	global $wpdb;
	
if($_POST['submitBTN']){
	$useremail = $_POST['emailAddress'];
	$password = $_POST['mtnPassowrd'];
	$username = get_user_by( 'email', $useremail);
	
	if(!empty($username->user_login)){
		$creds = array(
			'user_login'    => $username->user_login,
			'user_password' => $password,
			'remember'      => true
		);
		
		$user = wp_signon( $creds, false );
		$error = '';
		if ( is_wp_error( $user ) ) {
			$error =  $user->get_error_message();
			if ( ICL_LANGUAGE_CODE == "fr" ) {
		    $error = 'Mot de passe ou E-Mail invalide';		
			 }else{
				$error = 'E-Mail or Password not valid';	 
			 }
		  }else
		   {
			clean_user_cache($user->ID);
			wp_clear_auth_cookie();
			wp_set_current_user($user->ID);
			wp_set_auth_cookie($user->ID, true, false);
			update_user_caches($user);
			
			$registration_status =  get_user_meta( get_current_user_id(), 'diaspo_pdf_status' , true );
			if($registration_status != ''){
				
				if ( ICL_LANGUAGE_CODE == "fr" ) {
					 wp_redirect( site_url('registration-status/?lang=fr')); exit;		
				 }else{
					 wp_redirect( site_url('registration-status')); exit;	 
				 }
				
				
			}
          		
			
		  }
		
        }else{
		 if ( ICL_LANGUAGE_CODE == "fr" ) {
		    $error = 'Mot de passe ou E-Mail invalide';		
		 }else{
			$error = 'E-Mail or Password not valid';	 
		 }
	}		
		
		
}	
	
	
	
	
	
	date_default_timezone_set('Africa/Douala');
	$current_date = date('Y-m-d H:i:s');
	$htmlData = '';
	$args = array(
	'post_type' => 'event_ticket',
	'posts_per_page' => -1
    );
$readmore = 'Read more';
if(ICL_LANGUAGE_CODE == "fr")
{
$readmore = 'Lire la suite';	
}	 
	
	
	$events = get_posts( $args );
$count = 0;
//echo "<pre>";	
//print_r($events);
// The Loop
    
	$htmlData .= '<ul class="news-posts events-posts">';
	foreach ($events as $event ) {
		
		//$the_query->the_post();
		$eventname = $event->post_title;
		
		$eventdate = get_field('event_date', $event->ID);
		$eventlogo = get_field('event_logo', $event->ID);
		$eventlink = get_the_permalink($event->ID);
		$eventDes = get_field('event_description', $event->ID); 
		$ticket_activate_time = get_field('ticket_activate_time', $event->ID);
		//$ticket_activate_time_check = date('Y-m-d h:i:s', strtotime($ticket_activate_time));
	    $ticket_de_activate_time = get_field('ticket_de_activate_time', $event->ID);
		

	    if($ticket_de_activate_time > $current_date){	
		   
		    $htmlData .= '<li class="has-thumbnail">
                      <div class="news-img">
					  <a href="'.$eventlink.'">
					  <img width="250" height="297" src="'.$eventlogo.'" class="attachment-diaspo_news-thumbnail size-diaspo_news-thumbnail wp-post-image" alt="">
					  </a>
					  </div><div class="news-contents">
				                <p class="post-header">
				                    <span class="news-reading-time">Event Date<i><span class="reading_duration">'.$eventdate.'</span></i></span>
				                </p>
								<h2><a href="'.$eventlink.'">'.$eventname.'</a></h2>
								<div class="news-txt-block">
								'.$eventDes.'
								</div>
								<div class="news-footer">
								<a href="'.$eventlink.'" class="readMore-btn">'.$readmore.'</a>
								</div>

                      </div>
                      </li>';
					$count++;
	     }
	}
	
	if ( $count == 0 ) {
	if(ICL_LANGUAGE_CODE == "fr")
	 $htmlData .= '<li><p>Les billets d&#233;v&#233;nements ne sont pas disponibles.<p></li>';
    else
	 $htmlData .= '<li><p>Events Ticket are not available.</p></li>';	
    }
	
	$htmlData .= '</ul>';
	/* Restore original Post Data */
	wp_reset_postdata();

}else{
	$url1 = site_url('register');
	$url2 = site_url('wp-login.php?action=lostpassword');
	
	$url3 = site_url('register?lang=fr');
	$url4 = site_url('wp-login.php?action=lostpassword&lang=fr');
	
	$htmlData .= '<div class="container">
					<div class="row">
						<div class="col-md-1">
						</div>
						<div class="col-md-11">
						    <div class="mtnBackground">
								<div class="col-md-6">';
   if ( ICL_LANGUAGE_CODE == "fr" ) { 
   
	$htmlData .= '<div class="whBgLog">
					  <span class="MTnLogo"><img src="http://dsp.lab.kit-services.com/wp-content/uploads/2018/06/diaspo-logo-180-x-180.jpg" /></span>
					  <h3>Cr�ez votre Compte!</h2>
					  <h5><a>Connexion</a> ou <a href="'.$url3.'">Cr�ez un compte</a> pour utiliser ce service</h5>
					  <p>Avec votre compte MTN Mobile Money, g�rez vos affaires au pays peu importe o� vous vous trouvez! Votre num�ro sera votre compagnons m�me en itin�rance.</p>
					  <div class="logForm">
						<span class="error"><?php echo $error;?></span>
						<form action="" method="post" id="mtnLoginForm">
						<div class="log_mtn_form_field">
						 <label>Adresse E-Mail*</label>
						 <span><input type="text" id="emailAddress" name="emailAddress" placeholder="Type your email address" required/></span>
						</div>
						<div class="log_mtn_form_field">
						 <label>Mot de passe*</label>
						 <span><input type="password" id="mtnPassowrd" name="mtnPassowrd" placeholder="*****" required/></span>
						</div>
						<div class="subClasBtn">
						  <input type="submit" id="submitBTN" name="submitBTN" value="Connexion" />
						</div>
						</form>
					  </div>
					  <hr>
			         <div class="bottomLoginfoot"><a href="'.$url3.'">Cr�ez un compte</a> 
					 <a href="'.$url4.'">Mot de Passe oubli�?</a></div>
				</div>';
    } else {  
			  
	$htmlData .= '<div class="whBgLog">
					  <span class="MTnLogo"><img src="http://dsp.lab.kit-services.com/wp-content/uploads/2018/06/diaspo-logo-180-x-180.jpg" /></span>
					  <h3>Use Mobile Money Today!</h2>
					  <h5><a>Login</a> or <a href="'.$url1.'">Register</a> First to use this Service</h5>
					  <p>With MTN Mobile Money, control your business in home country wherever you are. This number will be with you "Everywhere you go"</p>
					  <div class="logForm">
						<span class="error">'.$error.'</span>
						<form action="" method="post" id="mtnLoginForm">
						<div class="log_mtn_form_field">
						 <label>Email Address*</label>
						 <span><input type="text" id="emailAddress" name="emailAddress" placeholder="Type your email address" required /></span>
						</div>
						<div class="log_mtn_form_field">
						 <label>Password*</label>
						 <span><input type="password" id="mtnPassowrd" name="mtnPassowrd" placeholder="*****" required/></span>
						</div>
						<div class="subClasBtn">
						  <input type="submit" id="submitBTN" name="submitBTN" value="Login" />
						</div>
						</form>
					  </div>
					  <hr>
					  <div class="bottomLoginfoot"><a href="'.$url1.'">Register</a> <a href="'.$url2.'">Forgot Password?</a></div>

				</div>';
				
	}			
				
				
}

	
 return $htmlData;	
	
}
add_shortcode('showevents', 'mtn_show_events');


//Event Payment Shortcode 16 May 2018
add_shortcode('mtn_event_payment', 'mtn_event_payment_cb');
function mtn_event_payment_cb()
{ 
    global $wpdb;	
	
	
	
	$trans28 = 'Did you make payment?';
    $trans29 = 'Yes';
    $trans30 = 'No';
	$trans31 = 'Open in Wallet';
	
	
	
if(ICL_LANGUAGE_CODE == "fr")
{	
	$trans28 = 'Avez-vous d&#233;j&#224; effectu&#233; le paiement?';
	$trans29 = 'Oui';
	$trans30 = 'Non';
	$trans31 = 'Ouvrir portefeuille';
}
	
    $event_payment_html  ='';
	
	$btcMsg = 'Please use your Bitcoin  wallet and scan the QR-Code from your smartphone.';		
	if(ICL_LANGUAGE_CODE == 'fr'){
		
		$btcMsg = 'Ouvrez votre application Bitcoin et scannez le QR-CODE a partir de votre t&#233;l&#233;phone';	
		
	}
	
	if(isset($_POST['event_book_sub']))
	{
		
	$totaleventamount = $_POST['event_amount']*$_POST['event_num_members'];

	$event_amount_btc = get_conversion_bitcoin_with_amount('EUR', 'BTC', $totaleventamount);
	
	
	
	// Variables 
	$myAPIKEY       = get_option('blocktrail_api_key');
	$myAPISECRET    = get_option('blocktrailsecret');
	$testnet        = true; //false for bitcoin mainnet or true for testnet
	$walletIdent    = get_option('testnet_wallet_identifier');
	$walletPassword = get_option('testnet_wallet_password');
	if(get_option('blocktrail_mode') == 'on'){
		$testnet    = false;
		$walletIdent    = get_option('live_wallet_identifier');
		$walletPassword = get_option('live_wallet_password');
	}
	//$callbackURL    = "http://dsp.lab.kit-services.com/blocktrail/notify.php";
	$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
	$wallet = $client->initWallet([
			"identifier" => $walletIdent,
			"passphrase" => $walletPassword
	]);

	
	

	$address = $wallet->getNewAddress();
	
	//$client->setupWebhook("http://dsp.lab.kit-services.com/notify.php", "wallet-testyogesh");
	
	$client->subscribeAddressTransactions("Webhook_02062018", $address);
	
	$ticket_id = genrateTicketID();
	$user_id = get_current_user_id();
	$first_name = get_user_meta($user_id, 'first_name', true);
    $last_name = get_user_meta($user_id, 'last_name', true);
	$btc_address = $address;
	$event_id = $_POST['event_id'];
	$event_name = $_POST['event_name'];
	$event_date = $_POST['event_date'];
	$ticket_type = $_POST['event_ticket_type'];
    $ticket_price_eur = $totaleventamount;
	$ticket_price_btc = $event_amount_btc;
	$payment_status = 'Pending';
	$no_of_members = $_POST['event_num_members'];
	$paid_eur = ''; 
	$paid_btc = ''; 
	$created = date('Y-m-d h:i:s');  
	
	
	
    $sql = "INSERT INTO `wp_event_order_history` (ticket_id, user_id, btc_address, event_id, event_name, event_date, ticket_type, ticket_price_eur, ticket_price_btc, buyer_first_name, buyer_last_name, payment_status, no_of_members, paid_eur, paid_btc, created) 
				VALUES('".$ticket_id."', '".$user_id."', '".$btc_address."', '".$event_id."', '".$event_name."', '".$event_date."', '".$ticket_type."', '".$ticket_price_eur."', '".$ticket_price_btc."', '".$first_name."', '".$last_name."', '".$payment_status."', '".$no_of_members."', '".$paid_eur."', '".$paid_btc."', '".$created."')";
  
    $wpdb->query($sql);
    
	$order_id = $wpdb->insert_id;
   
	$event_img_url = get_field('event_logo', $event_id);
	
	
	
	
	$iFrame = '<iframe height="350" width="350" src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=bitcoin:'.$address.'?amount='.$event_amount_btc.'"></iframe>';

	
	$btnwalletUrl = 'bitcoin:'.$address.'?amount='.$event_amount_btc;
	$btnHtml = '<a href="'.$btnwalletUrl.'">'.$trans31.'</a>';
	
	$event_payment_html .= '<h2 class="headTab">Payment</h2>
							<section>
							   <div class="contact-box">
							   <div class="row pay_spaceing pay_event">';
		
	
	$event_payment_html .= '<div class="col-sm-6" id="without_extra_bitcoin">
	        
			<label for="Bitcoin" style="width: inherit;"><img src="'.plugin_dir_url( __FILE__ ).'images/bitcoin-logo.png" /></label>
			 <div class="evtaddress"> 
		     <b>BTC Address: </b><span class="EventaddressBTC">'.$address.'</span></div><br/><div class="evtprice"><b>Event Price: </b><span class="EVENTPrice">'.$event_amount_btc.'
		    </span>&nbsp;BTC</div>
			
			<div class=""><img src="'.$event_img_url.'" style="padding:20px; padding-left:0px;"/></div>
			
			
			
			</div>
		';
			   
	$event_payment_html .= '<div class="col-sm-6">
	<div class="btcMSGEVT">'.$btcMsg.'</div><br/>
	<div class="TIMEREVT"></div><br/>
	<div id="qr_bitcoin">'.$iFrame.'</div>
	<div class="bitCoinDataWalletButtonEvent">'.$btnHtml.'</div>
	</div>';	
	
	
	
	$event_payment_html .= '</div>
		   </div>
		 <input type="hidden" value="'.site_url().'" id="ajaxUrl" />
	</section>';
	
	$event_payment_html .= '<script>
	 jQuery(document).ready(function(){
		 
		 eventTimerStart('.$order_id.');
		 var countTimer = 4*60*1000; 
		 startTimerBitcoinThirdForAddressEvent(countTimer, '.$order_id.');
		 
	 });
	</script>
	<div class="modal fade" id="getjsonRequest" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                              <div class="modal-dialog" role="document">
							 
                                <div class="modal-content">
								
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    
									
                                  </div>
								  <div class="modal-body">

	
       
            <h4>'.$trans28.'</h4>
			
            <input type="button"  id="yes_done1" class="yes_done" value="'.$trans29.'" />
            <input type="button"  id="no_done" value="'.$trans30.'" />			

								  </div>
								 
								</div>
							  </div>
    </div>
	
	<div class="modal fade" id="alertDataGetJson" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                              <div class="modal-dialog" role="document">
							 
                                <div class="modal-content">
								
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    
									
                                  </div>
								  <div class="modal-body">
                                          <h4 class="alertDataGetJson"></h4>
										  
										  <input type="button"  id="ok_done" value="OK" class="close" data-dismiss="modal" aria-label="Close"/>
			
           		                  </div>
								 
								</div>
							  </div>
    </div>';
		
	}
	 
	 return $event_payment_html;
}





// ajax hooks fro Event Checker
function action_eventCheker_callback(){
	
	global $wpdb;
	
	$OrderId = $_POST['OrderId'];
	
	$rowdata = $wpdb->get_row("SELECT * FROM `wp_event_order_history` WHERE order_id = '".$OrderId."'");
	
	$status = $rowdata->payment_status;
	
	if($status == 'Completed' && $rowdata->ticket_pdf_url == ''){
		
		$nonce = rand();
		$order_id = $rowdata->order_id;
		$ticket_id = $rowdata->ticket_id;
		$event_name = str_replace(' ', '', $rowdata->event_name);
		$event_date = $rowdata->event_date;
		$ticket_type = $rowdata->ticket_type;
		$paid_eur = $rowdata->paid_eur;
		//$paid_eur = $rowdata->ticket_price_eur;
		$buyer_first_name = $rowdata->buyer_first_name;
		$buyer_last_name = $rowdata->buyer_last_name;
		$user_id = $rowdata->user_id;
		$user = get_user_by('id', $user_id);
		$user_email = $user->user_email;
		
		
		$KEY = $event_name.$ticket_type.$event_date.$buyer_first_name.$buyer_last_name.$paid_eur.$ticket_id.$nonce;
		
		
	    $filename = 'ticket_'.$ticket_id.md5($KEY).'.png';
		
		//processing form input
		//remember to sanitize user input in real-life solution !!!
		$errorCorrectionLevel = 'S';
		  

		$matrixPointSize = 5;
		
		$filepath = MY_PLUGIN_PATH.'qrcode/temp/'.$filename;

        QRcode::png($KEY, $filepath, $errorCorrectionLevel, $matrixPointSize, 2);   
		
		$hashvalue = base64_encode($KEY);
		
		$html = ticketTemplate($filename, $order_id);
		
		$pdfUrl = ticketPDFCreation($html, $event_name, $order_id, $ticket_id);
		
		
		
		$to = $user_email;
		
		//'votiveyogesh@gmail.com,finances@diaspo-cc.com';
		
		$subject = 'Your Event ticket Confirmed!';
		
		$message = 'Your Booking is confirmed, Ticket is attached.';
		
		$fileName = 'ticket_'.$order_id.'_'.$ticket_id.'.pdf';
		
		$filePath = MY_PLUGIN_PATH.'/qrcode/ticketpdf/'.$fileName;
		
		 
		// Sending email
		sendEmailAttachament($to, $subject, $message, $filePath, $fileName);
		
	    $wpdb->query("UPDATE `wp_event_order_history` SET ticket_pdf_url = '".$pdfUrl."', qrcode_has = '".$hashvalue."' WHERE order_id = '".$order_id."'");
		
	}
	
	echo $status;
	
	wp_die();
	
	
}
add_action( 'wp_ajax_action_eventCheker', 'action_eventCheker_callback' );
add_action( 'wp_ajax_nopriv_action_eventCheker', 'action_eventCheker_callback' );



function go_checkout_bitcoin_address_event(){
	
   
	
global $wpdb;
$payment_bitcoin_address = $_POST['ProdId'];	
	

// Variables 
$myAPIKEY       = get_option('blocktrail_api_key');
$myAPISECRET    = get_option('blocktrailsecret');
$testnet        = true; //false for bitcoin mainnet or true for testnet
$walletIdent    = get_option('testnet_wallet_identifier');
$walletPassword = get_option('testnet_wallet_password');
if(get_option('blocktrail_mode') == 'on'){
	$testnet    = false;
	$walletIdent    = get_option('live_wallet_identifier');
    $walletPassword = get_option('live_wallet_password');
}


$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);
$wallet = $client->initWallet([
        "identifier" => $walletIdent,
        "passphrase" => $walletPassword
]);

    

$address = $wallet->getNewAddress();

$client->subscribeAddressTransactions("Webhook_02062018", $address);

$row = $wpdb->get_row("SELECT * FROM `wp_event_order_history` WHERE btc_address = '".$payment_bitcoin_address."'"); 
$euro_trans_amount = $row->ticket_price_eur;		
$sendAmount1  = get_conversion_bitcoin_with_amount('EUR', 'BTC', $euro_trans_amount); 
$sendAmount = convert_exponantial_to_decimal($sendAmount1);
$db = "INSERT INTO `wp_all_order_address` (id, order_id, user_id, address, type) VALUES('', '".$row->order_id."', '".$row->user_id."', '".$address."', 'event')";
$sql = "INSERT INTO `wp_all_order_address` (id, order_id, user_id, address, type) VALUES('', '".$row->order_id."', '".$row->user_id."', '".$address."', 'event')";
$wpdb->query($sql);	


$wpdb->query("UPDATE `wp_event_order_history` SET ticket_price_btc = '".$sendAmount."' WHERE order_id = '".$row->order_id."'");	
	
	echo $address.'##'.$sendAmount;
	
	die(0);
}
add_action( 'wp_ajax_go_checkout_bitcoin_address_event', 'go_checkout_bitcoin_address_event');
add_action( 'wp_ajax_nopriv_go_checkout_bitcoin_address_event', 'go_checkout_bitcoin_address_event');


//check notification manually for Event

function go_checkout_bitcoin_address_manually_event(){
	
global $wpdb;
$msg = '';
$payment_bitcoin_address = $_POST['btcAddress'];	
//$date = date('Y-md h:i:s');
// Variables 
	$myAPIKEY       = get_option('blocktrail_api_key');
	$myAPISECRET    = get_option('blocktrailsecret');
	$testnet        = true; //false for bitcoin mainnet or true for testnet
	$walletIdent    = get_option('testnet_wallet_identifier');
	$walletPassword = get_option('testnet_wallet_password');
	if(get_option('blocktrail_mode') == 'on'){
		$testnet = false;
		$walletIdent    = get_option('live_wallet_identifier');
		$walletPassword = get_option('live_wallet_password');
	}


$row = $wpdb->get_row("SELECT * FROM `wp_event_order_history` WHERE btc_address = '".$payment_bitcoin_address."'");
if($row){
if($row->payment_status == 'Pending'){
	
	
	$btceur = get_conversion_bitcoin('BTC', 'EUR');
	$btcxaf = get_conversion_bitcoin('BTC', 'XAF');
	$btcNetwork = 'TESTNET';
	if(get_option('blocktrail_mode') == 'on'){
		
		$btcNetwork = 'LIVENET';
		
	}
	
    

	$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);

	$data = $client->address($row->btc_address);
	$paid = '';
    if(!empty($data['received'])){
		
		$paid = $data['received'];
		
	}else if(!empty($data['unconfirmed_received'])){
		
	    $paid = $data['unconfirmed_received'];
    }
	else
	{
		
		echo "Recieved is Empty!";
	}
	
	
	
	
    
	if(!empty($paid)){
		
	$paidAmount = BlocktrailSDK::toBTC($paid);
	
	$email = 'votiveyogesh@gmail.com,finances@diaspo-cc.com';
	$sub = 'New Transaction Lab Event Yogesh';
	$body = 'Santoshi Amount: '.$paid.'-------------Amount: '.$paidAmount.'-------------Address:'.$payment_bitcoin_address;
	mail($email, $sub, $body);
	
	$euramount = get_conversion_bitcoin_with_amount('BTC', 'EUR', $paidAmount);
	
     
	if($paidAmount < $row->ticket_price_btc)
    {
		
	$wpdb->query("UPDATE `wp_event_order_history` SET paid_btc = '".$paidAmount."', paid_eur = '".$euramount."', payment_status = 'Rejected', refund_status = 'Pending' WHERE btc_address = '".$payment_bitcoin_address."'");
	 	
	}else{
		
	$wpdb->query("UPDATE `wp_event_order_history` SET paid_btc = '".$paidAmount."', paid_eur = '".$euramount."', payment_status = 'Completed' WHERE btc_address = '".$payment_bitcoin_address."'");
	 	
	}		
	 
	 
	 
    if ( ICL_LANGUAGE_CODE == "fr" ) { 
        echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
	   
	}else{
	 
      if ( ICL_LANGUAGE_CODE == "fr" ) { 
        echo "Votre paiement n'a pas encore &#233;t&#233; re&#231;u. Merci de patienter.";
	}else{
		echo ' Payment not yet received!';
	}		 
		
	}
   
   
} else {
	
	if ( ICL_LANGUAGE_CODE == "fr" ) { 
        echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
 }
}else{
	$row1 = $wpdb->get_row("SELECT * FROM `wp_all_order_address` WHERE address = '".$payment_bitcoin_address."'");
	
	$row2 = $wpdb->get_row("SELECT * FROM `wp_event_order_history` WHERE order_id = '".$row1->order_id."'");
	
	$btceur = get_conversion_bitcoin('BTC','EUR');
	$btcxaf = get_conversion_bitcoin('BTC','XAF');
	
	$btcNetwork = 'TESTNET';
	
	if(get_option('blocktrail_mode') == 'on'){
		
		$btcNetwork = 'LIVENET';
		
	}
	
	
	if($row2->payment_status == 'Pending'){
		
	$client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);

	$data = $client->address($payment_bitcoin_address);
	$paid = '';
    if(!empty($data['received'])){
		
		$paid = $data['received'];
	}elseif(!empty($data['unconfirmed_received'])){
	    $paid = $data['unconfirmed_received'];
    }
	else
	{
		echo " Recieved is Empty";
		
	}
    
	if(!empty($paid)){
		
	$paidAmount = BlocktrailSDK::toBTC($paid);
	
	$email = 'votiveyogesh@gmail.com,finances@diaspo-cc.com';
	$sub = 'New Transaction Lab Event Yogesh';
	$body = 'Santoshi Amount: '.$paid.'-------------Amount: '.$paidAmount.'-------------Address:'.$payment_bitcoin_address;
	mail($email, $sub, $body);
	
	$euramount = get_conversion_bitcoin_with_amount('BTC', 'EUR', $paidAmount);
	
    
	
	if($paidAmount < $row2->ticket_price_btc)
    {

	$wpdb->query("UPDATE `wp_event_order_history` SET paid_btc = '".$paidAmount."', paid_eur = '".$euramount."', payment_status = 'Rejected', refund_status = 'Pending' WHERE order_id = '".$row1->order_id."'");
	
	 	
	}else{
		
	$wpdb->query("UPDATE `wp_event_order_history` SET paid_btc = '".$paidAmount."', paid_eur = '".$euramount."', payment_status = 'Completed' WHERE order_id = '".$row1->order_id."'");
	 	
	}     
	   
	 
	if ( ICL_LANGUAGE_CODE == "fr" ) { 
        echo 'Paiement re&#231;u Selectionnez "OK" afin que nous traitions votre paiment';
	}else{
		echo 'Payment received! Please press "OK" for us to process your payment.';
	}
	 
	}else{
	 
     
      if ( ICL_LANGUAGE_CODE == "fr" ) { 
         echo "Votre paiement n'a pas encore &#233;t&#233; re&#231;u. Merci de patienter.";
	   }else{
		 echo 'Payment not yet received!';
	  }	 
		
	 }
		
	}	
		
	
}
  
  die(0);
}
add_action( 'wp_ajax_go_checkout_bitcoin_address_manually_event', 'go_checkout_bitcoin_address_manually_event' );
add_action( 'wp_ajax_nopriv_go_checkout_bitcoin_address_manually_event', 'go_checkout_bitcoin_address_manually_event' );

//For Ticket ID
function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}

function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); // edited

    for ($i=0; $i < $length; $i++) {
        $token .= $codeAlphabet[crypto_rand_secure(0, $max-1)];
    }

    return $token;
}

function genrateTicketID(){
	
	$ticketCounter = get_option('ticket_counter');
    $ticketUpdate = $ticketCounter + 1;
	
	update_option('ticket_counter', $ticketUpdate);
	
    return getToken(3).$ticketUpdate;
	
	
}

function ticketTemplate($filename, $order_id){
global $wpdb;
date_default_timezone_set('Africa/Douala');	
$rowdata = $wpdb->get_row("SELECT * FROM `wp_event_order_history` WHERE order_id = '".$order_id."'");
$booking_date = date('d/m/Y');
$event_date = $rowdata->event_date;
$paid_amount = $rowdata->ticket_price_eur;
$ticket_type = $rowdata->ticket_type;
$ticket_id = $rowdata->ticket_id;
$members = $rowdata->no_of_members;

$customerName = $rowdata->buyer_first_name.' '. $rowdata->buyer_last_name;
$event_name = $rowdata->event_name;

$eventlogo = get_field('event_logo', $rowdata->event_id);
$eventDesc = get_field('event_description', $rowdata->event_id);

$qrcodeImage =  plugins_url('/mtn-custom-plugin/qrcode/temp/'.$filename);
	
$html ='<html>
<head>
<title>diaspoCC - Ticket: '.$event_name.'</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
<style>
    body {
        font-family: Raleway, sans-serif;
        font-size: 14px; 
        line-height:20px;
    }
    .wrapper {
        width: 100%;
        max-width: 500px; 
        margin: 30px auto; 
        border:1px solid #ddd; 
        padding: 25px 20px;
    }
    .logo {
        width: 100%;
        text-align: center;
        margin: 10px 0 30px;
    }
    .logo img {
        width: 100%; 
        max-width: 200px;
        vertical-align: middle;
    }
    h1.heading {
        font-size: 26px; 
        color: #333; 
        margin: 0; 
        padding: 0 15px 30px; 
        line-height: 40px; 
        font-weight: 600;
        text-align: center;
        border-bottom: dotted 2px #ddd;
    }
    .event_details {
        margin: 0; 
        padding: 10px 0; 
        clear: both; 
        overflow: hidden; 
        border-bottom: dotted 2px #ddd; 
    }
    .event_details strong {
        width: 50%;
        float: left;
        text-align: left;
    }
    .event_details span {
        width: 50%;
        float: right;
        text-align: right;
    }
    .event_img {
        text-align: center;
        margin-top: 30px;
    }
    .event_img img {
        width: 100%; 
        vertical-align: middle; 
        max-width: 100%;
    }
    .event_ticket {
        padding: 5px; 
        background: #c4c4c4; 
        margin-top: 30px;
    }
    .evtkt_dtl {
        background: #fff;
        padding: 15px;
    }
    .evtkt_dtl h2 {
        text-align:center;
        margin: 0; 
        font-size: 20px; 
        font-weight: 700; 
        padding: 10px 0 0;
    }
    .qr_code {
        width: 100%;
        text-align: center; 
        max-width: 200px; 
        margin: 10px auto 30px;
        border-bottom: dotted 2px #ddd;
    }
    .qr_code img {
        width: 100%;
        max-width: 100%; 
        vertical-align: middle;
    }
    .event_ticket p {
        text-align: center; 
        line-height: 24px;
    }
</style>
</head>
<body style="font-family: Raleway, sans-serif; font-size: 25px; line-height:15px; margin: 0;">
    <table style="width: 100%; max-width: 500px; margin: 5px 10px auto; border:1px solid #ddd; padding: 10px 10px 10px;">
        <tr>
            <td style="text-align: center;">
               <img style="width: 50%; vertical-align: middle; height:100px;" src="'.$eventlogo.'" alt="" />
            </td>
        </tr>
        <tr>
            <td style="text-align: center;">
               <h1 style="font-size: 40px; color: #333; margin: 0; padding: 10px ; line-height: 30px; font-weight: 600;">'.$event_name.'</h1>
            </td>
        </tr>
		<tr>
               <td colspan="2" style="font-size: 25px; margin: 0; text-align: center; line-height: 20px;">
                 '.$eventDesc.'  
               </td>
        </tr>
		<tr>
            <td>
                <table style="width: 100%;">
				
				    <tr>
                        <td style="text-align: center; padding: 2px 0;border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <strong>Ticket ID</strong> 
                        </td>
                        <td style="text-align: center; padding: 2px 0;border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <span>'.$ticket_id.'</span>  
                        </td>
                    </tr>
					<tr>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <strong>Booking Date</strong> 
                        </td>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <span> '.$booking_date.'</span>  
                        </td>
                    </tr>
					<tr>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <strong>Event Date</strong> 
                        </td>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <span> '.$event_date.'</span>  
                        </td>
                    </tr>
					<tr>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <strong>Ticket Type</strong> 
                        </td>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <span>'.$ticket_type.'</span>  
                        </td>
                    </tr>
					<tr>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <strong>Customer</strong> 
                        </td>
                        <td style="text-align: center; padding: 6px 0; border-bottom: dotted 1px #ddd; border-top: dotted 1px #ddd;">
                            <span> '.$customerName.'</span>  
                        </td>
                    </tr>
			    </table>
            </td>				
        </tr>
        <tr>
            <td>
                <table style="width: 100%; background: #fff; border: solid 5px #c4c4c4; padding: 2px; margin-top: 5px;">
                    <tr>
                        <td colspan="2" style="text-align: center;">
                            <h2 style="text-align:center; margin: 0; font-size: 25px; font-weight: 700;"> '.$members.' Members :  &euro; '.$paid_amount.'</h2>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align:center;padding-left:8%;">
                            <img style="width: 50%; height:100px;" src="https://diaspo-cc.com/core/wp-content/uploads/2018/05/diaspo_cc_logo.png" alt="" />
                        </td>
					</tr>
                    <tr>					
                        <td style="text-align:center;padding-left:8%;">
                            <img style="width: 50%;" src="'.$qrcodeImage.'" alt="" />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-size: 20px; margin: 0; text-align: center; padding: 5px 0 5px; line-height: 15px;">
                            www.diaspo-cc.com
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';

return $html;

}

function ticketPDFCreation($html, $eventName, $order_id, $ticket_id){
	
	include(MY_PLUGIN_PATH. 'mpdf/mpdf.php');
	
	$mpdf = new mPDF('c','A4','',''); 
	$mpdf->SetProtection(array('print'));
	$mpdf->SetTitle("diaspoCC. - Ticket: ".$eventName);
	$mpdf->SetAuthor("diaspoCC.");
    //$mpdf->SetWatermarkText("Paid");
	$mpdf->showWatermarkText = true;
	$mpdf->watermark_font = 'DejaVuSansCondensed';
	$mpdf->watermarkTextAlpha = 0.1;
	$mpdf->SetDisplayMode('fullpage');


	$mpdf->WriteHTML($html);
	
	$mpdf->Output(MY_PLUGIN_PATH.'qrcode/ticketpdf/ticket_'.$order_id.'_'.$ticket_id.'.pdf','F');

	$url = plugins_url('/mtn-custom-plugin/qrcode/ticketpdf/ticket_'.$order_id.'_'.$ticket_id.'.pdf');

	return $url;
	
	
}

function sendEmailAttachament($email, $subject, $mainMessage, $filePath, $filename){
	
	$fileatt     = $filePath;
	$fileatttype = "application/pdf";
	$fileattname = $filename;
	$headers = "From: diaspoCC <info@kit-services.com>";

	// File
	$file = fopen($fileatt, 'rb');
	$data = fread($file, filesize($fileatt));
	fclose($file);

	// This attaches the file
	$semi_rand     = md5(time());
	$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
	$headers      .= "\nMIME-Version: 1.0\n" .
	"Content-Type: multipart/mixed;\n" .
	" boundary=\"{$mime_boundary}\"";
	
	$message = "This is a multi-part message in MIME format.\n\n" .
	"-{$mime_boundary}\n" .
	"Content-Type: text/plain; charset=\"iso-8859-1\n" .
	"Content-Transfer-Encoding: 7bit\n\n" .
	$mainMessage  . "\n\n";

	$data = chunk_split(base64_encode($data));
	$message .= "--{$mime_boundary}\n" .
	"Content-Type: {$fileatttype};\n" .
	" name=\"{$fileattname}\"\n" .
	"Content-Disposition: attachment;\n" .
	" filename=\"{$fileattname}\"\n" .
	"Content-Transfer-Encoding: base64\n\n" .
	$data . "\n\n" .
	"-{$mime_boundary}-\n";

	// Send the email

	mail($email, $subject, $message, $headers);
	
}


function create_freshdesk_ticket_for_identification_error($data){
	
	$freshdesk_login_url = get_option('freshdesk_login_url');
	$freshdesk_email = get_option('freshdesk_email');
	$freshdesk_password = get_option('freshdesk_password');
	
	     $postData = json_encode($data);
		 
		 $url = $freshdesk_login_url."/api/v2/tickets";
		
		 $header[] = "Content-type: application/json";
		 $ch = curl_init ($url);



		 curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
		 curl_setopt($ch, CURLOPT_USERPWD, $freshdesk_email.":".$freshdesk_password);
		 curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		 curl_setopt( $ch, CURLOPT_POSTFIELDS, $postData);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		 if( $debugMode ) {
		 // CURLOPT_VERBOSE: TRUE to output verbose information. Writes output to STDERR,
		 // or the file specified using CURLOPT_STDERR.
		 curl_setopt($ch, CURLOPT_VERBOSE, true);
		 $verbose = fopen('php://temp', 'rw+');
		 curl_setopt($ch, CURLOPT_STDERR, $verbose);
		 }

		 $returndata = curl_exec ($ch);

		 if( $debugMode ) {
		 !rewind($verbose);
		 $verboseLog = stream_get_contents($verbose);
		 print $verboseLog;
		 }

		 
		 
		$result = json_decode($returndata, TRUE);
		
		 
		 
		
		 
		
	return	$result;
}

//Identify the user identity card
function IdcioUser(){
	global $wpdb;
	$current_user_id = get_current_user_id();
	
	$user = get_user_by('id', $current_user_id);

    $username = $user->first_name; 

	$id_type = get_user_meta( $current_user_id, 'type', true);

	if ($id_type == 'ID-Card') {
		$idtype = explode('-', $id_type);
		$idtype = $idtype[0];
	} 
	else {
		$idtype = $id_type;
	}
	

	$doc_number = get_user_meta( $current_user_id, 'passport_number', true);

	$expiry_date = get_user_meta( $current_user_id, 'expiry_date', true);
	
	$e_date = explode('-', $expiry_date);
	$e_date_1 = str_replace(0, '', $e_date[1]);
	$exp_date = $e_date[0].'-'.$e_date_1;

	$date_of_birth = get_user_meta( $current_user_id, 'date_of_birth', true);
	$dateofbirth = explode('-', $date_of_birth);
	$dateofbirthYear = $dateofbirth[0];
	$dateofbirthMonth = $dateofbirth[1];
	$dateofbirthDay = $dateofbirth[2];
	
	$gender = get_user_meta( $current_user_id, 'gender', true);

	// echo 'userMeta: '.$idtype.' '.$doc_number.' '.$exp_date.' '.$date_of_birth.' '.$gender;
	// echo "<br>";
	
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, "https://api-test.idcheck.io/rest/v0/task/image?asyncMode=false");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);

	curl_setopt($ch, CURLOPT_POST, TRUE);

	$the_query = new WP_Query( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'author' => $current_user_id, 'posts_per_page' => 1) );
	if ( $the_query->have_posts() )
		while ( $the_query->have_posts() ) : $the_query->the_post();
	   	//the_title();
	   	if (strpos(get_the_title(), '_file2') !== false) {
		    $attachment_tlt = get_the_title();
		    $attachment_url = $wpdb->get_row("SELECT `guid` FROM `wp_posts` WHERE `post_title` LIKE '".$attachment_tlt."' AND `post_type` LIKE 'attachment'");
		}
		endwhile;
	
	//echo $attachment_url->guid.'<br>';

	/*Get image and convert into base64*/
	$path = $attachment_url->guid;
	$type = pathinfo($path, PATHINFO_EXTENSION);
	$data = file_get_contents($path);
	$base64_img = base64_encode($data);

	/*Get string and convert into base64*/
	$str = 'diaspocc@ariadnext.com:WhQFcY6P5g';
	$base64_str = base64_encode($str);

	curl_setopt($ch, CURLOPT_POSTFIELDS, '{  
	    "frontImage": "'.$base64_img.'",
	    "rectoImageCropped": false,
	    "signatureImageCropped": false,
	    "faceImageCropped": false
	}');

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	  "Content-Type: application/json",
	  "Authorization: Basic ".$base64_str,
	  "Accept-Language: en"
	));

	$response = curl_exec($ch);
	curl_close($ch);

	//var_dump($response);
	$response = json_decode($response);
	//echo "<pre>";print_r($response);
	//die();
	$idType = $response->documentClassification->idType;

	if ($idType == 'P') {
		$idType = 'Passport';
	}	

	$documentNumber = $response->documentDetail->documentNumber;	

	$expirationMonth = $response->documentDetail->expirationDate->month;
	$expirationYear = $response->documentDetail->expirationDate->year;
	$DOE = $expirationYear.'-'.$expirationMonth;

	$Bday = $response->holderDetail->birthDate->day;	
	$Bmonth = $response->holderDetail->birthDate->month;	
	$Byear = $response->holderDetail->birthDate->year;
	
	
	$api_gender = $response->holderDetail->gender;

	if ($api_gender=='F') {
		$api_gender = 'Female';
	} else {
		$api_gender = 'Male';
	}

	// echo 'IDCIO: '.$idType.' '.$documentNumber.' '.$DOE.' '.$DOB.' '.$api_gender;
	// echo "<br>";	

    $errors = '';	

	$identifier_SUMMARY_ID_IDENTIFIED = $response->checkReportSummary->check[0]->identifier;
	$result_id_SUMMARY_ID_IDENTIFIED = $response->checkReportSummary->check[0]->result;
	$resultMsg_SUMMARY_ID_IDENTIFIED = $response->checkReportSummary->check[0]->resultMsg;
	
	if($identifier_SUMMARY_ID_IDENTIFIED == 'SUMMARY_ID_IDENTIFIED' && $result_id_SUMMARY_ID_IDENTIFIED != 'OK'){
		
	  $errors .= '<p>Error: '.$resultMsg_SUMMARY_ID_IDENTIFIED.'</p>';	
	
	}
	
	
	$identifier_SUMMARY_ID_FALSIFIED = $response->checkReportSummary->check[1]->identifier;
	$result_id_SUMMARY_ID_FALSIFIED = $response->checkReportSummary->check[1]->result;
	$resultMsg_SUMMARY_ID_FALSIFIED = $response->checkReportSummary->check[1]->resultMsg;
	
	if($identifier_SUMMARY_ID_FALSIFIED == 'SUMMARY_ID_FALSIFIED' && $result_id_SUMMARY_ID_FALSIFIED != 'OK'){
		
	  $errors .= '<p>Error: '.$resultMsg_SUMMARY_ID_FALSIFIED.'</p>';	
	
	}
	
	$identifier_SUMMARY_ID_SPECIMEN = $response->checkReportSummary->check[2]->identifier;
	$result_id_SUMMARY_ID_SPECIMEN = $response->checkReportSummary->check[2]->result;
	$resultMsg_SUMMARY_ID_SPECIMEN = $response->checkReportSummary->check[2]->resultMsg;
	
	if($identifier_SUMMARY_ID_SPECIMEN == 'SUMMARY_ID_SPECIMEN' && $result_id_SUMMARY_ID_SPECIMEN != 'OK'){
		
	  $errors .= '<p>Error: '.$resultMsg_SUMMARY_ID_SPECIMEN.'</p>';	
	
	}
	
	
	$identifier_SUMMARY_ID_EXPIRED = $response->checkReportSummary->check[3]->identifier;
	$result_id_SUMMARY_ID_EXPIRED = $response->checkReportSummary->check[3]->result;
	$resultMsg_SUMMARY_ID_EXPIRED = $response->checkReportSummary->check[3]->resultMsg;
	
	if($identifier_SUMMARY_ID_EXPIRED == 'SUMMARY_ID_EXPIRED' && $result_id_SUMMARY_ID_EXPIRED != 'OK'){
		
	   $errors .= '<p>Error: '.$resultMsg_SUMMARY_ID_EXPIRED.'</p>';	
	
	}
	
	
	$identifier_SUMMARY_ID_COPY = $response->checkReportSummary->check[4]->identifier;
	$result_id_SUMMARY_ID_COPY = $response->checkReportSummary->check[4]->result;
	$resultMsg_SUMMARY_ID_COPY = $response->checkReportSummary->check[4]->resultMsg;
	
	if($identifier_SUMMARY_ID_COPY == 'SUMMARY_ID_COPY' && $result_id_SUMMARY_ID_COPY != 'OK'){
		
	  $errors .= '<p>Error: '.$resultMsg_SUMMARY_ID_COPY.'</p>';	
	
	}
	
	
	if($idtype != $idType) 
	{
		$errors .= '<p>Error: ID Type does not Match!</p>'.$idtype .'!='. $idType;
	}
	if($doc_number != $documentNumber) 
	{
		$errors .= '<p>Error: Document No. does not Match!</p>'.$doc_number .'!='. $documentNumber;
	}
	if($dateofbirthYear != $Byear || $dateofbirthMonth != $Bmonth || $dateofbirthDay != $Bday) 
	{
		$errors .= '<p>Error: Date of Birth does not Match!</p>'.$dateofbirthYear .'!='. $Byear .'||'. $dateofbirthMonth .'!='. $Bmonth .'||'. $dateofbirthDay .'!='. $Bday;
	}
	if($exp_date != $DOE) 
	{
		$errors .= '<p>Error: Date of Expiry does not Match!</p>'.$exp_date .'!='. $DOE;
	}
	if($gender != $api_gender) 
	{
		$errors .= '<p>Error: Gender does not Match!</p>'.$gender .'!='. $api_gender;
	}

	if($errors == ''){
		 update_user_meta($current_user_id, 'is_identified', 'yes');
		 $ticket_id = get_user_meta(get_current_user_id(), 'freshdesk_identification_ticket_id', true);
		 update_freshdesk_ticket($ticket_id);
		 update_user_meta(get_current_user_id(), 'freshdesk_identification_ticket_id', '');
	     echo 'OK';
		
	}
	else{
		
		$freshdesk_identification_ticket_id = get_user_meta(get_current_user_id(), 'freshdesk_identification_ticket_id', true);
		if($freshdesk_identification_ticket_id == ''){
			$to1 = 'support@diaspo-cc.com';
			$subject1  =  'Identification failed for #'.get_current_user_id();
			$message1  = '<p>Identification Errors listed below: </p>'. "\r\n";
			$message1 .= $errors;
			$ccEmail = array();
			$ccEmail[] = $to;
			$sender_phone = get_user_meta(get_current_user_id(), 'diaspo_user_phone', true);
			$user_info = get_userdata(get_current_user_id());
															
			$data = array( "description" => $message1,
						   "subject" => $subject1,
						   "email" => $user_info->user_email,
						   "priority" => 1,
						   "status" => 2,
						   "source" => 2,
						   "phone" => $sender_phone,
						   "cc_emails" => $ccEmail
						   
						);
													
			$results = create_freshdesk_ticket_for_identification_error($data);
			
			$ticket_id = $results['id'];
			
			update_user_meta(get_current_user_id(), 'freshdesk_identification_ticket_id', $ticket_id);
		}
		else{
			$to1 = 'support@diaspo-cc.com';
			$subject1  =  'Identification failed for #'.get_current_user_id();
			$message1  = '<p>Identification Errors listed below: </p>'. "\r\n";
			$message1 .= $errors;
			$ccEmail = array();
			$ccEmail[] = $to;
			$sender_phone = get_user_meta(get_current_user_id(), 'diaspo_user_phone', true);
			$user_info = get_userdata(get_current_user_id());
															
			$data = array( "description" => $message1);	
			//echo update_freshdesk_ticket_identification($freshdesk_identification_ticket_id, $data);
			update_freshdesk_ticket_identification($freshdesk_identification_ticket_id, $data);
			//print_r($update);
		}
		if ( ICL_LANGUAGE_CODE == "fr" ) {
			
		   echo  "Votre identification a &#233;chou&#233;e. Vous pouvez re-essayer ou vous faire assister par notre &#233;quipe support qui vous contactera.";
	    
		}else{
			
			echo "Your identification has failed. Feel free to try again or wait for our support Team to get to you for helping with the issue.".$errors;
		}
	
	}
	
	
		
    die();
	
}
add_action( 'wp_ajax_IdcioUser', 'IdcioUser' );
add_action( 'wp_ajax_nopriv_IdcioUser', 'IdcioUser' );