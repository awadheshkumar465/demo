<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_model extends CI_Model 
{
  
  // public function __construct() {
        
 //        $this->usOptTbl = "otd_user_option";
        
 //    }

/*________________________NEW FUNCTION MAKE HEAR________________________________________*/
    
    public function getGallery(){

      $gallery = AR("wp_posts",array('post_type' => 'gallery', 'post_status' => 'publish' ),"","");  
        if (!empty($gallery)) {
          for ($i=0; $i < count($gallery) ; $i++) {           

            $results['data'][$i] = array( 'ID' => $gallery[$i]['ID'],
            'post_title' => $gallery[$i]['post_title'],
            'post_name' => $gallery[$i]['post_name'],
            'post_type' => $gallery[$i]['ID'],
            //'guid' => $gallery[$i]['guid']
            'guid' => wp_get_attachment_url( get_post_thumbnail_id($gallery[$i]['ID']))
            );
          }
        }
        $args = array('post_type' => 'gallery','posts_per_page' => -1);
        $gallery_query = new WP_Query($args);
        while ($gallery_query->have_posts()) : $gallery_query->the_post();    
          $results['sliderimage'][] = get_field('gallery_slider_image');    
        endwhile;        
      return $results;
    }

    public function offerci(){

      $this->db->select('*');
      $this->db->from('wp_posts');
      $this->db->where(array('post_type' => 'saleproduct'));
      $query = $this->db->get();
      $sid =$query->result_array();
      
      for ($i=0; $i < count($sid); $i++) {

        $this->db->select('*');
        $this->db->from('wp_postmeta');
        $this->db->join( 'wp_posts', 'wp_postmeta.post_id = wp_posts.ID', 'left' );
        $this->db->where(array('post_id' => $sid[$i]['ID'], 'meta_key' => "offer_discount_price", 'meta_value !=' => "" ));
        $query = $this->db->get();
        $results[$i] =$query->result_array();
        if (!empty($results[$i])) { 
     
          $response['data'][] = array('ID' => $results[$i][0]['ID'],
                              'post_title' => $results[$i][0]['post_title'],
                              'post_name' => $results[$i][0]['post_name'],
                              'post_type' => $results[$i][0]['post_type'],
                              'discount_price' => $results[$i][0]['meta_value'],
                              'product_image' => wp_get_attachment_url( get_post_thumbnail_id($results[$i][0]['ID']))
                              );        
        }
        $response['offer_image'] = get_field('offer_image', 138); 

      }return $response;
    }



    /** Start get Combo Product  */

    public function getComboproduct(){
        $args = ['post_type' => 'saleproduct', 'posts_per_page' => -1];
        $combodata = get_posts( $args );
        global $post;
        for ($i=0; $i <count($combodata); $i++) { 
          $arr['menulist'][$i]['product_id'] = $combodata[$i]->ID;
          $arr['menulist'][$i]['product_name'] = $combodata[$i]->post_title;
          $arr['menulist'][$i]['price'] = get_field( "price", $arr['menulist'][$i]['product_id']);
          $arr['menulist'][$i]['product_image'] = wp_get_attachment_url( get_post_thumbnail_id($arr['menulist'][$i]['product_id']) );
          //$arr['menulist'][$i]['product_slider_image'] = get_field( "product_slider_image", $arr[$i]['product_id']);
          $category = get_the_terms($combodata[$i]->ID,'sale-product-cat');
          $category_name = $category[0]->name;
          if($category_name == "Special Orders"){
            $arr['menulist'][$i]['type'] = 0;
          }
          else{
             $arr['menulist'][$i]['type'] = 1;
          }
          
        }
        //die();
        $menu_slider_args = array('post_type' => 'saleproduct','posts_per_page' => -1);
        $menu_slider_query = new WP_Query($menu_slider_args);
        while ($menu_slider_query->have_posts()) : $menu_slider_query->the_post(); 
          $value = get_field( "product_slider_image" );
          if( $value ) {
          $arr['sliderimage'][] = $value;
          }
        endwhile;
        //die();
        return $arr;
    }


     /** Start get Combo Product  */

    public function getCart($visitor_id){
      $args = array('visitor_id' => $visitor_id);
      $this->db->select('*');
      $this->db->from(ADDTOCART);
      $this->db->where($args);
      $query = $this->db->get();
      $result = $query->result_array();
      return $result;
    }

    public function deleteCart($id){
      $this->db->where(array('id' => $id));
      $this->db->delete(ADDTOCART);

      //$query = $this->db->get();
      //$result = $query->result_array();
            //print_r($query);die();
      return 1;
    }

    function deleteRecords($table,$where_condition)
      {
         $this->db->where($where_condition);

      $this->db->delete($table);
      }


    /** ======================    Start Combo Product Details Page =========================== */
    public function getComboProductDetail($id){
      $product_id = $id;
      $data['product_image'] = wp_get_attachment_url( get_post_thumbnail_id($product_id) );
      $data['product_name'] = get_the_title($product_id);
      $data['product_price'] = get_field("price",$product_id);

        $repeater_value = get_post_meta($product_id, 'food_type', true);
        $how_many_foods_name = get_post_meta($product_id,'how_many_foods_name',true);
        if ($repeater_value) {
          for ($i=0; $i<$repeater_value; $i++) {
            $meta_key = 'food_type_'.$i.'_food_names';
            $foodtype[$i]['foodname'] = get_post_meta($product_id, $meta_key, true);
            $meta_keys = 'food_type_'.$i.'_food_various_types';
            $foodtype[$i]['foodvalue'] = get_post_meta($product_id, $meta_keys, true);
          }
        }
        if ($how_many_foods_name) {
          for ($j=0; $j<$how_many_foods_name; $j++) {
            $how_many_foods_key = 'how_many_foods_name_'.$j.'_included_items';
            $includeditems[$j] = get_post_meta($product_id, $how_many_foods_key, true);
          }
        }
        $combo_detail = array('cdata' =>$data , 'foodtype' => $foodtype , 'includeditems'=>$includeditems);
        return $combo_detail;
      die();
    }




    public function getOrder($visitor_id){
      $args = array('visitor_id' => $visitor_id);
      $this->db->select('*');
      $this->db->from(CHECKOUT);
      $this->db->where($args);
      $query = $this->db->get();
      $result = $query->result_array();
      return $result;
    }



}