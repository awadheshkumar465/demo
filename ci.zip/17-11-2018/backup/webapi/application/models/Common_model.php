<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_model extends CI_Model 
{
/*________________________NEW FUNCTION MAKE HEAR________________________________________*/
    
   public function getWalletList($user_id){
      $walletss = array();
      $wallets = all_Data("wp_user_wallets", array('user_id' => $user_id));
      foreach ($wallets as $wallet) {
        $walletss[] = $wallet['wallet_identifier'];
      }      
      return $walletss; 
   }
   public function transferBTC($data){


      global $wpdb;
      date_default_timezone_set('Africa/Douala');
      $user_id = $data['user_id'];
      $time = date('Y-m-d h:i:s');
      $nonce = rand();
      $currency_type_amount = $data['transfer_amount'];
      $fullname = $data['fullname'];
      $senderMsisdn = $data['senderMsisdn'];
      $sp_id = get_option('sp_id');
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip');
      $service_id = get_option('service_id');
      //$country_name = $data['country_name'];

      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
     
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;     
      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
      <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
      <spId>'.$spID.'</spId>
      <spPassword>'.$PasswordDigest.'</spPassword>

      <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
      </soap:Header>
      <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
      <serviceId>DiaspoCC</serviceId>
      <parameter>
      <name>DueAmount</name>
      <value>'.$currency_type_amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$senderMsisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>CurrCode</name>
      <value>XAF</value>
      </parameter>
      <parameter>
      <name>SenderID</name>
      <value>DiaspoCC</value>
      </parameter>
      </ns3:processRequest>
      </soap:Body>
      </soap:Envelope>';

      $to = "test5@kit-services.com,votiveyogesh@gmail.com,votivephp.prashant@gmail.com";
      $subject = "TESTBED URL - Send Request";
      $txt = $xml_post_string;
      $headers = "From: info@diaspo-cc.com," . "\r\n";
      mail($to,$subject,$txt,$headers);

      $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';

      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME') {
              $arr_name[$i++] = $value['value'];
            }
            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));

      if(count($arr) != count($arr1))
      { 
        $arr1[] = '';
      }
      $arr2 = array_combine($arr, $arr1);

      return $arr2;
   }
   public function pay_Deposit_ByAdmin($order_id, $user_id, $amount){

      //global $wpdb;
      
      $rowdata = get_user_meta( $user_id , 'diaspo_user_phone', true );
      $country_code = get_user_meta( $user_id , 'country_flag_code', true );
      $msisdn = $country_code.$rowdata;
      $Narration = '';
      $left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
      $lang = get_user_meta( $user_id, 'diaspo_user_language', true );
      $message = '';
      $subject = ''; 
      $user_info = get_userdata($user_id);
      $to = $user_info->user_email;
      
      $sp_id = get_option('sp_id'); 
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip'); 
      $service_id = get_option('service_id');
            
      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17";

      $nonce = rand();
      $rand = rand(3, 4);
      date_default_timezone_set('Africa/Douala');
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;

      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
      <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
      <ns1:spId>'.$spID.'</ns1:spId>
      <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
      <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
      </soapenv:Header>
      <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
      <serviceId>diaspoCC</serviceId>
      <parameter>
      <name>Amount</name>
      <value>'.$amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$msisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>serviceId</name>
      <value>'.$service_id.'</value>
      </parameter>
      <parameter>
      <name>appVersion</name>
      <value>1.7</value>
      </parameter>
      <parameter>
      <name>Narration</name>
      <value>'.$Narration.'</value>
      </parameter>
      <parameter>
      <name>PrefLang</name>
      <value>en</value>
      </parameter>
      <parameter>
      <name>OpCoID</name>
      <value>23701</value>
      </parameter>
      </ns1:processRequest>
      </soapenv:Body>
      </soapenv:Envelope>
      ';

      /*$pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';*/

      //print_r($headers);
      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME')
            {
              $arr_name[$i++] = $value['value'];
            }

            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));
      $arr2 = array_combine($arr, $arr1);
      return $arr2;
   }
   public function send_Deposit_ByAdmin($user_id,$msisdn,$amount){

      //global $wpdb;
      
      
      // $rowdata = get_user_meta( $user_id , 'diaspo_user_phone', true );
      // $country_code = get_user_meta( $user_id , 'country_flag_code', true );
      // echo $msisdn = $country_code.$rowdata;die;
      $Narration = '';
      $left_reward_points = get_user_meta($user_id, 'left_reward_points', true);
      $lang = get_user_meta( $user_id, 'diaspo_user_language', true );
      $message = '';
      $subject = ''; 
      $user_info = get_userdata($user_id);
      $to = $user_info->user_email;
      
      $sp_id = get_option('sp_id'); 
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip'); 
      $service_id = get_option('service_id');
            
      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/DepositMobileMoney/v17";

      $nonce = rand();
      $rand = rand(3, 4);
      date_default_timezone_set('Africa/Douala');
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;

      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
      <soapenv:Header>
      <ns1:RequestSOAPHeader xmlns:ns1="http://www.huawei.com.cn/schema/common/v2_1">
      <ns1:spId>'.$spID.'</ns1:spId>
      <ns1:spPassword>'.$PasswordDigest.'</ns1:spPassword>
      <ns1:timeStamp>'.$createdDate.'</ns1:timeStamp>
      </ns1:RequestSOAPHeader>
      </soapenv:Header>
      <soapenv:Body>
      <ns1:processRequest xmlns:ns1="http://b2b.mobilemoney.mtn.zm_v1.0/">
      <serviceId>diaspoCC</serviceId>
      <parameter>
      <name>Amount</name>
      <value>'.$amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$msisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>serviceId</name>
      <value>'.$service_id.'</value>
      </parameter>
      <parameter>
      <name>appVersion</name>
      <value>1.7</value>
      </parameter>
      <parameter>
      <name>Narration</name>
      <value>'.$Narration.'</value>
      </parameter>
      <parameter>
      <name>PrefLang</name>
      <value>en</value>
      </parameter>
      <parameter>
      <name>OpCoID</name>
      <value>23701</value>
      </parameter>
      </ns1:processRequest>
      </soapenv:Body>
      </soapenv:Envelope>
      ';

      /*$pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';*/

      //print_r($headers);
      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      /*curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);*/     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
         foreach ($value as $key_1 => $value_val) {
            if($key_1 == "tag" || $key_1 == "value") {
               if($value['tag'] == 'NAME')
               {
                 $arr_name[$i++] = $value['value'];
               }

               if($value['tag'] == 'VALUE') {
                 $arr_val[$j++] = $value['value'];
               }

            }
         }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));
      $arr2 = array_combine($arr, $arr1);
      return $arr2;
   }
   public function send_Deposit_ByUser($data){


      global $wpdb;
      date_default_timezone_set('Africa/Douala');
      $user_id = $data['user_id'];
      $time = date('Y-m-d h:i:s');
      $nonce = rand();
      $currency_type_amount = $data['transfer_amount'];
      $fullname = $data['fullname'];
      $senderMsisdn = $data['senderMsisdn'];
      $sp_id = get_option('sp_id');
      $sp_password = get_option('sp_password');
      $testbed_ip = get_option('testbed_ip');
      $service_id = get_option('service_id');
      //$country_name = $data['country_name'];

      $url = "https://".$testbed_ip.":8443/ThirdPartyServiceUMMImpl/UMMServiceService/RequestPayment/v17";
     
      $createdDate = date('Ymd');
      $createdTime = date('His');
      $created = $createdDate.$createdTime;
      $spID = $sp_id;
      $password = $sp_password;     
      $PasswordDigest = md5($spID.$password.$createdDate);

      $headers = array(
      "Content-type: text/xml;charset=\"utf-8\"",
      "Content-Length:569",
      "Host:127.0.0.1",
      "Cookie: sessionid=default8fcee064690b45faa9f8f6c7e21c6e5a"
      ); 

      $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
      <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Header>
      <ns2:RequestSOAPHeader xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0" xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1">
      <spId>'.$spID.'</spId>
      <spPassword>'.$PasswordDigest.'</spPassword>

      <timeStamp>'.$createdDate.'</timeStamp>
      </ns2:RequestSOAPHeader>
      </soap:Header>
      <soap:Body>
      <ns3:processRequest xmlns:ns2="http://www.huawei.com.cn/schema/common/v2_1" xmlns:ns3="http://b2b.mobilemoney.mtn.zm_v1.0">
      <serviceId>DiaspoCC</serviceId>
      <parameter>
      <name>DueAmount</name>
      <value>'.$currency_type_amount.'</value>
      </parameter>
      <parameter>
      <name>MSISDNNum</name>
      <value>'.$senderMsisdn.'</value>
      </parameter>
      <parameter>
      <name>ProcessingNumber</name>
      <value>'.$nonce.'</value>
      </parameter>
      <parameter>
      <name>CurrCode</name>
      <value>XAF</value>
      </parameter>
      <parameter>
      <name>SenderID</name>
      <value>DiaspoCC</value>
      </parameter>
      </ns3:processRequest>
      </soap:Body>
      </soap:Envelope>';

      $to = "test5@kit-services.com,votiveyogesh@gmail.com,votivephp.prashant@gmail.com";
      $subject = "TESTBED URL - Send Request";
      $txt = $xml_post_string;
      $headers = "From: info@diaspo-cc.com," . "\r\n";
      mail($to,$subject,$txt,$headers);

      $pemfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/client_certnew.pem';
      $keyfile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/private_MoMo_SHA1_07042017.key';
      $caFile = $_SERVER['DOCUMENT_ROOT'].'/certificates_MTN/MTN_root_ca.pem';
      $certPass = 'ZHDqdw7y243zpDD';

      // PHP cURL  for https connection with auth
      $ch = curl_init();
      //Added on 07.04.17 for logging
      curl_setopt($ch, CURLOPT_VERBOSE, true);
      $curl_log = fopen("curl.txt", 'w+');
      curl_setopt($ch, CURLOPT_STDERR, $curl_log);
      //Logging Partially End
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM'); 
      curl_setopt($ch, CURLOPT_SSLKEY, $keyfile);
      curl_setopt($ch, CURLOPT_CAINFO, $caFile);
      curl_setopt($ch, CURLOPT_SSLCERT, $pemfile); 
      curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $certPass);     
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      //Added on 10.04.17 for handling error "100-continue"
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      // converting
      $response = curl_exec($ch);
      curl_close($ch);
      $xml = simplexml_load_string($response);
      $xml_parser = xml_parser_create();
      xml_parse_into_struct($xml_parser, $response, $vals, $index);
      xml_parser_free($xml_parser);
      $arr_name =  array();
      $arr_val =  array();
      $i=0;
      $j = 0;
      foreach ($vals as $key => $value) {
        foreach ($value as $key_1 => $value_val) {
          if($key_1 == "tag" || $key_1 == "value") {
            if($value['tag'] == 'NAME') {
              $arr_name[$i++] = $value['value'];
            }
            if($value['tag'] == 'VALUE') {
              $arr_val[$j++] = $value['value'];
            }

          }
        }
      }

      $arr = array_values(array_unique($arr_name));
      $arr1 = array_values(array_unique($arr_val));

      if(count($arr) != count($arr1))
      { 
        $arr1[] = '';
      }
      $arr2 = array_combine($arr, $arr1);

      return $arr2;
   }







   public function count($total, $per_page, $current_page){

      $count = $total/$per_page;      
      if (is_float($count))
      {
        $count = intval($count)+1;
      }
      else
      {
         $count = intval($count);
      }
      return $count;

   }
   
  
}