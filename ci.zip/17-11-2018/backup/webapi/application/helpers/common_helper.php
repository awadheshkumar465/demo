<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// require $_SERVER['DOCUMENT_ROOT'].'/blocktrail/vendor/autoload.php';
// use Blocktrail\SDK\BlocktrailSDK;
// use Blocktrail\SDK\Wallet;
// use Blocktrail\SDK\WalletInterface;
// use Blocktrail\SDK\Connection\Exceptions\ObjectNotFound;


    if(!function_exists('Request'))
    {
        function Request()
        {
        if ($_POST){
            $param = $_POST;
        }else{
            $param = json_decode(file_get_contents("php://input"),true);
        }  
        return $param;
        }
    }

    // if(!function_exists('client'))
    // {
    //     function client() {

    //         //Wallet Creation

    //         $myAPIKEY       = "";//get_option('blocktrail_api_key');echo"<br>";
    //         $myAPISECRET    = "";//get_option('blocktrailsecret');echo"<br>";
    //         $testnet        = true;echo"<br>"; //false for bitcoin mainnet or true for 
    //         try { // Initialize the SDK                
    //             $client = new BlocktrailSDK($myAPIKEY, $myAPISECRET, "BTC", $testnet);            
    //         } catch (Exception $e) {
    //             $client = "Initializing the SDK failed because {$e->getMessage()}";
    //         }
    //         return $client;
    //     }
    // }





    // if(!function_exists('Not_found'))
    // {
    //     function Not_found()
    //     {
    //         $Error = array( 'code' => "404",
    //                         'status' => "false",
    //                         'message' =>"Page Not Found",
    //                         'response' => array('description' => "We could not find the resource you requested. Please refer to the documentation for the list of resources")
    //                         //The page you are looking for could not be found.
    //                         ); 
    //       return $Error;
    //     }
    // }
    // if(!function_exists('Server_error'))
    // {
    //     function Server_error()
    //     {
    //         $Error = array('code' => "500",
    //                          'status' => "false",
    //                          'message' => "Unexpected internal server error.",
    //                          'response' => array('description' => "We could not find the resource you requested. The server encountered an unexpected internal server error")
    //                         ); 
    //       return $Error;
    //     }
    // }

    // if(!function_exists('Created'))
    // {
    //     function Created($results)
    //     {
    //         $Success = array(   'code' => "201",
    //                             'status' => "true",
    //                             'message' => "",
    //                             'response' => $results
    //                         ); 
    //       return $Error;
    //     }
    // }

    // if(!function_exists('Ok'))
    // {
    //     function Ok($results)
    //     {
    //         $Success = array(   'code' => "200",
    //                             'status' => "true",
    //                             'message' => "",
    //                             'response' => $results
    //                         ); 
    //       return $Error;
    //     }
    // }






/*__________________________ Common Query _____________________*/
    


/*    //Update
    if(!function_exists('UR'))
    {
        function UR($t, $pd, $wc)
        {
            $ci =&get_instance();
            $ci->db->where($wc);
            $q = $ci->db->update($t,$pd);
            return $q;
        }
    }

    //select single by id
    if(!function_exists('SR'))
    {
        function SR($t,$c)
        {
            $ci =&get_instance();
            $q = $ci->db->get_where($t,$c)->row_array();
            return $q;
        }
    }


    if(!function_exists('AR'))
    {
        function AR($t,$c)
        {
            $ci =&get_instance();
            $q = $ci->db->get_where($t,$c)->result_array();
            return $q;
        }
    }

    


    //Insert record 
    if(!function_exists('IR'))
    {
        function IR($t,$pd)
        {
            $ci =&get_instance();
            $ci->db->insert($t,$pd);
            return $ci->db->insert_id();
        }
    }
    //Count Record
    if(!function_exists('CR'))
    {
        function CR($t,$c)
        {
            $ci =&get_instance();
            $q = $ci->db->get_where($t,$c)->num_rows();
            return $q;
        }
    }

    //select single by id
    if(!function_exists('TR'))
    {
        function TR($t)
        {
            $ci =&get_instance();
            $q = $ci->db->get($t)->result_array();
            return $q;
        }
    }*/

    if(!function_exists('p')) {
        function p($array) {
            echo '<pre>';
            print_r($array);
            echo '</pre>';die;
        }
    }
    //Time
    if ( ! function_exists('ftime'))
    {
        function ftime($time,$f) {
                  if (gettype($time)=='string') 
                  $time = strtotime($time);  
                
                  return ($f==24) ? date("G:i", $time) : date("g:i a", $time);  
                }
    }
/*-------------------------- Common Query ---------------------*/


/*__________________________ Common Query _____________________*/
    //Insert single record in Table
    if(!function_exists('InsertData')) {
        function InsertData($table,$array)
        {
            $ci =&get_instance();
            $ci->db->insert($table,$array);
            return $ci->db->insert_id();
        }
    }
    //Insert Bulk Record in Table 
    if(!function_exists('InsertButch')) {
        function InsertButch($table,$array)
        {
            $ci =&get_instance();
            $ci->db->insert_batch($table,$array);
            return $ci->db->affected_rows(); 
        }
    }
    //Update Data by id And return true/false
    if(!function_exists('UpdateData')) {
        function UpdateData($table, $array, $condition)
        {
            $ci =&get_instance();
            $ci->db->where($condition);
            $results = $ci->db->update($table,$array);
            return $results;
        }
    }
    //Update Data by id and Get updated Data
    if(!function_exists('UpdateRecord')) {
        function UpdateRecord($table, $array, $condition)
        {
            $ci =&get_instance();
            $ci->db->where($condition);
            $update = $ci->db->update($table,$array);            
            if ($update == 1) {$results = $ci->db->get_where($table,$condition)->result_array();}            
            return $results;
        }
    }
    //Update bulk Data by Column name
    if(!function_exists('UpdateButch')) {
        function UpdateButch($table, $array, $condition)
        {
            $ci =&get_instance();
            $ci->db->update_batch($table, $array, $condition);
            $results = $ci->db->affected_rows();                    
            return $results;
        }
    }
    //Get Data in Array Formate
    if(!function_exists('GetData')) {
        function GetData($table,$condition="",$colum="",$orderby='ASC',$limit="",$start="0")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}
            $results['count'] = (string)$ci->db->get($table)->num_rows();
            if($colum) { $ci->db->order_by($colum,$orderby);}
            if($limit) { 
                $ci->db->limit($limit, $start);
                $results['limit'] = $limit;
                $divide = $results['count']/$limit;
                $number = intval($divide,0);
                if(fmod($divide, 1) !== 0.00){ $results['lastoffset'] = $number;
                }elseif ($divide == 0) { $results['lastoffset'] = 0;
                }else{$results['lastoffset'] = $number-1; }                
            }
            if ($condition) { $ci->db->where($condition);}            
            $results['data'] = $ci->db->from($table)->get()->result_array();           
            return $results;
        }        
    }
    //Get Data in Array Formate
    if(!function_exists('all_Data')) {
        function all_Data($table,$condition="")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}            
            $results = $ci->db->from($table)->get()->result_array();           
            return $results;
        }        
    }
    //Get Data in Array Formate
    if(!function_exists('all_Record')) {
        function all_Record($table,$condition="")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}            
            $results = $ci->db->from($table)->get()->result();           
            return $results;
        }        
    }
    if(!function_exists('Get_Data')) {
        function Get_Data($table,$condition="")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}            
            $results = $ci->db->from($table)->get()->row_array();           
            return $results;
        }        
    }
    //Get Data in Array Formate
    if(!function_exists('Get_Record')) {
        function Get_Record($table,$condition="")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}            
            $results = $ci->db->from($table)->get()->row();           
            return $results;
        }        
    }

    //Get RecordGet in Object Formate
    if(!function_exists('GetRecord')) {
        function GetRecord($table,$condition="",$colum="",$orderby='ASC',$limit="",$start="0")
        {
            $ci =&get_instance();
            $results = array();
            if ($condition) { $ci->db->where($condition);}
            $results['count'] = (string)$ci->db->get($table)->num_rows();
            if($colum) { $ci->db->order_by($colum,$orderby);}
            if($limit) { 
                $ci->db->limit($limit, $start);
                $results['limit'] = $limit;
                $divide = $results['count']/$limit;
                $number = intval($divide,0);
                if(fmod($divide, 1) !== 0.00){ $results['lastoffset'] = $number;
                }elseif ($divide == 0) { $results['lastoffset'] = 0;
                }else{$results['lastoffset'] = $number-1; }                
            }
            if ($condition) { $ci->db->where($condition);}            
            $results['data'] = $ci->db->from($table)->get()->result();           
            return $results;
        }        
    } 
    //Get sum and avrage in array Formate
    if(!function_exists('GetSumAvg')) {
        function GetSumAvg($table,$colum,$condition="")
        {
            $ci =&get_instance();
            if ($condition) { $ci->db->where($condition);}
            $sum = $ci->db->select_sum($colum)->get($table)->row_array();
            $result['sum'] = $sum[$colum];
            if ($condition) { $ci->db->where($condition);}
            $avg = $ci->db->select_avg($colum)->get($table)->row_array();
            $result['avg'] = $avg[$colum];    
            return $result;
        }        
    }
    //Count Record in integer format
    if(!function_exists('CountData')) {
        function CountData($table,$condition="")
        {
            $ci =&get_instance();
            if ($condition) { $ci->db->where($condition);}
            $ci->db->from($table);
            $query = $ci->db->get();            
            $results = $query->num_rows();            
            return $results;
        }
    }
/*-------------------------- Common Query ---------------------*/

/*__________________________ Languge __________________________*/
    if(!function_exists('getlanguge'))
    {
        function getlanguge($uid)
        {
           $ci =&get_instance();
           $data = $ci->db->get_where(USERS,array("user_id" => $uid))->row_array();         
            $uid = $data["user_language"];
            return $uid;
        }
    }
    if(!function_exists('message'))
    {
        function message($word)
        {
            global $user_language;        
            $ci =&get_instance();            
            $data = $ci->db->get_where(MESSAGE,array("id" => $word))->row_array();            
            if ($user_language == 'ar') {
                $word = $data["arabic"];   
            }else{
                $word = $data["english"];    
            }
            return $word;
        }
    }
/*-------------------------- Languge --------------------------*/

/*__________________________ Send Mail _________________________*/
    if ( ! function_exists('sendEmail'))
    {
        function sendEmail($email,$subject,$message)
        {
            // print_r($email);print_r($subject);print_r($message);die;
            $ci =&get_instance();
            $from = "info@1apextech.com";
            $ci->load->library('email');
            $config['protocol']    = 'smtp';
            $config['smtp_host']    = 'ssl://smtp.gmail.com';
            $config['smtp_port']    = '465';
            $config['smtp_timeout'] = '7';
            $config['smtp_user']    = 'votive.prateek@gmail.com';;
            $config['smtp_pass']    = 'votive123';
            $config['charset']    = 'utf-8';
            $config['newline']    = "\r\n";
            $config['mailtype'] = 'html'; 
            $config['validation'] = 1;      
            $ci->email->initialize($config);
            //$fromname = "Sales Team";
            $fromemail = $from;
            $mpass = "votive123";
            $to = $email;
            $from = $from;
            $subject=$subject;
            $message=$message;
            $cc=0;
              $ci->email->from($fromemail);
              $ci->email->to($to);
              $ci->email->subject($subject);       
              $ci->email->message($message);
              //$ci->email->attach('C:\Users\xyz\Desktop\images\abc.png');  
                if($cc) {
                    $ci->email->cc($cc);
                }
               /* if(!empty($bcc)){
                    $this->email->bcc($bcc);
                } */

            if(!$ci->email->send()){
              return $ci->email->print_debugger();
            }
            else{
              return 1;
            }
        }
    }
    if ( ! function_exists('send_mail'))
    {
        function send_mail($msg, $subject, $useremail)
        {          
            $ci =&get_instance();
            $ci->load->library('email');
            $config['mailtype']='html';
            $ci->email->initialize($config);    
            $ci->email->from('no-reply@kit-services.com');
            $ci->email->to($useremail);
            $ci->email->subject($subject);
            $ci->email->message($msg);
            
            if($ci->email->send()) {    
                return true;
            } else {
                return false;
            }
        }
    }
/*-------------------------- Send Mail -------------------------*/


/*__________________________ Notification ______________________*/

    if(!function_exists('send_Notification')) {
        function send_Notification($input) { 

            //print_r($input);die;
            $device_token = $input['noti_deviceid'];
            $user_id = $input['noti_userid'];
            $order_id = $input['noti_orderid'];
            $target = $input['noti_deviceid'];//$_POST['target'];
            $title = $input['noti_title'];
            $description = $input['noti_desc'];
            //$supervisor_id = $input['supervisor_id'];
            $active_methods = array();

            $error = '';
            $error_sess = '';

            //$user_token = get_user_meta( $userid, '_token_id', true );die;

                if(empty($device_token) ) {
                   $error = 'Require Field Missing';
                // } elseif ($user_token_id != $user_token) {
                //     $error_sess = 'Your account is currently logged onto another device.Do you want to continue with this device ?';
                } else {

                    //FCM API end-point
                    $url = 'https://fcm.googleapis.com/fcm/send';
                    //api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
                    $server_key = 'AIzaSyDjI1nq1_3w0TIdtV3F8ub4Erxib85byrk';
                    $data = array("via"=>"EPCO", "title"=>$title, "description"=>$description, "order_id" => $order_id);
                    $fields = array();
                    $fields['data'] = $data;    
                        if(is_array($target)){
                            $fields['registration_ids'] = $target;
                        }else{
                            $fields['to'] = $target;
                        }
                        // print_r($input);die;

                        //header with content_type api key
                        $headers = array(
                        'Content-Type:application/json',
                          'Authorization:key='.$server_key
                        );
                        //CURL request to route notification to FCM connection server (provided by Google)  
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                        $result = curl_exec($ch);

                        if ($result === FALSE) {
                            return false;
                        }

                        curl_close($ch);
                        $jsn =json_decode($result);                
                        if($jsn->success){
                            return true;
                            
                        }else{
                            return true;
                           
                        }
                    }
        }
    }

    //Test notification

    if(!function_exists('testNotification'))
    {
        function testNotification()
        { 
            $device_token = $_REQUEST['device_token'];
            $userid = $_REQUEST['userid'];
            $user_token_id = $_REQUEST['token_id'];
            $target = $_REQUEST['target'];
            $title = $_REQUEST['title'];
            $description = $_REQUEST['description'];
            $active_methods = array();

            $error = '';
            $error_sess = '';

            $user_token = get_user_meta( $userid, '_token_id', true );

            if( empty($device_token) ) {
               $error = 'Require Field Missing';
            } 
            elseif ($user_token_id != $user_token) {
            $error_sess = 'Your account is currently logged onto another device.Do you want to continue with this device ?';
            }else {

                //FCM API end-point
                $url = 'https://fcm.googleapis.com/fcm/send';
                //api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
                $server_key = 'AAAAmGIOx8Y:APA91bHgsRHP-jGk7o82oRV_uuGMEfYRnT9r3eDmVTMHKlKnemKkE_0TmygkOR_fKP_KDFj7mFvK5aa6iRfwLMQBEo3pTZw5sw9xV_PHX5aFRy8jORRawbQAycVqxKPewa1l1JJM_WEF';
                $data = array("via"=>"Borex Poissons", "title"=>$title, "description"=>$description);
                $fields = array();
                $fields['data'] = $data;    
                if(is_array($target)){
                    $fields['registration_ids'] = $target;
                }else{
                    $fields['to'] = $target;
                }
                //header with content_type api key
                $headers = array(
                'Content-Type:application/json',
                  'Authorization:key='.$server_key
                );
                //CURL request to route notification to FCM connection server (provided by Google)  
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                $result = curl_exec($ch);
                if ($result === FALSE) {
                return false;
                }
                curl_close($ch);
                $jsn =json_decode($result);
                if($jsn->success){
                return true;
                }
                else{
                return true;
                }
            }
      
            $ar = array ("result" => 1, "message" => "success");
             echo json_encode($ar);
             exit();
        }
    }
/*-------------------------- Notification ----------------------*/


/*__________________________ Images Uploads ____________________*/
    if(!function_exists('imageUploads')) 
    {
        function imageUploads($image, $name, $folder){
            $imagename = array();
             $ci =&get_instance();
            // echo $folder;
            //  print_r($image);
            //   print_r($name);die;
            $config['upload_path'] = './uploads/'.$folder.'';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['encrypt_name'] = true;         
            $ci->load->library('upload', $config);
            if (!$ci->upload->do_upload($name))
            {
                
               $error = array('error' => $ci->upload->display_errors());
               //print_r($error); die;
            }
            else
            { 
                // if(!empty($image[$param])){
                // //unlink('./uploads/'.$folder.'/'.$image[$param]['name']);
                // }
                $image_name = array('upload_data' => $ci->upload->data());
                
                $imagename = $image_name['upload_data']['file_name'];  
                //$ci->output->clear_all_cache();                      
            }
            //print_r($imagename);die;
            return $imagename;
        }
    }
    if(!function_exists('multipulImage')) 
    {
        function multipulImage($image, $name, $folder){
            //echo $folder; die;

            //;print_r($name);//die;
            $imagename = array();
            $ci =&get_instance();
            foreach ($name as $param) {                
                if (array_key_exists($param, $image) && ($image[$param] != '')) {
                    //$b = $image[$param]; print_r($b);die;
                    $config['upload_path'] = './uploads/'.$folder.'';
                    $config['allowed_types'] = 'gif|jpg|png';
                    $config['encrypt_name'] = true;         
                    $ci->load->library('upload', $config);
                    if (!$ci->upload->do_upload($param))
                    {
                        $error = array('error' => $ci->upload->display_errors());
                    }
                    else
                    { 
                        // if(!empty($image[$param])){
                        // //unlink('./uploads/'.$folder.'/'.$image[$param]['name']);
                        // }
                        $image_name = array('upload_data' => $ci->upload->data());
                        
                        $imagename[$param] = $image_name['upload_data']['file_name'];   
                        //$ci->output->clear_all_cache();                     
                    }                                       
                }
            }
            //print_r($imagename);die;
            return $imagename;           
        }
    }
/*-------------------------- Images Uploads --------------------*/

/*__________________________ Cheack Required Field ______________*/


    /* For only cheack reqiuired paremeter*/

    if(!function_exists('check_required_value')) {
        function check_required_value($chk_params, $converted_array) {
            if (!empty($converted_array)) {
                foreach ($chk_params as $param) {
                    if (array_key_exists($param, $converted_array) && ($converted_array[$param] != '')) {
                        $Error = 0;
                    } else {
                        $Error = array('code' => '0', 'name' => 'Missing parameter','status' => 'false', 'message' => "".ucfirst($param).": Required parameter missing", 'response' => new stdclass);
                        break;
                    }
                }               
            }else{
                $Error = array('code' => '0', 'name' => 'Rong format','status' => 'false', 'message' => "Json format is not correct, please check your Json syntax.", 'response' => new stdclass);
            }
            return $Error;
        }
    }


    if(!function_exists('checkvalid')) {
        function checkvalid($chk_params, $converted_array) {
            if (empty($converted_array)) {
               $Error = array('code' => '0', 'name' => 'Rong format','status' => 'false', 'message' => "Json format is not correct, please check your Json syntax.", 'response' => new stdclass);
            }else{
                foreach ($chk_params as $param) {
                    if (array_key_exists($param, $converted_array) && ($converted_array[$param] != '')) {
                        $Error = 0;
                    } else {
                        $Error = array('code' => '0', 'name' => 'Missing parameter','status' => 'false', 'message' => "".ucfirst($param).": Required parameter missing", 'response' => new stdclass);
                        break;
                    }
                }                
                if ($Error == 0) {

                    $userdata = get_user_meta($converted_array['user_id'],'deviceid',true);   

                    if ($userdata != $converted_array['deviceid']) {
                        $Error = array( 'code' => '9', 'name' => 'Already Login',
                                        'status' => 'true', 'message' =>"You are already logged in some other device. Do you want to login in this device ?", 
                                        'response' => array('user_id' => $converted_array['user_id'])
                                    );
                    }else{
                        $Error = 0;
                    }
                } 
            }
        


            return $Error;
        }
    }
/*-------------------------- Cheack Required Field --------------*/

/*__________________________ SMS API ____________________________*/

    if(!function_exists('smsapi')) 
    {
      function smsapi($otp,$mobile){

        $sid = 'ACf3c15917b08e13ca3ae4c5bb91839065';
        $token = '57bd920870e7a35862931fcf3333cd86';
        $client = new Client($sid, $token);
        // Use the client to do fun stuff like send text messages!
        $client->messages->create(
            // the number you'd like to send the message to
            //'+91'.$mobile,
            '+972'.$mobile,
            array(
                // A Twilio phone number you purchased at twilio.com/console
                'from' => '+972526285726',
                // the body of the text message you'd like to send
                'body' => $otp. "Please verify this otp in v12mobile"
            )
        );
      }
    }

    if(!function_exists('sendsmsapi')) 
    {
      function sendsmsapi($otp,$phone){

        $toNumber = $phone;
          $fromNumber = get_option('from_number');
          $messageFormate = get_option('body_message');
          $messageWOTP = $messageFormate.' http://dsp.lab.kit-services.com: '.$otp;
          $send = sendSms($toNumber, $fromNumber, $messageWOTP);
      }
    }

    
/*-------------------------- SMS API ----------------------------*/

    /* For valid Login and valid jeson formate or cheack reqiuired paremeter*/
    if(!function_exists('check_required_and_valid')) {
        function check_required_and_valid($chk_params, $converted_array) {
            if (empty($converted_array)) {
               $Error = array('status' => '201', 'message' => message('1'), 'response' => new stdclass);
            }else{
                foreach ($chk_params as $param) {
                    if (array_key_exists($param, $converted_array) && ($converted_array[$param] != '')) {
                        $Error = 0;
                    } else {
                        $Error = array('status' => '203', 'message' => message('3').strtoupper($param), 'response' => new stdclass);
                        break;
                    }
                }                
                if ($Error == 0) {
                    $ci =&get_instance();
                    $userdata = $ci->db->get_where(USERS, array("user_id" => $converted_array['user_id'], "is_online" => 1))->row_array(); 
                    if (!empty($userdata)) {
                        if ($userdata['status'] == "1") {                        
                            if ($userdata['device_id'] != $converted_array['device_id'] && $userdata['is_online'] == "1") {
                                $Error = array('status' => '202', 'message' => message('2'), 'response' => array('user_id' => $converted_array['user_id'])); 
                            }else{
                                $Error = 0;
                            }
                        }else{
                            $Error = array('status' => '206', 'message' =>  message('8'), 'response' => new stdclass);

                        }                       
                    }else{
                        $Error = array('status' => '100', 'message' =>  message('5'), 'response' => new stdclass);
               
                    }
                   
                }
            }

            return $Error;
        }
    }

if (!function_exists('Results')) {
function Results($code,$results,$message="") {
    switch ($code) {
      case 100: $response = array('code' => '100', 'name' => 'Continue', 'status' => 'true', 'message' => $message, 'response' => $results?$results:new stdclass); break;
      case 101: $response = array('code' => '101', 'name' => 'Switching Protocols', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 200: $response = array('code' => '200', 'name' => 'OK', 'status' => 'true', 'message' => $message, 'response' => $results?$results:new stdclass); break;
      case 201: $response = array('code' => '201', 'name' => 'Created', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 202: $response = array('code' => '202', 'name' => 'Accepted', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 203: $response = array('code' => '203', 'name' => 'Non-Authoritative Information', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 204: $response = array('code' => '204', 'name' => 'No Content', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 205: $response = array('code' => '205', 'name' => 'Reset Content', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 206: $response = array('code' => '206', 'name' => 'Partial Content', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 300: $response = array('code' => '300', 'name' => 'Multiple Choices', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 301: $response = array('code' => '301', 'name' => 'Moved Permanently', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 302: $response = array('code' => '302', 'name' => 'Moved Temporarily', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 303: $response = array('code' => '303', 'name' => 'See Other', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 304: $response = array('code' => '304', 'name' => 'Not Modified', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 305: $response = array('code' => '305', 'name' => 'Use Proxy', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 400: $response = array('code' => '400', 'name' => 'Bad Request', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 401: $response = array('code' => '401', 'name' => 'Unauthorized', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 402: $response = array('code' => '402', 'name' => 'Payment Required', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 403: $response = array('code' => '403', 'name' => 'Forbidden', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 404: $response = array('code' => '404', 'name' => 'Not Found', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 405: $response = array('code' => '405', 'name' => 'Method Not Allowed', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 406: $response = array('code' => '406', 'name' => 'Not Acceptable', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 407: $response = array('code' => '407', 'name' => 'Proxy Authentication Required', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 408: $response = array('code' => '408', 'name' => 'Request Time-out', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 409: $response = array('code' => '409', 'name' => 'Conflict', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 410: $response = array('code' => '410', 'name' => 'Gone', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 411: $response = array('code' => '411', 'name' => 'Length Required', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 412: $response = array('code' => '412', 'name' => 'Precondition Failed', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 413: $response = array('code' => '413', 'name' => 'Request Entity Too Large', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 414: $response = array('code' => '414', 'name' => 'Request-URI Too Large', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 415: $response = array('code' => '415', 'name' => 'Unsupported Media Type', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 500: $response = array('code' => '500', 'name' => 'Internal Server Error', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 501: $response = array('code' => '501', 'name' => 'Not Implemented', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 502: $response = array('code' => '502', 'name' => 'Bad Gateway', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 503: $response = array('code' => '503', 'name' => 'Service Unavailable', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 504: $response = array('code' => '504', 'name' => 'Gateway Time-out', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 505: $response = array('code' => '505', 'name' => 'HTTP Version not supported', 'status' => 'true', 'message' => $message, 'response' => $results); break;
      case 0: $response = array('code' => '0', 'name' => 'Error', 'status' => 'false', 'message' => $message, 'response' => $results?$results:new stdclass); break;
        default:
            exit('Unknown http status code "' . htmlentities($code) . '"');
        break;
    }

return $response;

}
}