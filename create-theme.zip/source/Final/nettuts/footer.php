</div>

<?php get_sidebar(); ?>

<p>Copyright anyone, 2009.</p>

</div>

<?php wp_footer(); ?>
</body>
</html>