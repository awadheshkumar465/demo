wp-frontend-login
=================

Front-end account management (register/login/change password) for Wordpress.

More at 
http://cubiq.org/front-end-user-registration-and-login-in-wordpress

