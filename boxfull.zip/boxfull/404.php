<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<div class="error_main_out">
		

			<section class="main_error">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<div class="error_page">
								<div class="error_img main-eror-msg">
							    	<h1>404</h1>
							    	<p>Page not found</p>
							    	<div class="page-title">Oops! That page can’t be found.</div>
							    </div>
							    <div class="home_link">
							    
							    	<?php twentysixteen_the_custom_logo(); ?>
							    </div>
						    </div>
						</div>
					</div>
				</div>
			</section>


	

	</div><!-- .content-area -->


<?php get_footer(); ?>
