<?php 
/* Add New Regions HTML Starts Here */
if($type=='addnewregion'){ ?>
<div class="col-md-12">
<form method="POST" action="" id="addnewregion" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">Region Name:<span class="requiredpart">*</span></label>
<input type="text" class="newregionpost" name="newregionpost" class="form-control" id="newregionpost" value="" required>
</div>

<div class="form-group">
<label for="titles">Region Discription:</label>
<textarea name="newregiondescription" rows="10" cols="20"></textarea>
</div>
<input type="hidden" name="addnew_region" id="addnew_region" value="true" />
<?php wp_nonce_field( 'post_nonce', 'post_nonce_field_addnewregion' ); ?>
<input type="submit" class="btn btn-default addnewregion" value="Submit">
</form>
</div>
<?php
}
/* Add New Regions HTML Ends Here */
if(isset($_POST['post_nonce_field_addnewregion'])){
//print_r($_POST);
$regionName = $_POST['newregionpost'];
$regionDescription = $_POST['newregiondescription'];
$insertregions= wp_insert_term(
$regionName, // the term 
'country', // the taxonomy
array(
'description'=> $regionDescription,
'parent'=> ''
)
);
if(insertregions){
wp_redirect(get_the_permalink()."/?type=allregions");
exit;
}
}
?>