<?php 
if($type=='addschedulecategory'){
	global $wpdb;
	$html='';
	if(isset($_POST['schedulecategory'])){
		//print_r($_POST);
		 $schedule_category_title = $_POST['schedulecategory'];
		$schedule_keyword_title = $_POST['schedulekeyword'];
		foreach($_POST['schedulekeyword'] as $keyword_values){
			$insert = $wpdb->insert('wp_schedule_category_keyword', array(
			'schedule_category' =>$schedule_category_title,
			'schedule_keyword' =>$keyword_values,
			)); 
			$lastid = $wpdb->insert_id; 
		}
		if($lastid>0){
	?>
	<script type="text/javascript">
	alert ("Schedule Category And Keywords Added Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=show_schedule_category_keyword_lists";
	</script>
	<?php 
}
		
	}
	else {
	$html='
		<h2>Add Category / Keyword </h2>
		<form method="POST" action="" id="addnewcategory" >
			<div class="form-group ">
				<label for="titles">Category Name:<span class="requiredpart">*</span></label>
				<input type="text" class="newregionpost" name="schedulecategory" id="schedulecategory" value="" required="">
			</div>
			<div class="form-group input_fields_container">
				<label for="titles">Keyword :<span class="requiredpart">*</span></label>
				<input type="text" class="newregionpost" name="schedulekeyword[]" id="schedulekeyword" value="" required="">
				<button class="btn btn-sm btn-primary add_more_button">Add More
			</div>
			<input type="submit" name="schedulecategorykeywordform" value="Submit" >
		</form>	
	';
	}
	echo $html;
}