<?php
if($type=='setupadminmessages'){
	echo "<h2>Set Up Admin Messages</h2>"
?>
<form method="POST" action="" class="st_adm_msg">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label>Signup</label>
					<textarea class="form-control" rows="2" placeholder="" name="signup_message"><?php echo $signup_message = trim(get_option('signup_message')); ?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>Forget password</label>
					<textarea class="form-control" rows="2" placeholder="" name="forget_password_message"><?php $forget_password_message = get_option('forget_password_message'); 
					if(!empty($forget_password_message)){echo $forget_password_message;}?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>New Order</label>
					<textarea class="form-control" rows="2" placeholder="" name="new_order_message"><?php $new_order_message = get_option('new_order_message'); 
						if(!empty($new_order_message)){echo $new_order_message;}
					?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>Profile information change</label>
					<textarea class="form-control" rows="2" placeholder="" name="profile_info_change_message"><?php $profile_info_change_message = get_option('profile_info_change_message'); 
					if(!empty($profile_info_change_message)){echo $profile_info_change_message;}
					?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>Schedule a return</label>
					<textarea class="form-control" rows="2" placeholder="" name="scheduleareturn_message"><?php $scheduleareturn_message = get_option('scheduleareturn_message'); 
					if(!empty($scheduleareturn_message)){echo $scheduleareturn_message;}
					?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>Schedule a pickup</label>
					<textarea class="form-control" rows="2" placeholder="" name="scheduleapickup_message"><?php $scheduleapickup_message = get_option('scheduleapickup_message'); 
					if(!empty($scheduleapickup_message)){echo $scheduleapickup_message;}?></textarea>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<label>Payment Received</label>
					<textarea class="form-control" rows="2" placeholder="" name="payment_received_message"><?php $payment_received_message = get_option('payment_received_message'); 
					if(!empty($payment_received_message)){echo $payment_received_message;}
					?></textarea>
				</div>
			</div>
			<input type="submit" name="submit">
		</div>
	</div>
</form>
<!--
<div class="table-responsive">
	<table class="table table-striped table-bordered">
		<tr>
			<th class="sr_no">No.</th>
			<th>No.</th>
			<th>No.</th>
			<th>No.</th>
			<th>No.</th>
			<th class="action">Action</th>
		</tr>
		<tr>
			<td class="sr_no">1</td>
			<td>Check</td>
			<td>Bank</td>
			<td>Bank</td>
			<td>Bank</td>
			<td class="action">
				<a href="#" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
				<a href="#" class="del_btn"><i class="fa fa-trash" aria-hidden="true"></i></a>
			</td>
		</tr>
	</table>
</div>-->

<?php 
	if(isset($_POST['submit'])){
		$signup_message=trim($_POST['signup_message']);
		$forget_password_message=trim($_POST['forget_password_message']);
		$new_order_message=trim($_POST['new_order_message']);
		$profile_info_change_message=trim($_POST['profile_info_change_message']);
		$scheduleareturn_message=trim($_POST['scheduleareturn_message']);
		$scheduleapickup_message=trim($_POST['scheduleapickup_message']);
		$payment_received_message=trim($_POST['payment_received_message']);

		update_option('signup_message',$signup_message);
		update_option('forget_password_message',$forget_password_message);
		update_option('new_order_message',$new_order_message);
		update_option('profile_info_change_message',$profile_info_change_message);
		update_option('scheduleareturn_message',$scheduleareturn_message);
		update_option('scheduleapickup_message',$scheduleapickup_message);
		update_option('payment_received_message',$payment_received_message);
	}
}