<?php
$districtid = $_GET['districtid'];

if(($type=='editdistrict')&&(!empty($districtid))){
$post_id = get_post($districtid); 
//print_r($post_id);
$postid= $post_id->ID;
$title = $post_id->post_title;
$terms = get_terms([
'taxonomy' => 'country',
'hide_empty' => false,
]);
$terms_names = get_the_terms($postid, 'country' );
foreach($terms_names as $termcategory){ $districtname = $termcategory->name;}

?>
<div class="col-md-12">
<form method="POST" action="" id="editdistrict" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">District Name:</label>
<input type="text" class="districtpost" name="districtpost" class="form-control" id="districtpost" value="<?php echo ucfirst($title);?>" required>
</div>

<div class="form-group">
<label for="titles">Select Regions:</label>

<?php 
echo '<select name="cat" id="cat" class="postform" tabindex="4">';
echo '<option class="level-0" value="'.$termcategory->term_id.' ">'.$termcategory->name.'</optin>';
foreach($terms as $regionterms){ 
echo '<option class="level-0" value="'.$regionterms->term_id.' ">'.$regionterms->name.'</option>'; 
}
echo '</select>';
?>

<?php //wp_dropdown_categories( 'show_option_none=Category&tab_index=4&taxonomy=country&selected=$districtid,' ); ?>
</div>

<input type="hidden" class="hidden_district" name="district_ids" value="<?php echo $districtid; ?>" />

<?php //wp_nonce_field( 'post_nonce', 'post_nonce_field' ); ?>

<input type="hidden" name="update_district" id="update_district" value="true" />
<input type="submit" class="btn btn-default editdistrict" value="Update">
</form>
</div>
<?php } 

if(isset($_POST['update_district'])){ 
$districtpostname = $_POST['districtpost'];
$regionId =  $_POST['cat'];

$region_information = array(
'ID' => $districtid,
'post_title' =>  wp_strip_all_tags($_POST['districtpost']),
'post_type' => 'region',
'post_status' => 'publish'
);
$region_id = wp_update_post($region_information);
if(!empty($region_id)){
$termupdates = wp_set_post_terms( $region_id, $regionId, 'country');
wp_redirect(get_the_permalink()."/?type=alldistricts");
exit();

}
}
?>