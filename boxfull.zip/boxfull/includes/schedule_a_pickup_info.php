<?php 
if($type=='scheduleapickinfo')
{
global $wpdb;
$html='';
$user = wp_get_current_user();
$userId = $user->ID;
$user_emails = $user->user_email;
$user_info = get_user_by('email', $user_email );
$userid = $user_info->data->ID;
$countrycode = get_user_meta($userid,'country_code',true);
$html.='<h2>Schedule A Pick-up Information</h2>';

$get_pickupstatus=$wpdb->get_results("select pickup_status from wp_schedule_pickup_order where pickup_status IN ('0','1')",ARRAY_A);
foreach($get_pickupstatus as $statusval){
	//print_r($statusval);
	$pickup_status = $statusval['pickup_status'];
}
$getpickupinfo = $wpdb->get_results("select * from wp_schedule_pickup INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id = wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_pickup_product_id = wp_schedule_pickup_order.schedule_a_pickup_product_id where wp_schedule_pickup_order.pickup_status='$pickup_status' AND wp_schedule_pickup_order.payment_status='paid'",ARRAY_A);

$html.='
<div class="table-responsive">
<table class="table">
<tbody>
<tr>
<th><a href="">Name</a></th>
<th><a href="">Email Id</a></th>
<th><a href="">Product Id</a></th>
<th><a href="">Payment Method</a></th>
<th><a href="">Payment Status</a></th>
<th><a href="">Pickup Status</a></th>
<th><a href="">View Details</a></th>
</tr>
';
foreach($getpickupinfo as $pickupval)
{
	
	$productname = $pickupval['product_name_pickup'];
	$pick_up_product_id = $pickupval['pick_up_product_id'];
	$user_email_pickup = $pickupval['user_email_pickup'];
	$payment_status = $pickupval['payment_status'];
	if($payment_status=='paid'){$status='Paid';}else{$status='Pending';}
	$payment_method = $pickupval['payment_method'];
	$userid = $pickupval['user_id_pickup'];
	$schedule_pickup_orderid = $pickupval['schedule_pickup_orderid'];
	$pickup_status= $pickupval['pickup_status'];
	if($pickup_status==1){$pickstatus = 'Delivered';}else{$pickstatus = 'Pending';}
	$useremail = get_user_by( 'email', $user_email_pickup );
	$name = $useremail->display_name;
	if($productname=='Standard Box'){$proname="AS000$pick_up_product_id";}
					
	if(($productname=='Large Size Items') || ($productname=='Large Items')){$proname="AL000$pick_up_product_id";}

	if($productname=='Wardrobe Box'){$proname="AW000$pick_up_product_id";}

	if($productname=='Document Box'){$proname="AD000$pick_up_product_id";}

	if(($productname=='Medium Size Items')||($productname=='Medium Items')){$proname="AM000$pick_up_product_id";}

	if(($productname=='Small Size Items')||($productname=='Small Items')){$proname="AS000$pick_up_product_id";}
	//echo "<pre>"; print_r($pickupval); echo "</pre>";
	$html.='
	<tr>
<td>'.$name.' </td>
<td style="word-wrap: break-word;">'.$user_email_pickup.'</td>
<td>'.$proname.'</td>
<td>'.$payment_method.'</td>
<td>'.$status.'</td>
<td>'.$pickstatus.'</td>
<td><a href="'.get_the_permalink().'?type=editstatus&orderstatusid='.$schedule_pickup_orderid.'&emailid='.$user_email_pickup.'">View Details</a></td>
</tr>
	';
}
$html.='
</tbody>
</table>
</div>
';
echo $html;
}