<?php 
if($type=='showall' || $type==''){
    //$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$the_query = new WP_Query(
		array(
			'post_type' => 'storagetype',
			'post_status' => 'publish',
			'posts_per_page' => 10,
			'paged' => get_query_var('paged') ? get_query_var('paged') : 1
		)
	); 
		
?>
<div class="table-responsive">
	<table class="table table-striped table-bordered">
		<tbody>
			<tr>
				<th class="sr_no">No</th>
				<th>Image</th>
				<th>Title</th>
				<th>Description</th>
				<th>Author</th>
				<th>Storage Type Category</th>
				<th>Date</th>
				<th class="action">Action</th>
			</tr>
			<?php $i=1;
			global $wp;
			$current_url = home_url(add_query_arg(array(),$wp->request));
			while ($the_query -> have_posts()) : $the_query -> the_post(); 
				$post_id = get_the_ID();
				$taxonomy='storagetypecat';
				$terms = wp_get_post_terms( $post_id, $taxonomy );
				$pfx_date = get_the_date(get_the_date('Y/m/d'), $post_id );
				?>
				<tr>
					<td class="sr_no"><?php echo $i;?> </td>
					<td>
						<?php 
						$post_img = get_field('ktstorage_type_image', $post_id); ?>
						<img src="<?php echo $post_img; ?>" /> 
					</td>
					<td><?php echo get_the_title();?></td>
					<td><?php echo get_the_content(); ?></td>
					<td><?php echo $author = ucfirst(get_the_author()); ?></td>
					<td><?php echo $terms[0]->name; ?></td>
					<td><?php if($pfx_date) {echo $pfx_date; } ?></td>
					<td class="action">
						<a href="<?php echo $current_url;?>/?post=<?php echo $post_id; ?>&type=edit" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
						<?php if( !(get_post_status() == 'trash') ) : ?>
							<a onclick="return confirm('Are you sure you wish to delete post: <?php echo get_the_title() ?>?')"href="<?php echo get_delete_post_link( $post_id  ); ?>" class="del_btn"><i class="fa fa-trash" aria-hidden="true"></i></a>
						<?php endif; ?>
					</td>
				</tr>
				<?php $i++; 
			endwhile;
			
			 wp_reset_query();
					?>

		</tbody>
	</table>
	<?php $big = 999999999; // need an unlikely integer
			 echo '<nav class="custom-pagination"><span class="page-numbers page-num">';
			 echo paginate_links( array(
			    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
			    'format' => '?paged=%#%',
			    'current' => max( 1, get_query_var('paged') ),
			    'total' => $the_query->max_num_pages
			) ); 
			echo '</span></nav>'; ?>
</div>
<?php } ?>
