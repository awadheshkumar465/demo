<?php
if(($type=='edit')||($type=='trash')&&(!empty($editpostid)))
{ 
$post_id = get_post($editpostid); 
$postid= $post_id->ID;
$title = $post_id->post_title;
$content = $post_id->post_content;
/* get the category by term start */
$categories = get_terms( 'storagetypecat', 'orderby=count&hide_empty=0' );
$term_list = wp_get_post_terms($postid, 'storagetypecat', array("fields" => "all")); 
$post_term_id = $term_list[0]->term_id;
/* get the category by term end */

$ktstorage_type_price_store_plan = get_field('store_plan',$postid);
$ktstorage_type_price_ktstorage_type_price = get_field('ktstorage_type_price',$postid);
$storage_type_price_six = get_field('storage_type_price_six',$postid);
$storage_type_price_twelve = get_field('storage_type_price_twelve',$postid);
$ktstorage_type_image = get_field('ktstorage_type_image',$postid);
$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight',$postid);
?>

<div class="col-md-12">
<form method="POST" action="" id="editformsx" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">Storage Title:<span class="requiredpart">*</span></label>
<input type="text" class="storagenamepost" name="storagenamepost" class="form-control" id="storagenamepost" value="<?php echo ucfirst($title);?>" required>
</div>
<div class="form-group">
<label for="contents">Text Editor:</label>
<?php 
$content = $content;
$editor_id = 'kv_frontend_editor';
$settings =   array(
'wpautop' => true, // use wpautop?
'media_buttons' => true, // show insert/upload button(s)
'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."

//'toolbar1'=> 'bold,italic,underline,bullist,numlist,link,unlink,forecolor,undo,redo',
'tabindex' => '',
'editor_css' => '', //  extra styles for both visual and HTML editors buttons, 
'editor_class' => 'contentbox', // add extra class(es) to the editor textarea
'teeny' => true, // output the minimal editor config used in Press This
'dfw' => false, // replace the default fullscreen with DFW (supported on the front-end in WordPress 3.4)
'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
);
echo wp_editor( $content, $editor_id, $settings);
?>
</div>
<div class="form-group">
<label for="titles">Select Storage Type :<span class="requiredpart">*</span></label>
<select name="postcate">
<?php 
	foreach ($categories as $category) { 
		if($category->term_id == $post_term_id)
		{
		 $selected = "selected";
		} 
		else 
		{
		 $selected = "";
		} ?>
		<option value="<?php echo $category->term_id; ?>" <?php echo $selected; ?>><?php echo $category->name; ?></option>
	<?php } ?>
</select>
</div>
<div class="form-group">
<p class="storagetypes_settings">Storage Type Setting:</p>

<div class="storeplansadd">
<label for="titles">Store Plan :<span class="requiredpart">*</span></label>
<input type="text" class="storeplan"  name="storeplan" class="form-control" id="storeplan" value="<?php echo $ktstorage_type_price_store_plan;?>" required>
</div>

<div class="storeplansadd">
<label for="titles">Storage Type Price (3-5 months) :<span class="requiredpart">*</span></label>
<input type="text" class="ktstorage_type_price" name="ktstorage_type_price" class="form-control" id="ktstorage_type_price" value="<?php echo $ktstorage_type_price_ktstorage_type_price;?>" required>
</div>

<div class="storeplansadd">
<label for="titles">Storage Type Price Six (6-11 Months) :<span class="requiredpart">*</span></label>
<input type="text" name="storage_type_price_six" class="form-control" id="storage_type_price_six" value="<?php echo $storage_type_price_six;?>" required>
</div>

<div class="storeplansadd">
<label for="titles">Storage Type Price Twelve (12+ Months) :<span class="requiredpart">*</span></label>
<input type="text" name="storage_type_price_twelve" class="form-control" id="storage_type_price_twelve" value="<?php echo $storage_type_price_twelve;?>" required>
</div>

<div class="storeplansadd">
<label for="titles">Storage Type Image :<span class="requiredpart">*</span></label>
<input type="file" name="ktstorage_type_image" class="form-control" id="ktstorage_type_image" value="">
<img src="<?php echo $ktstorage_type_image;?>" class="img-responsive" style="width:150px;" />

<?php //wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
</div>

<div class="storeplansadd">
<label for="titles" >Storage Type Max Weight :<span class="requiredpart">*</span></label>

<input type="text" name="ktstorage_type_max_weight" class="form-control" id="ktstorage_type_max_weight" value="<?php echo $ktstorage_type_max_weight;?>" required>
</div>

<input type="hidden" class="hidden_postids" name="post_ids" value="<?php echo $editpostid;?>" />

<?php //wp_nonce_field( 'post_nonce', 'post_nonce_field' ); ?>

<input type="hidden" name="editstorageposts" id="submitted" value="true" />
<input type="submit" class="btn btn-default storagesubmit" value="Update">
</form>
</div>
<?php 
}

if(isset($_POST['editstorageposts'])){
$postids=$_POST['post_ids'];
$post_title = $_POST['storagenamepost'];
$post_content = $_POST['kv_frontend_editor'];
$storeplan = $_POST['storeplan'];
$ktstorage_type_price = $_POST['ktstorage_type_price'];
$storage_type_price_six = $_POST['storage_type_price_six'];
$storage_type_price_twelve = $_POST['storage_type_price_twelve'];
$storage_max_weight = $_POST['ktstorage_type_max_weight'];
$ktstorage_type_image=$_POST['ktstorage_type_image'];
$postcate = trim($_POST['postcate']); 
$post_information = array(
'ID' => $postids,
'post_title' =>  wp_strip_all_tags($_POST['storagenamepost']),
'post_content' =>$post_content,
'post_type' => 'storagetype',
'post_status' => 'publish'
);

print_r($_POST);
echo $post_id = wp_update_post( $post_information );

wp_set_post_terms($post_id,$postcate,'storagetypecat'); // update the category term 

update_field('field_59c232fdfa9a0',$storeplan,$post_id);
update_field('field_59ad1692bb534',$ktstorage_type_price,$post_id);
update_field('field_59bf4796b33f2',$storage_type_price_six,$post_id);
update_field('field_59bf47b8b33f3',$storage_type_price_twelve,$post_id);
update_field('field_59b8f551bc76a',$storage_max_weight,$post_id);

if(!empty($_FILES)) {
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/media.php' );
foreach ($_FILES as $file => $array) { //print_r($file); 
if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK) { 
//return "upload error : " . $_FILES[$file]['error'];
}
else{
 $attach_id = media_handle_upload( $file, $new_post );
}
} 
if ($attach_id > 0){ 
//and if you want to set that image as Post  then use:
//update_post_meta($new_post,'_thumbnail_id',$attach_id);
update_field('field_59ad496aab96e',$attach_id,$post_id);

} 
}



?>
<script>
window.location = "<?php echo get_bloginfo('url');?>/admin-dashboard/?type=showall";
</script>
<?php
}
/*edit section ends here */
?>