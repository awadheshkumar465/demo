<?php if($type=='transaction_history')
{ 
	global $wpdb;
	$orderid=$_GET['orderid'];
	$useremail = $_GET['useremail'];
	$user = get_user_by( 'email', $useremail );
	$user_id = $user->ID;
	$datetime = $_GET['date'];
	$username = $user->first_name;
	$company_name = get_user_meta( $user_id, 'company_name', true );
	echo '<h2>All Transction History List</h2>';
	$paymentdate = explode(" ",$datetime);
	$currentpaymentdate=$paymentdate[0];
	$upload_dir   = wp_upload_dir();

	$getorderlists = $wpdb->get_results("select * from wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id where wp_orders.paymentstatus!='' AND wp_orders.useremail='$useremail' GROUP BY wp_orders.`useremail`",ARRAY_A);

	$pickuporderlists = $wpdb->get_results("select * from wp_schedule_pickup_order INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup_order.order_id_pickup = wp_schedule_pickup_products.order_id where wp_schedule_pickup_order.payment_status!='' AND wp_schedule_pickup_order.user_email_pickup='$useremail' GROUP BY wp_schedule_pickup_order.`user_email_pickup`",ARRAY_A);
	$schedulereturnlists = $wpdb->get_results("select * from wp_schedulereturninformation INNER JOIN wp_product_return_lists ON wp_schedulereturninformation.scheduleareturnid = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_product_return_lists.schedule_return_id = wp_schedule_return_history.schedulereturnid where wp_schedule_return_history.`useremail`='$useremail' and wp_schedule_return_history.delivery_status='1' GROUP BY wp_schedule_return_history.`useremail`",ARRAY_A);

	/*echo '<pre>';
	print_r($getorderlists);
	echo '</pre>';*/ ?>
	<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>Customer Name</th>
					<th>Company Name</th>
					<th>Total Products</th>
					<th>Total Price</th>
					<th class="action">View Details</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php
					$sum=0;
						foreach ($getorderlists as $value) {
							$user_count = $wpdb->get_var( "SELECT COUNT(*) FROM wp_order_products where useremail='$useremail'" );
							$getprodetails =$wpdb->get_results("select * from wp_order_products where useremail='$useremail'" );
							$finval=0;
							foreach($getprodetails as $proqtyprice){
								$proqty = $proqtyprice->productqty;
								$profinprice = $proqtyprice->productprice;
								//echo $finval= ($profinprice/$proqty);
								$sum = $sum + $profinprice;
							} ?>
							<td><?php echo ucfirst($username); ?></td>
							<td><?php echo ucfirst($company_name); ?></td>
							<td><?php echo $user_count;?></td>
							<td><?php echo $sum;?></td>
							<td class="action"><a href="<?php echo get_the_permalink() ?>?type=orderdetailslists&date=<?php echo $datetime; ?>&orderid=<?php echo $orderid; ?>&useremail=<?php echo $useremail; ?>" class="edit_btn"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
						
				</tr>
				<?php } ?>
				<tr>
					<?php
					if(!empty($pickuporderlists)){
						foreach($pickuporderlists as $pickuporderlist){ 
							$orderid = $pickuporderlist['order_id_pickup'];
							$useremail = $pickuporderlist['user_email_pickup'];
							?>
							<td><?php echo ucfirst($username); ?></td>
							<td><?php echo ucfirst($company_name); ?></td>
							<td><?php echo $pickuporderlist['product_qty'];?></td>
							<td><?php echo $pickuporderlist['product_price'];?></td>
							<td class="action"><a href="<?php echo get_the_permalink() ?>?type=orderdetailslists&date=<?php echo $datetime; ?>&orderid=<?php echo $orderid; ?>&useremail=<?php echo $useremail; ?>" class="edit_btn"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
						<?php }
					} ?>	
				</tr>
				<tr>
					<?php
					if(!empty($schedulereturnlists)){
						foreach($schedulereturnlists as $schedulereturnlist){ 
							//print_r($schedulereturnlist);
							$orderid = $schedulereturnlist['order_id'];
							$useremail = $schedulereturnlist['useremail']; ?>
							<td><?php echo ucfirst($username); ?></td>
							<td><?php echo ucfirst($company_name); ?></td>
							<td><?php echo $schedulereturnlist['product_qty'];?></td>
							<td><?php echo $schedulereturnlist['product_price'];?></td>
							<td class="action"><a href="<?php echo get_the_permalink() ?>?type=orderdetailslists&date=<?php echo $datetime; ?>&orderid=<?php echo $orderid; ?>&useremail=<?php echo $useremail; ?>" class="edit_btn"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
						<?php }
					} ?>
				</tr>
			</tbody>
		</table>
	</div>



<?php
}?>