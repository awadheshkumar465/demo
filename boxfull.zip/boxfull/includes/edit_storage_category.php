<?php
if(!empty($cateid)){
$category = get_term_by('id', $cateid, 'storagetypecat');
$termid=$category->term_id;
$termname = $category->name;
$description = $category->description;
//print_r($category);  


?>
<!-- edit form for edit storage type -->
<div class="col-md-12">
<form method="POST" action="" id="editformcate" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">Storage Category Title:<span class="requiredpart">*</span></label>
<input type="text" class="termname" name="termname" class="form-control" id="termname" value="<?php echo ucfirst($termname);?>" required>
</div>
<div class="form-group">
<label for="contents">Storage Category Description:</label>
<?php 
$content = $description;
$editor_id = 'kv_frontend_editor_term';
$settings =   array(
'wpautop' => true, // use wpautop?
'media_buttons' => false, // show insert/upload button(s)
'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."

//'toolbar1'=> 'bold,italic,underline,bullist,numlist,link,unlink,forecolor,undo,redo',
'tabindex' => '',
'editor_css' => '', //  extra styles for both visual and HTML editors buttons, 
'editor_class' => 'contentbox', // add extra class(es) to the editor textarea
'teeny' => true, // output the minimal editor config used in Press This
'dfw' => false, // replace the default fullscreen with DFW (supported on the front-end in WordPress 3.4)
'tinymce' => false, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
);
echo wp_editor( $content, $editor_id, $settings);
?>
</div>

<input type="hidden" name="submittedtermcate" id="submittedtermcate" value="<?php echo $termid; ?>" />
<input type="submit" class="btn btn-default storagecatetermsubmit" value="Submit">
</form>
</div>

<?php
if(isset($_POST['submittedtermcate'])){
$termname=$_POST['termname'];
$kv_frontend_editor_term=$_POST['kv_frontend_editor_term'];
$term_id= $termid;
$taxonomy='storagetypecat';
$args=array(
'name' => $termname,
'description' => $kv_frontend_editor_term
);
$termupdates=wp_update_term( $term_id, $taxonomy,$args);
if(termupdates){
wp_redirect(get_the_permalink()."/?type=storagetypecate");
exit;
}

}
/*edit form for edit storage type ends here */

}
?>