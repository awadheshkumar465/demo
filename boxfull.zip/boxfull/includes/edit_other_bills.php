<?php 
if($type=='editotherbillingid'){
global $wpdb;

if(isset($_GET['editbillinglstid'])){
$editbillinglstid = trim($_GET['editbillinglstid']);


if(isset($_POST['editotherbills_other_fee'])){
print_r($_POST);

$storage_fee = trim($_POST['storage_fee']);

$handling_fee = trim($_POST['handling_fee']);

$delivery_fee = trim($_POST['delivery_fee']);

$additional_fees = trim($_POST['additional_fees']);

$editmainbillingid = trim($_POST['editmainbillingid']);

$updates = $wpdb->update('wp_billingmanagement',array(
'storage_fee'=>$storage_fee,
'handling_fee'=>$handling_fee,
'delivery_fee'=>$delivery_fee,
'additional_fee'=>$additional_fees,
),array('billing_main_id'=>$editmainbillingid)); 
?>
<script type = "text/javascript" language = "javascript">
			jQuery(document).ready(function() {
			alert ("Billing Updated Successfully");
			window.location = "<?php echo get_permalink();?>?type=showbillproductslists";
			});
		</script>
<?php 
}
else
{
	
$getneweidt=$wpdb->get_results("SELECT * FROM `wp_billingmanagement` WHERE `billing_main_id`=$editbillinglstid",ARRAY_A);
//print_r($getneweidt);

$storage_fee = trim($getneweidt[0]['storage_fee']);
$handling_fee = trim($getneweidt[0]['handling_fee']);
$delivery_fee = trim($getneweidt[0]['delivery_fee']);
$additional_fee = trim($getneweidt[0]['additional_fee']);
?>

<div class="user-table ">
		
	<div class="editboxID_number">
		<h2>Add Other Bills : </h2>
		<form class="form-horizontal-manual-billing" method="POST">
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 scanrow">
						<label>Storage Fee</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="storage_fee" value="<?php echo $storage_fee;?>" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 uploadimages">
						<label>Handling Fee</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="handling_fee" value="<?php echo $handling_fee;?>" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Delivery Fee </label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="delivery_fee" value="<?php echo $delivery_fee;?>">
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Additional Fees:</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="additional_fees" value="<?php echo $additional_fee;?>">
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12 custid">
										
					<input type="hidden" name="editmainbillingid" value="<?php echo $editbillinglstid;?>">
					<input type="submit" class="btn btn-primary btn-block" name="editotherbills_other_fee" value="Submit">
					</div>
				</div>
			</div>
		
		</form>
	</div>			
</div>
<?php 	
}
}
}

?>