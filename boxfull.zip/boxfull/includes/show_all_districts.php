<?php
/* Showing all district lists starts here */
$paged = ( $_GET['paged12'] ) ? $_GET['paged12'] : 1;
$district_page_url=site_url('admin-dashboard/?type=alldistricts');
if($type=='alldistricts'){ 
$query_district = new WP_Query(array(
'post_type' => 'region',
'post_status' => 'publish',
'order'	=>	'ASC',
'posts_per_page'=>10,
'paged' => $paged
)); 
?>
<div class="table-responsive">
	<table class="table table-striped table-bordered editdistricts">
		<tbody>
			<tr></tr>
			<tr>
				<th>Serial No</th>
				<th>Districts</th> 
				<th>Author</th>
				<th>Regions</th>
				<th>Date</th>
				<th class="action">Action</th>
			</tr>
			<?php $i=1;
			global $wp;
			$current_url = home_url(add_query_arg(array(),$wp->request));



			while ($query_district->have_posts()) {
			$query_district->the_post();
			$post_id = get_the_ID();
			$taxonomy='country';
			$terms = wp_get_post_terms( $post_id, $taxonomy );
			$pfx_date = get_the_date(get_the_date('Y/m/d'), $post_id );
			//echo get_the_permalink();
			?>
			<tr>
				<td><?php echo $i;?> </td>
				<td><?php echo get_the_title();?></td>
				<td><?php echo $author = get_the_author(); ?></td>
				<td><?php echo $terms[0]->name; ?></td>
				<td><?php if($pfx_date) {echo $pfx_date; } ?></td>
				<td class="action">
					<a href="<?php echo $current_url;?>/?districtid=<?php echo $post_id; ?>&type=editdistrict" class="edit_btn">
						<i class="fa fa-pencil" aria-hidden="true"></i>
					</a>
					<?php if( !(get_post_status() == 'trash') ) : ?>
					<a onclick="return confirm('Are you sure you wish to delete post: <?php echo get_the_title() ?>?')"href="<?php echo get_delete_post_link( $post_id  ); ?>" class="del_btn">
						<i class="fa fa-trash" aria-hidden="true"></i>
					</a>
				<?php endif; ?>
				</td>
			</tr>
			<?php $i++; } 

			wp_reset_query();
			?>
		</tbody>
	</table>
</div>
<?php
if (function_exists(custom_pagination)) {
        custom_pagination($query_district->max_num_pages,"",$paged,$district_page_url);
      }
}
/* Showing all district lists ends here */
?>