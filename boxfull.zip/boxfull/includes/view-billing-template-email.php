<?php 
if($type=="viewbillingtemplate")
{
	$upload_dir   = wp_upload_dir();
	$currency = get_option( 'currency_set' );
	$html='';
	//print_r($_GET); ?>
<div class="user-table ">
<h2>Billing Details</h2>
	<?php 
	if(isset($_GET['schrethistoryid'])){
		
		$storagetype = trim($_GET['stype']);
		
		$schedulereturnid = trim($_GET['schretid']);
		
		$schedule_returnhistory_id = trim($_GET['schrethistoryid']);
		
		$email = trim($_GET['email']);
		
		$getbillings = $wpdb->get_results("SELECT * FROM `wp_schedulereturninformation` INNER JOIN wp_product_return_lists  ON  wp_schedulereturninformation.scheduleareturnid = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_product_return_lists.schedule_return_id = wp_schedule_return_history.schedulereturnid INNER JOIN wp_schedule_return_history_order ON wp_schedule_return_history.useremail= wp_schedule_return_history_order.useremail where wp_schedulereturninformation.scheduleareturnid=$schedulereturnid AND wp_schedulereturninformation.useremail = '$email' AND wp_schedule_return_history.delivery_status!='0' AND wp_schedule_return_history_order.wp_schedule_return_history_order_id=$schedule_returnhistory_id",ARRAY_A);
		
		if(!empty($getbillings))
		{
			$html.='
			<div class="My_Stuff_main">
			<div class="Invoice_main_one">
			<section class="content content_content" id="printsall">
			<section class="invoice" id="invoices">
			<div class="row">
				<div class="col-xs-12">
					<h2 class="page-header">
						<img src="'.$upload_dir["baseurl"].'/2017/10/cropped-logo.png">
						<small class="pull-right">Date: '.date("Y/m/d").'</small>
					</h2>
				</div><!-- /.col -->
			</div>';
			foreach($getbillings as $schedulereturnvals)
			{
				
				$deliverydate = $schedulereturnvals['deliverydate'];
				
				$fulladdress = $schedulereturnvals['fulladdress'];
				
				$pick_select_date = $schedulereturnvals['pick_select_date'];
				
				$pick_select_time = $schedulereturnvals['pick_select_time'];
				
				$deliverydate = $schedulereturnvals['deliverydate'];
				
				$deliverytime = $schedulereturnvals['deliverytime'];
				
				$order_product_id = $schedulereturnvals['order_product_id'];
				
				$invoicenumber = "I".date("y")."000".$order_product_id;
				
				if($pick_select_date!='')
				{
					$deliverydates = $schedulereturnvals['pick_select_date'];
					
					$pick_select_date = $schedulereturnvals['pick_select_date'];
				
					$pick_select_time = $schedulereturnvals['pick_select_time'];
					
					$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($deliverydates))));
		
					$year =$invoicestartdate[0];
					$month =$invoicestartdate[1];

					//$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
					//$invoicefirstdate = date('Y/m/d', strtotime($invoicefirstdates));

					$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
					$invoicelduedate = date('Y/m/d', strtotime($invoicelduedates));
					
				}
				else
				{
					$deliverydates = $schedulereturnvals['deliverydate'];
				
					$delivery_select_time = $schedulereturnvals['deliverytime'];
					
					$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($deliverydates))));
		
					$year =$invoicestartdate[0];
					$month =$invoicestartdate[1];

					//$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
					//$invoicefirstdate = date('Y/m/d', strtotime($invoicefirstdates));

					$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
					$invoicelduedate = date('Y/m/d', strtotime($invoicelduedates));
					
				}
				//echo "<pre>"; print_r($schedulereturnvals); echo "</pre>";
				$product_name = $schedulereturnvals['product_name'];
				
				$product_price = $schedulereturnvals['product_price'];
				
				$product_qty = $schedulereturnvals['product_qty'];
				
				$finhiddenvalprice = $schedulereturnvals['finhiddenvalprice'];
				
				$usernames = get_user_by( 'email', $email );
				
				$user_id =$usernames->ID;
				
				$userDisplayName = $usernames->first_name;
				
				$userphone = get_user_meta($user_id, 'user_phone', true);
				
				$boxid = $wpdb->get_results("SELECT * FROM `wp_boximages` WHERE `order_product_id`=$order_product_id",ARRAY_A);
				
				if(!empty($boxid))
				{
					$boxnumber = $boxid[0]['boxid'];
				}
				$html.='
				<div class="row invoice-info">
					<div class="col-sm-4 invoice-col">
						<strong>Personnal Details</strong>
						<address>
							<b>Name: </b> <span>'.$userDisplayName.'</span>
							<br>
							<b>Address:</b> <span>'.$fulladdress.'</span><br>
							<b>Phone:</b> <span>'.$userphone.'</span><br>
							<b>Email:</b> <span>'.$email.'</span>                                
						</address>
					</div>
					<div class="col-sm-4 invoice-col">
						<strong> Drop off/ Pickup Details</strong>
							<address>
								<b>Delivery Date: </b> <span>'.$deliverydates.'</span>
								<br>
								<b>Delivery Time: </b> <span>'.$delivery_select_time.'</span>
								<br>
								<b>Pickup Date: </b> <span>'.$pick_select_date.'</span>
								<br>
								<b>Pickup Time: </b> <span>'.$pick_select_time.'</span>
							</address>
					</div>
					<div class="col-sm-4 invoice-col">
						<strong> Order Details Details</strong>
							<address>
								<b>Invoice: </b> <span>'.$invoicenumber.'</span>
								<br>
								<b>Payment Due: </b> <span>'.$invoicelduedate.'</span>
							</address>
					</div>
				</div>
				<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Product Name</th>
								<th>Item/Box ID</th>
								<th>Storage Plan</th>
								<th>Price</th>
								<th>Sub Total</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Standard Box</td>
								<td>'.$boxnumber.'</td>
								<td>'.$storagetype.'</td>
								<td>'.$currency."$".$finhiddenvalprice.'</td>
								<td>'.$currency."$".$finhiddenvalprice.'</td>
							</tr>
							<tr>
								<td colspan="4" style="text-align:right;"><strong>Total</strong></td><td>'.$currency."$".$finhiddenvalprice.'
							</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="row no-print">
					<div class="col-xs-12">
						<a href="javascript:void(0);" class="btn btn-default faprintbutton"><i class="fa fa-print"></i> Print</a>
					   
					</div>
				</div>
				</section>
				</section>	
				</div>
				</div>
				';
				
				

				//echo "<pre>"; print_r($getbillings); echo "</pre>";
			} ?>
<?php echo $html; 
		}
	}
	?>
</div>
<?php 	
}
?>