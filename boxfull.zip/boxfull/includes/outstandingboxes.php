<?php
if($type=='outstandingboxes'){
	global $wpdb;
	
	
	$args=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query = new WP_Query( $args );

if ($the_query->have_posts() ) :
while ($the_query->have_posts() ) : $the_query->the_post();
$productid[] = get_the_ID().",";
endwhile;
else:
echo 'no posts found';
endif;

$product_idresult = '';
foreach($productid as $i=>$k) {
    $product_idresult .=$k;
}
$product_idresult = rtrim($product_idresult,',');

	$allorders = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id INNER JOIN wp_boximages ON wp_order_products.order_product_id = wp_boximages.order_product_id where wp_order_products.productids IN ($product_idresult) AND wp_orders.paymentstatus!='' ",ARRAY_A);
	
	$gtschedulereturnino =$wpdb->get_results("SELECT * FROM `wp_schedulereturninformation` group by `useremail`",ARRAY_A);
	foreach($gtschedulereturnino as $returninfo)
	{
		$returninfoemail[]=$returninfo['useremail'];
	}
	
	foreach($allorders as $getdropoff)
	{
		$dropofemail[] = $getdropoff['useremail'];
	}
	
	$result=array_diff($dropofemail,$returninfoemail);
	foreach($result as $getemail)
	{
		$emailids[]= "'$getemail'".",";
	}
	//print_r($emailids);
	$newemailids = '';
	foreach($emailids as $i=>$k){
		$newemailids .= $k;
	}
	$new_user_emails = rtrim($newemailids,',');
	
	$alldropoff_boxes = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id INNER JOIN wp_boximages ON wp_order_products.order_product_id = wp_boximages.order_product_id where wp_orders.useremail IN ($new_user_emails) AND wp_orders.paymentstatus!='' ",ARRAY_A);
	
	
	echo '<h2>All Outstanding Boxes</h2>'; ?>
	<div class="outstandingboxes">
		<div class="table-responsive"> 
			<table class="table table-bordered">
				<tbody>
					<tr>
						<th>Box ID</th>
						<th>Order ID</th>
						<th>User ID</th>
						
					</tr>
					<?php
					foreach ( $alldropoff_boxes as $allorder ) {
						//echo "<pre>"; print_r($alldropoff_boxes ); echo "</pre>";
						
					$boxid = $allorder['boxid'];
					
					$customerid = $allorder['customer_id'];
					
					$orderid = $allorder['orderid'];
					
					$productids = $allorder['productids'];
					
					$orderproductid = $allorder['order_product_id'];
					
					$useremail = $allorder['useremail'];
					
					$finalorderid = "O".date("y")."000".$orderid;
					
					$userid = get_user_by( 'email', $useremail );
					
					$user_id = $userid->ID;
					
					
					?>
					<tr>
						<td><a href="<?php echo site_url();?>/admin-dashboard/?type=editboxid&orderid=<?php echo $orderid;?>&productid=<?php echo $productids;?>&orderproductid=<?php echo $orderproductid;?>&emailid=<?php echo $useremail;?>&addedby=admin" class="tbl_order_nom" ><?php echo $boxid;?></a></td>
						<td><a class="tbl_order_nom" href="javascript:void(0);"><?php echo $finalorderid; ?></a></td>
						<td><a class="tbl_order_nom" href="<?php echo site_url();?>/admin-dashboard/?type=editUsers&userId=<?php echo $user_id;?>"><?php echo $customerid;?></a></td>
					</tr>
					<?php }
				 ?>
				</tbody>
			</table>
		</div>
	</div>
<?php
	


}