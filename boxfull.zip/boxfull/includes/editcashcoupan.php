<?php
if($type=='editcashcoupan'){ 
	$user = wp_get_current_user();
	$userId = $user->ID;
	$userrole = $user->display_name;
	$cashcoupan_id =$_GET['cashcoupan_id'];
	$getdata = $wpdb->get_results("select * from wp_cashcoupancode where cashcoupan_id = $cashcoupan_id ");
	//print_r($getdata);
	foreach ($getdata as $getdatalists) {
		$cashcoupan_id = $getdatalists->cashcoupan_id;
		$cashcoupan_code = $getdatalists->cashcoupan_code;
		$cashcoupan_amount = $getdatalists->cashcoupan_amount;
	}
	if(isset($_POST['editcashcoupans'])){
		$cashcoupan_code=trim($_POST['cashcoupan_code']);
		$cashcoupan_amount=trim($_POST['cashcoupan_amount']);
		$update_data = $wpdb->update( 
					'wp_cashcoupancode', 
					array( 
						'cashcoupan_code' => $cashcoupan_code,
						'cashcoupan_amount' => $cashcoupan_amount
					), 
					array( 'cashcoupan_id' => $cashcoupan_id ) 
				);
		
		$redirects=get_the_permalink()."?type=allpromotions";
		echo "Cash Coupan code updated successfully";
		wp_redirect($redirects);
	}
	?>
	<form action="" class="form-horizontal" method="POST" role="form">
		<h2>Edit Cash Coupan</h2>
		<div class="form-group">
			<label for="coupancode" class="col-sm-3 control-label">Cash Coupan Code :<span class="requiredpart">*</span>
			</label>
			<div class="col-sm-9">
				<input type="text" id="cashcoupan_code" name="cashcoupan_code" class="form-control" autofocus="" value="<?php echo $cashcoupan_code; ?>" maxlength="10" required>
			</div>
		</div>
		<div class="form-group">
			<label for="coupanamount" class="col-sm-3 control-label">Cash Coupan Amount :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<input type="number"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" id="cashcoupan_amount" name="cashcoupan_amount" class="form-control" autofocus="" value="<?php echo $cashcoupan_amount; ?>" min="1" max="99" required >
			</div>
		</div>
	<div class="form-group">
	<div class="col-sm-3 col-sm-offset-3">
	<input type="submit" name="editcashcoupans" value="Submit">
	</div>
    </div>
</form>
<?php
}
