<?php
if($type=='bankandchecque')
{
	echo "<h2>Add Bank & Cheque Details</h2>"; ?>
	<?php 
	if(isset($_POST['bankandchecque'])){
		$bank_credentials = $_POST['bank_credentials'];
		$cheque_credentials = $_POST['cheque_credentials'];
		update_option('bank_credentials',$bank_credentials);
		update_option('cheque_credentials',$cheque_credentials);
	}
	?>
	<form method="POST" action="" id="addnewcategory">
		<div class="form-group ">
			<label for="titles">Enter Bank Credentials:<span class="requiredpart">*</span></label>
			<input type="text" class="bank_credentials" name="bank_credentials" id="bank_credentials" value="<?php echo get_option('bank_credentials'); ?>" required="">
		</div>
		<div class="form-group input_fields_container">
			<label for="titles">Enter Cheque Credentials:<span class="requiredpart">*</span></label>
			<input type="text" class="cheque_credentials" name="cheque_credentials" id="cheque_credentials" value="<?php echo get_option('cheque_credentials'); ?>" required="">
		</div>
		<input type="submit" name="bankandchecque" value="Submit">
	</form>
<?php
} ?>

