<!-- create new storage category starts here --> 
<div class="col-md-12">
<form method="POST" action="" id="editforms" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">Storage Category Title:<span class="requiredpart">*</span></label>
<input type="text" class="storagenamecate" name="storagenamecate" class="form-control" id="storagenamecate" value="<?php echo ucfirst($title);?>" required>
</div>
<div class="form-group">
<label for="contents">Storage Category Description:</label>
<?php 
$content = $content;
$editor_id = 'kv_frontend_editor_category';
$settings =   array(
'wpautop' => true, // use wpautop?
'media_buttons' => false, // show insert/upload button(s)
'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."

//'toolbar1'=> 'bold,italic,underline,bullist,numlist,link,unlink,forecolor,undo,redo',
'tabindex' => '',
'editor_css' => '', //  extra styles for both visual and HTML editors buttons, 
'editor_class' => 'contentbox', // add extra class(es) to the editor textarea
'teeny' => true, // output the minimal editor config used in Press This
'dfw' => false, // replace the default fullscreen with DFW (supported on the front-end in WordPress 3.4)
'tinymce' => false, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
'quicktags' => false // load Quicktags, can be used to pass settings directly to Quicktags using an array()
);
echo wp_editor( $content, $editor_id, $settings);
?>
</div>

<input type="hidden" name="submittedcate" id="submittedcate" value="1" />
<input type="submit" class="btn btn-default storagecatesubmit" value="Submit">
</form>
</div>	


<?php
if($_POST['submittedcate']){
//print_r($_POST);
$storenamecate=$_POST['storagenamecate'];
$tagdesc=$_POST['kv_frontend_editor_category'];
$wpdocs_cat = array(
//'taxonomy' => 'storagetypecat',
'cat_name' => 'Wpdocs Category', 
'category_description' => 'A Cool Category', 
'category_nicename' => 'category-slug', 
'category_parent' => ''
);

$insertcate= wp_insert_term(
$storenamecate, // the term 
'storagetypecat', // the taxonomy
array(
'description'=> $tagdesc,
'parent'=> ''
)
);
if(insertcate){
wp_redirect(get_the_permalink()."/?type=storagetypecate");
exit;
}

}
/* storage add new storage type ends here */
?>