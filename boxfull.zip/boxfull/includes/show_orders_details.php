<?php if($type=='orderdetailslists'){ 
$orderid=$_GET['orderid'];
$useremail = $_GET['useremail'];
$user = get_user_by( 'email', $useremail );
$user_id = $user->ID;
$datetime = $_GET['date'];
$date = date('y');
echo '<h2>Show Order Details</h2>';
$paymentdate = explode(" ",$datetime);
$currentpaymentdate=$paymentdate[0];
$upload_dir   = wp_upload_dir();
$getorderlists = $wpdb->get_results("select * from wp_orders where order_id =$orderid AND useremail='$useremail' AND datetime='$datetime'",ARRAY_A);
$userorderid = $getorderlists[0]['order_id'];
$user_details = get_user_by( 'email', $useremail );

$length = 3;
$invoiceno = '';
for ($i=0;$i<$length;$i++){
$invoiceno .= rand(1, 9);
}

$products_lists = $wpdb->get_results("select * from wp_order_products where order_id=$userorderid AND useremail='$useremail' ",ARRAY_A);

$html='';
$html.='<div class="My_Stuff_main"><div class="Invoice_main_one">
<section class="content content_content" id="printsall">
                    <section class="invoice" id="invoices">
                        <!-- title row -->
                        <div class="row">
                            <div class="col-xs-12">
                                <h2 class="page-header">
                                    <img src="'.$upload_dir["baseurl"].'/2017/10/cropped-logo.png">
                                    <small class="pull-right">Date: '.$currentpaymentdate.'</small>
                                </h2>
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                        <!-- info row -->
                        <div class="row invoice-info">';
						foreach($getorderlists as $getlistsorders){
							
						$cchangedateorder = explode("/",$getlistsorders["select_drop_off_date"]);
						$newchangedate = $getlistsorders["select_drop_off_date"];
						if(!empty($getlistsorders["pick_select_date"])){
						$cchangepickupdateorder = explode("/",$getlistsorders["pick_select_date"]);
						$pickupdate = $getlistsorders["pick_select_date"];
						}
						if(!empty($getlistsorders["pickup_of_boxes"])){
							if($getlistsorders["pickup_of_boxes"]=='on'){}else{
							$pickupdate=$getlistsorders["pick_select_date"];
							}
						}
						$paymentdate = explode(" ",$getlistsorders["datetime"]);
						$currentpaymentdate=$paymentdate[0];
						$expecteddates = date('Y-m-d', strtotime('+1 month', strtotime($currentpaymentdate)));
						
						
                           $html.='<div class="col-sm-4 invoice-col">
                                <strong>Personnal Details</strong>
                                <address>
                                    <b>Name: </b> <span>'.$getlistsorders["fullname"].'</span>
                                    <br>
                                    <b>Address:</b> <span>'.$getlistsorders["fulladdress"].'</span><br>
                                    <b>Phone:</b> <span>'.$getlistsorders["phonenumber"].' </span><br>
                                    <b>Email:</b> <span>'.$getlistsorders["useremail"].'</span>                                
								</address>
                            </div><!-- /.col -->
                            <div class="col-sm-4 invoice-col">
                               <strong> Drop off/ Pickup Details</strong>
                                <address>
                                    <b>Delivery Date: </b> <span>'.$newchangedate.'</span>
                                    <br>
                                    <b>Delivery Time: </b> <span>'.$getlistsorders["dropoff_select_time"].'</span>
                                    <br>
                                    <b>Pickup Date: </b> <span>'.$pickupdate.'</span>
                                    <br>
									<b>Pickup Time: </b> <span>'.$getlistsorders["pick_select_time"].'</span>
									                               
								</address>
                            </div><!-- /.col -->
                            <div class="col-sm-4 invoice-col">
                                 <strong> Order Details Details</strong>
                                 <address>
                                    <b>Invoice: </b> <span>I'.$date.'000'.$user_id.'</span>
                                    
                                    <br>
                                    <b>Payment Due: </b> <span>'.$expecteddates.'</span>
									                               
								</address>
							</div>';/* .col */
							}
                        $html.='</div><!-- /.row .invoice-info -->

                        <!-- Table row -->
                        
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Product Qty</th>
                                             <th>Price</th>
                                            <th>Sub Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
									foreach($products_lists as $allprolists){
									$productprice = $allprolists['productprice'];
									$productqty = $allprolists['productqty'];
									 $eachproductprice = ($productprice/$productqty);
									 $finalprice=$allprolists['finalprice'];
									
									$html.='<tr>
                                            <td>'.$allprolists['productname'].'</td>
                                            <td>'.$allprolists['productqty'].'</td>
                                            <td>HKD$'.$eachproductprice.'</td>
                                            <td>HKD$'.$allprolists['productprice'].'</td>
                                    </tr>';
									
									}
									$html.='<tr>
										<td colspan="3" style="text-align:right;"><strong>Total</strong></td><td>HKD$'.$finalprice.'
										</td>
									</tr>';
									$html.='</tbody>
                                </table>
                            </div><!-- /.col -->
                        <!-- /.row -->

                        <!-- this row will not appear when printing -->
                        <div class="row no-print">
                            <div class="col-xs-12">
                                <a href="javascript:void(0);" class="btn btn-default faprintbutton"><i class="fa fa-print"></i> Print</a>
                               
                            </div>
                        </div>
                    </section>
                </section>	
              
</div></div>';
echo $html;
}

if($type=='schedulereturnhistory'){ 
    $orderid=$_GET['orderid'];
    $useremail = $_GET['useremail'];
    $datetime = $_GET['date'];
    $currency_set = get_option('currency_set');
    echo '<h2>Show Schedule Return History Details</h2>';
    $paymentdate = explode(" ",$datetime);
    $currentpaymentdate=$paymentdate[0];
    $upload_dir   = wp_upload_dir();
    //echo "SELECT * FROM wp_schedule_return_history INNER JOIN wp_schedule_return_history_order ON wp_schedule_return_history.schedule_return_history_id= wp_schedule_return_history_order.wp_schedule_return_history_order_id where wp_schedule_return_history.useremail='$useremail' wp_schedule_return_history.delivery_status='1' ";
	
	
    $getschedulereturnlists = $wpdb->get_results("SELECT * FROM wp_schedule_return_history INNER JOIN wp_schedule_return_history_order ON wp_schedule_return_history.schedule_return_history_id= wp_schedule_return_history_order.wp_schedule_return_history_order_id where wp_schedule_return_history.useremail='$useremail' AND wp_schedule_return_history.delivery_status='1' GROUP BY wp_schedule_return_history.useremail ",ARRAY_A);
	
	
    foreach ($getschedulereturnlists as $getreturnlists) {
       // echo "<pre>"; print_r($getreturnlists); echo "</pre>";
        $fulladdress = $getreturnlists['fulladdress'];
        $deliverydate = $getreturnlists['deliverydate'];
        $deliverytime = $getreturnlists['deliverytime'];
        $id = $getreturnlists['schedule_return_history_id'];
        $useremail = $getreturnlists['useremail'];
        $user = get_user_by( 'email', $useremail );
        $user_phone = $user->user_phone;
        $user_name = $user->nickname;
        $order_id[] = $getreturnlists['order_id'].",";
    }
    //print_r($order_id);
	if(!empty($order_id)){
    $neworderids ='';
    foreach($order_id as $i=>$k)
    {
        $neworderids.=$k;
    }
    $neworderids = rtrim($neworderids,",");
	}
	
    $getproductinfo = $wpdb->get_results("SELECT * FROM `wp_order_products` WHERE `order_id` IN ($neworderids) ",ARRAY_A);
    $date = date('y');
    $duedate = date('Y');
    $duedate = date("Y-m-t", strtotime($duedate));
    ?>
    <div class="My_Stuff_main">
        <div class="Invoice_main_one">
            <section class="content content_content" id="printsall">
                <section class="invoice" id="invoices">
				<?php if(!empty($getschedulereturnlists)){ ?>
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="page-header">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/cropped-logo.png">
                                <small class="pull-right">Date:<?php echo $currentpaymentdate; ?></small>
                            </h2>
                        </div>
                    </div>
                    <div class="row invoice-info">
                       <div class="col-sm-4 invoice-col">
                            <strong>Personnal Details</strong>
                            <address>
                                <b>Name: </b> <span><?php echo $user_name; ?></span>
                                <br>
                                <b>Address:</b> <span><?php echo $fulladdress; ?></span><br>
                                <b>Phone:</b> <span><?php echo $user_phone; ?></span><br>
                                <b>Email:</b> <span><?php echo $useremail; ?></span>
                            </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                           <strong> Drop off/ Pickup Details</strong>
                            <address>
                                <b>Delivery Date: </b> <span><?php echo $deliverydate; ?></span>
                                <br>
                                <b>Delivery Time: </b> <span><?php echo $deliverytime; ?></span>
                                <br>                        
                            </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                             <strong> Order Details Details</strong>
                             <address>
                                <b>Invoice: </b> <span>I<?php echo $date; ?>000<?php echo $id; ?></span>
                                <br>
                                <b>Payment Due: </b> <span><?php echo $duedate; ?></span>
                                                               
                            </address>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Product Qty</th>
                                    <th>Store Plan</th>
                                     <th>Price</th>
                                    <th>Sub Total</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            if(!empty($getproductinfo))
                            {
                            $totalsum = 0;
                            foreach($getproductinfo as $allprolists){
                                $productname = $allprolists['productname'];
                                $order_product_id = $allprolists['order_product_id'];
                                $product_id = $allprolists['productids'];
                                $productqty = $allprolists['productqty'];
                                $productprice =$allprolists['productprice'];
                                $finalprice =  $productprice * $productqty;
                                $originalprice = $productprice / $productqty;
                                $mduration = getMonthDurationByProductId($product_id,$originalprice);
                                $totalsum = $totalsum + $finalprice;
                                $plans = $mduration[0]->meta_key;
                                if($plans=='store_plan'){ $storeplans = "Store Plan"; }
        
                                if($plans=='ktstorage_type_price'){ $storeplans = "3-5 Months"; }
                                
                                if($plans=='storage_type_price_six'){ $storeplans = "6-11 Months"; }
                                
                                if($plans=='storage_type_price_twelve'){ $storeplans = "12+ Months"; }
                                 ?>
                                <tr>
                                    <td><?php echo $productname;?></td>
                                    <td><?php echo $productqty; ?></td>
                                    <td><?php echo $storeplans; ?></td>
                                    <td><?php echo $currency_set; ?>$<?php echo $productprice; ?></td>
                                    <td><?php echo $currency_set; ?>$<?php echo $finalprice; ?></td>
                                </tr>
                                <?php }  ?>
                                <tr>
                                    <td colspan="4" style="text-align:right;">
                                        <strong>Total</strong>
                                    </td>
                                    <td><?php echo $currency_set; ?>$<?php echo $totalsum; ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row no-print">
                        <div class="col-xs-12">
                            <a href="javascript:void(0);" class="btn btn-default faprintbutton"><i class="fa fa-print"></i> Print</a>
                        </div>
                    </div>
<?php } else{echo "No Records Found";} ?>
                </section>
            </section>  
        </div>     
    </div>
<?php

}

if($type=='scheduleapickuplist'){ 
    $order_id = $_GET['order_id'];
    $product_id=$_GET['product_id'];
    $useremail = $_GET['useremail'];
    echo '<h2>Show Schedule A Pickup Details</h2>';
    $currency_set = get_option('currency_set');
    $user = get_user_by( 'email', $useremail );
    $company_name = $user->company_name;
    $user_name = $user->nickname;
    $user_phone = $user->user_phone;
    global $wpdb;
  


     $schedule_pickup_products_lists = $wpdb->get_results("SELECT * FROM wp_schedule_pickup_products INNER JOIN wp_schedule_pickup ON wp_schedule_pickup.schedule_pickup_id= wp_schedule_pickup_products.schedule_a_pickup_id where wp_schedule_pickup_products.user_mail='$useremail'",ARRAY_A);
    
    foreach ($schedule_pickup_products_lists as $pickupproductlists) {
        # code...
        $id = $pickupproductlists['schedule_pickup_product_id'];
        $full_address = $pickupproductlists['full_address'];
        $schedule_pickup_date = $pickupproductlists['schedule_pickup_date'];
        $schedule_pickup_time = $pickupproductlists['schedule_pickup_time'];
    }
    $date = date('y');
    $duedate = date('Y');
    $duedate = date("Y-m-t", strtotime($schedule_pickup_date));
    ?>
    <div class="My_Stuff_main">
        <div class="Invoice_main_one">
            <section class="content content_content" id="printsall">
                <section class="invoice" id="invoices">
				<?php if(!empty($schedule_pickup_products_lists)){ ?>
                    <div class="row">
                        <div class="col-xs-12">
                            <h2 class="page-header">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/cropped-logo.png">
                                <small class="pull-right">Date:<?php echo $schedule_pickup_date; ?></small>
                            </h2>
                        </div>
                    </div>
                    <div class="row invoice-info">
                       <div class="col-sm-4 invoice-col">
                            <strong>Personnal Details</strong>
                            <address>
                                <b>Name: </b> <span><?php echo $user_name; ?></span>
                                <br>
                                <b>Address:</b> <span><?php echo $full_address; ?></span><br>
                                <b>Phone:</b> <span><?php echo $user_phone; ?></span><br>
                                <b>Email:</b> <span><?php echo $useremail; ?></span>
                            </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                           <strong> Drop off/ Pickup Details</strong>
                            <address>
                                <b>Pickup Date: </b> <span><?php echo $schedule_pickup_date; ?></span>
                                <br>
                                <b>Pickup Time: </b> <span><?php echo $schedule_pickup_time; ?></span>
                                <br>                        
                            </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                             <strong> Order Details Details</strong>
                             <address>
                                <b>Invoice: </b> <span>I<?php echo $date; ?>000<?php echo $id; ?></span>
                                <br>
                                <b>Payment Due: </b> <span><?php echo $duedate; ?></span>
                                                               
                            </address>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Product Qty</th>
                                    <th>Store Plan</th>
                                     <th>Price</th>
                                    <th>Sub Total</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            if(!empty($schedule_pickup_products_lists))
                            {
                            $totalsum = 0;
                            foreach($schedule_pickup_products_lists as $allprolists){
                                $productname = $allprolists['product_name'];
                                $order_product_id = $allprolists['order_product_id'];
                                $product_id = $allprolists['product_id'];
                                $productqty = $allprolists['product_qty'];
                                $productprice =$allprolists['product_price'];
                                $finalprice =  $productprice * $productqty;
                                $originalprice = $productprice / $productqty;
                                $mduration = getMonthDurationByProductId($product_id,$originalprice);
                                $totalsum = $totalsum + $finalprice;
                                $plans = $mduration[0]->meta_key;
                                if($plans=='store_plan'){ $storeplans = "Store Plan"; }
        
                                if($plans=='ktstorage_type_price'){ $storeplans = "3-5 Months"; }
                                
                                if($plans=='storage_type_price_six'){ $storeplans = "6-11 Months"; }
                                
                                if($plans=='storage_type_price_twelve'){ $storeplans = "12+ Months"; }
                                 ?>
                                <tr>
                                    <td><?php echo $productname;?></td>
                                    <td><?php echo $productqty; ?></td>
                                    <td><?php echo $storeplans; ?></td>
                                    <td><?php echo $currency_set; ?>$<?php echo $productprice; ?></td>
                                    <td><?php echo $currency_set; ?>$<?php echo $finalprice; ?></td>
                                </tr>
                                <?php }  ?>
                                <tr>
                                    <td colspan="4" style="text-align:right;">
                                        <strong>Total</strong>
                                    </td>
                                    <td><?php echo $currency_set; ?>$<?php echo $totalsum; ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row no-print">
                        <div class="col-xs-12">
                            <a href="javascript:void(0);" class="btn btn-default faprintbutton"><i class="fa fa-print"></i> Print</a>
                        </div>
                    </div>
<?php } else{ echo "No Records Found";} ?>
                </section>
            </section>  
        </div>     
    </div>
    <?php 

}
