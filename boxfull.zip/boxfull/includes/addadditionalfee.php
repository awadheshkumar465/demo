<?php
if($type=='addadditonalfee'){
global $wpdb;
$html='';

if(isset($_POST['latecancellation'])){
	$latecancellation = trim($_POST['latecancellation']);
	$nowshow = trim($_POST['nowshow']);
	$outsideserviceareadelivery = trim($_POST['outsideserviceareadelivery']);
	$latepayment = trim($_POST['latepayment']);
	$stairs = trim($_POST['stairs']);
	$emptyboxpickupnonstorage = trim($_POST['emptyboxpickupnonstorage']);
	$remotelocationdeliveryfee = trim($_POST['remotelocationdeliveryfee']);
	$packingfee = trim($_POST['packingfee']);
	$parking = trim($_POST['parking']);
	$movingpenalty = trim($_POST['movingpenalty']);
	$overweightlimit = trim($_POST['overweightlimit']);
	$boxdamagefee = trim($_POST['boxdamagefee']);
	
	$inserts = $wpdb->insert('wp_additional_fee',array(
	'late_cancellation' => $latecancellation,
	'no_show' => $nowshow,
	'outside_service_area_delivery' => $outsideserviceareadelivery,
	'late_payment' => $latepayment,
	'stairs' => $stairs,
	'empty_box_pick_up_non_storage' => $emptyboxpickupnonstorage,
	'remote_location_delivery' => $remotelocationdeliveryfee,
	'packing_fee' => $packingfee,
	'parking' => $parking,
	'moving_penalty' => $movingpenalty,
	'over_weight_limit' => $overweightlimit,
	'box_damage_fee' => $boxdamagefee,
	));
	$lastid = $wpdb->insert_id; 
if($lastid>0){
	$redirect = get_the_permalink().'?type=feetypes';
	wp_redirect ($redirect);
	exit();
}
}
else {
$html.='
<div class="col-md-12">
	<h2>Additional Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Late Cancellation (Less than 24 hrs Notice) :<span class="requiredpart">*</span></label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="latecancellation" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;" required >
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<div class="col-md-3 handlingfees">
					<label for="titles">No Show :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="threefivemonths" name="nowshow" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;" required="">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<div class="col-md-3 handlingfees">
					<label for="titles">Outside Service Area Delivery :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="threefivemonths" name="outsideserviceareadelivery" id="addstoragenamepost" value="" required="">
				</div>
				<div class="col-md-3 titles"></div>
				<div class="clearer"></div>
				<div class="col-md-3 handlingfees">
					<label for="titles">Late Payment :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="threefivemonths" name="latepayment" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;" required>
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<input type="hidden" name="checkoutandrecheckinbyitem" value="checkoutandrecheckinhandlingfeebyitem" />
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Stairs :<span class="requiredpart">*</span></label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="stairs" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==2) return false;" required>
				</div>
				<div class="col-md-3 titles">Box Or Item/Level</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Empty Box Pick Up Non Storage :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="emptyboxpickupnonstorage" id="addstoragenamepost" value="" required="">
				</div>
				<div class="col-md-3 titles">Monthly Invoice</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Remote Location Delivery Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="remotelocationdeliveryfee" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Packing Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="packingfee" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">20 Mins/Box</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Parking  :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="parking" id="addstoragenamepost" value="" required="">
				</div>
				<div class="col-md-3 titles">20 Mins/Box</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Moving Penalty  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="movingpenalty" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==4) return false;">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />	
		</div>
		
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Over Weight Limit  : </label>
				</div>
				<div class="col-md-6 no-padding"
				<input type="text" class="payasyourstore" name="overweightlimit" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Box Damage Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="boxdamagefee" id="addstoragenamepost" value="" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">Per Box</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
		</div>
			<input type="hidden" name="itemcatid" value="3" />
			<input type="hidden" name="handlingfeebyitem" value="handlingfeebyitem"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Submit">
	</form>
</div>
';
echo $html;
}
}

?>
