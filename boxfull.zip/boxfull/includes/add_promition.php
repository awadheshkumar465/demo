<?php 
if(isset($_POST['addpromotions'])){
	echo $promotioncode=trim(strtoupper($_POST['promotioncode']));
	echo $promotionamount=trim($_POST['promotionamount']);
	
	$updatepromotionscode = update_option( 'promotioncode', $promotioncode );
	$updatepromotionsamount = update_option( 'promotionamount', $promotionamount );
	$redirects=get_the_permalink()."?type=allpromotions";
	echo "Promotion code updated successfully";
	wp_redirect($redirects);
	

}
else { 
?>
<form action="" class="form-horizontal" method="POST" role="form">
<h2>Add Promotion</h2>
	<div class="form-group">
	<label for="firstName" class="col-sm-3 control-label">Promotion Code :<span class="requiredpart">*</span></label>
	<div class="col-sm-9">
		<input type="text" id="promotioncode" name="promotioncode" placeholder="Add Promotion" class="form-control" autofocus="" value="" maxlength="10"  style="text-transform:uppercase" required>
	</div>
	</div>
	
	<div class="form-group">
	<label for="firstName" class="col-sm-3 control-label">Discount Amount :<span class="requiredpart">*</span></label>
	<div class="col-sm-9">
		<input type="text" id="promotionamount" name="promotionamount" placeholder="Add Promotion Amount" class="form-control" autofocus="" value="" maxlength="4" required >
		<span class="help-block">Promotion Amount, eg.: 20.3, 34,55.12</span>
	</div>
	</div>
	
	<div class="form-group">
	<div class="col-sm-3 col-sm-offset-3">
	<input type="hidden" name="addpromotionform" id="addpromotionorm" value="addpromotion">
	<input type="submit" class="btn btn-primary btn-block" name="addpromotions" value="Submit">
	</div>
     </div>
</form>
<?php } ?>



