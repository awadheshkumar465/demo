<?php if($type=='userorderlists'){ 
	echo "<h2>Show User Order Lists</h2>";
	$orderid=$_GET['orderid'];
	$useremail = $_GET['useremail'];
	$datetime = $_GET['date'];
	$currency_set = get_option('currency_set');
	$user = get_user_by( 'email', $useremail );
	$company_name = $user->company_name;
	$user_name = $user->nickname;
	global $wpdb;
	$orders_lists = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id= wp_order_products.order_id where wp_orders.useremail='$useremail' AND wp_orders.paymentstatus='paid'");

	$schedule_return_history_lists = $wpdb->get_results("SELECT * FROM wp_schedule_return_history where useremail='$useremail' AND delivery_status='1'");

	$schedule_pickup_products_lists = $wpdb->get_results("SELECT * FROM wp_schedule_pickup_products where user_mail='$useremail'"); ?>
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Customer Name</th>
					<th>Company Name</th>
					<th>Total Products</th>
					 <th>Total Price</th>
					<th>View Details</th>
				</tr>
			</thead>
			<tbody>
			<?php	
			$count = 0;
			$count1 = 0;
			foreach($orders_lists as $totalorderlists){
				$fullname = $totalorderlists->fullname;
				$finalprice = $totalorderlists->finalprice;
				$order_id = $totalorderlists->order_id;
				$count++;
			}
			if($count > 0) { ?>
				<tr>
					<td><?php echo $user_name; ?></td>
					<td><?php echo ucfirst($company_name); ?></td>
					<td><?php echo $count; ?></td>
					<td><?php echo $currency_set; ?>$<?php echo $finalprice; ?></td>
					<td class="action"><a class="edit_btn" href="<?php get_the_permalink();?>?type=orderdetailslists&date=<?php echo $datetime; ?>&orderid=<?php echo $order_id; ?>&useremail=<?php echo $useremail; ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
				</tr>
			<?php }
				foreach ($schedule_return_history_lists as $schedulelists) {
					$useremail = $schedulelists->useremail;
					$finhiddenvalprice = $schedulelists->finhiddenvalprice;
					$deliverydate = $schedulelists->deliverydate;
					$count1++;
				} 
				if($count1 > 0 ){ ?>
				<tr>
					<td><?php echo $user_name; ?></td>
					<td><?php echo $company_name; ?></td>
					<td><?php echo $count1; ?></td>
					<td><?php echo $currency_set; ?>$<?php echo $finhiddenvalprice; ?></td>
					<td class="action"><a class="edit_btn" href="<?php get_the_permalink();?>?type=schedulereturnhistory&date=<?php echo $deliverydate; ?>&useremail=<?php echo $useremail; ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
				</tr>
				<?php
				}
					$count2 = 0;
					foreach ($schedule_pickup_products_lists as $schedulepickuplists) {
						
						$product_id = $schedulepickuplists->product_id;
						$order_id = $schedulepickuplists->order_id;
						$user_mail = $schedulepickuplists->user_mail;
						$product_price = $schedulepickuplists->product_price;
						$count2++;
					}
					if($count2 > 0){ ?>
						<tr>
							<td><?php echo $user_name; ?></td>
							<td><?php echo $company_name; ?></td>
							<td><?php echo $count2; ?></td>
							<td><?php echo $currency_set; ?>$<?php echo $product_price; ?></td>
							<td class="action"><a class="edit_btn" href="<?php get_the_permalink();?>?type=scheduleapickuplist&product_id=<?php echo $product_id; ?>&order_id=<?php echo $order_id; ?>&useremail=<?php echo $useremail; ?>"><i class="fa fa-eye" aria-hidden="true"></i></a></td>
						</tr>
					<?php } ?>
			</tbody>
		</table>
	</div>
<?php
}