<?php
global $wpdb;
$currency_set = get_option('currency_set',true);
$html='';
/* edit handling fee by item starts here */
if($type=='editbyitemhandlingfee'){
	if(isset($_POST['payasyourstore'])){
		
	$payasyourstore = $_POST['payasyourstore'];
	$threefivemonths = $_POST['threefivemonths'];
	$sixelevenmonths = $_POST['sixelevenmonths'];
	$twelvemonthsplus = $_POST['twelvemonthsplus'];
	$finalcheckouthandlingfee = $_POST['finalcheckouthandlingfee'];
	
	$updates = $wpdb->update('wp_handling_fee', array('payasyourstore'=>$payasyourstore, 'threefivemonths'=>$threefivemonths, 'sixelevenmonths'=>$sixelevenmonths,'twelvemonthsplus'=>$twelvemonthsplus,'finalcheckouthandlingfee'=>$finalcheckouthandlingfee), array('handlingfeeby'=>'handlingfeebyitem'));
	if($updates>=1){
		?>
	<script type="text/javascript">
	alert ("Handling Fee By Item Updated Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
	}
	
}
else{
$byitem = getFeeByItem('handlingfeebyitem');
$payasyourstore = $byitem[0]['payasyourstore'];
$threefivemonths = $byitem[0]['threefivemonths'];
$sixelevenmonths = $byitem[0]['sixelevenmonths'];
$twelvemonthsplus = $byitem[0]['twelvemonthsplus'];
$finalcheckouthandlingfee = $byitem[0]['finalcheckouthandlingfee'];
$html.='
<div class="col-md-12">
	<h2>Edit Handling Fee By Item</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			<label class="maintitles titles">Check Out & Re-Check-In (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees"><label for="titles">Pay as you store('.$currency_set.'$):<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="payasyourstore" id="addstoragenamepost" value="'.$payasyourstore.'" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">3-5 Months('.$currency_set.'$):<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="threefivemonths" id="addstoragenamepost" value="'.$threefivemonths.'" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">6-11 Months('.$currency_set.'$)<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="sixelevenmonths" id="addstoragenamepost" value="'.$sixelevenmonths.'" required=""></div><div class="col-md-3 titles">1 Free (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">12 Months ('.$currency_set.'$):<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="twelvemonthsplus" id="addstoragenamepost" value="'.$twelvemonthsplus.'" required=""></div><div class="col-md-3 titles">2 Free (Min $80 )</div>
					<div class="clearer"></div>
					<input type="hidden" name="checkoutandrecheckinbyitem" value="checkoutandrecheckinhandlingfeebyitem" />
		</div>
		<div class="form-group">
			<label class="maintitles titles">Final Check Out (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">Final Check Out Handling Fee ('.$currency_set.'$):<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="finalcheckouthandlingfee" id="addstoragenamepost" value="'.$finalcheckouthandlingfee.'" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
				
		</div>
		
		
			<input type="hidden" name="itemcatid" value="3" />
			<input type="hidden" name="handlingfeebyitem" value="handlingfeebyitem"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Update">
	</form>
</div>
';
echo $html;
}
}
/* edit handling fee by item ends  here */

/* edit handling fee by box starts  here */
if($type=='editbyboxhandlingfee'){

if(isset($_POST['payasyourstore'])){
	$payasyourstore = $_POST['payasyourstore'];
	$threefivemonths = $_POST['threefivemonths'];
	$sixelevenmonths = $_POST['sixelevenmonths'];
	$twelvemonthsplus = $_POST['twelvemonthsplus'];
	$finalcheckouthandlingfee = $_POST['finalcheckouthandlingfee'];
	$twentyminutes = $_POST['twentyminutes'];
	$updates = $wpdb->update('wp_handling_fee', array('payasyourstore'=>$payasyourstore, 'threefivemonths'=>$threefivemonths, 'sixelevenmonths'=>$sixelevenmonths,'twelvemonthsplus'=>$twelvemonthsplus,'finalcheckouthandlingfee'=>$finalcheckouthandlingfee,'twentyminutes'=>$twentyminutes), array('handlingfeeby'=>'handlingfeebybox'));
	if($updates>=1){
		?>
	<script type="text/javascript">
	alert ("Handling Fee By Box Updated Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
	}
	
}
else{
$byboxedit = getFeeByBox('handlingfeebybox');
$payasyourstore = $byboxedit[0]['payasyourstore'];
$threefivemonths = $byboxedit[0]['threefivemonths'];
$sixelevenmonths = $byboxedit[0]['sixelevenmonths'];
$twelvemonthsplus = $byboxedit[0]['twelvemonthsplus'];
$finalcheckouthandlingfee = $byboxedit[0]['finalcheckouthandlingfee'];
$twentyminutes = $byboxedit[0]['twentyminutes'];
$html.='
<div class="col-md-12">
	<h2>Edit Handling Fee By Box</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			<label class="maintitles titles">Check Out & Re-Check-In (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees"><label for="titles">Pay as you store ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="payasyourstore" id="addstoragenamepost" value="'.$payasyourstore.'" required=""></div><div class="col-md-3 titles">Per Box (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">3-5 Months ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="threefivemonths" id="addstoragenamepost" value="'.$threefivemonths.'" required=""></div><div class="col-md-3 titles">Per Box (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">6-11 Months ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="sixelevenmonths" id="addstoragenamepost" value="'.$sixelevenmonths.'" required=""></div><div class="col-md-3 titles">1 Free (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">12 Months ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="twelvemonthsplus" id="addstoragenamepost" value="'.$twelvemonthsplus.'" required=""></div><div class="col-md-3 titles">2 Free (Min $100 )</div>
					<div class="clearer"></div>
					<input type="hidden" name="checkoutandrecheckinbybox" value="checkoutandrecheckinhandlingfeebybox" />
		</div>
		<div class="form-group">
			<label class="maintitles titles">Final Check Out (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">Final Check Out Handling Fee ('.$currency_set.'$) :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="finalcheckouthandlingfee" id="addstoragenamepost" value="'.$finalcheckouthandlingfee.'" required=""></div><div class="col-md-3 titles">Per Box (Min $100)</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbybox" value="finalcheckouthandlingfeebybox" />
				
		</div>
		
		<div class="form-group">
			<label class="maintitles titles">Empty Box Collect - Final Check Out : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">20 Mins : </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="twentyminutes" id="addstoragenamepost" value="'.$twentyminutes.'" ></div><div class="col-md-3 titles"></div>
				<div class="clearer"></div>
				<input type="hidden" name="emptyboxcollectfinalcheckoutbybox" value="emptyboxcollectfinalcheckouthandlingfeebybox" />
				
		</div>
			<input type="hidden" name="boxcatid" value="2" />
			<input type="hidden" name="handlingfeebybox" value="handlingfeebybox"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Update">
	</form>
</div>
';
echo $html;

}
}
/* edit handling fee by box ends  here */

/* Edit delivery fee starts here */

if($type=='editdeliveryfee'){
	if(isset($_POST['samebusinessday'])){ 

$samebusinessday = trim($_POST['samebusinessday']);

$nextbusinessday = trim($_POST['nextbusinessday']);

$inormorethantwobusinessday = trim($_POST['inormorethantwobusinessday']);

$afterhoursdelivery = trim($_POST['afterhoursdelivery']);

$handlingfeebydelivery = trim($_POST['handlingfeebydelivery']);

$updates = $wpdb->update('wp_handling_fee', array('samebusinessday'=>$samebusinessday, 'nextbusinessday'=>$nextbusinessday, 'inormorethantwobusinessday'=>$inormorethantwobusinessday,'afterhoursdelivery'=>$afterhoursdelivery), array('handlingfeeby'=>'deliveryfee'));
	if($updates>=1){
	?>
	<script type="text/javascript">
	alert ("Delivery Fee Updated Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
} 
}
else { 
	$deliveryfee = getFeeByDelivery('deliveryfee');
	$samebusinessday = $deliveryfee[0]['samebusinessday'];
	$nextbusinessday = $deliveryfee[0]['nextbusinessday'];
	$inormorethantwobusinessday = $deliveryfee[0]['inormorethantwobusinessday'];
	$afterhoursdelivery = $deliveryfee[0]['afterhoursdelivery'];
	$html.='
<div class="col-md-12">
	<h2>Edit Delivery Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			
				<div class="col-md-3 deliveryfee"><label for="titles">Same Business Day ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="samebusinessday" id="addstoragenamepost" value="'.$samebusinessday.'" required=""></div><div class="col-md-3 titles">Per Box</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">Next Business Day ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="nextbusinessday" id="addstoragenamepost" value="'.$nextbusinessday.'" required=""></div><div class="col-md-3 titles">Per Box </div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">In Or More Than 2 Business Days ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="inormorethantwobusinessday" id="addstoragenamepost" value="'.$inormorethantwobusinessday.'" required=""></div><div class="col-md-3 titles"></div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">After Hours Delivery ('.$currency_set.'$) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="afterhoursdelivery" id="addstoragenamepost" value="'.$afterhoursdelivery.'" required=""></div><div class="col-md-3 titles"></div>
					<div class="clearer"></div>
		</div>
		<div class="col-md-12">
			<input type="hidden" name="handlingfeebydelivery" value="deliveryfee"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Update">
		</div>
	</form>
</div>
';
echo $html;
}
}
/* Edit delivery fee ends here */

?>