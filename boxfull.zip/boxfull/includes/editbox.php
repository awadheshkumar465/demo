<?php if($type=='editboxid')
{
	global $wpdb;
	
	if(isset($_POST['hiddeneditboxid_ids'])){
		$newexp = explode(",",$_POST['hiddeneditboxid_ids']);
		$orderids = $newexp[0];
		$productid = $newexp[1];
		$order_product_id=$newexp[2];
		$addedby=$newexp[3];
		$idno = $newexp[4];
		$user_email = $newexp[5];
	}
	
	if(isset($_GET['orderid'])){
		$orderid = trim($_GET['orderid']);
		$productid = trim($_GET['productid']);
		$order_product_id = trim($_GET['order_product_id']);
		$emailid = trim($_GET['emailid']);
	}
	if(!empty($users_info))
	{
		foreach($users_info as $users)
		{
		 $user_id = $users->ID;
		}
	}
	//echo $user_id;
	$country_code = get_user_meta($user_id, 'country_code', true);
	$year = date('y');
	$cust_id = $country_code.$year."000".$user_id;

	if(isset($_POST['boximageid']))
	{
		//print_r($_POST); exit();
		$qrcodeval = $_POST['qrcodeval'];
		$storetype = $_POST['storetype'];
		$custids = $_POST['custids'];
		$boximageid = $_POST['boximageid'];
		$addwarehouse = $_POST['addwarehouse'];
		$warehouse_sections = $_POST['warehouse_sections'];
		$warehouse_location = $_POST['warehouse_location'];
		$warehouse_item_size = $_POST['warehouse_item_size'];
		$warehouse_item_wieght = $_POST['warehouse_item_wieght'];
		$warehouse_remark = $_POST['warehouse_remark'];
		$warehouse_reference = $_POST['warehouse_reference'];

		if(!empty($_FILES["product_tracking_images"]))
		{
			
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/media.php' );

			$files = $_FILES["product_tracking_images"]; 
			$attach_id=[];  
			foreach ($files['name'] as $key => $value)
			{            
				if ($files['name'][$key]) 
				{ 
					$file = array( 
					'name' => $files['name'][$key],
					'type' => $files['type'][$key], 
					'tmp_name' => $files['tmp_name'][$key], 
					'error' => $files['error'][$key],
					'size' => $files['size'][$key]
					); 
					$_FILES = array ("product_tracking_images" => $file); 
					foreach ($_FILES as $file => $array) 
					{              
						$attach_id = media_handle_upload( $file,$trackingproid );
					}
					if ($attach_id > 0)
					{
						$date = date('Y/m/d');
						
						$update = $wpdb->update('wp_boximages', array(
							'attachmentids' =>$attach_id,
							'boxid' =>$qrcodeval,
							'storage_type' =>$storetype,
							'add_warehouse'=>$addwarehouse,
							'warehouse_sections'=>$warehouse_sections,
							'warehouse_location'=>$warehouse_location,
							'warehouse_item_size'=>$warehouse_item_size,
							'warehouse_item_wieght'=>$warehouse_item_wieght,
							'warehouse_remark'=>$warehouse_remark,
							'warehouse_reference'=>$warehouse_reference,
							'customer_id' =>$custids,
							'box_add_date'=>$date
							
							),array("boximageid"=>$boximageid)); 
					}
				} 
			}
			if(empty($attach_id)){
				$date = date('Y/m/d');
						
			$update = $wpdb->update('wp_boximages', array(
							'boxid' =>$qrcodeval,
							'storage_type' =>$storetype,
							'add_warehouse'=>$addwarehouse,
							'warehouse_sections'=>$warehouse_sections,
							'warehouse_location'=>$warehouse_location,
							'warehouse_item_size'=>$warehouse_item_size,
							'warehouse_item_wieght'=>$warehouse_item_wieght,
							'warehouse_remark'=>$warehouse_remark,
							'warehouse_reference'=>$warehouse_reference,
							'customer_id' =>$custids,
							'box_add_date'=>$date
							),array("boximageid"=>$boximageid));
			}

		}
		
		?>
			<script type="text/javascript">
				alert ("Box Number and BOx Images Edited successfully.");
				window.location =  "<?php echo get_the_permalink();?>?type=allboxes&addboxes=yes";
			</script><?php 
	}
	else
	{	

		if(isset($_POST['hiddeneditboxid_ids'])){
		$newexp = explode(",",$_POST['hiddeneditboxid_ids']);
		$orderid = $newexp[0];
		$productid = $newexp[1];
		$order_product_id=$newexp[2];
		$addedby=$newexp[3];
		$idno = $newexp[4];
		$user_email = $newexp[5];
	}
	else{
		$orderid=$_GET['orderid'];
		$productid=$_GET['productid'];
		$order_product_id=$_GET['orderproductid'];
		$addedby=$_GET['addedby'];
		$user_email=$_GET['emailid'];
	}
		$box_counts = $wpdb->get_var("select count(*) FROM `wp_boximages` where productid = $productid AND useremail='$user_email'");
		if($box_counts==0){?>
		<script type="text/javascript">
			alert ("Add Id Number.");
			window.location =  "<?php echo get_the_permalink();?>?type=addboxid&orderid=<?php echo $orderid;?>&productid=<?php echo $productid;?>&orderproductid=<?php echo $order_product_id;?>&emailid=<?php echo $user_email;?>&addedby=<?php echo $addedby;?> ";
			</script>	
		<?php 
		}
		
		$getdetails = getOrderIds($orderid,$productid);
		$productname = $getdetails['producttitle'];
		$newimgsx = getBoxImgIds($orderid,$productid);
		
		$boximgsrc = getBoxImgSrc($newimgsx);
		if($boximgsrc){
			foreach($boximgsrc as $imgvals){
				$removeid=$imgvals['imageid'];
				$upload_dir   = wp_upload_dir();
				$imgpath = $upload_dir['baseurl']."/".$imgvals['imagesrc'];
			}
		}
		
		$boximagesdata = $wpdb->get_results("SELECT * FROM `wp_boximages` where productid = $productid AND useremail='$user_email'");
		foreach($boximagesdata as $boxtypes)
		{
			$boximageid = $boxtypes->boximageid;
			$orderid = $boxtypes->orderid;
			$boxid = $boxtypes->boxid;
			$storage_type = $boxtypes->storage_type;
			$customer_id = $boxtypes->customer_id;
			$add_warehouse = $boxtypes->add_warehouse;
			$warehouse_sections = $boxtypes->warehouse_sections;
			$warehouse_location = $boxtypes->warehouse_location;
			$warehouse_item_size = $boxtypes->warehouse_item_size;
			$warehouse_item_wieght = $boxtypes->warehouse_item_wieght;
			$warehouse_remark = $boxtypes->warehouse_remark;
			$warehouse_reference = $boxtypes->warehouse_reference;
		}
		$boxnumber = str_replace("'", "", $getdetails[boxnumber]);
		$html='';
		$html.='<div class="editboxID_number">
					<h2>Edit BoxId Number : </h2>
					<form class="form-horizontal" method="POST" role="form" enctype="multipart/form-data">
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 scanrow">
									<label>Add ID Number OR <a class="scanqucode" href="javascript:void(0);">Scan QR </a></label>
								</div>
								<div class="col-md-8 scanrow">
									<input type="text" name="qrcodeval" value="'.$boxid.'" class="qrcodevals">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 uploadimages">
									<label>Add Image</label>
								</div>
								<div class="col-md-8 uploadimages">
									<span class="imgsrcs">
									<img src="'.$imgvals[imagesrc].'">
									<input type="file" name="product_tracking_images[]" id="product_tracking_images[]" multiple="true" >
									</span>
								</div>
							</div>
						</div>';
						$args = array(
						'post_type'=> 'storagetype',
						'order'    => 'ASC'
						);              

						$the_query = new WP_Query( $args );
						
						$html.='
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Storage Type:</label>

								</div>
								<div class="col-md-8 sto_type">
								<select name="storetype">';
								if($the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
								$selected =get_the_title();
								if($storage_type==$selected){ $selected = "selected";} else{$selected = "";}
								$html.='
									<option value="'.get_the_title().'" '.$selected.'>'.get_the_title().'</option>';
								endwhile;
								endif;	
								$html.='
								</select>
									
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Warehouse:</label>

								</div>
								<div class="col-md-8 sto_type">
									<input type="text" name="addwarehouse" value="'.$add_warehouse.'" id="add_warehouseid">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Warehouse Sections:</label>

								</div>
								<div class="col-md-8 sto_type">
									<input type="text" name="warehouse_sections" value="'.$warehouse_sections.'" id="add_warehouse_sections" Placeholder="Enter Only Numeric Values">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Warehouse Location:</label>

								</div>
								<div class="col-md-8 sto_type">
									<input type="text" name="warehouse_location" value="'.$warehouse_location.'" id="add_warehouse_location" Placeholder="Enter Only Numeric Values">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Size:</label>

								</div>
								<div class="col-md-8 sto_type">
									<input type="text" name="warehouse_item_size" value="'.$warehouse_item_size.'" Placeholder="Enter Item Size">
								</div>
							</div>
						</div>
											
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Weight:</label>

								</div>
								<div class="col-md-8 sto_type">
									<input type="text" name="warehouse_item_wieght" value="'.$warehouse_item_wieght.'" Placeholder="Enter Item Weight" id="addwarehouse_item_wieght">
								</div>
							</div>
						</div>
						
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Remark:</label>

								</div>
								<div class="col-md-8 sto_type">
									<textarea name="warehouse_remark" >'.$warehouse_remark.'</textarea>
									
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 sto_type">
									<label>Add Reference:</label>
								</div>
								<div class="col-md-8 sto_type">
									<textarea name="warehouse_reference" >'.$warehouse_reference.'</textarea>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<div class="row">
								<div class="col-md-4 custid">
									<label>Add Customer ID OR <a class="scanqucode_custid" href="javascript:void(0);">Scan QR </a>
									</label>
								</div>
								<div class="col-md-8 custid">
									<input type="text" value="'.$customer_id.'" name="custids" class="cust_ids">
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-md-12 custid">
									<input type="hidden" name="boximageid" value="'.$boximageid.'" />
	                    			<input type="submit" class="btn btn-primary btn-block" name="update" value="Update">
								</div>
							</div>
						</div>
					<form>
		        </div>';
		echo $html;
	}
		
}