<?php
if($type=='allregions'){
	$limit = 10;
	$current_page = max( 1, get_query_var('paged') );
	$offset = ($current_page - 1) * $limit;
	$regions = get_terms( array(
		'taxonomy' => 'country',
		'hide_empty' => false,
		'number'   => $limit,
        'offset'   => $offset
		) );
 	$total_users = (int)count(get_terms());
    $total_pages = intval($total_users / $limit)- $limit;
	?>
	<div class="table-responsive">
		<?php 
		echo '<table class="table table-striped table-bordered allregions" >
			<tbody>
				<tr>
					<th>Serial No</th>
					<th>Name</th>
					<th>Description</th>
					<th>Count</th>
					<th class="action">Action</th>
				</tr>';
  				$i=1;
 				foreach($regions as $regionsname){  //print_r($regionsname);
					$region_id = $regionsname->term_id;
					$region_description = $regionsname->description;
					$region_name = $regionsname->name;
					$region_slug = $regionsname->slug;
					$region_term_taxonomy_id = $regionsname->term_taxonomy_id;
					$region_taxonomy = $regionsname->taxonomy;
					$term_count = $regionsname->count;
					$taxonomyname = $regionsname->taxonomy;
				echo '<tr>
						<td>'.$i.'</td>
						<td>'.$region_name.'</td>
						<td>'.$region_description.'</td>
						<td>'.$term_count.'</td>
						<td class="action"><a href="'.get_the_permalink().'?region_id='.$region_id.'&type=editregion" class="editusersbyid edit_btn">
						<i class="fa fa-pencil" aria-hidden="true"></i>
						</a>
						<a class="deleteregions del_btn" href="javascript:void(0);" data-regionname="'.$region_id.'" data-regiontaxonomy="'.$region_taxonomy.'">
						<i class="fa fa-trash" aria-hidden="true"></i>
						</a>
						</td>
						
				</tr>';
 
 					$i++;
 				} 

			echo '</tbody>
		</table>';
		echo '<nav class="custom-pagination" class="clearfix">';
		   echo paginate_links( array(
		      'base' =>  get_pagenum_link(1) . '%_%',
		      'format' => '&paged=%#%',
		      'prev_text' => __('Previous Page'), // text for previous page
		      'next_text' => __('Next Page'), // text for next page
		      'current' => max( 1, get_query_var('paged') ),
		      'total' => $total_pages,
		   ) );
		echo '</nav>'; ?>
	</div>
<?php
}
?>
