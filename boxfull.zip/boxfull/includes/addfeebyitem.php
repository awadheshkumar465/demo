<?php
if($type=='addbyitemhandlingfee'){
global $wpdb;
$html='';
$html.='
<div class="col-md-12">
	<h2>By Item Handling Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			<label class="maintitles titles">Check Out & Re-Check-In (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees"><label for="titles">Pay as you Store : </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="payasyourstore" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">3-5 Months : </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="threefivemonths" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">6-11 Months : </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="sixelevenmonths" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">1 Free (Min $80)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">12 Months+ : </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="twelvemonthsplus" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles"> 2 Free (Min $80)</div>
					<div class="clearer"></div>
					<input type="hidden" name="checkoutandrecheckinbyitem" value="checkoutandrecheckinhandlingfeebyitem" />
		</div>
		<div class="form-group">
			<label class="maintitles titles">Final Check Out (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">Final Check Out Handling Fee : </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="finalcheckouthandlingfee" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Item (Min $80)</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbyitem" value="finalcheckouthandlingfeebyitem" />
				
		</div>
		
		
			<input type="hidden" name="itemcatid" value="3" />
			<input type="hidden" name="handlingfeebyitem" value="handlingfeebyitem"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Submit">
	</form>
</div>
';
echo $html;
if(isset($_POST['payasyourstore'])){

$payasyourstore = trim($_POST['payasyourstore']);

$threefivemonths = trim($_POST['threefivemonths']);

$sixelevenmonths = trim($_POST['sixelevenmonths']);

$twelvemonthsplus = trim($_POST['twelvemonthsplus']);

$checkoutandrecheckinbyitem = trim($_POST['checkoutandrecheckinbyitem']);

$finalcheckouthandlingfee = trim($_POST['finalcheckouthandlingfee']);

$finalcheckoutbyitem = trim($_POST['finalcheckoutbyitem']);

$emptyitemcollectfinalcheckoutbyitem = trim($_POST['emptyitemcollectfinalcheckoutbyitem']);

$itemcatid = trim($_POST['itemcatid']);

$handlingfeebyitem = trim($_POST['handlingfeebyitem']);

$insert = $wpdb->insert('wp_handling_fee', array(
'payasyourstore' =>$payasyourstore,
'threefivemonths' =>$threefivemonths,
'sixelevenmonths' =>$sixelevenmonths,
'twelvemonthsplus' =>$twelvemonthsplus,
'checkoutandrecheckin' =>$checkoutandrecheckinbyitem,
'finalcheckouthandlingfee' =>$finalcheckouthandlingfee,
'finalcheckout' =>$finalcheckoutbyitem,
'twentyminutes' =>'',
'emptyboxcollectfinalcheckout' => $emptyitemcollectfinalcheckoutbyitem,
'boxcatid' => $itemcatid,
'handlingfeeby' => $handlingfeebyitem,
'samebusinessday' =>'',
'nextbusinessday' =>'',
'inormorethantwobusinessday' =>'',
'afterhoursdelivery' =>'',
)); 
$lastid = $wpdb->insert_id; 
if($lastid>0){
	?>
	<script type="text/javascript">
	alert ("Hndling Fee By Item Added Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
} 
}


}

?>