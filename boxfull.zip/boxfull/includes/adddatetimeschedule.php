<?php
if($type=='adddatetimeavailability'){
	global $wpdb;
	$html='';
	$html.='
	<h2>Add Holidays</h2>';
	
	if(isset($_POST['holidayname'])){
		if($_POST['timeslots']==''){
		$html.='<div class="error"><h6 style="color:#FF0000;">Please select any block time</div>';
	}
		if(!empty($_POST['timeslots'])){
			foreach($_POST['timeslots'] as $timeslotsval)
			{
				$holidayname = $_POST['holidayname'];
				$publicholidate = $_POST['publicholidate'];
				$insert = $wpdb->insert('publicholidays',array(
				'holiday_name'=>$holidayname,
				'holiday_date'=>$publicholidate,
				'time_block' =>$timeslotsval,
			));
			}
		}
			
	}
	$html.='
	<form method="POST" action="">
	
		<div class="col-md-6">
			<div class="form-group">
				<div class="holname">
					<label class="holidaynames">Holiday Name:<span class="requiredpart">*</span></label>
					<input type="text" name="holidayname" class="holidaynamesclass" required>
				</div>
			</div>
		</div>
		
		<div class="col-md-6">
			<div class="form-group">	
				<div class="holidaydatepicker">
					<label class="holidaydates">Holiday Date:<span class="requiredpart">*</span></label>
					<input type="text" name="publicholidate" id="startschedulepickupdates" placeholder="" value="" required>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group timeslotcheckbox">
				';
					$gettimeblocklist = $wpdb->get_results("select * from timeblock",ARRAY_A);
					
					if($gettimeblocklist)
					{
						
						foreach($gettimeblocklist as $timeblockvals)
						{
							$status = $timeblockvals['status'];
							$timeblockid = $timeblockvals['timeblockid'];
							$timeslot = $timeblockvals['timeslot'];
							$status = $timeblockvals['status'];
							$timeslot = $timeblockvals['timeslot'];
							//if($status == 1){$checked="checked";} else{$checked="";}
							$html.='
							<div class="block_holidaytime">
								<input class="blcoktime" type="checkbox" name="timeslots[]" value="'.$timeslot.'">'.$timeslot.'
							</div>';
						}
						
						
						
					}
				$html.='
					
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<div class="submitholidayname">
					<input type="submit" name="submit" value="Add">
				</div>
			</div>
		</div>
	
	</form>
	';
	
	$getholidaylists = $wpdb->get_results("SELECT * FROM publicholidays ",ARRAY_A);
	
	/* getting public holidays lists */
	
	if($getholidaylists)
	{ //print_r($getholidaylists);
	$html.='
	<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<tbody>
				<tr>
				<th>Holiday Name</th>
				<th>Holiday Date</th>
				<th>Blocked Time</th>
				<th class="action">Action</th>
				</tr>';
		
			foreach($getholidaylists as $holidayvals){
				//print_r($holidayvals);
				$ajaxurl = admin_url('admin-ajax.php');
				$holiday_name = $holidayvals['holiday_name'];
				$holiday_date = $holidayvals['holiday_date'];
				$holidayid = $holidayvals['holidayid'];
				$timeslot = $holidayvals['time_block'];
				$html.='
				<tr>
				<td>'.$holiday_name.' </td>
				<td>'.$holiday_date.'</td>
				<td>'.$timeslot.'</td>
				<td class="action"><a class="btn btn-default deletepublicholidays del_btn" href="javascript:void(0);" data-id="'.$holidayid.'" data-ajaxurl="'.$ajaxurl.'" ><i class="fa fa-trash" aria-hidden="true"></i></a></td>
				</tr>';
			}
		
			$html.='
			</tbody>
		</table>
	</div>
	';
	}
	/* public holidays lists ends here */
	
	/* Time slot block order */
	
	if(isset($_POST['submittimeslot'])){
		
		$count_time_slot = "select count(*) from  wp_time_slot_order_limit";
	
		$count_time_slot_limit = $wpdb->get_var($count_time_slot);
		
	if($count_time_slot_limit == 0){		
		$j=0;
		foreach($_POST['timeslots'] as $timeslotsvals){
		$blokQty = $_POST['blockqty'][$j];
		$insertslots = $wpdb->insert ('wp_time_slot_order_limit',array(
		'time_slots'=>$timeslotsvals,
		'no_of_units' =>$blokQty
		));
		
		$j++;
		}
	}
	else
	{
		$j=0;
		foreach($_POST['timeslots'] as $timeslotsvals)
		{
			if($_POST['blockqty'][$j]!='')
			{  
				
				$time_slots = $_POST['timeslots'][$j];
				
				$limit_timeslot_order_id =  $j+1; 
				
				$blokQty = $_POST['blockqty'][$j];
				
				$update=$wpdb->update('wp_time_slot_order_limit', array('time_slots'=>$time_slots, 'no_of_units'=>$blokQty), array('limit_timeslot_order_id'=>$limit_timeslot_order_id));
				
			}
		
			$j++;
		}
	}
		
	}
	
	$html.='
	<h2>Limit Orders Per Time Slot</h2>
	
	<form action="" method="post" >
	
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_timeslot">7:00am-9:00am:<span class="requiredpart">*</span></label>
					<input type="text" name="blockqty[]" value="" required>
					<input type="hidden" name="timeslots[]" value="7:00am-9:00am" />
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_timeslot">9:00am-1:00pm:<span class="requiredpart">*</span></label>
					<input type="text" name="blockqty[]" value="" required>
					<input type="hidden" name="timeslots[]" value="9:00am-1:00pm" />
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_timeslot">1:00pm-5:00pm:<span class="requiredpart">*</span></label>
					<input type="text" name="blockqty[]" value="" required>
					<input type="hidden" name="timeslots[]" value="1:00pm-5:00pm" />
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_timeslot">5:00pm-9:00pm:<span class="requiredpart">*</span></label>
					<input type="text" name="blockqty[]" value="" required>
					<input type="hidden" name="timeslots[]" value="5:00pm-9:00pm" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_timeslot">9:00pm-12:00am:<span class="requiredpart">*</span></label>
					<input type="text" name="blockqty[]" value="" required>
					<input type="hidden" name="timeslots[]" value="9:00pm-12:00am" />
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<div class="form-group">
				<div class="limitslotorder">
					<input type="submit" name="submittimeslot" value="Add">
				</div>
			</div>
		</div>
	
	
	</form>
	';
	$getblockorders = $wpdb->get_results("select * from wp_time_slot_order_limit ",ARRAY_A);
	if($getblockorders)
	{
	$html.='
	<h2>Max Units Per Time Slot</h2>
	<div class="rightedit"></div>
	<div class="table-responsive">
		<table class="table">
		<tbody>
			<tr>
				<td>Time Slots</td>
				<td>Maximum items/boxes per time slot (including pick-ups & deliveries)</td>
				
			</tr>';
			
		
			foreach($getblockorders as $blockvals)
			{
				
				$limit_timeslot_order_id = $blockvals['limit_timeslot_order_id'];
				$time_slots = $blockvals['time_slots'];
				$no_of_units = $blockvals['no_of_units'];
				$html.='
				<tr>
					<td>'.$time_slots.'</td>
					<td>'.$no_of_units.'</td>
				</tr>
				';
			}
		}
		$html.='
		</tbody>
		
		</table>
	</div>
	
	';
	/* Time slot block order */
	
	/* Limit no of order per day */
	if(isset($_POST['submitdayslot']))
	{
		
		
		$count_date_slot = "select count(*) from  wp_day_slot_order_limit";
	
		$count_day_slot_limit = $wpdb->get_var($count_date_slot);
		
	if($count_day_slot_limit == 0){		
		$j=0;
		foreach($_POST['daysslots'] as $dayslotsvals){
		$dayblokQty = $_POST['blockday'][$j];
		$insertslots = $wpdb->insert ('wp_day_slot_order_limit',array(
		'day_slots'=>$dayslotsvals,
		'no_of_units' =>$dayblokQty
		));
		
		$j++;
		}
	}
	else
	{
		//print_r($_POST);
		//exit();
		$j=0;
		foreach($_POST['daysslots'] as $daysslotssvals)
		{
			if($_POST['blockday'][$j]!='')
			{  
				
				$day_slots = $_POST['daysslots'][$j];
				
				$day_slots_id =  $j+1; 
				
				$blokQty = $_POST['blockday'][$j];
				
				$update=$wpdb->update('wp_day_slot_order_limit', array('day_slots'=>$day_slots, 'no_of_units'=>$blokQty), array('day_slots_id'=>$day_slots_id));
				
			}
		
			$j++;
		}
	}
	
		
	
	}
	$html.='
	<h2>Max Orders Per Day</h2>
	
	<form action="" method="post" >
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Monday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Monday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Tuesday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Tuesday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Wednesday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Wednesday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Thrusday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Thrusday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Friday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Friday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-4">
			<div class="form-group">
				<div class="limitslotorder">
					<label class="orderlimit_dateslot">Saturday:<span class="requiredpart">*</span></label>
					<input type="text" name="blockday[]" value="" required>
					<input type="hidden" name="daysslots[]" value="Saturday" />
				</div>
			</div>
		</div>
		
		<div class="col-md-12">
			<div class="form-group">
				<div class="limitslotorder">
					<input type="submit" name="submitdayslot" value="Add">
				</div>
			</div>
		</div>
		
	</form>
	';
	
	$getdatsblockorders = $wpdb->get_results("select * from wp_day_slot_order_limit ",ARRAY_A);
	if($getdatsblockorders)
	{
	$html.='
	<h2>Block Units Per Time</h2>
	<div class="table-responsive">
	<table class="table">
	<tbody>
		<tr>
			<td>Days</td>
			<td>Maximum number of items/boxes per day (including pick-ups and deliveries)</td>
		</tr>';
		
	
		foreach($getdatsblockorders as $blocdayskvals)
		{
			//print_r($blockvals);
			$day_slots = $blocdayskvals['day_slots'];
			$no_of_units = $blocdayskvals['no_of_units'];
			$html.='
			<tr>
				<td>'.$day_slots.'</td>
				<td>'.$no_of_units.'</td>
			</tr>
			';
		}
	}
	$html.='
	</tbody>
	
	</table>
	</div>';
	
	
	/* Limit no of order per day */
	
	echo $html;
}

?>