<?php 
if(isset($_POST['addcashcoupancode'])){
	echo $cashcoupan_code=trim(strtoupper($_POST['cashcoupan_code']));
	echo $cashcoupan_amount=trim($_POST['cashcoupan_amount']);
	$insert_data = $wpdb->insert( 
					'wp_cashcoupancode', 
					array( 
						'cashcoupan_code' => $cashcoupan_code,
						'cashcoupan_amount' => $cashcoupan_amount
					), 
					array( 
						'%s',
						'%d' 
					) 
				); 
	$redirects=get_the_permalink()."?type=allpromotions";
	echo "Promotion code updated successfully";
	wp_redirect($redirects);
	

}
else { 
?>
<form action="" class="form-horizontal" method="POST" role="form">
<h2>Add Cash Coupan Code</h2>
	<div class="form-group">
	<label for="cashcoupancode" class="col-sm-3 control-label">Cash Coupan Code :<span class="requiredpart">*</span></label>
	<div class="col-sm-9">
		<input type="text" id="cashcoupan_code" name="cashcoupan_code" placeholder="Add Cash Coupan Code" class="form-control" autofocus="" value="" maxlength="10"  style="text-transform:uppercase" required>
	</div>
	</div>
	
	<div class="form-group">
	<label for="cashcoupan_amount" class="col-sm-3 control-label">Cash Coupan Amount :<span class="requiredpart">*</span></label>
	<div class="col-sm-9">
		<input type="number" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" id="cashcoupan_amount" name="cashcoupan_amount" placeholder="Add Cash Coupan Amount" class="form-control" min="1" max="99" required >
	</div>
	</div>
	
	<div class="form-group">
	<div class="col-sm-3 col-sm-offset-3">
	<input type="submit" class="btn btn-primary btn-block" name="addcashcoupancode" value="Submit">
	</div>
     </div>
</form>
<?php } ?>



