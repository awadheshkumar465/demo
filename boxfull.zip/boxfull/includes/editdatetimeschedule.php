<?php
if($type=='editatetimeavailability'){
$html='';
//print_r($_POST);
if(isset($_POST['editstartscheduledate'])){
	$editstartscheduledate = trim($_POST['editstartscheduledate']);
	$editstarttimedisableTimeRangesExample = trim($_POST['editstarttimedisableTimeRangesExample']);
	$editendscheduledate = trim($_POST['editendscheduledate']);
	$editendtimedisableTimeRangesExample = trim($_POST['editendtimedisableTimeRangesExample']);
	
	if($editstartscheduledate){update_option( 'startscheduledate', $editstartscheduledate );}
	if($editstarttimedisableTimeRangesExample){update_option( 'startscheduletime', $editstarttimedisableTimeRangesExample );}
	if($editendscheduledate){update_option( 'endscheduledate', $editendscheduledate );}
	if($editendtimedisableTimeRangesExample){update_option( 'endscheduletime', $editendtimedisableTimeRangesExample );}
	$location =get_the_permalink()."?type=datetimeavailability";
	wp_redirect($location);
	exit();
		
	
}
else {
	
$startdate = get_option('startscheduledate');
$starttime = get_option('startscheduletime');
$enddate = get_option('endscheduledate');
$endtime = get_option('endscheduletime');
$html.='<h2>Edit Date Time Availability</h2>';
	$html.='
	<div class="user-table">
		
			<form method="POST" action="" id="" enctype="multipart/form-data">
				<div class="col-md-12">
					<div class="form-group">
						<div class="col-md-6">
						<label for="titles">Select Start Available Date <span class="requiredpart">*</span>:</label>
						<input type="text" id="editstartscheduledate" name="editstartscheduledate" value="'.$startdate.'" required>
						</div>
						<div class="col-md-6">
						<label for="titles">Select Start Available Time <span class="requiredpart">*</span>:</label>
						<input id="editstarttimedisableTimeRangesExample" type="text" name="editstarttimedisableTimeRangesExample" class="time ui-timepicker-input" value="'.$starttime.'" required>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="form-group">
					<div class="col-md-6">
						<label for="titles">Select End Available Date <span class="requiredpart">*</span>:</label>
						<input type="text" id="editendscheduledate" name="editendscheduledate" value="'.$enddate.'" required>
					</div>
					<div class="col-md-6">
					<label for="titles">Select End Available Time <span class="requiredpart">*</span>:</label>
						<input id="editendtimedisableTimeRangesExample" name="editendtimedisableTimeRangesExample" type="text" class="time ui-timepicker-input" value="'.$endtime.'" required >
					</div>
					</div>
				</div>
				<div class="col-md-12">
				<input type="hidden" class="hidden_addpostids" name="post_ids" value="1">
				<input type="hidden" id="add_post_nonce_field" name="add_post_nonce_field" value="eec9519611"><input type="hidden" name="_wp_http_referer" value="/klutterclearnew/admin-dashboard/?type=addnewstorage">
				<input type="submit" class="btn btn-default addstoragesubmit" value="Set Date Time">
				</div>
			</form>
		
	</div>
	';
}
	echo $html;
}

?>