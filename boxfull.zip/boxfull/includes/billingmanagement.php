<?php
if($type=='billingmanagement')
{ ?>
<link rel="alternate" type="" title="" href="<?php echo get_stylesheet_directory_uri().'/css/jquery.dataTables.min.css'; ?>" />
<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/datatable.js'; ?>'></script>

<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/jquery.dataTables.min.js'; ?>'></script>
<?php
global $wpdb;
$currency = get_option( 'currency_set' );

echo '<h2>Billing Management</h2>';

$adminurlajax=admin_url('admin-ajax.php' );

$invoiceforschedulereturn = $wpdb->get_results("SELECT * FROM `wp_schedulereturninformation` INNER JOIN wp_product_return_lists ON wp_schedulereturninformation.scheduleareturnid = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_product_return_lists.schedule_return_id=wp_schedule_return_history.schedulereturnid INNER JOIN wp_schedule_return_history_order ON wp_schedule_return_history.useremail =wp_schedule_return_history_order.useremail where wp_schedule_return_history_order.status!='' AND wp_schedule_return_history.delivery_status='1' GROUP BY wp_schedulereturninformation.scheduleareturnid",ARRAY_A);

?>
<div class="row admin_schedule_return_status">
	<div class="table-responsive">
	<?php $html.='
	<table id="example" class="table table-striped table-bordered display" cellspacing="0">
					<thead>
						<tr>
						
							<th>Pickup Date</th>
							<th>Billing Start Date</th>
							<th>Invoice Date</th>
							<th>Due Date</th>
							<th>Invoice #</th>
							<th>Amount</th>
							<th>Customer ID</th>
							<th>Paid By</th>
							<th>Reference</th>
							<th>Status</th>
							<th>Refund</th>
							<th>Edit/Cancel</th>
							<th class="action">Add Additional Fee</th>
							<th class="action">Add Other Bills</th>
							<th class="action">View Bill</th>
						</tr>
					</thead>
					<tbody>';

$blogusers = get_users( 'blog_id=1&orderby=nicename&role=customer' );
foreach ( $blogusers as $user ) {
	$useremails = $user->user_email;
	$display_name =$user->display_name;
	$instatement[] ="'$useremails'".",";
}
$getemail='';
foreach($instatement as $i=>$k) {
    $getemail .=$k;
}
$getemail = rtrim($getemail,',');



if(!empty($invoiceforschedulereturn))
{
	$j=0;
	foreach($invoiceforschedulereturn as $invocescheretu)
	{
		
		$pick_select_date = $invocescheretu['pick_select_date'];
		$businessday = $invocescheretu['businessday'];
		$deliverydate = $invocescheretu['deliverydate'];
		if(!empty($pick_select_date)){
			$deliverydates = $pick_select_date; 
			$pickupdate = date('d-M-y', strtotime($pick_select_date));
			
			$picupdate = date('d-M-y', strtotime($deliverydates));
			$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($deliverydates))));
		
			$year =$invoicestartdate[0];
			$month =$invoicestartdate[1];

			$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
			$invoicefirstdate = date('d-M-y', strtotime($invoicefirstdates));

			$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
			$invoicelduedate = date('d-M-y', strtotime($invoicelduedates));
			
		}
		else{
			
			$deliverydates = $deliverydate;
			
			$pickupdate = date('d-M-y', strtotime($deliverydate));
			 
			
			
			$picupdate = date('d-M-y', strtotime($deliverydates));
			$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($deliverydates))));
		
			$year =$invoicestartdate[0];
			$month =$invoicestartdate[1];

			$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
			$invoicefirstdate = date('d-M-y', strtotime($invoicefirstdates));

			$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
			$invoicelduedate = date('d-M-y', strtotime($invoicelduedates));
		}
		
		$order_id = $invocescheretu['order_id'];
		
		$order_product_id = $invocescheretu['order_product_id'];
		
		$invoiceorderid = I.date("y")."000".$order_product_id;
		
		$finhiddenvalprice = $invocescheretu['finhiddenvalprice'];
		
		$amount = $currency."$".$finhiddenvalprice; 
		
		$payment_method = $invocescheretu['payment_method'];
		
		$status = $invocescheretu['status'];
		
		$get_customer_stuffs = $wpdb->get_results("select * from wp_boximages where order_product_id =$order_product_id",ARRAY_A); 
		if(!empty($get_customer_stuffs))
		{
			$custid = $get_customer_stuffs[0]['customer_id'];
			
			$warehouse_reference = $get_customer_stuffs[0]['warehouse_reference'];
		}
		
		$product_id = $invocescheretu['product_id'];
		
		$order_product_id = $invocescheretu['order_product_id'];
		
		$useremail = $invocescheretu['useremail'];
		
		$product_name = $invocescheretu['product_name'];
		
		$product_qty = $invocescheretu['product_qty'];
		
		$product_price = $invocescheretu['product_price'];
		
		$originalprice = $product_price / $product_qty;
		
		$mduration = getMonthDurationByProductId($product_id,$originalprice);
		
		
		$scheduleareturnid = $invocescheretu['scheduleareturnid'];
		
		$wp_schedule_return_history_order_id = $invocescheretu['wp_schedule_return_history_order_id'];
		
		$return_product_id = $invocescheretu['return_product_id'];
		
		$getbillsinfo = $wpdb->get_results("select * from wp_billingmanagement where product_id=$product_id AND order_product_id=$order_product_id AND user_email='$useremail' AND schedule_a_returnid_bill !='' order by billing_main_id ASC",ARRAY_A);
		
		//getBillingManagementDetails($product_id,$order_product_id,$useremail);
		
		
		//echo "<pre>"; print_r($mduration); echo "</pre>";
		
		$plans = $mduration[0]->meta_key;//store_plan
		
		if($plans=='store_plan'){ $storeplans = "Store Plan"; }
		
		if($plans=='ktstorage_type_price'){ $storeplans = "3-5 Months"; }
		
		if($plans=='storage_type_price_six'){ $storeplans = "6-11 Months"; }
		
		if($plans=='storage_type_price_twelve'){ $storeplans = "12+ Months"; }
		
		
		if(!empty($getbillsinfo))
		{
			
			//echo "<pre>"; print_r($getbillsinfo); echo "</pre>";
			$billing_main_id = $getbillsinfo[0]['billing_main_id'];
			$product_qty = $getbillsinfo[0]['product_qty'];
			$product_price = $getbillsinfo[0]['product_price'];
			$proemail = $getbillsinfo[0]['user_email'];
			$storage_fee = $getbillsinfo[0]['storage_fee'];
			$handling_fee = $getbillsinfo[0]['handling_fee'];
			$delivery_fee = $getbillsinfo[0]['delivery_fee'];
			$additional_fee = $getbillsinfo[0]['additional_fee'];
			$schedule_a_returnid_bill = $getbillsinfo[0]['schedule_a_returnid_bill'];
			
			$wp_schedule_return_history_order_id_bill = $getbillsinfo[0]['wp_schedule_return_history_order_id_bill'];
			if ((in_array($schedule_a_returnid_bill, $invoiceforschedulereturn[$j]))&&(in_array($wp_schedule_return_history_order_id_bill, $invoiceforschedulereturn[$j])))
			{
				$schedule_a_returnid_bills = $schedule_a_returnid_bill;
				$wp_schedule_return_history_order_id_billsp = $wp_schedule_return_history_order_id_bill; 
			}
			else
			{
				$schedule_a_returnid_bills='';
				$wp_schedule_return_history_order_id_billsp='';
			}
		}
		
		//echo "<pre>"; print_r($invocescheretu); echo "</pre>";
		
		
		$html.='
		<tr>
			<td>'.$picupdate.'</td>
			<td>26-Oct-17</td>
			<td>'.$invoicefirstdate.'</td>
			<td>'.$invoicelduedate.'</td>
			<td>'.$invoiceorderid.'</td>
			<td>'.$amount.'</td>
			<td>'.$custid.'</td>
			<td>'.ucfirst($payment_method).'</td>
			<td>'.ucfirst($warehouse_reference).'</td>
			<td>'.ucfirst($status).'</td>
			<td></td>
			<td class="action">
				<a href="#" class="edit_btn">
					<i class="fa fa-pencil" aria-hidden="true"></i>
				</a>
				<a href="#" class="del_btn">
					<i class="fa fa-times" aria-hidden="true"></i>
				</a>
			</td>
		<td class="action">';
			if((!empty($schedule_a_returnid_bills))&& (!empty( $wp_schedule_return_history_order_id_billsp)))
			{
				
			}
			else{
			$html.='
			<a href="'.get_the_permalink().'?type=mannualbillings&orderproid='.$order_product_id.'&schereturnid='.$scheduleareturnid.'&useremail='.$useremail.'&orderhistoryid='.$wp_schedule_return_history_order_id.'&returnproid='.$return_product_id.' &action=add" class="addmanualbills edit_btn">
							<i class="fa fa-plus" aria-hidden="true"></i>
							</a>
			';
			}
			if(!empty($schedule_a_returnid_bills)){ 
			$html.='
			<a href="'.get_the_permalink().'?type=editmannualbillings&billingid='.$billing_main_id.'" class="addmanualbills edit_btn">
				<i class="fa fa-pencil" aria-hidden="true"></i>
			</a>';
			}
			if(!empty($schedule_a_returnid_bills)){
			$html.='
			<a class="delbillingmana del_btn" href="javascript:void(0);" data-billingid="'.$billing_main_id.'" data-emailid="'.$proemail.'" data-ajaxurl="'.$adminurlajax.'">
			<i class="fa fa-trash" aria-hidden="true"></i>
			</a>';
			}
		$html.='</td>';
		$html.='<td class="action">';
		if((!empty($schedule_a_returnid_bills))&& (!empty( $wp_schedule_return_history_order_id_billsp)))
		{ 
			if(($storage_fee!='0')||($handling_fee!='0')||($delivery_fee!='0')||($additional_fee!='0')){}
			else 
			{
				$html.='<a href="'.get_the_permalink().'?type=addotherbills&otherbillingid='.$billing_main_id.'" class="addmanualbills edit_btn">
					<i class="fa fa-plus" aria-hidden="true"></i>
				</a>';
			}
			$html.='<a href="'.get_the_permalink().'?type=editotherbillingid&editbillinglstid=<?php echo $billing_main_id;?>" class="addmanualbills edit_btn">
				<i class="fa fa-pencil" aria-hidden="true"></i>
			</a>';
						
		}
		else{$html.='Add Additional Fee first.';}
						
		$html.='</td>';
		$html.='<td class="action"><a class="edit_btn" href="'.get_the_permalink().'?type=viewbillingtemplate&stype='.$storeplans.'&schretid='.$scheduleareturnid.'&schrethistoryid='.$wp_schedule_return_history_order_id.'&email='.$useremail.'"><i class="fa fa-eye" aria-hidden="true"></i></a></td>	';
		$html.='</tr>';
	$j++;				
	}

}

$getpickupinfo = $wpdb->get_results("SELECT * FROM `wp_schedule_pickup`Inner Join wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id =  wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_a_pickup_id= wp_schedule_pickup_order.schedule_a_pickup_ids where wp_schedule_pickup_order.payment_status!='' AND wp_schedule_pickup_order.pickup_status='1' GROUP BY wp_schedule_pickup.schedule_pickup_id",ARRAY_A);
if(!empty($getpickupinfo))
{
	foreach($getpickupinfo as $pickupinfo)
			{
				
				$deliverydates = $pickupinfo['schedule_pickup_date'];
				
				$picupdate = date('d-M-y', strtotime($deliverydates));
				
				$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($deliverydates))));
			
				$year =$invoicestartdate[0];
				$month =$invoicestartdate[1];

				$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
				$invoicefirstdate = date('d-M-y', strtotime($invoicefirstdates));

				$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
				$invoicelduedate = date('d-M-y', strtotime($invoicelduedates));
				
				$order_product_id = $pickupinfo['order_product_id'];
				$invoiceorderid = I.date("y")."000".$order_product_id;
				
				$amount = $currency."$".$pickupinfo['pickup_final_price'];
				
				$get_customer_stuffs = $wpdb->get_results("select * from wp_boximages where order_product_id =$order_product_id",ARRAY_A); 
				if(!empty($get_customer_stuffs))
				{
					$custid = $get_customer_stuffs[0]['customer_id'];
					
					$warehouse_reference = $get_customer_stuffs[0]['warehouse_reference'];
				}
				
				//echo "<pre>"; print_r($pickupinfo); echo "</pre>";
				
				$schedule_pickup_orderid = $pickupinfo['schedule_pickup_orderid'];
				
				$schedule_a_pickup_product_id =$pickupinfo['schedule_a_pickup_product_id'];
						
				$schedule_a_pickup_ids =$pickupinfo['schedule_a_pickup_ids'];
				
				$pick_up_product_id =$pickupinfo['pick_up_product_id'];
				
				$order_product_id_pickup =$pickupinfo['order_product_id_pickup'];
				
				$order_id_pickup =$pickupinfo['order_id_pickup'];
				
				$product_name_pickup =$pickupinfo['product_name_pickup'];
				
				$product_qty_pickup =$pickupinfo['product_qty_pickup'];
				
				$product_price_pickup =$pickupinfo['product_price_pickup'];
				
				$user_email_pickup =$pickupinfo['user_email_pickup'];
				
				$payment_method = $pickupinfo['payment_method'];
				
				$payment_status = $pickupinfo['payment_status'];
				 
				$getbillsinfo= $wpdb->get_results("select * from wp_billingmanagement where product_id=$pick_up_product_id AND order_product_id=$order_product_id_pickup AND user_email='$user_email_pickup' AND schedule_pickup_orderid!='0' ",ARRAY_A);
				
				if(!empty($getbillsinfo))
				{
					//echo "<pre>"; print_r($getbillsinfo); echo "</pre>";
						$billing_main_id = $getbillsinfo[0]['billing_main_id'];
						$product_qty = $getbillsinfo[0]['product_qty'];
						$product_price = $getbillsinfo[0]['product_price'];
						$proemail = $getbillsinfo[0]['user_email'];
						$storage_fee = $getbillsinfo[0]['storage_fee'];
						$handling_fee = $getbillsinfo[0]['handling_fee'];
						$delivery_fee = $getbillsinfo[0]['delivery_fee'];
						$additional_fee = $getbillsinfo[0]['additional_fee'];
				}
				
				$html.='
				<tr>
					<td>'.$picupdate.'</td>
					<td>26-Oct-17</td>
					<td>'.$invoicefirstdate.'</td>
					<td>'.$invoicelduedate.'</td>
					<td>'.$invoiceorderid.'</td>
					<td>'.$amount.'</td>
					<td>'.$custid.'</td>
					<td>'.ucfirst($payment_method).'</td>
					<td>'.ucfirst($warehouse_reference).'</td>
					<td>'.ucfirst($status).'</td>
					<td></td>
					<td class="action">
						<a href="#" class="edit_btn">
							<i class="fa fa-pencil" aria-hidden="true"></i>
						</a>
						<a href="#" class="del_btn">
							<i class="fa fa-times" aria-hidden="true"></i>
						</a>
						</td>
						<td class="action">';
					if(!empty($billing_main_id)){
					
					} else{
					$html.='<td class="action">
					<a href="'.get_the_permalink().'?type=mannualbillings&schpupoid='.$schedule_pickup_orderid.'&useremail='.$user_email_pickup.'&action=add" class="addmanualbills edit_btn">
						<i class="fa fa-plus" aria-hidden="true"></i>
						</a>';
						}
					if(!empty($billing_main_id)){
						
						$html.='
						<a href="'.get_the_permalink().'?type=editmannualbillings&billingid='.$billing_main_id.'" class="addmanualbills edit_btn">
					<i class="fa fa-pencil" aria-hidden="true"></i>
					</a>
						';
					}
					if(!empty($billing_main_id)){ 
					$html.='
					<a class="delbillingmana del_btn" href="javascript:void(0);" data-billingid="'.$billing_main_id.'" data-emailid="'.$proemail.'" data-ajaxurl="'.$adminurlajax.'">
					<i class="fa fa-trash" aria-hidden="true"></i>
					</a>
					';
					}
		$html.='</td>';
		$html.='<td class="action">';
		if(!empty($billing_main_id))
		{ 
			if(($storage_fee!='0')||($handling_fee!='0')||($delivery_fee!='0')||($additional_fee!='0')){}
			else 
			{
				$html.='<a href="'.get_the_permalink().'?type=addotherbills&otherbillingid='.$billing_main_id.'" class="addmanualbills edit_btn">
					<i class="fa fa-plus" aria-hidden="true"></i>
				</a>';
			}
			$html.='<a href="'.get_the_permalink().'?type=editotherbillingid&editbillinglstid=<?php echo $billing_main_id;?>" class="addmanualbills edit_btn">
				<i class="fa fa-pencil" aria-hidden="true"></i>
			</a>';
						
		}
		else{$html.='Add Additional Fee first.';}
						
		$html.='</td>';
		$html.='<td class="action"><a class="edit_btn" href="javascript:void(0);"><i class="fa fa-eye" aria-hidden="true"></i></a></td>	';
		$html.='</tr>';
				
			
			}
}
$getneworders = $wpdb->get_results("select * from wp_orders INNER JOIN wp_order_products on wp_orders.order_id=wp_order_products.order_id where wp_orders.paymentstatus!='' group by wp_orders.useremail",ARRAY_A);	

if(!empty($getneworders))
{
	foreach($getneworders as $neworderinfo)
	{
		
		$pick_select_date = $neworderinfo['pick_select_date'];
		
		$select_drop_off_date = $neworderinfo['select_drop_off_date'];
		
		if(!empty($pick_select_date))
		{
			$picupdate = date('d-M-y', strtotime($pick_select_date));
				
			$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($pick_select_date))));
		
			$year =$invoicestartdate[0];
			$month =$invoicestartdate[1];

			$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
			$invoicefirstdate = date('d-M-y', strtotime($invoicefirstdates));

			$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
			$invoicelduedate = date('d-M-y', strtotime($invoicelduedates));
		}
		else
		{
			$select_drop_off_date = $neworderinfo['select_drop_off_date'];
			
			$picupdate = date('d-M-y', strtotime($select_drop_off_date));
				
			$invoicestartdate = explode("/",date('Y/m/d', strtotime('+1 month', strtotime($select_drop_off_date))));
		
			$year =$invoicestartdate[0];
			$month =$invoicestartdate[1];

			$invoicefirstdates = date('Y/m/d', mktime(0, 0, 0, $month, 15, $year));
			$invoicefirstdate = date('d-M-y', strtotime($invoicefirstdates));

			$invoicelduedates = date('Y-m-t', mktime(0, 0, 0, $month, 1, $year));
			$invoicelduedate = date('d-M-y', strtotime($invoicelduedates));
		}
		
		$order_product_id = $neworderinfo['order_product_id'];
		
		$order_id = $neworderinfo['order_id'];
		
		$invoiceorderid = I.date("y")."000".$order_id;
		
		$amount = $currency."$".$neworderinfo['finalprice'];
		
		$paymentmode = $neworderinfo['paymentmode'];
		
		$paymentstatus = $neworderinfo['paymentstatus'];
		
		$get_customer_stuffs = $wpdb->get_results("select * from wp_boximages where order_product_id =$order_product_id",ARRAY_A); 
		if(!empty($get_customer_stuffs))
		{
			$custid = $get_customer_stuffs[0]['customer_id'];
			
			$warehouse_reference = $get_customer_stuffs[0]['warehouse_reference'];
		}
		
		
		
		$order_id = $neworderinfo['order_id'];
		
		$order_product_id = $neworderinfo['order_product_id'];
		
		$productname = $neworderinfo['productname'];
		
		$productqty = $neworderinfo['productqty'];
		
		$finalprice = $neworderinfo['finalprice'];
		
		$product_id = $neworderinfo['productids'];
		
		$select_drop_off_date = $neworderinfo['select_drop_off_date'];
		
		$useremail = $neworderinfo['useremail'];
		
		$getinoneworder=$wpdb->get_results("select * from wp_billingmanagement where product_id=$product_id AND order_product_id=$order_product_id AND user_email='$useremail' ",ARRAY_A);
		
		//echo "<pre>"; print_r($neworderinfo); echo "</pre>";
		
		if(!empty($getinoneworder))
		{
			//echo "<pre>"; print_r($getinoneworder); echo "</pre>";
			$billing_main_id = $getbillsinfo[0]['billing_main_id'];
			$product_qty = $getbillsinfo[0]['product_qty'];
			$product_price = $getbillsinfo[0]['product_price'];
			$proemail = $getbillsinfo[0]['user_email'];
			$storage_fee = $getbillsinfo[0]['storage_fee'];
			$handling_fee = $getbillsinfo[0]['handling_fee'];
			$delivery_fee = $getbillsinfo[0]['delivery_fee'];
			$additional_fee = $getbillsinfo[0]['additional_fee'];
		}
		
		$html.='
		<tr>
			<td>'.$picupdate.'</td>
			<td>26-Oct-17</td>
			<td>'.$invoicefirstdate.'</td>
			<td>'.$invoicelduedate.'</td>
			<td>'.$invoiceorderid.'</td>
			<td>'.$amount.'</td>
			<td>'.$custid.'</td>
			<td>'.ucfirst($paymentmode).'</td>
			<td>'.ucfirst($warehouse_reference).'</td>
			<td>'.ucfirst($paymentstatus).'</td>
			<td></td>
			<td class="action">
				<a href="#" class="edit_btn">
					<i class="fa fa-pencil" aria-hidden="true"></i>
				</a>
				<a href="#" class="del_btn">
					<i class="fa fa-times" aria-hidden="true"></i>
				</a>
				</td>';
				$html.='<td class="action">';
				if(!empty($billing_main_id)){
				
				} else{
					$html.='<a href="'.get_the_permalink().'?type=mannualbillings&schpupoid='.$schedule_pickup_orderid.'&useremail='.$user_email_pickup.'&action=add" class="addmanualbills edit_btn">
						<i class="fa fa-plus" aria-hidden="true"></i>
						</a> ';
				}
				if(!empty($billing_main_id)){
					$html.='
					<a href="'.get_the_permalink().'?type=editmannualbillings&billingid='.$billing_main_id.'" class="addmanualbills edit_btn">
						<i class="fa fa-pencil" aria-hidden="true"></i>
					</a>';
				}
				if(!empty($billing_main_id)){
					$html.='
					<a class="delbillingmana del_btn" href="javascript:void(0);" data-billingid="'.$billing_main_id.'" data-emailid="'.$proemail.'" data-ajaxurl="'.$adminurlajax.'">
						<i class="fa fa-trash" aria-hidden="true"></i>
						</a>
					';
				}
				$html.='</td>';
		$html.='<td class="action">';
		if(!empty($billing_main_id))
		{ 
			if(($storage_fee!='0')||($handling_fee!='0')||($delivery_fee!='0')||($additional_fee!='0')){}
			else 
			{
				$html.='<a href="'.get_the_permalink().'?type=addotherbills&otherbillingid='.$billing_main_id.'" class="addmanualbills edit_btn">
					<i class="fa fa-plus" aria-hidden="true"></i>
				</a>';
			}
			$html.='<a href="'.get_the_permalink().'?type=editotherbillingid&editbillinglstid=<?php echo $billing_main_id;?>" class="addmanualbills edit_btn">
				<i class="fa fa-pencil" aria-hidden="true"></i>
			</a>';
						
		}
		else{$html.='Add Additional Fee first.';}
						
		$html.='</td>';
		$html.='<td class="action"><a class="edit_btn" href="javascript:void(0);"><i class="fa fa-eye" aria-hidden="true"></i></a></td>	';
				$html.='</tr>';
		
	}
}	
$html.='			
</tbody>
</table>';
echo $html;
?>					
</div>
</div>


<?php
}
?>
<script type="text/javascript">
jQuery(document).ready(function() {
var table = jQuery('#example').DataTable();

// Event listener to the two range filtering inputs to redraw on input
jQuery('#min, #max').keyup( function() {
table.draw();
} );
var rowCount = jQuery('#example tr').length;


	if(rowCount>=11){
		jQuery('div#example_length').css('display','block');
		jQuery('div#example_paginate').css('display','block');
	}
	else{
		jQuery('div#example_length').css('display','none');
		jQuery('div#example_paginate').css('display','none');
		
	}
  jQuery('#example_filter label input').attr('placeholder','search');
} );
</script>
<!--
<script type="text/javascript">
jQuery(document).ready(function() {
var table = jQuery('#example1').DataTable();

// Event listener to the two range filtering inputs to redraw on input
jQuery('#min, #max').keyup( function() {
table.draw();
} );
var rowCount = jQuery('#example1 tr').length;

//alert (rowCount);

	if(rowCount>=11){
		jQuery('div#example1_length').css('display','block');
		jQuery('div#example1_paginate').css('display','block');
	}
	else{
		jQuery('div#example1_length').css('display','none');
		jQuery('div#example1_paginate').css('display','none');
		
	}
	
	
	
  jQuery('#example1_filter label input').attr('placeholder','search');
} );
</script>-->


