<?php if($type=='addboxid'){
	global $wpdb;
	$html='';
	$valexp = explode(",",$_POST['hiddenaddidnoorder_ids']);
	//print_r($_POST);
	$orderid=$valexp[0];
	$productid=$valexp[1];
	$order_product_id=$valexp[2];
	$addedby=$valexp[3];
	$box_id=$valexp[4]; 
	$user_email=$valexp[5];
	$user_id=$valexp[6];
	$users = get_user_by('email',$user_email);
	$userid = $users->ID;
	$user_country = get_user_meta($userid,'country_code',true);
	
	if(isset($_GET['orderid']))
	{
		$orderid=$_GET['orderid'];
		$productid=$_GET['productid'];
		$order_product_id=$_GET['orderproductid'];
		$addedby=$_GET['addedby'];
		$user_email=$_GET['emailid'];
	}
	$country_code = get_user_meta($user_id, 'country_code', true);
	$year = date('y');
	$boxid = "AM000".$userid;
	$nums= $wpdb->get_var("SELECT count(*) as total FROM `wp_boximages` where order_product_id=$order_product_id AND orderid=$orderid AND useremail='$user_email'");

	if($nums>0){ ?>
	<script type="text/javascript">
		alert ("Box number and images are already available. Click here to edit/add more image.");
		window.location =  "<?php echo get_the_permalink();?>?type=editboxid&orderid=<?php echo $orderid;?>&productid=<?php echo $productid; ?>&order_product_id=<?php echo $order_product_id;?>&emailid=<?php echo $user_email;?> ";
		</script>	
	<?php
	}
	else
	{
		$getstorage = $wpdb->get_results("SELECT * FROM `wp_order_products` INNER JOIN  wp_orders ON wp_order_products.`order_id` =  wp_orders.order_id where  wp_order_products.`useremail`='$user_email' AND wp_order_products.`order_product_id`=$order_product_id AND  wp_orders.paymentstatus='paid'",ARRAY_A);
					if(!empty($getstorage)){
							
						foreach($getstorage as $boxtypes){
							$productname=$boxtypes['productname'];
						}
					} ?>
		<h2>Add ID Number: </h2>
		<form action="<?php echo get_the_permalink();?>?type=addboxid" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-6 scanrow">
					<label>Add ID Number OR <a class="scanqucode" href="javascript:void(0);">Scan QR: </a><span class="requiredpart">*</span>
					<?php 
					$users = get_user_by('email',$user_email);
					$userid = $users->ID;
					$user_country = get_user_meta($userid,'country_code',true); ?>
					</label>
				</div>
				<div class="col-md-6 scanrow">
					<input type="text" name="qrcodeval" value="" class="qrcodevals" placeholder="<?php echo $boxid; ?>" required>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 uploadimages">
					<label>Add Image <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 uploadimages">
					<input name="myFiles" type="file" class="proimage" required>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 sto_type">
					<label>Add Storage Type:<span class="requiredpart">*</span></label>
				</div>
				<div class="col-md-6 sto_type">
				<select name="storetype">';
				<?php $args = array(
								'post_type'=> 'storagetype',
								'order'    => 'ASC'
								);              

				$the_query = new WP_Query( $args );
				if($the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
				$selected =get_the_title();
				if($box_id==$selected){ $selected = "selected";} else{$selected = "";}
				
				?>
				
				<option value="<?php echo get_the_title();?>" <?php echo $selected;?>><?php echo get_the_title();?></option>;
				<?php 
				endwhile;
				endif;
				?>	
				</select>
				</div>
			</div>
			
			
			<div class="row">
				<div class="col-md-6 custid">
					<label>Add Warehouse: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 custid">
					<input type="text" name="addwarehouse" value="" class="addwarehouse" placeholder="Add Warehouse" required>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 warehousesection">
					<label>Add Warehouse Sections: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 warehousesection">
					<input type="text" name="warehouse_sections" value="" class="warehouse_sections" placeholder="Enter Numeric Values Only" required id="add_warehouse_sections">
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 warehouselocation">
					<label>Add Warehouse Location: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 warehouselocation">
					<input type="text" name="warehouse_location" value="" class="warehouse_sections" id="add_warehouse_location" Placeholder="Enter Only Numeric Values" required >
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 addsize">
					<label>Add Size: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 addsize">
					<input type="text" name="warehouse_item_size" value="" class="warehouse_sections" id="add_warehouse_location" Placeholder="Enter Item Size" required >
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 addweight">
					<label>Add Weight: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 addweight">
					<input type="text" name="warehouse_item_wieght" value="" class="warehouse_sections" id="add_warehouse_location" Placeholder="Enter Item Weight" id="addwarehouse_item_wieght" required >
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 addwremakr">
					<label>Add Remark: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 addwremakr">
					<textarea name="warehouse_remark" ></textarea>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 addreferenece">
					<label>Add Reference: <span class="requiredpart">*</span>:</label>
				</div>
				<div class="col-md-6 addreferenece">
					<textarea name="warehouse_reference" ></textarea>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6 custid">
					<label>Add Customer ID OR <span class="scanqucode_custid" href="javascript:void(0);">Scan QR:<span class="requiredpart">*</span> </span>
					
					</label>
				</div>
				<div class="col-md-6 custid">
					<input type="text" value="<?php echo "HK"."000".$userid;?>" name="custids" class="cust_ids" required>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 submitbutton">
					<input type="hidden" name="hidden_order_id" value="<?php echo $orderid; ?>" />
					<input type="hidden" name="hidden_product_id" value="<?php echo $productid; ?>" />
					<input type="hidden" name="hidden_order_product_id" value="<?php echo $order_product_id; ?>" />
					
					<input type="hidden" name="hidden_user_email" value="<?php echo $user_email; ?>" />
					<input type="hidden" name="hidden_added_by" value="<?php echo $addedby; ?>" />
					<input type="submit" name="submitaddid" value="Add ID Number" />
				</div>
			</div>
		</form> 
	<?php } 
	if(isset($_POST['submitaddid'])){
		
		
		 $box_id = $_POST['qrcodeval'];
		 $useremail = $_POST['hidden_user_email'];
		 $orderid = $_POST['hidden_order_id'];
		 $productid = $_POST['hidden_product_id'];
		 $order_product_id = $_POST['hidden_order_product_id'];
		 $added_by = $_POST['hidden_added_by'];
		 $storetype = $_POST['storetype'];
		 
		 $addwarehouse = trim($_POST['addwarehouse']);
		 $warehouse_sections = trim($_POST['warehouse_sections']);
		 $warehouse_location = trim($_POST['warehouse_location']);
		 $warehouse_item_size = trim($_POST['warehouse_item_size']);
		 $warehouse_item_wieght = trim($_POST['warehouse_item_wieght']);
		 $warehouse_remark = trim($_POST['warehouse_remark']);
		 $warehouse_reference = trim($_POST['warehouse_reference']);
		 $custids = $_POST['custids'];
		 $date = date('Y/m/d');

		// print_r($_POST);
		// exit();

		$insert = $wpdb->insert('wp_boximages', array(
			'orderid' =>$orderid,
			'productid' =>$productid,
			'order_product_id' =>$order_product_id,
			'boxid' =>$box_id,
			'useremail' =>$useremail,
			'addedby' =>$added_by,
			'storage_type' =>$storetype,
			'add_warehouse'=>$addwarehouse,
			'warehouse_sections'=>$warehouse_sections,
			'warehouse_location'=>$warehouse_location,
			'warehouse_item_size'=>$warehouse_item_size,
			'warehouse_item_wieght'=>$warehouse_item_wieght,
			'warehouse_remark'=>$warehouse_remark,
			'warehouse_reference'=>$warehouse_reference,
			'customer_id' =>$custids,
			'box_add_date'=>$date
			)); 
		$lastid = $wpdb->insert_id; 
		if ($_FILES) {
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
			foreach ($_FILES as $file => $array) 
			{ 
				if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK)
				{
					return "upload error : " . $_FILES[$file]['error'];
				}
				$attach_id = media_handle_upload( $file, $new_post );
			} 
			if ($attach_id > 0){
				$update = $wpdb->update('wp_boximages', array(
						'attachmentids' =>$attach_id
						),array("boximageid"=>$lastid)); 
			}  
		}
		if((!empty($lastid)) ||(!empty($attach_id))){
			$location =get_the_permalink()."?type=allboxes";
   		wp_redirect(site_url('admin-dashboard/?type=allboxes'));
    		exit(); 
		}
	}
		
	//echo $html;
						
}
?>