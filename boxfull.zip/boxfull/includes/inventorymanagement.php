<?php
if($type=='inventorymanagement'){ ?>
<script type="text/javascript">
jQuery(document).ready(function(){
/* Add Box ID admin section starts here */
	jQuery("input.addboxitemsnoids").click(function(e){
		alert ("esdf");
		
            var favorite = [];
            jQuery.each(jQuery("input[name='checkboxorderids']:checked"), function(){ 
			favorite.push(jQuery(this).val());
			jQuery('.hiddenaddidnoorder_ids').val(favorite); 
			
            });
			if(favorite==''){
				alert ("Please select a product.");
				e.preventDefault();
				return false;
			}
			else{
				
			}
			
            
        });
});
/* Add Box ID admin section ends here */
</script>
<link rel="alternate" type="" title="" href="<?php echo get_stylesheet_directory_uri().'/css/jquery.dataTables.min.css'; ?>" />
<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/datatable.js'; ?>'></script>

<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/jquery.dataTables.min.js'; ?>'></script>
<?php
global $wpdb;
echo '<h2>Inventory</h2>';
//$selects = getScheduleAReturnInformation();		
?>
<!--Showing all Schedule a return Information lists -->
<div class="row admin_schedule_return_status">
<?php $ajaxurl = admin_url("admin-ajax.php"); ?>
<input type="hidden" value="<?php $ajaxurl; ?>" name="adminurls" class="adminurls">
	<div class="table-responsive">
	
	<?php
	
	$newhtml='';
				$newhtml.='
				<table id="example" class="table table-striped table-bordered display" cellspacing="0">
					<thead>
						<tr>
						
							<th>Item/Box ID</th>
							<th>First Storage date</th>
							<th>Days in Storage</th>
							<th>Store Plan</th>
							<th>Warehouse</th>
							<th>Section</th>
							<th>Location</th>
							<th>Category</th>
							<th>Keyword</th>
							<th>Description</th>
							<th>Storage Type</th>
							<th>Size (HxWxD cm)</th>
							<th>Weight (Kg)</th>
							<th>Status</th>
							<th>Schedule</th>
							<th>Customer</th>
							<th>Empty Box with customer (days)</th>
							<th>Transaction History</th>
							<th class="boximg_datatable">Image</th>
							<th>Remark</th>
							
							
						</tr>
					</thead>
					
					<tbody>';
					
	$blogusers = get_users( 'blog_id=1&orderby=nicename&role=customer' );
// Array of WP_User objects.
foreach ( $blogusers as $user ) {
	//print_r($user);
	//echo "<br>";
	$useremails = $user->user_email;
	//echo "<br>";
	$display_name =$user->display_name;
	
	$instatement[] ="'$useremails'".",";
}
$getemail='';

foreach($instatement as $i=>$k) {
    $getemail .=$k;
}
$getemail = rtrim($getemail,',');

	//echo "select * from wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id INNER JOIN wp_boximages ON wp_order_products.order_id = wp_boximages.orderid INNER JOIN wp_box_sub_images_pick_up ON wp_boximages.attachmentids = wp_box_sub_images_pick_up.main_image_attachment_id where wp_orders.useremail IN($getemail) and  wp_orders.paymentstatus!='' group by wp_boximages.boximageid order by wp_boximages.boximageid DESC "; 
	
	$getInverntoryOutput = $wpdb->get_results("select * from wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id INNER JOIN wp_boximages ON wp_order_products.order_product_id = wp_boximages.order_product_id LEFT JOIN wp_box_sub_images_pick_up ON wp_boximages.attachmentids = wp_box_sub_images_pick_up.main_image_attachment_id where wp_orders.useremail IN($getemail) and  wp_orders.paymentstatus!='' ",ARRAY_A);
	if(!empty($getInverntoryOutput)){
		$j=0;
		foreach($getInverntoryOutput as $inventorytables){
			//echo "<pre>"; print_r($inventorytables); echo "</pre>";
			
			$productids = $inventorytables['productids'];
			
			$proqty=$inventorytables['productqty'];
			
			$proprice = ($inventorytables['productprice']/$proqty);
			
			$datetime = $inventorytables['datetime'];
			
			$datetimeurl = $inventorytables['datetime'];
			
			$expdatetime = explode(" ",$datetime);
			
			$datetime = date("d-M-y", strtotime($expdatetime[0]));
			
			$boxids = $inventorytables['boxid'];
			
			$order_id=$inventorytables['order_id'];

			$useremail = $inventorytables['useremail'];
			$useremails = get_user_by( 'email', $useremail );
			$userids = $useremails->ID;
			$order_product_id=$inventorytables['order_product_id'];
			
			$productname = $inventorytables['productname'];
			
			if($productname=='Standard Box'){$proname="AS000$productids";}
					
			if(($productname=='Large Size Items') || ($productname=='Large Items')){$proname="AL000$productids";}
			
			if($productname=='Wardrobe Box'){$proname="AW000$productids";}
			
			if($productname=='Document Box'){$proname="AD000$productids";}
			
			if(($productname=='Medium Size Items')||($productname=='Medium Items')){$proname="AM000$productids";}
			
			if(($productname=='Small Size Items')||($productname=='Small Items')){$proname="AS000$productids";}
			
			
			$addedby=$display_name;
			
			$category = get_term_by('name', 'Hong Kong Island', 'country');
			
			$productweight = get_post_meta($productids, 'ktstorage_type_max_weight', true );
			
			$productsize = get_post_meta($productids, 'storage_type_size', true );

			if ( ! empty( $productweight ) ) {
				$proweight = $productweight;
			} 
			//echo "<pre>"; print_r($inventorytables); echo "</pre>";
			
			$pick_select_date = $inventorytables['pick_select_date'];
	
			if(!empty($pick_select_date)){
				$deliverydates = $pick_select_date;
				
				$picupdate = date('d-M-y', strtotime($deliverydates));
			
			}
			
			$useremail = $inventorytables['useremail'];
			
			$getscheduleinfo = $wpdb->get_results("select * from wp_schedulereturninformation where useremail IN ($getemail) group by scheduleareturnid",ARRAY_A);
			
			if(!empty($getscheduleinfo)){
				
				$deliverydates = $getscheduleinfo[$j]['deliverydate'];
				
				$pickupdatesreschedule = $getscheduleinfo[$j]['pick_select_date'];
				
				if(!empty($pickupdatesreschedule)){
					
					$deliverydatesnextpickup = $pickupdatesreschedule;
					
					$nextpickupdate =date('d-M-y', strtotime($deliverydatesnextpickup));
				}
				else{
					$deliverydatesnextdelivery = $deliverydates;
					
					$nextpickupdate =date('d-M-y', strtotime($deliverydatesnextdelivery));
				}
				
				//echo $getscheduleinfo[$j]['pick_select_date'];
			//echo "<pre>"; print_r($getscheduleinfo); echo "</pre>";
			
			}
			$boxcategory = $inventorytables['category'];
			
			$boxdescription=$inventorytables['description'];
			
			$mduration = getMonthDurationByProductId($productids,$proprice);
			
			
			if(!empty($mduration)){
				$plans = $mduration[$j]->meta_key;
				if($plans=='store_plan'){$storeplan = "Pay as you store";}
				
				if($plans=='ktstorage_type_price'){$storeplan = "3-5 Months";}
				
				if($plans=='storage_type_price_six'){$storeplan = "6-11 Months";}
				
				if($plans=='storage_type_price_twelve'){$storeplan = "12+ Months";}
			}
			
			$attachmentids = $inventorytables['attachmentids'];
			
			$image_attributes = wp_get_attachment_image_src( $attachment_id = $attachmentids );
			
			if ( $image_attributes ) { 
				$imgsrc = '<img src="'.$image_attributes[0].'" class="img-responsive"" />';
			 } 
			 
			 $keyword =json_decode($inventorytables['keyword']);
			 
			$useremail =$inventorytables['useremail'];
			$add_warehouse =$inventorytables['add_warehouse'];
			$warehouse_sections =$inventorytables['warehouse_sections'];
			$warehouse_location =$inventorytables['warehouse_location'];
			$warehouse_item_size =$inventorytables['warehouse_item_size'];
			$warehouse_item_wieght = $inventorytables['warehouse_item_wieght'];
			$warehouse_remark = $inventorytables['warehouse_remark'];
			$customer_id = $inventorytables['customer_id'];
			
			//echo "<pre>"; print_r($inventorytables); echo "</pre>";
			
			$getuseremails = $inventorytables['useremail'];
			//echo "select * from wp_schedule_pickup where user_mail='$getuseremails' Group by user_mail"; 
			$getstoredates = $wpdb->get_results("select * from wp_schedule_pickup where user_mail='$getuseremails' Group by user_mail",ARRAY_A);
			if(!empty($getstoredates))
			{
				//echo "<pre>"; print_r($getstoredates); echo "</pre>";
				$nextdate = $getstoredates[$j]['schedule_pickup_date'];
				
				$user_mail_extra = $getstoredates[$j]['user_mail'];
				
				$date1 = date_create(date("Y/m/d"));

				$date2 = date_create($nextdate);

				$diff = date_diff($date1,$date2);
				
				
			$getstoredatescustomer = $wpdb->get_results("SELECT * FROM `wp_schedule_return_history` where useremail='$user_mail_extra' group by useremail",ARRAY_A);
			
			if(!empty($getstoredatescustomer))
			{
				//print_r($getstoredatescustomer);
				$deliverynewdates = $getstoredatescustomer[$j]['deliverydate'];
				
				$delivery_date1 = date_create($nextdate);

				$delivery_date2 = date_create($deliverynewdates);

				$customer_diff = date_diff($delivery_date1,$delivery_date2);
			}
			
			}
			
			$newhtml.='
					<tr>
					
					<td><a href="'.get_the_permalink().'?type=editboxid&orderid='.$order_id.'&productid='.$productids.'&order_product_id='.$order_product_id.'&emailid='.$useremail.'" class="tbl_order_nom">'.$boxids.'</a></td>
					<td>'.$picupdate.'</td>
					<td>';
					if(!empty($diff)){
						$newhtml.=$diff->format("%a");
					}
					else{$newhtml.='';}
					$newhtml.='
					</td>
					<td>'.$storeplan.'</td>
					<td>'.$add_warehouse.'</td>
					<td>'.$warehouse_sections.'</td>
					<td>'.$warehouse_location.'</td>
					<td>'.$boxcategory.'</td>
					<td>';
					if(!empty($keyword)){
					foreach($keyword as $newkeywords){$newhtml.=$newkeywords;}}
					$newhtml.='
					</td>
					<td>'.$boxdescription.'</td>
					<td>'.$productname.'</td>
					<td>'.$warehouse_item_size.'</td>
					
					<td>'.$warehouse_item_wieght.'</td>';
					
			$getpickup = $wpdb->get_results("SELECT * FROM `wp_schedule_pickup` INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup.schedule_pickup_id=wp_schedule_pickup_order.schedule_a_pickup_ids where wp_schedule_pickup_order.pickup_status!=''",ARRAY_A);
			if(!empty($getpickup)){
				 $statuspickup =$getpickup[$j]['pickup_status'];
				 $schedule_pickup_date=$getpickup[$j]['schedule_pickup_date'];
				if($statuspickup=='1'){
					$statuspickups = "Warehouse";
				}
				else{
					$statuspickups = "Customer"; 
					$scheduledate = explode(" ",$schedule_pickup_date);
					$scheduledatetime = date("d-M-y", strtotime($scheduledate[0]));
				}
				
				$newhtml.='
					<td>'.$statuspickups.'</td>
					<td>';
					if(!empty($nextpickupdate)){$newhtml.=$nextpickupdate;}
					$newhtml.='</td>
					<td>
						<a href="'.get_the_permalink().'?type=editUsers&userId='.$userids.'" class="editusersbyid tbl_order_nom">'.$customer_id.'</a>
					</td>
					<td>';
					if(!empty($customer_diff))
					{
						$newhtml.=$customer_diff->format("%a")."days"; 
					}
					$newhtml.='
					</td>
					<td class="action"><a href="'.get_the_permalink().'?type=transaction_history&date='.$datetimeurl.'&orderid='.$order_id.'&useremail='.$useremail.'" class="edit_btn"><i class="fa fa-eye" aria-hidden="true"></i></a></td>';
					if(!empty($imgsrc)){
						$newhtml.='<td>'.$imgsrc .'</td>';
					}
					
					$newhtml.='<td>'.$warehouse_remark.'</td>';
					
			}
			$newhtml.='</tr>
					';
			
			
	$j++;		
	}
	}


					$newhtml.='	
					</tbody>
				</table>';
	
				echo $newhtml;
				?>
				
		
		</div>

</div>	
<?php } ?>
<script type="text/javascript">
jQuery(document).ready(function() {
var table = jQuery('#example').DataTable();

// Event listener to the two range filtering inputs to redraw on input
jQuery('#min, #max').keyup( function() {
table.draw();
} );
var rowCount = jQuery('#example tr').length;


	if(rowCount>=11){
		jQuery('div#example_length').css('display','block');
		jQuery('div#example_paginate').css('display','block');
	}
	else{
		jQuery('div#example_length').css('display','none');
		jQuery('div#example_paginate').css('display','none');
		
	}
  jQuery('#example_filter label input').attr('placeholder','search');
} );
</script>
