<?php 
if($type=='editadditionalfee'){
	global $wpdb;
	//print_r($_POST);
	if(isset($_POST['late_cancellation'])){
		$handlingfeeid = trim($_POST['handlingfeeid']);
		$late_cancellation = trim($_POST['late_cancellation']);
		$no_show = trim($_POST['late_cancellation']);
		$outside_service_area_delivery = trim($_POST['outside_service_area_delivery']);
		$late_payment = trim($_POST['late_payment']);
		$stairs = trim($_POST['stairs']);
		$empty_box_pick_up_non_storage = trim($_POST['empty_box_pick_up_non_storage']);
		$remote_location_delivery = trim($_POST['remote_location_delivery']);
		$packing_fee = trim($_POST['packing_fee']);
		$parking = trim($_POST['parking']);
		$moving_penalty = trim($_POST['moving_penalty']);
		$over_weight_limit = trim($_POST['over_weight_limit']);
		$box_damage_fee = trim($_POST['box_damage_fee']);
		
		$updates = $wpdb->update('wp_additional_fee',array(
			'late_cancellation' =>$late_cancellation,
			'no_show' =>$no_show,
			'outside_service_area_delivery' =>$outside_service_area_delivery,
			'late_payment' =>$late_payment,
			'stairs' =>$stairs,
			'empty_box_pick_up_non_storage' =>$empty_box_pick_up_non_storage,
			'remote_location_delivery' =>$remote_location_delivery,
			'packing_fee' =>$packing_fee,
			'parking' =>$parking,
			'moving_penalty' =>$moving_penalty,
			'over_weight_limit' =>$over_weight_limit,
			'box_damage_fee' =>$box_damage_fee,
		), array('additional_fee_id'=>$handlingfeeid));
		if($updates==1){
			$redirects = get_the_permalink()."?type=feetypes";
			wp_redirect($redirects);
			exit();
		};
	}
	else{
	$feeid = trim($_GET['feeid']);
	$additional_fee_info = $wpdb->get_results("select * from wp_additional_fee where additional_fee_id=$feeid",ARRAY_A);
	//print_r($additional_fee_info);
	$additional_fee_id = $additional_fee_info[0]['additional_fee_id'];
	$late_cancellation = $additional_fee_info[0]['late_cancellation'];
	$no_show = $additional_fee_info[0]['no_show'];
	$outside_service_area_delivery = $additional_fee_info[0]['outside_service_area_delivery'];
	$late_payment = $additional_fee_info[0]['late_payment'];
	$stairs = $additional_fee_info[0]['stairs'];
	$empty_box_pick_up_non_storage = $additional_fee_info[0]['empty_box_pick_up_non_storage'];
	$remote_location_delivery = $additional_fee_info[0]['remote_location_delivery'];
	$packing_fee = $additional_fee_info[0]['packing_fee'];
	$parking = $additional_fee_info[0]['parking'];
	$moving_penalty = $additional_fee_info[0]['moving_penalty'];
	$over_weight_limit = $additional_fee_info[0]['over_weight_limit'];
	$box_damage_fee = $additional_fee_info[0]['box_damage_fee'];
	
	$html.='
<div class="col-md-12">
	<h2>Edit Additional Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
				<div class="col-md-3 handlingfees"><label for="titles">Late Cancellation (Less Than 24 hrs Notice) :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding">
						<input type="number" class="payasyourstore" name="late_cancellation" id="addstoragenamepost" value="'.$late_cancellation.'" onKeyPress="if(this.value.length==3) return false;" required >
					</div>
					<div class="col-md-3 titles">Flat Fee</div>
					<div class="clearer"></div>
					
					<div class="col-md-3 handlingfees">
						<label for="titles">No Show :<span class="requiredpart">*</span> </label>
					</div>
					<div class="col-md-6 no-padding">
						<input type="number" class="threefivemonths" name="no_show" id="addstoragenamepost" value="'.$no_show.'" onKeyPress="if(this.value.length==3) return false;" required="">
					</div>
					<div class="col-md-3 titles">Flat Fee</div>
					<div class="clearer"></div>
					
				<div class="col-md-3 handlingfees"><label for="titles">Outside Service Area Delivery :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="outside_service_area_delivery" id="addstoragenamepost" value="'.$outside_service_area_delivery.'" required="">
					</div>
					<div class="col-md-3 titles"></div>
					<div class="clearer"></div>
					
				<div class="col-md-3 handlingfees"><label for="titles">Late Payment :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="number" class="threefivemonths" name="late_payment" id="addstoragenamepost" value="'.$late_payment.'" onKeyPress="if(this.value.length==3) return false;" required>
					</div>
					<div class="col-md-3 titles">Flat Fee</div>
					<div class="clearer"></div>
				</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Stairs :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="number" class="payasyourstore" name="stairs" id="addstoragenamepost" value="'.$stairs.'" onKeyPress="if(this.value.length==2) return false;" required>
				</div>
				<div class="col-md-3 titles">Box Or Item/Level</div>
				
				<div class="clearer"></div>
				
				
		</div>
		
		
		<div class="form-group">
			
				<div class="col-md-3 handlingfees">
					<label for="titles">Empty Box Pick-Up Non Storage : </label>
				</div>
				<div class="col-md-6 no-padding">
				<textarea rows="5" cols="5" class="payasyourstore" name="empty_box_pick_up_non_storage" id="addstoragenamepost" >'.$empty_box_pick_up_non_storage.'</textarea>
				</div><div class="col-md-3 titles">Monthly Invoice</div>
				
				<div class="clearer"></div>
				
				
		</div>
		
		<div class="form-group">
			
				<div class="col-md-3 handlingfees">
					<label for="titles">Remote Location Delivery Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
				<input type="number" class="payasyourstore" name="remote_location_delivery" id="addstoragenamepost" value="'.$remote_location_delivery.'" onKeyPress="if(this.value.length==3) return false;">
				</div><div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Packing Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="number" class="payasyourstore" name="packing_fee" id="addstoragenamepost" value="'.$packing_fee.'" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">20 Mins/Box</div>
				<div class="clearer"></div>
		</div>
		<div class="form-group">
				<div class="col-md-3 handlingfees">
					<label for="titles">Parking  :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="text" class="payasyourstore" name="parking" id="addstoragenamepost" value="'.$parking.'" required="">
				</div>
				<div class="col-md-3 titles">20 Mins/Box</div>
				
				<div class="clearer"></div>
				
				
		</div>
		
		<div class="form-group">
			
				<div class="col-md-3 handlingfees">
					<label for="titles">Moving Penalty  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="number" class="payasyourstore" name="moving_penalty" id="addstoragenamepost" value="'.$moving_penalty.'" onKeyPress="if(this.value.length==4) return false;">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				<div class="clearer"></div>
				
				
		</div>
		
		<div class="form-group">
			
				<div class="col-md-3 handlingfees">
					<label for="titles">Over Weight Limit  : </label>
				</div>
				<div class="col-md-6 no-padding"><input type="number" class="payasyourstore" name="over_weight_limit" id="addstoragenamepost" value="'.$over_weight_limit.'" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">Flat Fee</div>
				
				<div class="clearer"></div>
				
				
		</div>
		
		
		<div class="form-group">
			
				<div class="col-md-3 handlingfees">
					<label for="titles">Box Damage Fee  : </label>
				</div>
				<div class="col-md-6 no-padding">
					<input type="number" class="payasyourstore" name="box_damage_fee" id="addstoragenamepost" value="'.$box_damage_fee.'" onKeyPress="if(this.value.length==3) return false;">
				</div>
				<div class="col-md-3 titles">Per Box</div>
				<div class="clearer"></div>
				
				
		</div>
			<input type="hidden" name="handlingfeeid" value="'.$additional_fee_id.'"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Edit Additional Fee">
	</form>
</div>
';
}
echo $html;
}