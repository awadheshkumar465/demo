<?php 
if($type=='scheduleareturninfo')
{ ?>
<link rel="alternate" type="" title="" href="<?php echo get_stylesheet_directory_uri().'/css/jquery.dataTables.min.css'; ?>" />
<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/datatable.js'; ?>'></script>

<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri().'/js/jquery.dataTables.min.js'; ?>'></script>
<?php
global $wpdb;
echo '<h2> Schedule A Return Information</h2>';
//$selects = getScheduleAReturnInformation();		
?>
<!--Showing all Schedule a return Information lists -->
<div class="row admin_schedule_return_status">
<?php $ajaxurl = admin_url("admin-ajax.php"); ?>
<input type="hidden" value="<?php $ajaxurl; ?>" name="adminurls" class="adminurls">
	<div class="table-responsive">
	
	<?php
				
				$newhtml='';
				$newhtml.='
				<table id="example" class="table table-striped table-bordered display" cellspacing="0">
					<thead>
						<tr>
							<th>Delivery date</th>
							<th>Delivery Service</th>
							<th>Order Number</th>
							<th>Company Name</th>
							<th>Company number</th>
							<th>Customer Name</th>
							<th>Full Address</th>
							<th>Region</th>
							<th>Phone</th>
							<th>Instruction</th>
							<th>Status</th>
							<th>Product Name</th>
							<th>Product Qty</th>
							<th>Order Type</th>
							<th>Stairs (Floors)</th>
							<th>Payment</th>
							<th class="action">Action</th>
							
						</tr>
					</thead>
					
					<tbody>';
				$get_pickupstatus = $wpdb->get_results("select * from wp_schedulereturninformation INNER JOIN wp_product_return_lists ON wp_schedulereturninformation.scheduleareturnid = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_schedulereturninformation.scheduleareturnid = wp_schedule_return_history.schedulereturnid INNER JOIN wp_schedule_return_history_order ON wp_schedule_return_history.useremail = wp_schedule_return_history_order.useremail where wp_schedule_return_history.delivery_status IN ('0','1') group by wp_schedulereturninformation.scheduleareturnid",ARRAY_A);
				$j=0;
				$sumtotal=0;
				$finalsum = 0;
				$smallsum=0;
				$mediumsum=0;
				$largesum=0;
				$wardrobesum=0;
				$standardsum=0;
				$documentsum=0;
				
				
				foreach($get_pickupstatus as $statusval)
				{
					/*echo '<pre>';
					print_r($statusval);
					echo '</pre>';*/
					
					$useremail = $statusval['useremail']; 
					
					$user = get_user_by( 'email', $useremail );
					
					$deliverydate = $statusval['deliverydate'];
					
					$businessday = $statusval['businessday'];
					
					$order_id = $statusval['order_id'];
					
					$deliveryorderid = "D".date("y")."000".$order_id;
					
					$userid = $user->data->ID;
					
					$company_name = get_user_meta($userid,'company_name',true );
					
					$office_number = get_user_meta($userid,'office_number',true );
					
					$user_phone =  get_user_meta($userid,'user_phone',true );
					
					$user_name = $user->first_name . ' ' . $user->last_name;
					
					$fulladdress = $statusval['fulladdress'];
					
					
					$product_id = $statusval['product_id'];
					
					$term_list = wp_get_post_terms($product_id, 'country', array("fields" => "all"));
					
					$post_term_id = $term_list[0]->term_id;
					
					$special_instructions = $statusval['special_instructions'];
					
					if($special_instructions==''){$special_instructions="NA";}
					
					$pickup_status = $statusval['pickup_status'];
					
					$status = $statusval['status'];
					if(($status=='completed')|| ($status=='paid')){$status="Paid";}
					
					$pick_select_date = $statusval['pick_select_date'];
					
					if($pick_select_date==''){$neworder = "New order pickup";}
					
					$schedulereturnid = $statusval['schedulereturnid'];
					
					$delivery_status = $statusval['delivery_status'];
					
					$linkdeliverystatus = $statusval['delivery_status'];
					
					if($delivery_status=='1'){$delivery_status="Complete";}
					
					$no_of_floors = $statusval['no_of_floors'];
					
					$getinfoorder = $wpdb->get_results("select productname,productqty from wp_order_products where order_id =$order_id",ARRAY_A);
					
					$edit = '<a href="'.get_the_permalink().'?type=editstatusreturnschedule&orderstatusid='.$linkdeliverystatus.'&emailid='.$useremail.'" class="edit_btn"><i class="fa fa-pencil" ></i></a>';
					
					//$terms = wp_get_post_terms(13, $taxonomy, $args );
					$countrylists = $statusval['countrylists'];
					if(!empty($getinfoorder)){
						
						$pronames = $getinfoorder[$j]['productname'];
						
						if(($pronames=='Medium Size Items') || ($pronames=='Medium Items'))
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							
							$mediumsum =$mediumsum + $proqty;
				
						}
						
						
						if(($pronames=='Large Size Items') || ($pronames=='Large Items'))
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							$largesum =$largesum + $proqty;
				
						}
						
						if($pronames=='Wardrobe Box')
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							
							$wardrobesum =$wardrobesum + $proqty;
				
						}
						
						if($pronames=='Standard Box')
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							
							$standardsum =$standardsum + $proqty;
				
						}
						
						if(($pronames=='Small Size  Items') || ($pronames=='Small Items'))
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							
							$smallsum =$smallsum + $proqty;
							
				
						}
						
						if($pronames=='Document Box')
						{
							
							$proname = $getinfoorder[$j]['productname'];
						
							$proqty = $getinfoorder[$j]['productqty'];
							
							$documentsum =$documentsum + $proqty;
							
						}
						
						
						$finalsum = $documentsum + $smallsum +$standardsum +$wardrobesum +$largesum +$mediumsum;
						
					$return_product_id = $statusval['return_product_id'];
					
					$order_product_id = $statusval['order_product_id'];
					
						
					}
					
					$newhtml.='
					<tr>
					<td>'.$deliverydate.'</td>
					<td>'.$businessday.'</td>
					<td><a href="'.get_the_permalink().'?type=showallprolists&return_product_id='.$return_product_id.'&order_product_id='.$order_product_id.'&tablename=wp_product_return_lists" >'.$deliveryorderid.'</a></td>
					<td>'.$company_name.'</td>
					<td>'.$office_number.'</td>
					<td>'.$user_name.'</td>
					<td>'.$fulladdress.'</td>
					<td>'.$countrylists.'</td>
					<td>'.$user_phone.'</td>
					<td>'.$special_instructions.'</td>
					<td>'.$delivery_status.'</td>
					<td>'.$proname.'</td>
					
					<td>'.$proqty.'</td>
					<td>Schedule A Return</td>
					<td>'.$no_of_floors.'</td>
					<td>'.$status.'</td>
					<td class="action">'.$edit.'</td>
					
					</tr>
					
					';
				$j++;	
				}

$pickupschedulestatus = $wpdb->get_results("SELECT * FROM `wp_schedule_pickup` INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id = wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_pickup_product_id= wp_schedule_pickup_order.schedule_a_pickup_product_id Where wp_schedule_pickup_order.pickup_status IN ('0','1') AND wp_schedule_pickup_order.payment_status!=''",ARRAY_A);				
$k=0;

$sumtotal=0;
$finalsum = 0;
$smallsum=0;
$mediumsum=0;
$largesum=0;
$wardrobesum=0;
$standardsum=0;
$documentsum=0;
foreach($pickupschedulestatus as $keyvalurs)
{
	//echo "<pre>"; print_r($keyvalurs); echo "</pre>";
	$useremail = $statusval['useremail']; echo "<br>";
	$user = get_user_by( 'email', $useremail );
	
	$full_address = $keyvalurs['full_address'];
	
	$region_id = (int)$keyvalurs['region_id'];
	
	$category = get_term_by('term_id',$region_id, 'country');
	
	$regions = ucfirst($category->name);
	
	$schedule_pickup_date = $keyvalurs['schedule_pickup_date'];
	
	$order_id = $keyvalurs['order_id'];
	
	$scheduleordernumber = "P".date("y")."000".$order_id;
	
	$userid = $user->data->ID;
	
	$company_names = get_user_meta($userid,'company_name',true );
					
	$office_numbers = get_user_meta($userid,'office_number',true );
	
	$user_names = $user->first_name . ' ' . $user->last_name;
	
	$special_instructions = $keyvalurs['special_instructions'];
	
	if($special_instructions==''){$special_instructions="NA";}
	
	$getinfoorder = $wpdb->get_results("select productname,productqty from wp_order_products where order_id =$order_id",ARRAY_A);
					
if(!empty($getinfoorder)){
	
	$pronames = $getinfoorder[$j]['productname'];
						
	if(($pronames=='Medium Size Items') || ($pronames=='Medium Items'))
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		
		$mediumsum =$mediumsum + $proqty;

	}
	
	
	if(($pronames=='Large Size Items') || ($pronames=='Large Items'))
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		$largesum =$largesum + $proqty;

	}
	
	if($pronames=='Wardrobe Box')
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		
		$wardrobesum =$wardrobesum + $proqty;

	}
	
	if($pronames=='Standard Box')
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		
		$standardsum =$standardsum + $proqty;

	}
	
	if(($pronames=='Small Size  Items') || ($pronames=='Small Items'))
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		
		$smallsum =$smallsum + $proqty;
		

	}
	
	if($pronames=='Document Box')
	{
		
		$proname = $getinfoorder[$j]['productname'];
	
		$proqty = $getinfoorder[$j]['productqty'];
		
		$documentsum =$documentsum + $proqty;
		
	}
	
	
	$finalsum = $documentsum + $smallsum +$standardsum +$wardrobesum +$largesum +$mediumsum;
}

$pickup_status = $keyvalurs['pickup_status'];

$no_of_floors = $keyvalurs['no_of_floors'];	
				
$payment_status = $keyvalurs['payment_status'];

$pickup_status = $keyvalurs['pickup_status'];

$schedule_pickup_product_id = $keyvalurs['schedule_pickup_product_id'];

$pickuporderproid = $keyvalurs['order_product_id'];

$tablename ="wp_schedule_pickup_products";

$edit = '<a href="'.get_the_permalink().'?type=editstatus&orderstatusid='.$pickup_status.'&emailid='.$useremail.'" class="edit_btn"><i class="fa fa-pencil" ></i></a>';

$user_phone =  get_user_meta($userid,'user_phone',true );

if($pickup_status =='1'){$pickup_status = "Complete";} else{$pickup_status = "Pending";}
	$newhtml.='
	<tr>
	<td>'.$schedule_pickup_date.'</td>
	<td>NA</td>
	<td><a href="'.get_the_permalink().'?type=showallprolists&return_product_id='.$schedule_pickup_product_id.'&order_product_id='.$pickuporderproid.'&tablename='.$tablename.'">'.$scheduleordernumber.'</td>
	<td>'.$company_names.'</td>
	<td>'.$office_numbers.'</td>
	<td>'.$user_names.'</td>
	<td>'.$full_address.'</td>
	<td>'.$regions.'</td>
	<td>'.$user_phone.'</td>
	<td>'.$special_instructions.'</td>
	<td>'.$pickup_status.'</td>
	<td>'.$proname.'</td>
	<td>'.$proqty.'</td>
	<td>Schedule A Pick Up</td>
	<td>'.$no_of_floors.'</td>
	<td>'.$payment_status.'</td>
	<td class="action">'.$edit.'</td>
	</tr>';
$k++;
	}

					echo $newhtml;
					$newhtml.='	
					</tbody>
				</table>';?>
				
		
		</div>
		
<?php } ?>
<script type="text/javascript">
jQuery(document).ready(function() {
var table = jQuery('#example').DataTable();

// Event listener to the two range filtering inputs to redraw on input
jQuery('#min, #max').keyup( function() {
table.draw();
} );
var rowCount = jQuery('#example tr').length;


	if(rowCount>=11){
		jQuery('div#example_length').css('display','block');
		jQuery('div#example_paginate').css('display','block');
	}
	else{
		jQuery('div#example_length').css('display','none');
		jQuery('div#example_paginate').css('display','none');
		
	}
  jQuery('#example_filter label input').attr('placeholder','search');
} );
</script>