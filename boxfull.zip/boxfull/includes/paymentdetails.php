<?php if($type=='paymentdetails')
{
	global $wpdb;
	echo '<h2>Show All Payment Lists</h2>';
	$payment_order_details = $wpdb->get_results("select * from wp_orders where paymentstatus!='' and paymentmode!='paypal'");

	$schedule_return_history_orders = $wpdb->get_results("select * from wp_schedule_return_history_order where status!='' and payment_method!='paypal' and payment_method!=''");

	$schedule_pickup_orders = $wpdb->get_results("select * from wp_schedule_pickup_order where payment_status!='' and payment_method!='paypal' and payment_method!=''");
	
	$adminurl= admin_url('admin-ajax.php');
	?>
	<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>Customer Name</th>
					<th>Company Name</th>
					<th>Order Email</th>
					<th>Region</th>
					<th>Address</th>
					<th>Payment Mode</th>
					<th>Payment Status</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php
					foreach ($payment_order_details as $payment_order_detail) { 
						$order_id = $payment_order_detail->order_id;
						$useremail = $payment_order_detail->useremail;
						$user = get_user_by( 'email', $useremail );
						$user_id = $user->ID;
						$company_name = get_user_meta($user_id,'company_name',true);?>
						<td>
							<?php echo ucfirst($payment_order_detail->fullname); ?>
						</td>
						<td><?php echo ucfirst($company_name); ?></td>
						<td><?php echo $useremail; ?></td>
						<td><?php echo ucfirst($payment_order_detail->region); ?></td>
						<td>
							<?php echo ucfirst($payment_order_detail->fulladdress); ?>
						</td>
						<td>
							<?php echo ucfirst($payment_order_detail->paymentmode); ?>
						</td>
						<td>
							
							<a class="changepaymentstaus" href="javascript:void(0);" data-orderid="<?php echo $order_id; ?>" data-tablenames="<?php echo "wp_orders"; ?>" data-tablecolumns="order_id"  data-tablecolstatus = "paymentstatus" data-adminurl="<?php echo $adminurl;?>"><?php echo ucfirst($payment_order_detail->paymentstatus); ?></a>
						</td>
				</tr>
					<?php } ?>
				<tr>
					<?php
					foreach ($schedule_return_history_orders as $history_order) { 
						$order_id=$history_order->wp_schedule_return_history_order_id;
						$useremail = $history_order->useremail;
						$user = get_user_by( 'email', $useremail );
						$user_id = $user->ID;
						$user_name = get_user_meta($user_id,'first_name',true);
						$company_name = get_user_meta($user_id,'company_name',true);?>
						<td><?php echo ucfirst($user_name); ?></td>
						<td><?php echo ucfirst($company_name); ?></td>
						<td><?php echo $useremail; ?></td>
						<td></td>
						<td></td>
						<td><?php echo ucfirst($history_order->payment_method); ?></td>
						<td>
							<a class="changepaymentstaus" href="javascript:void(0);" data-orderid="<?php echo $order_id; ?>" data-tablenames="<?php echo "wp_schedule_return_history_order"; ?>" data-tablecolumns="wp_schedule_return_history_order_id"  data-tablecolstatus = "status" data-adminurl="<?php echo $adminurl;?>"><?php echo ucfirst($history_order->status); ?></a>
						</td>
				</tr>
				<?php } ?>
				<tr>
					<?php
					foreach ($schedule_pickup_orders as $schedule_pickup_order) { 
						$order_id = $schedule_pickup_order->schedule_pickup_orderid;
						$useremail = $schedule_pickup_order->user_email_pickup;
						$user = get_user_by( 'email', $useremail );
						$user_id = $user->ID;
						$user_name = get_user_meta($user_id,'first_name',true);
						$company_name = get_user_meta($user_id,'company_name',true);?>
						<td><?php echo ucfirst($user_name); ?></td>
						<td><?php echo ucfirst($company_name); ?></td>
						<td><?php echo $useremail; ?></td>
						<td></td>
						<td></td>
						<td><?php echo $schedule_pickup_order->payment_method; ?></td>
						<td>
							<a class="changepaymentstaus" href="javascript:void(0);" data-orderid="<?php echo $order_id; ?>" data-tablenames="<?php echo "wp_schedule_pickup_order"; ?>" data-tablecolumns="schedule_pickup_orderid"  data-tablecolstatus = "payment_status" data-adminurl="<?php echo $adminurl;?>"><?php echo ucfirst($schedule_pickup_order->payment_status); ?></a>
						</td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
<?php	
} ?>