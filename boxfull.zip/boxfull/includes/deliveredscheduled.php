<?php
if($type=='deliveredscheduled'){
	global $wpdb;
	echo '<h2>All Delivered Scheduled</h2>';
	$allorders = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id where wp_orders.schedule_drop_off_date!=''",ARRAY_A);
	
	$allorders_empty_dropoff = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id where wp_orders.select_drop_off_date!=''",ARRAY_A);
	
	$empty_drop_boxes = $wpdb->get_results("SELECT * FROM `wp_schedulereturninformation` inner join wp_product_return_lists on wp_schedulereturninformation.`scheduleareturnid` = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_product_return_lists.schedule_return_id=wp_schedule_return_history.schedulereturnid where wp_schedule_return_history.delivery_status IN('0','1') GROUP BY wp_schedule_return_history.schedulereturnid", ARRAY_A); ?>
	<div class="delivered">
		<div class="table-responsive"> 
			<table class="table table-bordered">
				<tbody>
					<h3>New Order Pick-Up</h3>
					<tr>
						<th>Product Image</th>
						<th>Product Name</th>
						<th>Region / District</th>
						<th>Schedule PickUp Date</th>
						<th>Schedule PickUp Time</th>
						<th>Payment Status</th>
						<th>Payment Method</th>
					</tr>
					<?php
					foreach ( $allorders as $allorder ) {
					$productids = $allorder['productids'];
					$product_image = get_field('ktstorage_type_image', $productids);
					$productname = $allorder['productname'];
					$region = $allorder['region'];
					$district = $allorder['district'];
					
					$schedule_drop_off_date = $allorder['schedule_drop_off_date'];
					$schedule_drop_off_time = $allorder['schedule_drop_off_time'];
					$paymentstatus = $allorder['paymentstatus'];
					$paymentmode = $allorder['paymentmode'];
					
					?>
					<tr>
						<td><img src="<?php echo $product_image; ?>"></td>
						<td><?php echo $productname; ?></td>
						<td><?php echo $region;?> /<br><?php echo $district; ?></td>
						<td><?php echo $schedule_drop_off_date; ?></td>
						<td><?php echo $schedule_drop_off_time; ?></td>
						<td><?php echo ucfirst($paymentstatus); ?></td>
						<td><?php echo ucfirst($paymentmode); ?></td>
					</tr>
					<?php 
				} ?>
				</tbody>
			</table>

			<!-- Start Empty Box Drop off -->
			<h3>Empty Box Drop Off</h3>
			<table class="table table-bordered">
				<tbody>
					<tr>
						<th>Product Image</th>
						<th>Product Name</th>
						<th>Region / District</th>
						<th>Drop Off Date</th>
						<th>Drop Off Time</th>
						<th>Payment Status</th>
						<th>Payment Method</th>
					</tr>
					<?php
					foreach ( $allorders_empty_dropoff as $allorder ) {
					$productids = $allorder['productids'];
					$product_image = get_field('ktstorage_type_image', $productids);
					$productname = $allorder['productname'];
					$region = $allorder['region'];
					$district = $allorder['district'];
					$select_drop_off_date = $allorder['select_drop_off_date'];
					
					$dropoff_select_time = $allorder['dropoff_select_time'];
					$paymentstatus = $allorder['paymentstatus'];
					$paymentmode = $allorder['paymentmode'];
					
					?>
					<tr>
						<td><img src="<?php echo $product_image; ?>"></td>
						<td><?php echo $productname; ?></td>
						<td>
							<?php echo $region;?> /<br><?php echo $district; ?>
						</td>
						<td><?php echo $select_drop_off_date; ?></td>
						<td><?php echo $dropoff_select_time; ?></td>
						<td><?php echo ucfirst($paymentstatus); ?></td>
						<td><?php echo ucfirst($paymentmode); ?></td>
					</tr>
					<?php 
				} ?>
				</tbody>
			</table>
			<!-- End Empty Box Drop off -->

			<!-- Start Schedule a Return -->
			<h3>Schedule a Return Information</h3>
			<table class="table table-bordered">
				<tbody>
					<tr>
						<th>Product Image</th>
						<th>Product Name</th>
						<th>Delivery Date</th>
						<th>Delivery Time</th>
						<th>Special Instructions</th>
						<th>Payment Method</th>
						<th>Payment Status</th>
						
					</tr>
					<?php
					foreach ( $empty_drop_boxes as $empty_drop_boxe ) {
					$productids = $empty_drop_boxe['product_id'];
					$product_image = get_field('ktstorage_type_image', $productids);
					$useremail = $empty_drop_boxe['useremail'];
					$order_id = $empty_drop_boxe['order_id'];
					$productname = $empty_drop_boxe['product_name'];
					$region = $empty_drop_boxe['region'];
					$district = $empty_drop_boxe['district'];
					$deliverydate = $empty_drop_boxe['deliverydate'];
					$deliverytime = $empty_drop_boxe['deliverytime'];
					$delivery_status = $empty_drop_boxe['delivery_status'];
					$special_instructions = $empty_drop_boxe['special_instructions'];
					$getPayment = $wpdb->get_results("select * from wp_schedule_return_history_order where order_id = $order_id and useremail='$useremail' and status='completed' group by order_id ");
					foreach($getPayment as $payment)
					{
						 $status = $payment->status;
						 $payment_method = $payment->payment_method;
					} ?>
					<tr>
						<td><img src="<?php echo $product_image; ?>"></td>
						<td><?php echo $productname; ?></td>
						<td><?php echo $deliverydate; ?></td>
						<td><?php echo $deliverytime; ?></td>
						<td><?php echo ucfirst($special_instructions); ?></td>
						<td><?php echo ucfirst($payment_method); ?></td>
						<td>
							<?php 
							if($delivery_status == 1){
								echo "Delivered";
							}
							else{
								echo "Pending";
							}
							 ?>
						</td>
					</tr>
					<?php 
				} ?>
				</tbody>
			</table>
			<!-- Start Schedule a Pick-Up Information -->
			<h3>Schedule a Pick-Up Information</h3>
			<?php
			$get_pickupstatus=$wpdb->get_results("select pickup_status from wp_schedule_pickup_order where pickup_status IN ('0','1')",ARRAY_A);
			foreach($get_pickupstatus as $statusval){
				$pickup_status = $statusval['pickup_status'];
			}
			$getpickupinfo = $wpdb->get_results("select * from wp_schedule_pickup INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id = wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_pickup_product_id = wp_schedule_pickup_order.schedule_a_pickup_product_id where wp_schedule_pickup_order.pickup_status='$pickup_status' AND wp_schedule_pickup_order.payment_status='paid'",ARRAY_A);
			?>
			<table class="table table-bordered">
				<tbody>
					<tr>
						<th>User Name</th>
						<th>Email Id</th>
						<th>Product Id</th>
						<th>Payment Method</th>
						<th>Payment Status</th>
						<th>Pickup Status</th>
						<th>View Details</th>
					</tr>
					<?php
					foreach($getpickupinfo as $pickupval)
					{
					$productname = $pickupval['product_name_pickup'];
					$pick_up_product_id = $pickupval['pick_up_product_id'];
					$user_email_pickup = $pickupval['user_email_pickup'];
					$payment_status = $pickupval['payment_status'];
					$payment_method = $pickupval['payment_method'];
					if($pickup_status==1)
					{
						$pickstatus = 'Delivered';
					}
					else
					{
						$pickstatus = 'Pending';
					}
					$useremail = get_user_by( 'email', $user_email_pickup );
					$name = $useremail->display_name;
					?>
					<tr>
						<td><?php echo ucfirst($name); ?></td>
						<td style="word-wrap: break-word;">
							<?php echo $user_email_pickup; ?>
						</td>
						<td><?php echo $productname; ?></td>
						<td><?php echo $payment_method; ?></td>
						<td><?php echo $status; ?></td>
						<td><?php echo $pickstatus; ?></td>
						<td class="action"></td>
					</tr>
					<?php 
					} ?>
				</tbody>
			</table>
		</div>
	</div>
<?php

}
?>
