<?php
if($type=='addbyboxhandlingfee'){
global $wpdb;
$html='';
$html.='
<div class="col-md-12">
	<h2>By Box Handling Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			<label class="maintitles titles">Check Out & Re-Check-In (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees"><label for="titles">Pay as you store :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="payasyourstore" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Box (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">3-5 Months :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="threefivemonths" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Mox (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">6-11 Months :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="sixelevenmonths" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">1 Free (Min $100)</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">12 Months :<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="twelvemonthsplus" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">2 Free (Min $100 )</div>
					<div class="clearer"></div>
					<input type="hidden" name="checkoutandrecheckinbybox" value="checkoutandrecheckinhandlingfeebybox" />
		</div>
		<div class="form-group">
			<label class="maintitles titles">Final Check Out (Handling Fee) : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">Final Check Out Handling Fee :<span class="requiredpart">*</span> </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="finalcheckouthandlingfee" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Box (Min $100)</div>
				<div class="clearer"></div>
				<input type="hidden" name="finalcheckoutbybox" value="finalcheckouthandlingfeebybox" />
				
		</div>
		
		<div class="form-group">
			<label class="maintitles titles">Empty Box Collect - Final Check Out : </label><br/>
				<div class="col-md-3 handlingfees">
					<label for="titles">20 Mins : </label>
				</div>
				<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="twentyminutes" id="addstoragenamepost" value="" ></div><div class="col-md-3 titles"></div>
				<div class="clearer"></div>
				<input type="hidden" name="emptyboxcollectfinalcheckoutbybox" value="emptyboxcollectfinalcheckouthandlingfeebybox" />
				
		</div>
			<input type="hidden" name="boxcatid" value="2" />
			<input type="hidden" name="handlingfeebybox" value="handlingfeebybox"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Submit">
	</form>
</div>
';
echo $html;
if(isset($_POST['payasyourstore'])){

$payasyourstore = trim($_POST['payasyourstore']);

$threefivemonths = trim($_POST['threefivemonths']);

$sixelevenmonths = trim($_POST['sixelevenmonths']);

$twelvemonthsplus = trim($_POST['twelvemonthsplus']);

$checkoutandrecheckinbybox = trim($_POST['checkoutandrecheckinbybox']);

$finalcheckouthandlingfee = trim($_POST['finalcheckouthandlingfee']);

$finalcheckoutbybox = trim($_POST['finalcheckoutbybox']);

$twentyminutes = trim($_POST['twentyminutes']);

$emptyboxcollectfinalcheckoutbybox = trim($_POST['emptyboxcollectfinalcheckoutbybox']);

$boxcatid = trim($_POST['boxcatid']);

$handlingfeebybox = trim($_POST['handlingfeebybox']);

$insert = $wpdb->insert('wp_handling_fee', array(
'payasyourstore' =>$payasyourstore,
'threefivemonths' =>$threefivemonths,
'sixelevenmonths' =>$sixelevenmonths,
'twelvemonthsplus' =>$twelvemonthsplus,
'checkoutandrecheckin' =>$checkoutandrecheckinbybox,
'finalcheckouthandlingfee' =>$finalcheckouthandlingfee,
'finalcheckout' =>$finalcheckoutbybox,
'twentyminutes' =>$twentyminutes,
'emptyboxcollectfinalcheckout' => $emptyboxcollectfinalcheckoutbybox,
'boxcatid' => $boxcatid,
'handlingfeeby' => $handlingfeebybox,
'samebusinessday' =>'',
'nextbusinessday' =>'',
'inormorethantwobusinessday' =>'',
'afterhoursdelivery' =>'',
)); 
$lastid = $wpdb->insert_id; 
if($lastid>0){
	?>
	<script type="text/javascript">
	alert ("Hndling Fee By Box Added Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
}
}


}

?>