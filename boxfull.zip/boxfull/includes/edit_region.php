<?php

if($type=='editregion'){
$region_id = $_GET['region_id']; 
$terms = get_terms([
'taxonomy' => 'country',
'hide_empty' => false,
]);
$regions_lists = get_term_by( 'id', $region_id, 'country' );
//print_r($regions_lists);
$region_name = $regions_lists->name;
$region_description =$regions_lists->description;
$region_term_id = $regions_lists->term_id;
$region_taxonomy = $regions_lists->taxonomy;

?>
<!-- edit regions html starts here -->
<div class="col-md-12">
<form method="POST" action="" id="editregion" enctype="multipart/form-data">
	<div class="form-group">
	<label for="titles">Region Name:<span class="requiredpart">*</span></label>
	<input type="text" class="newdistrictpost" name="newdistrictpost" class="form-control" id="newdistrictpost" value="<?php echo ucfirst($region_name);?>" required>
	</div>
	
	<div class="form-group">
	<label for="titles">Region Discription:</label>
	<textarea name="regiondescription" rows="10" cols="20"><?php echo $region_description;?> </textarea>
	</div>
	
	
	<input type="hidden" class="hidden_editregion" name="hiddeneditregion" value="<?php echo $region_term_id;?>" />
	<input type="hidden" name="region_taxonomy" value="<?php echo $region_taxonomy; ?>" />
	<input type="hidden" name="regin_id" value=""/>
	<?php wp_nonce_field( 'post_nonce', 'post_nonce_field_editregion' ); ?>

	<input type="hidden" name="edit_region" id="edit_region" value="true" />
	<input type="submit" class="btn btn-default editistrict" value="Update">
</form>
</div>	
<!-- edit regions html ends here -->
<?php
}
/* submit edit region form starts here */
if(isset($_POST['post_nonce_field_editregion'])){
//print_r($_POST);
$region_id = $_POST['hiddeneditregion'];
$region_title = $_POST['newdistrictpost'];
$region_description = $_POST['regiondescription'];
$region_id = $_POST['hiddeneditregion'];
$region_taxonomy = $_POST['region_taxonomy'];
$args=array(
'name' => $region_title,
'description' => $region_description
);
$regionupdate=wp_update_term( $region_id, $region_taxonomy,$args);
if(regionupdate){
wp_redirect(get_the_permalink()."/?type=allregions");
exit;
}
}
/* submit edit region form starts here */
?>