<?php
if($type=='mannualbillings')
{
	global $wpdb;
//echo "manual billing";
$timeFirst  = strtotime('2018-01-18 18:20:20');
$timeSecond = strtotime('2018-01-19 18:28:20');
$differenceInSeconds = $timeSecond - $timeFirst;


if($_POST['add_munnally_fee']){
	
	$schedule_pickup_orderid = trim($_POST['schedule_pickup_orderid']);
	
	$schedule_a_pickup_product_id = trim($_POST['schedule_a_pickup_product_id']);
	
	$schedule_a_pickup_ids = trim($_POST['schedule_a_pickup_ids']);
	
	$pick_up_product_id = trim($_POST['pick_up_product_id']);
	
	$order_product_id_pickup = trim($_POST['order_product_id_pickup']);
	
	$order_id_pickup = trim($_POST['order_id_pickup']);
	
	$product_name_pickup = trim($_POST['product_name_pickup']);
	
	$product_qty_pickup = trim($_POST['product_qty_pickup']);
	
	$product_price_pickup = trim($_POST['product_price_pickup']);
	
	$user_email_pickup = trim($_POST['user_email_pickup']);
	
	$payment_method = trim($_POST['payment_method']);
	
	$noshowfee=trim($_POST['noshowfee']);
	
	$outstanding_areafee=trim($_POST['outstanding_areafee']);
	
	$packing_fee=trim($_POST['packing_fee']);
	
	$parkings=trim($_POST['parkings']);
	
	$moving_penality=trim($_POST['moving_penality']);
	
	$overweight_limit=trim($_POST['overweight_limit']);
	
	$box_damage=trim($_POST['box_damage']);
	
	$insert =$wpdb->insert('wp_billingmanagement',array(
		'schedule_pickup_orderid'=>$schedule_pickup_orderid ,
		'schedule_a_pickup_product_id'=>$schedule_a_pickup_product_id ,
		'schedule_a_pickup_ids'=>$schedule_a_pickup_ids ,
		'product_id'=>$pick_up_product_id ,
		'order_product_id'=>$order_product_id_pickup ,
		'order_id'=>$order_id_pickup ,
		'product_name'=>$product_name_pickup ,
		'product_qty'=>$product_qty_pickup ,
		'product_price'=>$product_price_pickup ,
		'user_email'=>$user_email_pickup ,
		'payment_method'=>$payment_method ,
		'noshowfee'=>$noshowfee ,
		'outstanding_areafee'=>$outstanding_areafee ,
		'packing_fee'=>$packing_fee ,
		'parkings'=>$parkings ,
		'moving_penality'=>$moving_penality ,
		'overweight_limit'=>$overweight_limit ,
		'box_damage'=>$box_damage ,
		'storage_fee'=>'',
		'handling_fee'=>'',
		'delivery_fee'=>'',
		'additional_fee'=>'',
	));
	$lastid = $wpdb->insert_id;?>
	<script type = "text/javascript" language = "javascript">
			jQuery(document).ready(function() {
			alert ("Monthly Bill Added Successfully");
			window.location = "<?php echo get_permalink();?>?type=showbillproductslists";
			});
		</script>
<?php 
}
else {
if(!empty($_GET['useremail'])){
$getemail=trim($_GET['useremail']);	
$schedule_pickup_orderid=trim($_GET['schpupoid']);	
$action = trim($_GET['action']);


//echo "select * from wp_schedule_pickup_order where pickup_status='1' AND user_email_pickup IN ($getemail) GROUP BY user_email_pickup";

$getpickupinformation = $wpdb->get_results("select * from wp_schedule_pickup_order where schedule_pickup_orderid = $schedule_pickup_orderid AND pickup_status='1' AND user_email_pickup ='$getemail'",ARRAY_A);

?>
<div class="user-table ">
		
	<div class="editboxID_number">
		<h2>Manual Billing : </h2>
		<form class="form-horizontal-manual-billing" method="POST" >
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 scanrow">
						<label>No Show Fee</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="noshowfee" value="" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 uploadimages">
						<label>Outside Service Area Delivery</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="outstanding_areafee" value="" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Packing Fee </label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="packing_fee" value="">
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Parking:</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="parkings" value="" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Moving Penalty:</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="moving_penality" value="" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Over Weight Limit :</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="overweight_limit" value="" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Box Damage :</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="box_damage" value="" >
					</div>
				</div>
			</div>	
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12 custid">
					<?php $j=0;
					foreach($getpickupinformation as $manuvals){
						//echo "<pre>"; print_r($manuvals); echo "</pre>";
						
						$schedule_pickup_orderid = $manuvals['schedule_pickup_orderid'];
						
						$schedule_a_pickup_product_id = $manuvals['schedule_a_pickup_product_id'];
						
						$schedule_a_pickup_ids = $manuvals['schedule_a_pickup_ids'];
						
						$pick_up_product_id = $manuvals['pick_up_product_id'];
						
						$order_product_id_pickup = $manuvals['order_product_id_pickup'];
						
						$order_id_pickup = $manuvals['order_id_pickup'];
						
						$product_name_pickup = $manuvals['product_name_pickup'];
						
						$product_qty_pickup = $manuvals['product_qty_pickup'];
						
						$product_price_pickup = $manuvals['product_price_pickup'];
						
						$user_email_pickup = $manuvals['user_email_pickup'];
						
						$payment_method = $manuvals['payment_method'];
						
						$product_qty = $manuvals['product_qty_pickup'];
						
					$getpickudate = $wpdb->get_results("select schedule_pickup_date from wp_schedule_pickup where schedule_pickup_id= $schedule_a_pickup_ids",ARRAY_A);
					$schedule_pickup_date=$getpickudate[$j]['schedule_pickup_date'];
					$j++;?>
					
					<input type="hidden" name="schedule_pickup_orderid" value="<?php echo $schedule_pickup_orderid;?>">
					
					<input type="hidden" name="schedule_a_pickup_product_id" value="<?php echo $schedule_a_pickup_product_id;?>">
					
					<input type="hidden" name="schedule_a_pickup_ids" value="<?php echo $schedule_a_pickup_ids;?>">
					
					<input type="hidden" name="pick_up_product_id" value="<?php echo $pick_up_product_id;?>">
					
					<input type="hidden" name="order_product_id_pickup" value="<?php echo $order_product_id_pickup;?>">
					
					<input type="hidden" name="order_id_pickup" value="<?php echo $order_id_pickup;?>">
					
					<input type="hidden" name="product_name_pickup" value="<?php echo $product_name_pickup;?>">
					
					<input type="hidden" name="product_qty_pickup" value="<?php echo $product_qty_pickup;?>">
					
					<input type="hidden" name="product_price_pickup" value="<?php echo $product_price_pickup;?>">
					
					<input type="hidden" name="user_email_pickup" value="<?php echo $user_email_pickup;?>">
					
					<input type="hidden" name="payment_method" value="<?php echo $payment_method;?>">
										
					<input type="hidden" name="schedule_pickup_date" value="<?php echo $schedule_pickup_date;?>">
					
					<?php 
					}
					?>
						
						<input type="submit" class="btn btn-primary btn-block" name="add_munnally_fee" value="Submit">
					</div>
				</div>
			</div>
		
		</form>
	</div>			
</div>
<?php
}

else{?>
<div class="user-table ">
		
	<div class="editboxID_number">
		<h2>Manual Billing : </h2>
	</div>
</div>
<?php 
}
}
}
?>