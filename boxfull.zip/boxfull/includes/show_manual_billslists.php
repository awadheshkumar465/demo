<?php
if($type=='showbillproductslists')
{ 
//echo "manual billing";
$currency_set=get_option('currency_set');
$timeFirst  = strtotime('2018-01-18 18:20:20');
$timeSecond = strtotime('2018-01-19 18:28:20');
$differenceInSeconds = $timeSecond - $timeFirst;

$blogusers = get_users( 'blog_id=1&orderby=nicename&role=customer' );
// Array of WP_User objects.
foreach ( $blogusers as $user ) {
	//print_r($user);
	//echo "<br>";
	$useremails = $user->user_email;
	//echo "<br>";
	$display_name =$user->display_name;
	
	$instatement[] ="'$useremails'".",";
}
$getemail='';

foreach($instatement as $i=>$k) {
    $getemail .=$k;
}
$getemail = rtrim($getemail,',');

//echo "select * from wp_schedule_pickup_order where pickup_status='1' AND user_email_pickup IN ($getemail) GROUP BY user_email_pickup";

$getpickupinformation = $wpdb->get_results("select * from wp_schedule_pickup_order where pickup_status='1' AND user_email_pickup IN ($getemail)",ARRAY_A);

echo '<h2>Show Billing informtion</h2>';
?>
<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<tbody>
				<tr>
					<th>Product Name</th>
					<th>Quantity</th>
					<th>Price</th>
					<th>Email</th>
					<th class="action">Add Monthly Bills</th>
					<th class="action">Add Other Bills</th>
				</tr>
				<?php 
				if(!empty($getpickupinformation)){
					$adminurlajax=admin_url('admin-ajax.php' );
					foreach($getpickupinformation as $finmanbills){
						//echo "<pre>"; print_r($finmanbills); echo "</pre>";
						
						$schedule_pickup_orderid =$finmanbills['schedule_pickup_orderid'];
						
						$schedule_a_pickup_product_id =$finmanbills['schedule_a_pickup_product_id'];
						
						$schedule_a_pickup_ids =$finmanbills['schedule_a_pickup_ids'];
						
						$pick_up_product_id =$finmanbills['pick_up_product_id'];
						
						$order_product_id_pickup =$finmanbills['order_product_id_pickup'];
						
						$order_id_pickup =$finmanbills['order_id_pickup'];
						
						$product_name_pickup =$finmanbills['product_name_pickup'];
						
						$product_qty_pickup =$finmanbills['product_qty_pickup'];
						
						$product_price_pickup =$finmanbills['product_price_pickup'];
						
						$user_email_pickup =$finmanbills['user_email_pickup'];
						
						$payment_method =$finmanbills['payment_method']; 
						
						$getbillsinfo = getBillingManagementDetails($pick_up_product_id,$order_product_id_pickup,$user_email_pickup);
						//echo "<pre>"; print_r($getbillsinfo); echo "</pre>";
						$billing_main_id = $getbillsinfo[0]['billing_main_id'];
						$product_qty = $getbillsinfo[0]['product_qty'];
						$product_price = $getbillsinfo[0]['product_price'];
						$proemail = $getbillsinfo[0]['user_email'];
						$storage_fee = $getbillsinfo[0]['storage_fee'];
						$handling_fee = $getbillsinfo[0]['handling_fee'];
						$delivery_fee = $getbillsinfo[0]['delivery_fee'];
						$additional_fee = $getbillsinfo[0]['additional_fee'];
						?>
					<tr>
						<td><?php echo $product_name_pickup;?></td>
						<td><?php echo $product_qty_pickup;?></td>
						<td><?php echo $currency_set."$".$product_price_pickup;?></td>
						<td><?php echo $user_email_pickup;?></td>
						<td class="action">
						
						<?php if(!empty($billing_main_id)){ ?>
							
						<?php 
						} else{ ?>
						
						<a href="<?php echo get_the_permalink();?>?type=mannualbillings&schpupoid=<?php echo $schedule_pickup_orderid;?>&useremail=<?php echo $user_email_pickup;?>&action=add" class="addmanualbills edit_btn">
						<i class="fa fa-plus" aria-hidden="true"></i>
						</a> <?php } if(!empty($billing_main_id)){ ?>
						<a href="<?php echo get_the_permalink();?>?type=editmannualbillings&billingid=<?php echo $billing_main_id;?>" class="addmanualbills edit_btn">
						<i class="fa fa-pencil" aria-hidden="true"></i>
						</a>
						<?php } ?>
						<?php if(!empty($billing_main_id)){ ?>
						<a class="delbillingmana del_btn" href="javascript:void(0);" data-billingid="<?php echo $billing_main_id;?>" data-emailid="<?php echo $proemail; ?>" data-ajaxurl="<?php echo $adminurlajax;?>">
						<i class="fa fa-trash" aria-hidden="true"></i>
						</a>
						<?php } ?>
						
						</td>
						
						<td class="action">
						<?php if(!empty($billing_main_id)){ 
						if(($storage_fee!='0')||($handling_fee!='0')||($delivery_fee!='0')||($additional_fee!='0')){}
						else {
						?>
						<a href="<?php echo get_the_permalink();?>?type=addotherbills&otherbillingid=<?php echo $billing_main_id ;?>" class="addmanualbills edit_btn">
						<i class="fa fa-plus" aria-hidden="true"></i>
						</a>
						<?php } ?>
						<a href="<?php echo get_the_permalink();?>?type=editotherbillingid&editbillinglstid=<?php echo $billing_main_id;?>" class="addmanualbills edit_btn">
						<i class="fa fa-pencil" aria-hidden="true"></i>
						</a>
						
						<?php  } else{echo "Add monthly bills first.";}?>
						</td>
						
				</tr>
				
					<?php
					}
				}
				?>
				
			</tbody>
		</table>
		<nav class="custom-pagination"></nav>	
</div>
<?php 
	
}
?>