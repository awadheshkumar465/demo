<?php
if($type=='editdiscountcoupan'){ 
	$user = wp_get_current_user();
	$userId = $user->ID;
	$userrole = $user->display_name;
	$discount_id =$_GET['discount_id'];
	$discount_coupan_amount = $_GET['discount_coupan_amount'];
	$discount_coupan_code = $_GET['coupancode'];
	$getdata = $wpdb->get_results("select * from wp_discountcoupans where discount_id = $discount_id ");
	//print_r($getdata);
	foreach ($getdata as $getdatalists) {
		$discount_id = $getdatalists->discount_id;
		$discount_coupan_duration = $getdatalists->discount_coupan_duration;
		$discount_coupan_code = $getdatalists->discount_coupan_code;
		$discount_coupan_amount = $getdatalists->discount_coupan_amount;
	}
	if(isset($_POST['editcoupans'])){
		$discount_coupan_duration=trim($_POST['discount_coupan_duration']);
		$discount_coupan_code=trim($_POST['discount_coupan_code']);
		$discount_coupan_amount=trim($_POST['discount_coupan_amount']);
		$update_data = $wpdb->update( 
					'wp_discountcoupans', 
					array( 
						'discount_coupan_duration' => $discount_coupan_duration, 
						'discount_coupan_code' => $discount_coupan_code,
						'discount_coupan_amount' => $discount_coupan_amount
					), 
					array( 'discount_id' => $discount_id ) 
				);
		
		$redirects=get_the_permalink()."?type=allpromotions";
		echo "Coupan code updated successfully";
		wp_redirect($redirects);
	}
	?>
	<form action="" class="form-horizontal" method="POST" role="form">
		<h2>Edit Discount Coupan</h2>
		<div class="form-group">
			<label for="coupancode" class="col-sm-3 control-label">Discount Coupan Duration :<span class="requiredpart">*</span>
			</label>
			<div class="col-sm-9">
				<input type="text" id="discount_coupan_duration" name="discount_coupan_duration" class="form-control" autofocus="" value="<?php echo $discount_coupan_duration; ?>" maxlength="10" readpnly>
			</div>
		</div>
		<div class="form-group">
			<label for="coupancode" class="col-sm-3 control-label">Discount Coupan Code :<span class="requiredpart">*</span>
			</label>
			<div class="col-sm-9">
				<input type="text" id="discount_coupan_code" name="discount_coupan_code" class="form-control" autofocus="" value="<?php echo $discount_coupan_code; ?>" maxlength="10" required>
			</div>
		</div>
		<div class="form-group">
			<label for="coupanamount" class="col-sm-3 control-label">Discount Coupan Amount :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<input type="text" id="discount_coupan_amount" name="discount_coupan_amount" class="form-control" autofocus="" value="<?php echo $discount_coupan_amount; ?>" maxlength="4" required >
				<span class="help-block">Coupan Discount, eg.: 2%, 5%, 10%</span>
			</div>
		</div>
	<div class="form-group">
	<div class="col-sm-3 col-sm-offset-3">
	<input type="submit" name="editcoupans" value="Submit">
	</div>
    </div>
</form>
<?php
}
