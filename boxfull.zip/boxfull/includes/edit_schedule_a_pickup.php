<?php
if($type=='editstatus'){

global $wpdb; ?>
<h2>Schedule A Pick Up</h2>
<?php

$orderstatusid = $_GET['orderstatusid'];
if($orderstatusid){
	$emailid = $_GET['emailid'];
	//echo "SELECT * FROM wp_schedule_pickup INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id = wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_pickup_product_id = wp_schedule_pickup_order.schedule_a_pickup_product_id where wp_schedule_pickup_order.payment_status='paid' AND wp_schedule_pickup_order.user_email_pickup='$emailid' AND  wp_schedule_pickup_order.schedule_pickup_orderid =$orderstatusid"; 
$getpickupinfo = getScheduleAPickupInformation($orderstatusid,$emailid); ?>
<!--Showing all Schedule a return Information lists -->
<div class="col-md-12 admin_schedule_return_status">
<?php $ajaxurl = admin_url("admin-ajax.php"); ?>
<input type="hidden" value="<?php echo $ajaxurl; ?>" name="adminurls" class="adminurls">
	<?php
	foreach($getpickupinfo as $val){
		//echo "<pre>"; print_r($val); echo "</pre>";
		$oredr_id = $val['order_product_id'];
		$user_email_pickup = $val['user_email_pickup'];
		$fulladdress = $val['full_address'];	
		$region= $val['region_id'];
		$distict= $val['distict_id'];
		$useremail= $val['useremail'];
		$special_instructions= $val['special_instructions'];
		$pickup_of_boxes= $val['pickup_of_boxes'];
		$nooffloors= $val['no_of_floors'];
		$pickupdate= $val['schedule_pickup_date'];
		$pickuptime= $val['schedule_pickup_time'];
		$pickup_status = $val['pickup_status'];
		if($pickup_status==0){$status = 'Pending';}
		if($pickup_status==1){$status = 'Delivered';}
		$schedule_pickup_orderid = $val['schedule_pickup_orderid'];
		$regionname = get_term_by('term_id', $region, 'country');
		$region_name = $regionname->name;
		$schedule_pickup_id = $val['schedule_pickup_id'];
		foreach($regionname as $countrylists){
			echo $countrylists->name;
		}
		$title = $wpdb->get_results("SELECT post_title FROM `wp_posts` where ID=$distict",ARRAY_A);
		$dist_title = $title[0]['post_title'];
		$user = get_user_by( 'email', $user_email_pickup );
		$user_name = $user->first_name . ' ' . $user->last_name;
		$region_dist = $region_name . ' / ' . $dist_title;
		?>
		<div class="col-md-8">
			<ul class="user_purchase">
				<li><label>Name</label>
					<?php echo $user_name; ?>
				</li>
				<li><label>Address</label>
					<?php echo $fulladdress; ?>
				</li>
				<li>
					<label>Regions / District</label>
					<?php echo $region_dist; ?>
				</li>
				<li>
					<label>Stairs (No. Of Floors)</label>
					<?php echo $nooffloors; ?>
				</li>
				<li>
					<label>Schedule Pick Up Date</label>
					<?php echo $pickupdate; ?>
				</li>
				<li>
					<label>Schedule Pick-up Time</label>
					<?php echo $pickuptime; ?>
				</li>
				<li>
					<label>Special Instructions</label>
					<?php echo $special_instructions; ?>
				</li>
				<li>
					<label>Delivery Status</label>
					<?php echo $status; ?>
				</li>
				<li>
					<label>Change Status</label>
					<a class="change_pickup_status" href="javascript:void(0);" data-schedulepickupid="<?php echo $schedule_pickup_id;?>">Change Status</a>
				</li>
			</ul>
		</div>
		<div class="col-md-4">
			<?php 
			$productids = $wpdb->get_results("SELECT * FROM `wp_schedule_pickup_products` where order_product_id = '$oredr_id' ");
			foreach ($productids as $productid) { ?>
				<div class="userproimage">
				<?php 
					$schedule_return_id = $productid->product_id;
					$imgsrc = get_field('ktstorage_type_image',$schedule_return_id);
				?>
				<img src="<?php echo $imgsrc; ?>"" class="img-responsive">
				</div>
			<?php } ?>
		</div>
		<?php 
	} ?>
	</div>
<?php
	
}

}

?>