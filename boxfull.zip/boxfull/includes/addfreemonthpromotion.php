<?php 
if($type=='addfreemonthpromotion'){
	global $wpdb;
	$count_query = "select * from freemonthpromptation where promotion_duration";
	if(isset($_POST['addpromotions'])){
		$promotion_duration=trim($_POST['promotion_duration']);
		$promotion_code=trim(strtoupper($_POST['promotion_code']));
		$promotion_amount=trim($_POST['promotion_amount']);
		$alldata = $wpdb->get_results("select * from freemonthpromptation where promotion_duration = '$promotion_duration' ");
		echo $promotion_id = $alldata[0]->promotion_id;
		if(empty($alldata)){
			$insert_data = $wpdb->insert( 
					'freemonthpromptation', 
					array( 
						'promotion_duration' => $promotion_duration, 
						'promotion_code' => $promotion_code,
						'promotion_amount' => $promotion_amount
					), 
					array( 
						'%s', 
						'%s',
						'%d' 
					) 
				); 
			$redirects=get_the_permalink()."?type=allpromotions";
			echo "Promotion code Created successfully";
			wp_redirect($redirects);
		}
		else{
			echo $update_data = $wpdb->update( 
					'freemonthpromptation', 
					array( 
						'promotion_duration' => $promotion_duration, 
						'promotion_code' => $promotion_code,
						'promotion_amount' => $promotion_amount
					), 
					array( 'promotion_id' => $promotion_id ) 
				);
			echo '<pre>';
			print_r($update_data);
			echo '</pre>';
			$redirects=get_the_permalink()."?type=allpromotions";
			echo "Promotion code Updated successfully";
			wp_redirect($redirects);
		}
		
		
		//$updatepromotionscode = update_option( 'freepromotioncode', $freepromotioncode );
		//$updatepromotionsamount = update_option( 'freepromotionamount', $freepromotionamount );

		
		//wp_redirect($redirects);	
	}
	else { ?>
		<form action="" class="form-horizontal" method="POST" role="form">
		<h2>First Month Free Promotion Code</h2>
			<div class="form-group">
				<label for="promotion_duration" class="col-sm-3 control-label">Promotion Duration :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<select name="promotion_duration">
				  <option value="First Month">First Month</option>
				  <option value="Second Month">Second Month</option>
				  <option value="Third Month">Third Month</option>
				  <option value="Fourth Month">Fourth Month</option>
				  <option value="Fifth Month">Fifth Month</option>
				  <option value="Sixth Month">Sixth Month</option>
				  <option value="Seventh Month">Seventh Month</option>
				  <option value="Eighth Month">Eighth Month</option>
				  <option value="Ninth Month">Ninth Month</option>
				  <option value="Tenth Month">Tenth Month</option>
				  <option value="Eleventh Month">Eleventh Month</option>
				  <option value="Twelveth Month">Twelveth Month</option>
				</select>
			</div>
			</div>
			<div class="form-group">
			<label for="promotion_code" class="col-sm-3 control-label">Promotion Code :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<input type="text" id="promotion_code" name="promotion_code" placeholder="Add Promotion" class="form-control" autofocus="" value="" maxlength="10"  style="text-transform:uppercase" required>
			</div>
			</div>
			<div class="form-group">
			<label for="promotion_amount" class="col-sm-3 control-label">Promotion Amount :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<input type="text" id="promotion_amount" name="promotion_amount" placeholder="Add Promotion Amount" class="form-control" autofocus="" value="" maxlength="4" required >
				<span class="help-block">Promotion Amount, eg.: 20.3, 34,55.12</span>
			</div>
			</div>
			
			<div class="form-group">
			<div class="col-sm-3 col-sm-offset-3">
			<input type="hidden" name="addpromotionform" id="addpromotionorm" value="addpromotion">
			<input type="submit" class="btn btn-primary btn-block" name="addpromotions" value="Submit">
			</div>
		     </div>
		</form>
	<?php }
}