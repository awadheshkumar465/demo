<?php
if($type=='adddeliveryfee'){
global $wpdb;
$html='';
$html.='
<div class="col-md-12">
	<h2>Add Delivery Fee</h2>
	<form method="POST" action="" id="addfeebybox" enctype="multipart/form-data">
		<div class="form-group">
			
				<div class="col-md-3 deliveryfee"><label for="titles">Same Business Day:<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="payasyourstore" name="samebusinessday" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Box</div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">Next Business Day:<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="nextbusinessday" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles">Per Box </div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">In Or More Than 2 Business Days:<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="inormorethantwobusinessday" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles"></div>
					<div class="clearer"></div>
				<div class="col-md-3 handlingfees"><label for="titles">After Hours Delivery:<span class="requiredpart">*</span> </label></div>
					<div class="col-md-6 no-padding"><input type="text" class="threefivemonths" name="afterhoursdelivery" id="addstoragenamepost" value="" required=""></div><div class="col-md-3 titles"></div>
					<div class="clearer"></div>
		</div>
		<div class="col-md-12">
			<input type="hidden" name="handlingfeebydelivery" value="deliveryfee"  />
			<input type="submit" class="btn btn-default addstoragesubmit" value="Submit">
		</div>
	</form>
</div>
';
echo $html;
if(isset($_POST['samebusinessday'])){

$samebusinessday = trim($_POST['samebusinessday']);

$nextbusinessday = trim($_POST['nextbusinessday']);

$inormorethantwobusinessday = trim($_POST['inormorethantwobusinessday']);

$afterhoursdelivery = trim($_POST['afterhoursdelivery']);

$handlingfeebydelivery = trim($_POST['handlingfeebydelivery']);

$insert = $wpdb->insert('wp_handling_fee', array(
'payasyourstore' =>'',
'threefivemonths' =>'',
'sixelevenmonths' =>'',
'twelvemonthsplus' =>'',
'checkoutandrecheckin' =>'',
'finalcheckouthandlingfee' =>'',
'finalcheckout' =>'',
'twentyminutes' =>'',
'emptyboxcollectfinalcheckout' => '',
'boxcatid' => '',
'handlingfeeby' => $handlingfeebydelivery,
'samebusinessday' =>$samebusinessday,
'nextbusinessday' =>$nextbusinessday,
'inormorethantwobusinessday' =>$inormorethantwobusinessday,
'afterhoursdelivery' =>$afterhoursdelivery,
)); 
$lastid = $wpdb->insert_id; 
if($lastid>0){
	?>
	<script type="text/javascript">
	alert ("Delivery Fee Added Successfully.");
	window.location =  "<?php echo get_the_permalink();?>?type=feetypes";
	</script>
	<?php 
} 
}


}

?>