<?php
if($type=='editmannualbillings')
{
	global $wpdb;


if($_POST['edit_munnally_fee']){
	
	$noshowfee=trim($_POST['noshowfee']);
	
	$outstanding_areafee=trim($_POST['outstanding_areafee']);
	
	$packing_fee=trim($_POST['packing_fee']);
	
	$parkings=trim($_POST['parkings']);
	
	$moving_penality=trim($_POST['moving_penality']);
	
	$overweight_limit=trim($_POST['overweight_limit']);
	
	$box_damage=trim($_POST['box_damage']);
	
	$editbillingid=trim($_POST['editbillingid']);
	
	//print_r($_POST); exit();
	$updates =$wpdb->update('wp_billingmanagement',array(
		'noshowfee'=>$noshowfee ,
		'outstanding_areafee'=>$outstanding_areafee ,
		'packing_fee'=>$packing_fee ,
		'parkings'=>$parkings ,
		'moving_penality'=>$moving_penality ,
		'overweight_limit'=>$overweight_limit ,
		'box_damage'=>$box_damage ,
	),array('billing_main_id'=>$editbillingid));
	$lastid = $wpdb->insert_id;
	?>
	<script type = "text/javascript" language = "javascript">
			jQuery(document).ready(function() {
			alert ("Billing Updated Successfully");
			window.location = "<?php echo get_permalink();?>?type=showbillproductslists";
			});
		</script>
<?php 
}
else {
if(!empty($_GET['billingid'])){
$billingid=trim($_GET['billingid']);	



//echo "SELECT * FROM `wp_billingmanagement` WHERE `billing_main_id`=$billingid";

$getpickupinformation = $wpdb->get_results("SELECT * FROM `wp_billingmanagement` WHERE `billing_main_id`=$billingid",ARRAY_A);
if(!empty($getpickupinformation)){
foreach($getpickupinformation as $alllists){
//echo "<pre>"; print_r($alllists); echo "</pre>";

$noshowfee =trim($alllists['noshowfee']);	

$outstanding_areafee =trim($alllists['outstanding_areafee']);	

$packing_fee =trim($alllists['packing_fee']);	

$parkings =trim($alllists['parkings']);	

$moving_penality =trim($alllists['moving_penality']);	

$overweight_limit =trim($alllists['overweight_limit']);	

$box_damage =trim($alllists['box_damage']);	
}
}
?>
<div class="user-table ">
		
	<div class="editboxID_number">
		<h2>Edit Manual Billing : </h2>
		<form class="form-horizontal-manual-billing" method="POST" >
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 scanrow">
						<label>No Show Fee</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="noshowfee" value="<?php echo $noshowfee;?>" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 uploadimages">
						<label>Outside Service Area Delivery</label>
					</div>
					<div class="col-md-8 scanrow">
						<input type="text" name="outstanding_areafee" value="<?php echo $outstanding_areafee;?>" class="qrcodevals">
					</div>
				</div>
			</div>
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Packing Fee </label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="packing_fee" value="<?php echo $packing_fee;?>">
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Parking:</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="parkings" value="<?php echo $parkings;?>" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Moving Penalty:</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="moving_penality" value="<?php echo $moving_penality;?>" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Over Weight Limit :</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="overweight_limit" value="<?php echo $overweight_limit;?>" >
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-4 sto_type">
						<label>Box Damage :</label>

					</div>
					<div class="col-md-8 sto_type">
						<input type="text" name="box_damage" value="<?php echo $box_damage;?>" >
					</div>
				</div>
			</div>	
			
			<div class="form-group">
				<div class="row">
					<div class="col-md-12 custid">
					<?php $j=0;
					foreach($getpickupinformation as $manuvals){
						//echo "<pre>"; print_r($manuvals); echo "</pre>";
						
						$billing_main_id = $manuvals['billing_main_id'];
						
						
					$j++;?>
					
					<input type="hidden" name="editbillingid" value="<?php echo $billing_main_id;?>">
					
					
					
					<?php 
					}
					?>
						
						<input type="submit" class="btn btn-primary btn-block" name="edit_munnally_fee" value="Submit">
					</div>
				</div>
			</div>
		
		</form>
	</div>			
</div>
<?php
}

else{?>
<div class="user-table ">
		
	<div class="editboxID_number">
		<h2>Manual Billing : </h2>
	</div>
</div>
<?php 
}
}
}
?>