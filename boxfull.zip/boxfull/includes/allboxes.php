<?php
if(($type=='allboxes')){?>
<script type="text/javascript">
jQuery(document).ready(function(){
/* Add Box ID admin section starts here */
	jQuery("input.addboxitemsnoids").click(function(e){
				
            var favorite = [];
            jQuery.each(jQuery("input[name='checkboxorderids']:checked"), function(){ 
			favorite.push(jQuery(this).val());
			jQuery('.hiddenaddidnoorder_ids').val(favorite); 
			
            });
			if(favorite==''){
				alert ("Please select a product.");
				e.preventDefault();
				return false;
			}
			else{
				
			}
			
            
        });
		
		 jQuery("#sorbyorderid").live("change keyup", function () {
                jQuery("#form1").submit();
            });
			
		jQuery("#sortbyidnum").live("change keyup", function () {
                jQuery("#form2").submit();
            });
			
		jQuery("#sortbycustomernum").live("change keyup", function () {
                jQuery("#form3").submit();
            });
});
		</script>
<?php 
global $wpdb;
$user = wp_get_current_user();
//print_r($user);
$username = $user->display_name;
$userId = $user->ID;
$user_email = $user->user_email;
$addboxes=$_GET['addboxes'];

// echo "SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id AND wp_orders.paymentstatus!=''";
 
 if(isset($_POST['sortbyorder']))
 {
	// print_r($_POST);
	 $sortorderby=$_POST['sortbyorder'];
	 if($sortorderby=='ASC'){$orderby="order by wp_orders.`order_id` ASC";}
	 if($sortorderby=='DESC'){$orderby="order by wp_orders.`order_id` DESC";}
 }
 
 //print_r($_POST);
 
 if(isset($_POST['sortbyidnumber']))
 {
	 $sortbyidnumber = $_POST['sortbyidnumber'];
	 
	 if($sortbyidnumber=='DESC')
	 {
		 $orderbyd = "ORDER BY `wp_boximages`.`boximageid` DESC";
	 }
	 
	  if($sortbyidnumber=='ASC')
	 {
		 $orderbyd = "ORDER BY `wp_boximages`.`boximageid` ASC";
	 }
	 
	 
	 
	 $selects = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id AND wp_orders.paymentstatus!='' left JOIN wp_boximages ON wp_order_products.order_product_id=wp_boximages.order_product_id $orderbyd ");
 }
 
 if(isset($_POST['sortbycustnumbers']))
 {
	 echo $sortbyidnumber = $_POST['sortbycustnumbers'];
	 
	 if($sortbyidnumber=='DESC')
	 {
		 $orderbys = "ORDER BY `wp_boximages`.`customer_id` DESC";
	 }
	 
	  if($sortbyidnumber=='ASC')
	 {
		 $orderbys = "ORDER BY `wp_boximages`.`customer_id` ASC";
	 }
	 $selects = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id AND wp_orders.paymentstatus!='' left JOIN wp_boximages ON wp_order_products.order_product_id=wp_boximages.order_product_id $orderbys ");
 }
 
 
 else{
$selects = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id AND wp_orders.paymentstatus!='' $orderby");	
 }

// print_r($selects );
$html='';
if(!empty($selects)){
$html.='<div class="allboxeslists">
<h2>All Box Number</h2>
<div class="col-xs-12 table-responsive ">
	<div class="row">
		<div class="col-md-4 sortbyorder">
			
			<form id="form1" method="POST" action="'.get_the_permalink().'?type=allboxes">
			<select id="sorbyorderid" name="sortbyorder">
				<option value="">Sort By Order Number</option>
				<option value="ASC">ASC</option>
				<option value="DESC">DESC</option>
			</select>
			</form>
		</div>
		
		<div class="col-md-4 sortbyidno">
			
			<form id="form2" method="POST" action="'.get_the_permalink().'?type=allboxes">
			<select id="sortbyidnum" name="sortbyidnumber">
				<option value="">Sort By ID Number</option>
				<option value="ASC">ASC</option>
				<option value="DESC">DESC</option>	
			</select>
			</form>
		</div>
		
		<div class="col-md-4 sortbyidsuctid">
		
			<form id="form3" method="POST" action="'.get_the_permalink().'?type=allboxes">
			<select id="sortbycustomernum" name="sortbycustnumbers">
				<option value="">Sort By Customer ID</option>
				<option value="ASC">ASC</option>
				<option value="DESC">DESC</option>	
			</select>
			</form>
		</div>
		
	</div>
<table class="table table-striped">
<thead>
<tr>
<th></th>
<th>Item or Box Id</th>
<th>Storage Type</th>
<th>ID</th>
<th>Date</th>
<th>Invoice Number</th>
</tr>
</thead>
<tbody>';
$j=0;
foreach($selects as $vals)
{
	//echo "<pre>"; print_r($vals); echo "</pre>";
	if(isset($_POST['sortbyorder']))
	{
		
		$order_id = $vals->order_id;
		$fullname = $vals->fullname;
		$useremail =$vals->useremail;
		$productname = $vals->productname;
		$productids = $vals->productids;
		$order_product_id = $vals->order_product_id;
		$user_email = get_user_by( 'email', $useremail );
		$umail="'$useremail'";
		
		$boxids = getIdNumberByEmail($useremail,$order_product_id);
		//echo "<pre>"; print_r($boxids); echo "</pre>";
		$boxidno=$boxids[1];
		if($productname=='Standard Box'){$proname="AS000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;}
						
		if(($productname=='Large Size Items') || ($productname=='Large Items')){$proname="AL000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;}
		
		if($productname=='Wardrobe Box'){$proname="AW000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;}
		
		if($productname=='Document Box'){$proname="AD000$productids";$invoicenumber= "I".date("y")."000".$order_product_id;}
		
		if(($productname=='Medium Size Items')||($productname=='Medium Items')){$proname="AM000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;}
		
		if(($productname=='Small Size Items')||($productname=='Small Items')){$proname="AS000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;}
		
		$addedby=$username;
		
		
	}
	
	if(isset($_POST['sortbyidnumber']))
	{
		$order_id = $vals->order_id;
		$fullname = $vals->fullname;
		$useremail =$vals->useremail;
		$productname = $vals->productname;
		$productids = $vals->productids;
		$order_product_id = $vals->order_product_id;
		$user_email = get_user_by( 'email', $useremail );
		$umail="'$useremail'";
		$boxids = $vals->boxid;
		
		$proname = $boxids;
		
		$invoicenumber= "I".date("y")."000".$order_product_id;
		
		$boxidno = $vals->box_add_date;
	}
	
	if(isset($_POST['sortbycustnumbers']))
	{
		$order_id = $vals->order_id;
		$fullname = $vals->fullname;
		$useremail =$vals->useremail;
		$productname = $vals->productname;
		$productids = $vals->productids;
		$order_product_id = $vals->order_product_id;
		$user_email = get_user_by( 'email', $useremail );
		$umail="'$useremail'";
		$boxids = $vals->boxid;
		
		$proname = $boxids;
		
		$invoicenumber= "I".date("y")."000".$order_product_id;
		
		$boxidno = $vals->box_add_date;
	}
	 
	else
	{
		$order_id = $vals->order_id;
		$fullname = $vals->fullname;
		$useremail =$vals->useremail;
		$productname = $vals->productname;
		$productids = $vals->productids;
		$order_product_id = $vals->order_product_id;
		$user_email = get_user_by( 'email', $useremail );
		$umail="'$useremail'";
		
		$boxids = getIdNumberByEmail($useremail,$order_product_id);
		//echo "<pre>"; print_r($boxids); echo "</pre>";
		$boxidno=$boxids[1];
		if($productname=='Standard Box'){$proname="AS000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Standard Box";}
						
		if(($productname=='Large Size Items') || ($productname=='Large Items')){$proname="AL000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Large Items";}
		
		if($productname=='Wardrobe Box'){$proname="AW000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Wardrobe Box";}
		
		if($productname=='Document Box'){$proname="AD000$productids";$invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Document Box";}
		
		if(($productname=='Medium Size Items')||($productname=='Medium Items')){$proname="AM000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Medium Items";}
		
		if(($productname=='Small Size Items')||($productname=='Small Items')){$proname="ASM000$productids"; $invoicenumber= "I".date("y")."000".$order_product_id;
		$newpronamesid="Small Items";}
		
		$addedby=$username;
	}
	
		$html.='<tr class="allboxeslists">';

	$html.='<td><input type="checkbox" name="checkboxorderids" value="'.$order_id.",".$productids.",".$order_product_id.",".$addedby.",".$newpronamesid.",".$useremail.'" class="checkaddeditdelete">
	
	</td>
	<td>';
	if(!empty($boxids)){
		$html.=$proname;
	}
	else{$html.='';}
	
	$html.=
	'</td>
	<td>'.$productname.'</td>
	<td>';
	
	$html.="HK".date("y")."000".$user_email->data->ID;
	
	$html.='</td>
	<td>'.$boxidno.'</td>
	<td>';
	
		$html.=$invoicenumber;
	
	
	$html.='</td>
	</tr>';
	
$j++;	
}

$html.='

</tbody>

</table>
<div class="allboxes_actionbtn">
<div class="form-group">
<form method="POST" action="'.get_the_permalink().'?type=addboxid" >
<input type="hidden" class="hiddenaddidnoorder_ids" name="hiddenaddidnoorder_ids" value="" />
<input type="submit" class="addboxitemsnoids" name="addidno" value="ADD ID"> 
</form>
</div>
<div class="form-group">
<form method="POST" action="'.get_the_permalink().'?type=editboxid" >
<input type="hidden" class ="hiddeneditboxid_ids" name="hiddeneditboxid_ids" value="" />
<input type="submit" class="editboxitemsnoids" name="editboxid" value="Edit"> 
</form>
</div>
<div class="form-group">
<form method="POST" action="" >
<input type="hidden" name="hiddendeleteboxid_ids" value="" />
<input type="submit" class="deleteboxitemsnoids" name="deleteboxid" value="Delete"> 
</form>
</div>
</div>
</div>';
}
else
{
	$html.='<div class="col-xs-12 table-responsive">
<h2>All Box Number</h2>
<table class="table table-striped">
<tbody>
<tr>
<td>No Products Found</td>
</tr>
</tbody>
</table>
</div>';
}
$html.='</div>';
echo $html; 
}
 
?>
