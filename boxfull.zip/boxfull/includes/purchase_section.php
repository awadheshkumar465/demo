<div class="purchase_out_sec"> <?php //print_r($_SESSION); ?>
					<div class="purchase_outmain">
					<div class="purchase_out">
					<h3>Storage</h3>
					<div class="edit_strtyp"><a href="<?php echo site_url('order'); ?>"><i class="fa fa-pencil"></i></a></div>
					
					<?php 
					$totalsessionprice='';
					$tetings='';
					//print_r($_SESSION);
					if($_SESSION["product_id"])
					{
						$hdndlingfeebyboxsums=0;
						$pro_pricemonth_array_session[]=array_combine($_SESSION["store_duration_months"],$_SESSION["product_qty"]);
						//print_r($pro_pricemonth_array_session);
						$total='';
						$totfinal=array();
						$priceshtmls=array();
						
					
					$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);
					$totalsessionprice=get_total_price_using_session_cart($pro_qty_array_session,$pricestoragesession,$categoryids); 
					
					$i=1;
					$s=0;
					global $wpdb; $signup_user = $_SESSION['signup_user'];
					$finprice = 0;
					
					foreach($pro_pricemonth_array_session as $proprice=>$proqty){
						
						if($proqty==0){} else{
							
							$totsum[]=$proprice*$proqty;
							$pricepro[]=$proprice;
							$selects = $wpdb->get_results("select checkcartitemsid from checkoutcartitems where userid = $signup_user");
							
							//$wpdb->update('checkoutcartitems', array('price'=>$proprice), array('userid'=>$signup_user));
							
						}
						}
						$j=0; $sum=0; $tot=0;
						
					foreach($pro_qty_array_session as $proid=>$proqty)
					{ 
						if($proqty==0){} else{ 
						
						if($_SESSION["store_duration_months"]=='store plan'){
							$storefields = 'store_plan';
						}
						
						if($_SESSION["store_duration_months"]=='3-5 Months'){
							$storefields = 'ktstorage_type_price';
						}
						
						if($_SESSION["store_duration_months"]=='6-11 Months'){
							$storefields = 'storage_type_price_six';
						}
						
						if($_SESSION["store_duration_months"]=='12+ Months'){
							$storefields = 'storage_type_price_twelve';
						}
						
						//echo $proid;
						//echo $proqty;
						$newprice = get_field($storefields,$proid);
						$tot = $newprice*$proqty;
						$totsum[]=$newprice*$proqty;
						$sum=$sum+($tot);
						$titles=get_the_title($proid);
						$testings.=$proqty.",".$titles.",";
						$testing[]=array('qty'=>$proqty,'proitem'=>$titles);
						
						
						//echo $proqty;
						//echo $pricepro[$j];
						//echo "select * from wp_postmeta where meta_value = ".$pricepro[$j]." and post_id = ".$proid." ";
						$mduration = getMonthDurationByProductId($proid,$pricepro[$j]);
						
						foreach($mduration as $montduration){
							$storagedurations = $montduration->meta_key;
							if($storagedurations=='store_plan'){$storageduration[]="Store Plan";}
							if($storagedurations=='ktstorage_type_price'){$storageduration[]="3-5 Months";} 
							if($storagedurations=='storage_type_price_six'){$storageduration[]="6-11 Months";} 
							if($storagedurations=='storage_type_price_twelve'){$storageduration[]="12+ Months";} 
						}
						$storeby = getStorageType($proid);
						$storeboxitems = $storeby[0]['name'];
						/*
						if($storeboxitems=='Store by the item')
						{
							;
						$itemminprice = 80;
						
						$hdndlingfeebyitems = getHandlingFeeByItemFrontend($pricepro[$j],$proqty,$storageduration[$j],$itemminprice);
						
						
						}
						
						if($storeboxitems=='Store by the box')
						{
							;
						$boxminprice = 100;
						
						$hdndlingfeebyboxs = getHandlingFeeByBoxFrontend($pricepro[$j],$proqty,$storageduration[$j],$boxminprice);
						
						
						}
						$hdndlingfeebyboxsums = $hdndlingfeebyboxsums + $hdndlingfeebyitems +$hdndlingfeebyboxs;*/
						echo '<div class="str_dtls">';
						echo '<div class="odrDtls">'.$_SESSION["store_duration_months"].'</div>';
						echo '<div class="odrDtls">'.$proqty.' * '.get_the_title($proid).'</div>';
						echo '<div class="odrDtls">'.$currencycodes.'$'.$tot.'</div>';
						echo "</div>";
						$j++;
						}
						
					}
					

					}
					
					
					?>
					
					</div>
					</div>
					<div class="total_out">
						<div class="total_out_left">
						<span class="monthly storage_fee">Monthly Storage Fee :</span>
						</div>
						<div class="total_out_right">
							<?php $finalprices = $sum; echo $currencycodes."$".$sum; 
							$_SESSION['totprices'] = $finalprices; ?>
						</div>
						<!--<div class="total_out_left" style="clear: left;">
							<span class="monthly storage_fee">Less Handling Fee :</span>
						</div>
					
						<div class="total_out_right" style="clear: right;">
							<?php //echo $currencycodes."$".$hdndlingfeebyboxsums; ?>
						</div>
					
						<div class="total_out_left" style="clear: left;">
							<span class="monthly storage_fee" >Total  Fee :</span>
						</div>
					
						<div class="total_out_right" style="clear: right;">
							<?php //echo $currencycodes."$".$finalprices; ?>
						</div>-->
					
					</div>
					
					
					
					</div>
					<input type="hidden" name="finalamount" value="<?php echo $finalprices;?>" >
					
					<input type="hidden" name="store_monthsduration" value="<?php echo $_SESSION['store_duration_months'];?>" >
					
					
					<script type="text/javascript">
					jQuery(document).ready(function(){
						
						jQuery('div.left>div').each(function(){
							var i=0;
						//var intext[i] = jQuery(this).text(); 
						//jQuery('.col-md-4.largefonts').html(intext);
						});
						//alert (intext);
						
					});
					
					</script>