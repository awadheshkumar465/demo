<?php
if($type=='allpromotions'){
	global $wpdb;
	$user = wp_get_current_user();
	$userId = $user->ID;
	$userrole = $user->display_name;
	$currency_set=get_option('currency_set');
	$adminurl = admin_url('admin-ajax.php'); 
	$monthpromptation = $wpdb->get_results("select * from freemonthpromptation where promotion_duration!='' ");
	$discountcoupanslists = $wpdb->get_results("select * from wp_discountcoupans where discount_coupan_duration!='' ");
	$adminurl =admin_url('admin-ajax.php');
	
	$cashcoupanslists = $wpdb->get_results("select * from wp_cashcoupancode");
	
	 ?>
	<div class="table-responsive">
		<h2>Show All Promotions</h2>
		<table class="table table-striped table-bordered">
			<tr>
				<th>Promotion Duration</th>
				<th>Promotion Code</th>
				<th>Promotion Amount (<?php echo $currency_set."$"; ?>)</th>
				<th>Author</th>
				<th class="action">Action</th>
			</tr>
			<?php if($monthpromptation){ 
				foreach ($monthpromptation as $allpromptations) { 
				
					$promotion_id = $allpromptations->promotion_id;
					$promotion_duration = $allpromptations->promotion_duration;
					$promotion_code = $allpromptations->promotion_code;
					$promotion_amount = $allpromptations->promotion_amount;
					?>
					<tr>
						<td><?php echo $promotion_duration; ?></td>
						<td><?php echo $promotion_code; ?></td>
						<td><?php echo $currency_set."$".$promotion_amount; ?></td>
						<td><?php echo ucfirst($userrole); ?></td>
						<td class="action">
							<a href="<?php echo get_the_permalink();?>/?type=promotioncode&promoid=<?php echo $promotion_id;?>" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
							<a class="deletepromotioins del_btn" href="javascript:void(0);" data-promotionid="<?php echo $promotion_id;?>" data-ajaxurls="<?php echo $adminurl;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
						</td>
					</tr>
					<?php } 
				}

			else{
				echo '<tr><td colspan="5"><h3><a href="'.get_the_permalink().'?type=addnewpromotion"> No Promotions click here to add</a></h3></t></tr>';
			} ?>
		</table>
	</div>


	<!-- Show Coupan Amout start 27-01-2018 --> 

	<div class="table-responsive">
		<h2>Show Discount Coupan Details</h2>
		<table class="table table-striped table-bordered">
			<tr>
				<th>Discount Coupan Duration</th>
				<th>Coupan Code</th>
				<th>Coupan Discount(%)</th>
				<th>Author</th>
				<th class="action">Action</th>
			</tr>
			<?php if($discountcoupanslists){ 
				foreach ($discountcoupanslists as $coupanslists) { 
					$discount_id = $coupanslists->discount_id;
					$discount_coupan_duration = $coupanslists->discount_coupan_duration;
					$discount_coupan_code = $coupanslists->discount_coupan_code	;
					$discount_coupan_amount = $coupanslists->discount_coupan_amount ;?>
					<tr>
						<td><?php echo $discount_coupan_duration; ?></td>
						<td><?php echo $discount_coupan_code; ?></td>
						<td><?php echo $discount_coupan_amount; ?>%</td>
						<td><?php echo ucfirst($userrole); ?></td>
						<td class="action">
							<a href="<?php echo get_the_permalink();?>/?type=editdiscountcoupan&discount_id=<?php echo $discount_id; ?>&discount_coupan_amount=<?php echo $discount_coupan_amount; ?>&coupancode=<?php echo $discount_coupan_code; ?>" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
							<a class="deletecoupans del_btn" href="javascript:void(0);" data-coupandisid="<?php echo $discount_id; ?>" data-ajaxurls="<?php echo $adminurl;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
						</td>
					</tr>
				<?php }
			} 
			else{
				echo '<tr><td colspan="4"><h3><a href="'.get_the_permalink().'?type=adddiscountcoupon"> No Coupan click here to add</a></h3></t></tr>';
			} ?>
		</table>
	</div>
	<!-- Ending For Show Coupan Amout start 27-01-2018 --> 
	
	
	<!-- Show Cah Coupan Data start 27-01-2018 --> 

	<div class="table-responsive">
		<h2>Show Cash Coupan Details</h2>
		<table class="table table-striped table-bordered">
			<tr>
				<th class="action">S.No</th>
				<th>Coupan Code</th>
				<th>Coupan Discount(%)</th>
				<th>Author</th>
				<th class="action">Action</th>
			</tr>
			<?php if($cashcoupanslists){ 
				foreach ($cashcoupanslists as $cashcoupansdata) { 
					$cashcoupan_id = $cashcoupansdata->cashcoupan_id;
					$cashcoupan_code = $cashcoupansdata->cashcoupan_code;
					$cashcoupan_amount = $cashcoupansdata->cashcoupan_amount;?>
					<tr>
						<td><?php echo ++$i; ?></td>
						<td><?php echo $cashcoupan_code; ?></td>
						<td><?php echo $cashcoupan_amount; ?>%</td>
						<td><?php echo ucfirst($userrole); ?></td>
						<td class="action">
							<a href="<?php echo get_the_permalink();?>/?type=editcashcoupan&cashcoupan_id=<?php echo $cashcoupan_id; ?>" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
							<a class="deletecashcoupans del_btn" href="javascript:void(0);" data-cashcoupan_id="<?php echo $cashcoupan_id; ?>" data-ajaxurls="<?php echo $adminurl;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
						</td>
					</tr>
				<?php }
			} 
			else{
				echo '<tr><td colspan="5"><h3><a href="'.get_the_permalink().'?type=cashcoupancode"> No Cash Coupan click here to add</a></h3></t></tr>';
			} ?>
		</table>
	</div>
	<!-- Ending For Show Cash Coupan Data start 27-01-2018 --> 
	
<?php 
} 
if($type=='promotioncode'){
		 $key=$type;
		 $promotion_id =$_GET['promoid'];
		 $label ="Promotion Code";
		 $getdata = $wpdb->get_results("select * from freemonthpromptation where promotion_id = $promotion_id ");
		 foreach ($getdata as $datalists) {
		 	$promotion_id = $datalists->promotion_id;
		 	$promotion_duration = $datalists->promotion_duration;
		 	$promotion_code = $datalists->promotion_code;
		 	$promotion_amount = $datalists->promotion_amount;
		 }
	if(isset($_POST['addpromotions'])){
		print_r($_POST);

		$promotion_duration=trim($_POST['promotion_duration']);
		$promotion_code=trim(strtoupper($_POST['promotion_code']));
		$promotion_amount=trim($_POST['promotion_amount']);
		$update_data = $wpdb->update( 
					'freemonthpromptation', 
					array( 
						'promotion_duration' => $promotion_duration, 
						'promotion_code' => $promotion_code,
						'promotion_amount' => $promotion_amount
					), 
					array( 'promotion_id' => $promotion_id ) 
				);
			$redirects=get_the_permalink()."?type=allpromotions";
			echo "Promotion code updated successfully";
			wp_redirect($redirects);
	}
	else { ?>
		<form action="" class="form-horizontal" method="POST" role="form">
			<h2>Edit Promotion </h2>
			<div class="form-group">
				<label for="firstName" class="col-sm-3 control-label">Promotion Duration:<span class="requiredpart">*</span></label>
				<div class="col-sm-9">
					<input type="text" id="promotion_duration" name="promotion_duration" placeholder="Add Promotion" class="form-control" autofocus="" value="<?php echo $promotion_duration; ?>"  style="text-transform:uppercase"  readonly>
				</div>
			</div>
			<div class="form-group">
				<label for="firstName" class="col-sm-3 control-label"><?php echo $label; ?>:<span class="requiredpart">*</span></label>
				<div class="col-sm-9">
					<input type="text" id="promotion_code" name="promotion_code" placeholder="Add Promotion" class="form-control" autofocus="" value="<?php echo $promotion_code; ?>" maxlength="10"  style="text-transform:uppercase"  required>
				</div>
			</div>
			<div class="form-group">
				<label for="firstName" class="col-sm-3 control-label">Discount Amount :<span class="requiredpart">*</span></label>
				<div class="col-sm-9">
					<input type="text" id="promotion_amount" name="promotion_amount" class="form-control" autofocus="" value="<?php echo $promotion_amount; ?>" maxlength="4"  required >
					<span class="help-block">Promotion Amount, eg.: 20.3, 34,55.12</span>
				</div>
			</div>
			<div class="form-group">
				<div class="col-sm-3 col-sm-offset-3">
					<input type="hidden" name="addpromotionform" id="addpromotionorm" value="addpromotion">
					<input type="hidden" name="promotioncodekey" id="promotioncodekey" value="<?php echo $key;?>">
					<input type="hidden" name="promotionamountkey" id="addpromotionorm" value="<?php echo $value;?>">
					<input type="submit" class="btn btn-primary btn-block" name="addpromotions" value="Update">
				</div>
	    	 </div>
		</form>
	<?php }
}
?>

