<?php

$terms = get_terms( array(
'taxonomy' => 'storagetypecat',
'hide_empty' => false,
) );

?>
<!-- show all storage cate lists starts here -->
<div class="table-responsive">
	<table class="table table-striped table-bordered allstoragecatelists" style="<?php if(!empty($cateid)){ ?> display:none;<?php }?>" >
		<tbody>
			<tr>
				<th>Serial No</th>
				<th>Name</th>
				<th>Description</th>
				<th>Count</th>
				<th class="action">Action</th>
			</tr>
			<?php $i=1;
			foreach($terms as $catename){ 
			$term_id = $catename->term_id;
			$taxonomyname = $catename->taxonomy;
			?>
			<tr>
				<td><?php echo $i;?> </td>
				<td><?php echo $catename->name;?></td>
				<td><?php echo $catename->description; ?></td>
				<td><?php echo $catename->count; ?></td>
				<td class="action">
					<a href="<?php bloginfo('url');?>/admin-dashboard/?type=storagetypecate&cateid=<?php echo $term_id;?>" class="edit_btn"><i class="fa fa-pencil" aria-hidden="true"></i></a>
					<a class="deleteterms del_btn" href="javascript:void(0);" data-catid="<?php echo $term_id;?>" data-name="<?php echo $taxonomyname;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
				</td>
			</tr>

			<?php $i++; } 
			//wp_delete_term( 21, 'storagetypecate' )
			?>

		</tbody>
	</table>
</div>
<!-- show all storage cate lists starts here -->