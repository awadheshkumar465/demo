<?php
if($type=='editstatusreturnschedule'){

global $wpdb; ?>
<h2>Schedule A Return</h2>
<?php

$orderstatusid = $_GET['orderstatusid'];
if($orderstatusid){
	$emailid = $_GET['emailid'];
$getpickupinfo = $wpdb->get_results("SELECT * FROM wp_schedulereturninformation INNER JOIN wp_product_return_lists ON wp_schedulereturninformation.scheduleareturnid = wp_product_return_lists.schedule_return_id INNER JOIN wp_schedule_return_history ON wp_product_return_lists.schedule_return_id = wp_schedule_return_history.schedulereturnid where wp_schedulereturninformation.useremail='$emailid' group by wp_schedulereturninformation.useremail",ARRAY_A); ?>
<!--Showing all Schedule a return Information lists -->
<div class="col-md-12 admin_schedule_return_status">
<?php $ajaxurl = admin_url("admin-ajax.php"); ?>
<input type="hidden" value="<?php echo $ajaxurl; ?>" name="adminurls" class="adminurls">
	<?php 
	if(!empty($getpickupinfo))
	{
	foreach($getpickupinfo as $val){
		//echo "<pre>"; print_r($val); echo "</pre>";
		$oredr_id = $val['order_product_id'];
		$user_email_pickup = $val['useremail'];
		$fulladdress = $val['fulladdress'];	
		$region= $val['region'];
		$distict= $val['distict'];
		$useremail= $val['useremail'];
		$special_instructions= $val['special_instructions'];
		$pickup_of_boxes= $val['pickup_of_boxes'];
		$nooffloors= $val['no_of_floors'];
		$pickupdate= $val['deliverydate'];
		$pickuptime= $val['deliverytime'];
		$pickup_status = $val['delivery_status'];
		if($pickup_status==0){$status = 'Pending';}
		if($pickup_status==1){$status = 'Delivered';}
		$schedule_pickup_orderid = $val['order_id'];
		$regionname = get_term_by('term_id', $region, 'country');
		$region_name = $regionname->name;
		$scheduleareturnid = $val['scheduleareturnid'];
		foreach($regionname as $countrylists){
			echo $countrylists->name;
		}
		$title = $wpdb->get_results("SELECT post_title FROM `wp_posts` where ID=$distict",ARRAY_A);
		$dist_title = $title[0]['post_title'];
		$user = get_user_by( 'email', $user_email_pickup );
		$user_name = $user->first_name . ' ' . $user->last_name;
		$region_dist = $region_name . ' / ' . $dist_title;
		?>
		<div class="col-md-8">
			<ul class="user_purchase">
				<li><label>Name</label>
					<?php echo $user_name; ?>
				</li>
				<li><label>Address</label>
					<?php echo $fulladdress; ?>
				</li>
				<li>
					<label>Regions / District</label>
					<?php echo $region_dist; ?>
				</li>
				<li>
					<label>Stairs (No. Of Floors)</label>
					<?php echo $nooffloors; ?>
				</li>
				<li>
					<label>Schedule Pick Up Date</label>
					<?php echo $pickupdate; ?>
				</li>
				<li>
					<label>Schedule Pick-up Time</label>
					<?php echo $pickuptime; ?>
				</li>
				<li>
					<label>Special Instructions</label>
					<?php echo $special_instructions; ?>
				</li>
				<li>
					<label>Delivery Status</label>
					<?php echo $status; ?>
				</li>
				<li>
					<label>Change Status</label>
					<a class="change_returning_schedule_status" href="javascript:void(0);" data-schedulehistoryid="<?php echo $scheduleareturnid;?>">Change Status</a>
				</li>
			</ul>
		</div>
		<div class="col-md-4">
			<?php 
			$productids = $wpdb->get_results("SELECT * FROM `wp_product_return_lists` where order_product_id = '$oredr_id' group by order_product_id" );
			foreach ($productids as $productid) { ?>
				<div class="userproimage">
				<?php 
					$schedule_return_id = $productid->product_id;
					$imgsrc = get_field('ktstorage_type_image',$schedule_return_id);
				?>
				<img src="<?php echo $imgsrc; ?>"" class="img-responsive">
				</div>
			<?php } ?>
		</div>
		<?php 
	} 
}?>
	</div>
<?php
	
}

}

?>