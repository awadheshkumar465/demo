<div class="col-md-12">
<form method="POST" action="" id="addformsx" enctype="multipart/form-data">
<div class="form-group">
<label for="titles">Storage Title:<span class="requiredpart">*</span></label>
<input type="text" class="addstoragenamepost" name="addstoragenamepost" class="form-control" id="addstoragenamepost" value="" required>
</div>
<div class="form-group">
<label for="contents">Text Editor:</label> 
<?php 
$content = '';
$editor_id = 'kv_frontend_editor_add';
$settings =   array(
'wpautop' => true, // use wpautop?
'media_buttons' => false, // show insert/upload button(s)
'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
'textarea_rows' => get_option('default_post_edit_rows', 10), // rows="..."

//'toolbar1'=> 'bold,italic,underline,bullist,numlist,link,unlink,forecolor,undo,redo',
'tabindex' => '',
'editor_css' => '', //  extra styles for both visual and HTML editors buttons, 
'editor_class' => 'contentbox', // add extra class(es) to the editor textarea
'teeny' => true, // output the minimal editor config used in Press This
'dfw' => false, // replace the default fullscreen with DFW (supported on the front-end in WordPress 3.4)
'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
'quicktags' =>  array( 'buttons' => 'strong,em,del,ul,ol,li,close' ) // load Quicktags, can be used to pass settings directly to Quicktags using an array()
);
echo wp_editor( $content, $editor_id, $settings);
?>
</div>
<div class="form-group">
	<label for="titles">Select Storage Type :<span class="requiredpart">*</span></label>
	<?php wp_dropdown_categories( 'show_option_none=Select Storage Type&tab_index=4&taxonomy=storagetypecat' ); ?>
</div>
<div class="form-group">
	<p class="storagetypes_settings">Storage Type Setting:</p>
	<div class="storeplansadd">
		<label for="titles">Store Plan :<span class="requiredpart">*</span></label>
		<input type="text" class="storeplan"  name="addstoreplan" class="form-control" id="storeplan" value="" required>
	</div>

	<div class="storeplansadd">
		<label for="titles">Storage Type Price (3-5 months) :<span class="requiredpart">*</span></label>
		<input type="text" class="ktstorage_type_price" name="addktstorage_type_price" class="form-control" id="ktstorage_type_price" value="" required>
	</div>

	<div class="storeplansadd">
		<label for="titles">Storage Type Price Six (6-11 Months) :<span class="requiredpart">*</span></label>
		<input type="text" name="addstorage_type_price_six" class="form-control" id="storage_type_price_six" value="" required>
	</div>

	<div class="storeplansadd">
		<label for="titles">Storage Type Price Twelve (12+ Months) :<span class="requiredpart">*</span></label>
		<input type="text" name="addstorage_type_price_twelve" class="form-control" id="storage_type_price_twelve" value="" required>
	</div>

	<div class="storeplansadd">
		<label for="titles">Storage Type Image :<span class="requiredpart">*</span></label>
		<input type="file" name="addktstorage_type_image" class="form-control" id="addktstorage_type_image" required>
		<?php //wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
	</div>

	<div class="storeplansadd">
		<label for="titles">Storage Type Max Weight :<span class="requiredpart">*</span></label>

		<input type="text" name="addktstorage_type_max_weight" class="form-control" id="addktstorage_type_max_weight" value="" required>
	</div>

</div>
<input type="hidden" class="hidden_addpostids" name="post_ids" value="1" />
<?php wp_nonce_field( 'post_nonce', 'add_post_nonce_field' ); ?>

<input type="submit" class="btn btn-default addstoragesubmit" value="Submit">
</form>
</div>
<?php
if(isset($_POST['add_post_nonce_field'])){ 



$title= $_POST['addstoragenamepost'];
$description= $_POST['kv_frontend_editor_add'];
$storeplan= $_POST['addstoreplan'];
$ktstorage_type_price= $_POST['addktstorage_type_price'];
$storage_type_price_six= $_POST['addstorage_type_price_six'];
$storage_type_price_twelve= $_POST['addstorage_type_price_twelve'];
$category=trim($_POST['cat']); 
$storage_max_weight=$_POST['addktstorage_type_max_weight'];

$post = array(
'post_title'	=> $title,
'post_content'	=> $description,
'post_category'	=> $category,  // Usable for custom taxonomies too
'post_status'	=> 'publish',			// Choose: publish, preview, future, etc.
'post_type'	=> 'storagetype',
'taxonomy'	=> 'storagetypecat'
);
//print_r($post);
$termsname = get_term_by('id', $category, 'storagetypecat' );
$categogy_slug = $termsname->slug;

$postids= wp_insert_post($post);
$aterm = wp_set_object_terms( $postids, $categogy_slug, 'storagetypecat' );
update_field('field_59c232fdfa9a0',$storeplan,$postids);
update_field('field_59ad1692bb534',$ktstorage_type_price,$postids);
update_field('field_59bf4796b33f2',$storage_type_price_six,$postids);
update_field('field_59bf47b8b33f3',$storage_type_price_twelve,$postids);
update_field('field_59b8f551bc76a',$storage_max_weight,$postids);

if ($_FILES) {
require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/media.php' );
foreach ($_FILES as $file => $array) { print_r($array); 
if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK) {
return "upload error : " . $_FILES[$file]['error'];
}
echo $attach_id = media_handle_upload( $file, $new_post );
} 
if ($attach_id > 0){
//and if you want to set that image as Post  then use:
//update_post_meta($new_post,'_thumbnail_id',$attach_id);
update_field('field_59ad496aab96e',$attach_id,$postids);
}  
}

if(!empty($attach_id)){
wp_redirect(get_the_permalink()."admin-dashboard/?type=showall");
exit();

}
?>

<?php
}
 ?>