<?php 
if($type=='showallprolists'){
	global $wpdb;
	$html='';
	if(isset($_GET['return_product_id']))
	{
		//print_r($_GET);
		$return_product_id = trim($_GET['return_product_id']);
		
		$order_product_id = trim($_GET['order_product_id']);
		
		$tablename = trim($_GET['tablename']);
		if($tablename=='wp_product_return_lists'){
		
		$get_info = $wpdb->get_results("select * from $tablename where return_product_id=$return_product_id AND order_product_id=$order_product_id",ARRAY_A);
		if(!empty($get_info))
		{
			foreach($get_info as $getscheduleinfo)
			{
				$html='<tr>';
				//echo "<pre>"; print_r($getscheduleinfo); echo "</pre>";
				
				$order_id = $getscheduleinfo['order_id'];
				
				$schedule_return_id = $getscheduleinfo['schedule_return_id'];
				
				$product_name = $getscheduleinfo['product_name'];
				
				$ordernumber = "D".date("y")."000".$order_id;
				
				$getdatetimesch = $wpdb->get_results("select * from wp_schedulereturninformation where scheduleareturnid=$schedule_return_id",ARRAY_A);
				
				//echo "<pre>"; print_r($getdatetimesch); echo "</pre>";
				
				$businessday = $getdatetimesch[0]['businessday'];
				if(!empty($getdatetimesch[0]['businessday'])){
					$businessday = $getdatetimesch[0]['businessday'];
					$deliverydate = $getdatetimesch[0]['deliverydate'];
					$deliverytime = $getdatetimesch[0]['deliverytime'];
					$html.='
					<td>'.$deliverydate.'</td>
					<td>'.$businessday.'</td>
					<td>'.$deliverytime.'</td>
					<td>'.$ordernumber.'</td>
					<td>'.$product_name.'</td>';
				}
				
				$html.='</tr>';
			}
			
			
		}
		}
		
		if($tablename=='wp_schedule_pickup_products')
		{
			
			$getpickup_info = $wpdb->get_results("select * from $tablename where schedule_pickup_product_id=$return_product_id AND order_product_id=$order_product_id",ARRAY_A);
			
			if(!empty($getpickup_info)){
				
				foreach($getpickup_info as $pickuppro){
					$html.='<tr>';
					//echo "<pre>"; print_r($pickuppro); echo "</pre>";
					
					$schedule_a_pickup_id = $pickuppro['schedule_a_pickup_id'];
					
					$order_product_id = $pickuppro['order_product_id'];
					
					$product_name = $pickuppro['product_name'];
					
					$getpickupdate = $wpdb->get_results("select * from wp_schedule_pickup where schedule_pickup_id=$schedule_a_pickup_id",ARRAY_A);
					if(!empty($getpickupdate)){
						foreach($getpickupdate as $pickupvalsdates)
						{
							//echo "<pre>"; print_r($pickupvalsdates); echo "</pre>";
							$full_address = $pickupvalsdates['full_address'];
							
							$schedule_pickup_date = $pickupvalsdates['schedule_pickup_date'];
							
							$schedule_pickup_time = $pickupvalsdates['schedule_pickup_time'];
							
							$ordernumber = "P".date("y")."000".$order_product_id;
							$html.='
							<td>'.$schedule_pickup_date.'</td>
							<td>NA</td>
							<td>'.$schedule_pickup_time.'</td>
							<td>'.$ordernumber.'</td>
							<td>'.$product_name.'</td>';
						}
					}
					$html.='</tr>';
				}
				
			}
			
		}
		
		?>
	<div class="table-responsive">
		<table class="table table-striped table-bordered display" cellspacing="0">
			<thead>
				<tr>
					<th>Delivery Date</th>
					<th>Delivery Service</th>
					<th>Scheduled Time</th>
					<th>Order Number</th>
					<th>Product Name</th>
				</tr>
				
			
			</thead>
			<tbody>
			<?php echo $html; ?>
			</tbody>
		</table>
	
	</div>
	<?php 
	}

}

?>