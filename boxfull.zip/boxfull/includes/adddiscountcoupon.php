<?php
if($type=='adddiscountcoupon'){ 
	if(isset($_POST['addcoupans'])){
		$discount_coupan_duration = trim($_POST['discount_coupan_duration']);
		$discount_coupan_code=trim(strtoupper($_POST['discount_coupan_code']));
		$discount_coupan_amount=trim($_POST['discount_coupan_amount']);
		$alldata = $wpdb->get_results("select * from wp_discountcoupans where discount_coupan_duration = '$discount_coupan_duration' ");

		echo $discount_id = $alldata[0]->discount_id;
		if(empty($alldata)){
			$insert_data = $wpdb->insert( 
					'wp_discountcoupans', 
					array( 
						'discount_coupan_duration' => $discount_coupan_duration, 
						'discount_coupan_code' => $discount_coupan_code,
						'discount_coupan_amount' => $discount_coupan_amount
					), 
					array( 
						'%s', 
						'%s',
						'%d' 
					) 
				); 
			$redirects=get_the_permalink()."?type=allpromotions";
			echo "Coupan code Created successfully";
			wp_redirect($redirects);
		}
		else{
			echo $update_data = $wpdb->update( 
					'wp_discountcoupans', 
					array( 
						'discount_coupan_duration' => $discount_coupan_duration, 
						'discount_coupan_code' => $discount_coupan_code,
						'discount_coupan_amount' => $discount_coupan_amount
					), 
					array( 'discount_id' => $discount_id ) 
				);
			echo '<pre>';
			print_r($update_data);
			echo '</pre>';
			$redirects=get_the_permalink()."?type=allpromotions";
			echo "Coupan code updated successfully";
			wp_redirect($redirects);
		}
	}
	else{
	?>
	<form action="" class="form-horizontal" method="POST" role="form">
		<h2>Add New Discount Coupan</h2>
		<div class="form-group">
				<label for="discount_coupan_duration" class="col-sm-3 control-label">Discount Coupan Duration :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<select name="discount_coupan_duration">
				  <option value="First Month">First Month</option>
				  <option value="Second Month">Second Month</option>
				  <option value="Third Month">Third Month</option>
				  <option value="Fourth Month">Fourth Month</option>
				  <option value="Fifth Month">Fifth Month</option>
				  <option value="Sixth Month">Sixth Month</option>
				  <option value="Seventh Month">Seventh Month</option>
				  <option value="Eighth Month">Eighth Month</option>
				  <option value="Ninth Month">Ninth Month</option>
				  <option value="Tenth Month">Tenth Month</option>
				  <option value="Eleventh Month">Eleventh Month</option>
				  <option value="Twelveth Month">Twelveth Month</option>
				</select>
			</div>
			</div>
		<div class="form-group">
			<label for="coupancode" class="col-sm-3 control-label">Discount Coupan Code :<span class="requiredpart">*</span>
			</label>
			<div class="col-sm-9">
				<input type="text" id="discount_coupan_code" name="discount_coupan_code" placeholder="Add Coupan Code" class="form-control" autofocus="" value="" maxlength="10" required>
			</div>
		</div>
		<div class="form-group">
			<label for="coupanamount" class="col-sm-3 control-label">Discount Coupan Amount :<span class="requiredpart">*</span></label>
			<div class="col-sm-9">
				<input type="text" id="discount_coupan_amount" name="discount_coupan_amount" placeholder="Add Coupan Discount" class="form-control" autofocus="" value="" maxlength="4" required >
				<span class="help-block">Coupan Discount, eg.: 2%, 5%, 10%</span>
			</div>
		</div>
	<div class="form-group">
	<div class="col-sm-3 col-sm-offset-3">
	<input type="submit" name="addcoupans" value="Submit">
	</div>
    </div>
</form>
<?php 
}


}