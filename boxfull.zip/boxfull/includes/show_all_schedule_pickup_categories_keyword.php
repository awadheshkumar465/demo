<?php
if($type=='show_schedule_category_keyword_lists'){
	global $wpdb;
	$ajaxurl = admin_url('admin-ajax.php');
	$html='';
	
	$query             = "SELECT * FROM wp_schedule_category_keyword";
	$total_query     = "SELECT COUNT(1) FROM (${query}) AS wp_schedule_category_keyword";
	$total             = $wpdb->get_var( $total_query );
	$items_per_page = 10;
	$page             = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
	$offset         = ( $page * $items_per_page ) - $items_per_page;
	$result         = $wpdb->get_results( $query . " ORDER BY schedule_category ASC LIMIT ${offset}, ${items_per_page}",ARRAY_A );
	$totalPage         = ceil($total / $items_per_page);
	
	$html.='<h2>Show All Category / Keyword </h2>
	<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<tbody>
				<tr>
					<th>Category Name</th>
					<th>Keyword Name</th>
					<th class="action">Action</th>
				</tr>';
				foreach($result as $wpschedulecategorydetails){
					$schedule_category_keyword_id = $wpschedulecategorydetails['schedule_category_keyword_id'];
					$html.='
					<tr>
						<td>'.$wpschedulecategorydetails['schedule_category'].' </td>
						<td>'.$wpschedulecategorydetails['schedule_keyword'].' </td>
						<td class="action"><a href="javascript:void(0);" class="btn btn-default deletecategory_keywords del_btn" data-catkeyid="'.$schedule_category_keyword_id.'" data-ajaxurl="'.$ajaxurl.'"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
					</tr>';
				}
					$html.='
			</tbody>
		</table>
</div>';






if($totalPage > 1){
	
$html.=  '<nav class="custom-pagination"><span class="page-numbers page-num">Page '.$page.' of '.$totalPage.'</span>'.paginate_links( array(
'base' => add_query_arg( 'cpage', '%#%' ),
'format' => '',
'prev_text' => __('&laquo;'),
'next_text' => __('&raquo;'),
'total' => $totalPage,
'current' => $page
)).'</nav>';
}



echo $html;

}