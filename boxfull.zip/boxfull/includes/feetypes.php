<?php
if($type=='feetypes'){
global $wpdb;
$currency_set = get_option('currency_set',true);
$html='';
$currency_set = get_option('currency_set',true);
 $results = getFeeByBox('handlingfeebybox');
$byitem = getFeeByItem('handlingfeebyitem');
$deliveryfee = getFeeByDelivery('deliveryfee');
$additionalee = getAdditonalFee();

$html.='
<h2 class="handlingfeedetails">Handling Fee</h2>';
if($results){
$html.='<h3 class="handlingfeebybox">By-Box</h3>
<a class="editbyboxhandlingfee edit_btn" href="'.get_the_permalink().'?type=editbyboxhandlingfee"><i class="fa fa-pencil" aria-hidden="true"></i></a>
<div class="table-responsive">
<table class="table table-striped">
	<tbody>';
	foreach ($results as $handlingfeebybox){ 
	$payasyourstore = $handlingfeebybox['payasyourstore'];
	$threefivemonths = $handlingfeebybox['threefivemonths'];
	$sixelevenmonths = $handlingfeebybox['sixelevenmonths'];
	$twelvemonthsplus = $handlingfeebybox['twelvemonthsplus'];
	$finalcheckouthandlingfee = $handlingfeebybox['finalcheckouthandlingfee'];
	$twentyminutes = $handlingfeebybox['twentyminutes'];
		$html.='
		<tr>
			<td><strong>By box Check Out & Re-Check-in (Handling Fee) </strong></td>
			<td><strong>Pay as you Store: '.$currency_set.'$</strong>'.$payasyourstore.' Per Box (Min $100)<br><br>
			<strong>3-5 Months:  '.$currency_set.'$</strong>'.$threefivemonths.' Per Box (Min $100)<br><br>
			<strong>6-11 Months: </strong>1 Free, Additional '.$currency_set.'$'.$sixelevenmonths.' Per Box (Min $100)<br><br>
			<strong>12 Months+: </strong>2 Free, Additional  '.$currency_set.'$'.$twelvemonthsplus.' Per Box (Min $100 )<br>
			</td>			
		</tr>
		
		<tr>
			<td><strong>By Box Final Check Out (Handling Fee) </strong></td>
			
			<td><strong>Handling Fee: '.$currency_set.'$</strong>'.$finalcheckouthandlingfee.' Per Box (Min $100)<br></td>			
		</tr>
		
		<tr>
			<td><strong>Empty Box Collect - Final Check Out (Handling Fee) </strong></td>
			
			<td><strong>20 Mins: '.$twentyminutes.'<br></td>			
		</tr>';
		
	}
}
else{
	$html.='<center><h3 class="handlingfeebybox">By-Box</h3></center>
	<div class="table-responsive">
		<table class="table table-striped">
			<tbody>
				<tr>
					<td colspan="2"><center>No Handling Fee By Box Available. <a class="addboxhandlingfee" href="'.get_the_permalink().'?type=addbyboxhandlingfee">Click Here To Add</a></center></td>
				</tr>
			</tbody>
		</table>
	</div>';
}
	$html.='</tbody>
</table>
</div>
';
if($byitem){
$html.='
<h3 class="handlingfeebyitem edit_btn">By Item</h3>
<a class="editbyboxhandlingfee" href="'.get_the_permalink().'?type=editbyitemhandlingfee"><i class="fa fa-pencil" aria-hidden="true"></i></a>
<div class="table-responsive">
<table class="table table-striped">';
$html.='
	<tbody>';
	foreach ($byitem as $handlingfeebybox){ 
	$payasyourstore = $handlingfeebybox['payasyourstore'];
	$threefivemonths = $handlingfeebybox['threefivemonths'];
	$sixelevenmonths = $handlingfeebybox['sixelevenmonths'];
	$twelvemonthsplus = $handlingfeebybox['twelvemonthsplus'];
	$finalcheckouthandlingfee = $handlingfeebybox['finalcheckouthandlingfee'];
	$twentyminutes = $handlingfeebybox['twentyminutes'];
		$html.='
		<tr>
			<td><strong>Check Out & Re-Check-In  </strong></td>
			<td><strong>Pay as you Store: '.$currency_set.'$</strong>'.$payasyourstore.' Per Item (Min $80)<br><br>
			<strong>3-5 Months:  '.$currency_set.'$</strong>'.$threefivemonths.' Per Item (Min $80)<br><br>
			<strong>6-11 Months: </strong>1 Free, Additional '.$currency_set.'$'.$sixelevenmonths.' Per Item (Min $80)<br><br>
			<strong>12mths+: </strong>2 Free, Additional  '.$currency_set.'$'.$twelvemonthsplus.' Per Item (Min $80 )<br>
			</td>			
		</tr>
		
		<tr>
			<td><strong>By Item Final Check Out (Handling Fee)</strong></td>
			
			<td><strong>Handling Fee: '.$currency_set.'$</strong>'.$finalcheckouthandlingfee.' Per Box (Min $80)<br></td>			
		</tr>';	
	}
}
	else{
	$html.='<center><h3 class="handlingfeebybox">By-Box</h3></center>
	<div class="table-responsive">
		<table class="table table-striped">
			<tbody>
				<tr>
					<td colspan="2">
						<center>No Handling Fee By Item Available. <a class="addboxhandlingfee" href="'.get_the_permalink().'?type=addbyitemhandlingfee">Click Here To Add</a></center>
					</td>
				</tr>
			</tbody>
		</table>
	</div>';
}

	$html.='</tbody>
</table>
</div>
';

if($deliveryfee){
$html.='
<h3 class="handlingfeebyitem edit_btn">Delivery Fee</h3>
<a class="editbyboxhandlingfee" href="'.get_the_permalink().'?type=editdeliveryfee"><i class="fa fa-pencil" aria-hidden="true"></i></a>
<div class="table-responsive">
<table class="table table-striped">';
$html.='
	<tbody>';
	foreach ($deliveryfee as $deliveryfeebyboth){ 
	$samebusinessday = $deliveryfeebyboth['samebusinessday'];
	$nextbusinessday = $deliveryfeebyboth['nextbusinessday'];
	$inormorethantwobusinessday = $deliveryfeebyboth['inormorethantwobusinessday'];
	$afterhoursdelivery = $deliveryfeebyboth['afterhoursdelivery'];
		$html.='
		<tr>
			<td><strong>Same Business Day: </strong></td>
			<td><strong>'.$currency_set.'$</strong>'.$samebusinessday.' Per Box<br></td>			
		</tr>
		
		<tr>
			<td><strong>Next Business Day</strong></td>
			
			<td><strong>'.$currency_set.'$</strong>'.$nextbusinessday.' Per Box</td>			
		</tr>
		<tr>
			<td><strong>In Or More Than 2 Business Days</strong></td>
			
			<td><strong>'.$currency_set.'$</strong>'.$inormorethantwobusinessday.'</td>			
		</tr>
		
		<tr>
			<td><strong>After Hours Delivery</strong></td>
			
			<td><strong>'.$currency_set.'$</strong>'.$afterhoursdelivery.'</td>			
		</tr>';
			
	}
}
else{
	$html.='<center><h3 class="handlingfeebybox">By-Box</h3></center>
	<div class="table-responsive">
		<table class="table table-striped">
			<tbody>
				<tr>
					<td colspan="2">
						<center>No Delivery Fee Available. <a class="addboxhandlingfee" href="'.get_the_permalink().'?type=adddeliveryfee">Click Here To Add</a></center>
					</td>
				</tr>
			</tbody>
		</table>
	</div>';
}
	$html.='</tbody>
</table>
</div>
';
if($additionalee){
	$additional_fee_id = $additionalee[0]['additional_fee_id'];
$html.='
<h3 class="handlingfeebyitem edit_btn">Additional Fee</h3>
<a class="editbyboxhandlingfee" href="'.get_the_permalink().'?type=editadditionalfee&feeid='.$additional_fee_id.'"><i class="fa fa-pencil" aria-hidden="true"></i></a>
<div class="table-responsive">
<table class="table table-striped">';
$html.='
	<tbody>';
	$html.='</tbody>';
		foreach($additionalee as $finval){ 
		//print_r($finval);
		$late_cancellation = $finval['late_cancellation'];
		$no_show = $finval['no_show'];
		$outside_service_area_delivery = $finval['outside_service_area_delivery'];
		$late_payment = $finval['late_payment'];
		$stairs = $finval['stairs'];
		$empty_box_pick_up_non_storage = $finval['empty_box_pick_up_non_storage'];
		$remote_location_delivery = $finval['remote_location_delivery'];
		$packing_fee = $finval['packing_fee'];
		$parking = $finval['parking'];
		$moving_penalty = $finval['moving_penalty'];
		$over_weight_limit = $finval['over_weight_limit'];
		$box_damage_fee = $finval['box_damage_fee'];
	
			$html.='
			<tr>
				<td><strong>Late Cancellation (Less Than 24 hrs Notice): </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$late_cancellation.' Flat Fee</td>			
			</tr>
			<tr>
				<td><strong>No Show: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$no_show.' Flat Fee</td>			
			</tr>
			<tr>
				<td><strong>Outside Service Area Delivery: </strong></td>
				<td><strong></strong>'.$outside_service_area_delivery.' </td>			
			</tr>
			<tr>
				<td><strong>Late Payment: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$late_payment.' Flat Fee</td>			
			</tr>
			<tr>
				<td><strong>Stairs: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$stairs.' /Box Or Item/Level</td>			
			</tr>
			<tr>
				<td><strong>Empty Box Pick-Up Non-Storage : </strong></td>
				<td>'.$empty_box_pick_up_non_storage.' </td>			
			</tr>
			<tr>
				<td><strong>Remote Location Delivery : </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$remote_location_delivery.' Flat Fee</td>			
			</tr>
			<tr>
				<td><strong>Packing Fee: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$packing_fee.' Mins/Box</td>			
			</tr>
			<tr>
				<td><strong>Parking: </strong></td>
				<td><strong></strong>'.$parking.' </td>			
			</tr>
			<tr>
				<td><strong>Moving Penalty: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$moving_penalty.' Mins/Box</td>			
			</tr>
			<tr>
				<td><strong>Over weight limit: </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$over_weight_limit.' Flat Fee</td>			
			</tr>
			<tr>
				<td><strong>Box Damage Fee : </strong></td>
				<td><strong>'.$currency_set.'$</strong>'.$box_damage_fee.' Per Box</td>			
			</tr>
			';
		}
			$html.='
</tbody>
</table>
</div>
';
	
}
else{
	$html.='<center><h3 class="handlingfeebybox">Additonal Fee</h3></center>
	<div class="table-responsive">
		<table class="table table-striped">
			<tbody>
				<tr>
					<td colspan="2">
						<center>No Additional Fee Available. <a class="addboxhandlingfee" href="'.get_the_permalink().'?type=addadditonalfee">Click Here To Add</a></center>
					</td>
				</tr>
			</tbody>
		</table>
	</div>';
}

echo $html;

}

?>