<?php
	if($type =='addnewdistrict'){ 
	$terms = get_terms([
	'taxonomy' => 'country',
	'hide_empty' => false,
	]);
	?>
	<div class="col-md-12">
	<form method="POST" action="" id="adddistrict" enctype="multipart/form-data">
	<div class="form-group">
	<label for="titles">District Name :<span class="requiredpart">*</span></label>
	<input type="text" class="newdistrictpost" name="newdistrictpost" class="form-control" id="newdistrictpost" value="<?php echo ucfirst($title);?>" required>
	</div>

	<div class="form-group">
	<label for="titles">Select Regions:</label>

	<?php 
	echo '<select name="cat" id="cat" class="postform" tabindex="4">';
	echo '<option class="level-0" value="">Select Regions</option>';
	foreach($terms as $regionterms){ 
	echo '<option class="level-0" value="'.$regionterms->term_id.' ">'.$regionterms->name.'</option>'; 
	}
	echo '</select>';
	?>

	<?php //wp_dropdown_categories( 'show_option_none=Category&tab_index=4&taxonomy=country&selected=$districtid,' ); ?>
	</div>

	<input type="hidden" class="hidden_newdistrict" name="district_newids" value="" />

	<?php wp_nonce_field( 'post_nonce', 'post_nonce_field_newdistrict' ); ?>

	<input type="hidden" name="add_district" id="add_district" value="true" />
	<input type="submit" class="btn btn-default adddistrict" value="Submit">
	</form>
	</div>	
	<?php
	}
	if(isset($_POST['post_nonce_field_newdistrict'])){
	//print_r($_POST);
	$newdistricttitle = $_POST['newdistrictpost'];
	$newdistrictcat = $_POST['cat'];

	$my_district = array(
	'post_title'    => wp_strip_all_tags($_POST['newdistrictpost']),
	'post_type' => 'region',
	'post_status'   => 'publish'
	);

	// Insert the post into the database
	$new_districtId = wp_insert_post( $my_district );
	if(!empty($new_districtId)){
	//$newterms = wp_get_post_terms( $new_districtId, 'country');
	//print_r();
	$termupdates = wp_set_post_terms( $new_districtId, $newdistrictcat, 'country');
	wp_redirect(get_the_permalink()."/?type=alldistricts");
	exit();
	}

	}
?>