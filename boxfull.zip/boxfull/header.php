<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
	<!--<link rel="shortcut icon" type="image/png" href="<?php //echo get_stylesheet_directory_uri(); ?>/favicon.ico"/>  -->
</head>

<body <?php body_class(); ?>>
<?php 

if(is_user_logged_in()){

}
else{
 
unset($_SESSION['signup_user']);
unset($_SESSION['product_id']);
unset($_SESSION['product_qty']);
unset($_SESSION['pricestorage_duration']);
unset($_SESSION['categories_id']);
}


?>
<!-- 		<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentysixteen' ); ?></a> -->
<?php 
//custom fields
$head_contact_number=get_option('head_contact_number');
$head_contact_number_link=get_option('head_contact_number_link');

if(is_user_logged_in())
{

	?>
	<style>
	.login_sec
	{
		display: none !important;
	}

	</style>

	<?php
}

?>
		<header class="main-header">
		
		<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="httop-sub">
						<ul class="main-httop">
						<?php 
							if($head_contact_number) { ?>		
						<li>
							<a href="tel:<?php echo $head_contact_number_link;?>">
							<i class="fa fa-phone" aria-hidden="true"></i>
							<?php echo $head_contact_number; ?>
							</a>
						</li>
					<?php 	} ?>
					<?php if(ICL_LANGUAGE_CODE=='en'){ ?>
						<li class="login_sec">
							<a href="<?php echo site_url('login'); ?>">
							<i class="fa fa-user" aria-hidden="true"></i>
							Login
							</a>
						</li>
						<li class="login_sec"><a href="<?php echo site_url('sign-up');?>">
							<i class="fa fa-lock" aria-hidden="true"></i>
							Sign up
							</a>
						</li>
						<?php 
						$current_user = wp_get_current_user();
						$user_id = $current_user->ID;
						$user = new WP_User( $user_id );
						if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
							foreach ( $user->roles as $role ){
								
								if($role=='administrator'){
									?>
									<li><a href="<?php echo get_bloginfo('url');?>/admin-dashboard/?type=showall"><i class="fa fa-user-o" aria-hidden="true"></i> Admin </a></li>
									
								<?php 
								}
								if($role=='customer'){ ?>
									
									<li><a href="<?php echo get_bloginfo('url');?>/user-dashboard/?type=mystuff"><i class="fa fa-user-o" aria-hidden="true"></i> My Stuff </a></li>
									
								<?php 
								}
							}
						}
					}
					if(ICL_LANGUAGE_CODE=='zh-hant'){ ?>
						<li class="login_sec">
							<a href="<?php echo site_url('login').'/?lang=zh-hant'; ?>">
							<i class="fa fa-user" aria-hidden="true"></i>
							登入
							</a>
						</li>
						<li class="login_sec"><a href="<?php echo site_url('sign-up').'/?lang=zh-hant';?>">
							<i class="fa fa-lock" aria-hidden="true"></i>
							註冊
							</a>
						</li>
						<?php 
						$current_user = wp_get_current_user();
						$user_id = $current_user->ID;
						$user = new WP_User( $user_id );
						if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
							foreach ( $user->roles as $role ){
								
								if($role=='administrator'){
									?>
									<li><a href="<?php echo get_bloginfo('url');?>/admin-dashboard/?type=showall"><i class="fa fa-user-o" aria-hidden="true"></i> Admin </a></li>
									
								<?php 
								}
								if($role=='customer'){ ?>
									
									<li><a href="<?php echo get_bloginfo('url');?>/user-dashboard/?type=mystuff"><i class="fa fa-user-o" aria-hidden="true"></i> My Stuff </a></li>
									
								<?php 
								}
							}
						} 
					} ?>
							
				<li class="dropdown cstm_lang">
					<i class="fa fa-globe" aria-hidden="true"></i>
					<?php dynamic_sidebar('sidebar-8' ); ?>
			    </li>
				</ul></div>
				</div>
			</div>
		</div>
	</div>
	<div class="header-middle">
		<nav class="navbar navbar-default">
		  <div class="container ">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      <?php twentysixteen_the_custom_logo(); ?>
		    </div>

		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      
		  
			  <?php if ( has_nav_menu( 'primary' ) ) : 
						wp_nav_menu( array(
							'theme_location' => 'primary',
							'menu_class'     => 'primary-menu nav navbar-nav navbar-right',
						 ) );
					 endif; ?>
		    </div><!-- /.navbar-collapse -->
		  </div><!-- /.container-fluid -->
		</nav>
	</div>
</header>

<?php
$home_slider='';
if(is_front_page())
{
	
	// check if the repeater field has rows of data
	
if( have_rows('kt_header_slider_settings') ):
$home_slider .='<section class="top-slider">
		<div id="owl-demo" class="owl-demo owl-carousel owl-theme">';
 	// loop through the rows of data
    while ( have_rows('kt_header_slider_settings') ) : the_row();

        // display a sub field value
        $kt_home_slide_image=get_sub_field('kt_home_slide_image');
		$kt_home_slide_heading=get_sub_field('kt_home_slide_heading');
		$kt_home_slide_subheading=get_sub_field('kt_home_slide_subheading');
		$home_slider .='<div class="item">
                <div class="st-div">
                    <div class="slidetop-img">
                        <img src="'.$kt_home_slide_image.'">
                    </div>
                    <div class="st-txt">
                    	<h3>'.$kt_home_slide_heading.'</h3>
                    	<p>'.$kt_home_slide_subheading.'</p>
                    </div>
                    <span class="slide-top-link">';
                    if(ICL_LANGUAGE_CODE=='en'){
                    $home_slider .='<a href="'.get_bloginfo("url").'/sign-up">Get Started</a>';
               		}
               		if(ICL_LANGUAGE_CODE=='zh-hant'){
                    $home_slider .='<a href="'.site_url().'/sign-up/?lang=zh-hant">開始使用</a>';
               		}
                    $home_slider .='</span>
                </div>
            </div>';

    endwhile;
$home_slider .=' </div>
	</section>';

endif;

}
echo $home_slider;	


?>

