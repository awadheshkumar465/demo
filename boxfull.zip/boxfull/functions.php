<?php
add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );
function enqueue_parent_styles() {
wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );


wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri().'/css/bootstrap.min.css' );
wp_enqueue_style( 'master-style', get_stylesheet_directory_uri().'/css/master.css' );
wp_enqueue_style( 'jqueryalerts-style', get_stylesheet_directory_uri().'/css/jquery.alerts.css' );

wp_enqueue_style( 'fontawesome-style', get_stylesheet_directory_uri().'/css/font-awesome.css' );
wp_enqueue_style( 'owlcarousel-style', get_stylesheet_directory_uri().'/css/owl.carousel.css' );
wp_enqueue_style( 'owltheme-style', get_stylesheet_directory_uri().'/css/owl.theme.css' );
wp_enqueue_style( 'slick-style', get_stylesheet_directory_uri().'/css/slick.css' );
wp_enqueue_style( 'slicktheme-style', get_stylesheet_directory_uri().'/css/slick-theme.css' );
wp_enqueue_style( 'jqueryui-style', get_stylesheet_directory_uri().'/css/jquery-ui.min.css' );
wp_enqueue_style( 'popupwindow-style', get_stylesheet_directory_uri().'/css/popupwindow.css' );
wp_enqueue_style( 'admindash-style', get_stylesheet_directory_uri().'/css/admin-dash.css' );
wp_enqueue_style( 'easyresponsivetabs-style', get_stylesheet_directory_uri().'/css/easy-responsive-tabs.css' );
wp_enqueue_style( 'jquerytimepicker-style', get_stylesheet_directory_uri().'/css/jquery.timepicker.css' );
//Include Fonts

wp_enqueue_style( 'font-style1', 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700' );


//JS
//wp_enqueue_script( 'stripejs', 'https://js.stripe.com/v2/','','',true );
wp_enqueue_script( 'jqueryprintareajs', get_stylesheet_directory_uri().'/js/jquery.PrintArea.js','','',true );
wp_enqueue_script( 'bootstrap-script', get_stylesheet_directory_uri().'/js/bootstrap.min.js','','',true );
wp_enqueue_script( 'jqueryalerts-script', get_stylesheet_directory_uri().'/js/jquery.alerts.js','','',false );
wp_enqueue_script( 'theme-custom-script', get_stylesheet_directory_uri().'/js/custom.js','','',false );

wp_enqueue_script( 'owl-carousel-script', get_stylesheet_directory_uri().'/js/owl.carousel.min.js','','',false );
wp_enqueue_script( 'jquery-ui-min-script', get_stylesheet_directory_uri().'/js/jquery-ui.min.js','','',false );
wp_enqueue_script( 'popupwindow-script', get_stylesheet_directory_uri().'/js/popupwindow.js','','',false );
wp_enqueue_script( 'jquerytimepicker-script', get_stylesheet_directory_uri().'/js/jquery.timepicker.js','','',false );

}
add_action('wp_head', 'cvf_ps_enqueue_datepicker');
function cvf_ps_enqueue_datepicker() {
    wp_enqueue_script('jquery-ui-datepicker');
    wp_enqueue_style('jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');
    
}
function wedding_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Footer 1', 'twentysixteen' ),
		'id'            => 'footer-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<div class="col-md-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="f_heading"><h3>',
		'after_title'   => '</h3></div>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer 2', 'twentysixteen' ),
		'id'            => 'footer-2',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<div class="col-md-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="f_heading"><h3>',
		'after_title'   => '</h3></div>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer 3', 'twentysixteen' ),
		'id'            => 'footer-3',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<div class="col-md-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="f_heading"><h3>',
		'after_title'   => '</h3></div>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer 4', 'twentysixteen' ),
		'id'            => 'footer-4',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<div class="col-md-6">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="f_heading"><h3>',
		'after_title'   => '</h3></div>',
	) );
	
	

	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'twentysixteen' ),
		'id'            => 'blog-sidebar',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="">',
		'after_widget'  => '</section>',
		'before_title'  => '<div class="f_heading"><h3>',
		'after_title'   => '</h3></div>',
	) );

}
add_action( 'widgets_init', 'wedding_widgets_init' );
function get_excerpt($limit, $source = null){

    if($source == "content" ? ($excerpt = get_the_content()) : ($excerpt = get_the_excerpt()));
    $excerpt = preg_replace(" (\[.*?\])",'',$excerpt);
    $excerpt = strip_shortcodes($excerpt);
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, $limit);
    $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt = trim(preg_replace( '/\s+/', ' ', $excerpt));
    $excerpt = $excerpt.'... <a href="'.get_permalink($post->ID).'">more</a>';
    return $excerpt;
}
/**
 * Register a custom menu page.
 */
function theme_settings_menu_cb() {
    add_menu_page(
        __( 'Theme Settings', 'textdomain' ),
        'Theme Settings',
        'manage_options',
        'theme_settings',
        'theme_settings_cb',
        '',
      9
    );
	  add_menu_page("Currency Settings", "Currency Settings", "manage_options", "currence-settings", "currency_settings_page", null, 99);

}
function currency_settings_page()
{
	if(isset($_POST['currency_save']))
	{
		update_option('currency_set',$_POST['currency_set']);
		
	}
	
	$currency_set=get_option('currency_set');
	
	
	
	$curr_array=array('AUD' => 'Australian Dollar',
'BRL' => 'Brazilian Real',
'BDT' => 'Bangladeshi Taka',
'CAD' => 'Canadian Dollar',
'CHF' => 'Swiss Franc',
'CRC' => 'Costa Rican Colon',
'CZK' => 'Czech Koruna',
'DKK' => 'Danish Krone',
'EUR' => 'Euro',
'GBP' => 'Pound Sterling',
'HKD' => 'Hong Kong Dollar',
'HUF' => 'Hungarian Forint',
'ILS' => 'Israeli New Sheqel',
'INR' => 'Indian Rupee',
'JPY' => 'Japanese Yen',
'KZT' => 'Kazakhstan Tenge',
'KRW' => 'Korean Won',
'KHR' => 'Cambodia Kampuchean Riel',
'MYR' => 'Malaysian Ringgit',
'MXN' => 'Mexican Peso',
'NOK' => 'Norwegian Krone',
'NGN' => 'Nigerian Naira',
'NZD' => 'New Zealand Dollar',
'PHP' => 'Philippine Peso',
'PKR' => 'Pakistani Rupees',
'PLN' => 'Polish Zloty',
'SEK' => 'Swedish Krona',
'TWD' => 'Taiwan New Dollar',
'THB' => 'Thai Baht',
'TRY' => 'Turkish Lira',
'USD' => 'U.S. Dollar',
'VND' => 'Vietnamese Dong');
	
	?>
	<h3>Currency Settings</h3>
	<form method="post" action="">
	<div>
	<label>Set Currency : </label>
	<select name="currency_set">
	<?php
	
	foreach($curr_array as $currkey=>$currval)
	{
		$selected='';
		if($currency_set==$currkey)
		{
				$selected='selected';
			
		}
		echo '<option '.$selected.' value="'.$currkey.'">'.$currval.'</option>';
	}
	
	?>
	
	</select>
	</div>
	

	
	<input type="submit" value="Save" name="currency_save">
	
	</form>
	
	<!-- awadhesh  -->
	<?php 

	 $paypalrefund = 'sandbox';
	 $sandbox_username = get_option('sandbox_username');
	 $sandbox_password = get_option('sandbox_password');
	 $sandbox_signature = get_option('sandbox_signature'); 

	 $live_username = get_option('live_username'); 
	 $live_password = get_option('live_password');
	 $live_signature = get_option('live_signature');
	?>
	<div class="paypal_setting-container">
			<h3>Paypal Settings</h3>
			<input type="radio" name="paypalrefund" value="sandbox" id="sandbox" <?php if($paypalrefund == 'sandbox'){ echo "checked";}?> />Sandbox  			
			<input type="radio" name="paypalrefund" value="live" id="live" <?php if($paypalrefund == 'live'){ echo "checked";}?> />Live<br>
	</div>
	<div id="sandbox_user">
		<form method="post" action="">
			<h4>Sandbox Credential</h4>
			<label>User-Name</label>
			<input type="text" name="sandbox_username" value="<?php echo $sandbox_username; ?>"><br>
			<label>Password</label>
			<input type="Password" name="sandbox_password" value="<?php echo $sandbox_password;?>"><br>
			<label>Signature</label>
			<input type="Password" name="sandbox_signature" value="<?php echo $sandbox_signature; ?>"><br>	
			<input type="submit" value="Save" name="paypalcredentialsandbox">
		</form>
	</div>

	<div id="livepaypal_user">
		<form method="post" action="">
		<h4>Live Credential</h4>
		<label>Paypal Username</label>
		<input type="text" name="live_username" value="<?php echo $live_username; ?>"><br>
		<label>Paypal Password</label>
		<input type="Password" name="live_password" value="<?php echo $live_password;  ?>"><br>
		<label>Payapal SIGNATURE</label>
		<input type="Password" name="live_signature" value="<?php echo $live_signature; ?>"><br>	

		<input type="submit" value="Save" name="paypalcredentiallive">
		</form>
	</div>
	<script type="text/javascript">
		jQuery(document).ready(function(){
		    jQuery("input[name='paypalrefund']").change(function() {
				if (this.value == 'sandbox') {
			        jQuery("#sandbox_user").show();
			       jQuery("#livepaypal_user").hide();
			    }
			    else if (this.value == 'live') {
			        jQuery("#sandbox_user").hide();
			         jQuery("#livepaypal_user").show();
			    }
		 	});
		});
	</script>
	<style>
		#sandbox_user form label,#livepaypal_user form label{
		    width: 150px;
		    display: inline-block;
		}
		#sandbox_user form input[type="text"],#sandbox_user form input[type="password"],
		#livepaypal_user form input[type="text"],#livepaypal_user form input[type="password"] {
			margin-bottom: 10px;
			width: 250px;
		}
	</style>
	<?php 
	if(isset($_POST['paypalcredentialsandbox']))
	{          
			$paypal_sandbox = "sandbox";
			//print_r($_POST);
		
		update_option('paypalrefund',$paypal_sandbox);
		update_option('sandbox_username',$_POST['sandbox_username']);
		update_option('sandbox_password',$_POST['sandbox_password']);
		update_option('sandbox_signature',$_POST['sandbox_signature']);
		
	}
	?>
	<?php 
	if(isset($_POST['paypalcredentiallive']))
	{ 
		$paypal_live = "live";
		//print_r($_POST);
		$live_username = $_POST['live_username'];
		update_option('paypalrefund',$paypal_live);
		update_option('live_username',$_POST['live_username']);
		update_option('live_password',$_POST['live_password']);
		update_option('live_signature',$_POST['live_signature']);
		
	
	}
	if($paypalrefund == 'sandbox'){ ?>
		<style>
		#sandbox_user{

			display: block;
		}
		#livepaypal_user{

			display: none;
		}
		</style>
	<?php 
	}
	else
	{ ?>
	<style>
	#sandbox_user{

			display: none;
		}
		#livepaypal_user{

			display: block;
		}
	</style>
	<?php }
	?>
	
	<div id="from-email-containier">
		<?php
		if(isset($_POST['fromsubmit']))
	{          
		update_option('from_email_id',$_POST['from_email_id']);
	}
		$from_email = get_option('from_email_id'); ?>
		<form method="post" action="">
			<h3 class="form_emil">From Email Credential</h3>
			<label>From Email</label>
			<input type="email" name="from_email_id" value="<?php echo $from_email; ?>"><br>
			<input type="submit" name="fromsubmit">
		</form>
	</div>
	

	<!-- ending awadhesh -->
	
	<?php
}
add_action( 'admin_menu', 'theme_settings_menu_cb' );
function theme_settings_cb()
{
	
	
	if(isset($_POST['theme_set_sub']))
	{
		foreach($_POST as $postkey=>$postvalue)
		{
			if(!empty($postvalue))
			{
				update_option($postkey,$postvalue);
				
				if($postkey=='footer_copyright')
					update_option($postkey,html_entity_decode(stripcslashes($postvalue)));
				
			}
		}
	}
	$head_contact_number=get_option('head_contact_number');
	$head_contact_number_link=get_option('head_contact_number_link');
	
	$foot_contact_number=get_option('foot_contact_number');
	$foot_contact_number_link=get_option('foot_contact_number_link');
	
	$foot_email_id=get_option('foot_email_id');
	
	$paypal_pay_mode=get_option('paypal_pay_mode');
	
	$paypal_seller_mail=get_option('paypal_seller_mail');
	
	
	$facebook_link=get_option('facebook_link');
	$twitter_link=get_option('twitter_link');
	$linkdin_link=get_option('linkdin_link');

	
	?>
	<h2>Theme Settings</h2>
	<form method="post" action="">
	
	<table class="form-table">
	<tbody>
	<tr>
	<th scope="row">Header Contact Number : </th>
	<td>
		<input type="text" name="head_contact_number" id="head_contact_number" placeholder="" value="<?php echo $head_contact_number; ?>">

	</td>
	</tr>
	<tr>
	<th scope="row">Header Contact Number Link : </th>
	<td>
		<input type="text" name="head_contact_number_link" id="head_contact_number_link" placeholder="123456789" value="<?php echo $head_contact_number_link; ?>">

	</td>
	</tr>
	<tr>
	<th scope="row">Footer Email id : </th>
	<td>
		<input type="email" name="foot_email_id" id="foot_email_id" placeholder="" value="<?php echo $foot_email_id; ?>">

	</td>
	</tr>
	
	<tr>
	<th scope="row">Footer Contact Number : </th>
	<td>
		<input type="text" name="foot_contact_number" id="foot_contact_number" placeholder="" value="<?php echo $foot_contact_number; ?>">

	</td>
	</tr>
	<tr>
	<th scope="row">Footer Contact Number Link : </th>
	<td>
		<input type="text" name="foot_contact_number_link" id="foot_contact_number_link" placeholder="" value="<?php echo $foot_contact_number_link; ?>">

	</td>
	</tr>
	
	<!-- Social Icons Start  -->
	
	<tr>
	<th scope="row">Facebook Link : </th>
	<td>
		<input type="text" name="facebook_link" id="facebook_link" placeholder="" value="<?php echo $facebook_link; ?>">

	</td>
	</tr>
	
	<tr>
	<th scope="row">Twitter Link : </th>
	<td>
		<input type="text" name="twitter_link" id="twitter_link" placeholder="" value="<?php echo $twitter_link; ?>">

	</td>
	</tr>
	
	<tr>
	<th scope="row">Linkdin Link : </th>
	<td>
		<input type="text" name="linkdin_link" id="linkdin_link" placeholder="" value="<?php echo $linkdin_link; ?>">

	</td>
	</tr>
	
	
	
	
	<tr>
	<th scope="row">Footer Copyright Section : </th>
	<td>
		<?php
		
		$editor_id = 'footer_copyright';
		$content = get_option($editor_id);

	$settings = array('textarea_name' => 'footer_copyright','textarea_rows' => 5,'wpautop'=> false);

	wp_editor( $content, $editor_id, $settings ); 
		
		
		?>

	</td>
	</tr>
	
	
	
	
	<tr>
	<th scope="row"><h2>Paypal Payment Settings</h2>  </th>
	
	</tr>
	<tr>
	<th scope="row">Paypal Mode : </th>
	<?php
	$testmode='';
	$livemode='';
	if($paypal_pay_mode=='testmode')
	{
		$testmode='checked';
	}
	if($paypal_pay_mode=='livemode')
	{
		$livemode='checked';
	}
	?>
	<td>
		<label>Test/Demo</label><input value="testmode" type="radio" name="paypal_pay_mode" <?php echo $testmode; ?>> 
		<label>Live</label><input value="livemode" type="radio" name="paypal_pay_mode" <?php echo $livemode; ?>> 
	</td>
	</tr>
	
	<tr>
	<th scope="row">Seller Mail ID : </th>
	<td>
		<input type="text" name="paypal_seller_mail" id="paypal_seller_mail" value="<?php echo $paypal_seller_mail; ?>">

	</td>
	</tr>
	


	</tbody>
	</table>
	
	
	<input type="submit" name="theme_set_sub" value="Save">
	
	</form>
	
	
	<?php
}

add_post_type_support( 'page', 'excerpt' );
//Get Excerpt length
function get_excerpt_by_id($post_id,$gexcerpt_length=45){
  
    $the_post = get_post($post_id); //Gets post ID
    $the_excerpt = $the_post->post_content; //Gets post_content to be used as a basis for the excerpt
    $excerpt_length = $gexcerpt_length; //Sets excerpt length by word count
    $the_excerpt = strip_tags(strip_shortcodes($the_excerpt)); //Strips tags and images
    $words = explode(' ', $the_excerpt, $excerpt_length + 1);

    if(count($words) > $excerpt_length) :
        array_pop($words);
        array_push($words, '…');
        $the_excerpt = implode(' ', $words);
    endif;

    $the_excerpt = $the_excerpt.' <a href="'.get_permalink($post_id).'">Read More</a>';

    return $the_excerpt;
}
function getCurrency_symbol($countryCode = 'USD')
{
    //If user enter country code in Lower case convert it Upper case 
    $countryCode = strtoupper($countryCode);
    $currency = array(
    "AUD" => "&#36;" , //Australian Dollar
    "BRL" => "R&#36;" , // OR add &#8354; Brazilian Real
    "BDT" => "&#2547;", //Bangladeshi Taka
    "CAD" => "C&#36;" , //Canadian Dollar
    "CHF" => "Fr" , //Swiss Franc
    "CRC" => "&#8353;", //Costa Rican Colon
    "CZK" => "K&#269;" , //Czech Koruna
    "DKK" => "kr" , //Danish Krone
    "EUR" => "&euro;" , //Euro
    "GBP" => "&pound;" , //Pound Sterling
    "HKD" => "HK&#36;" , //Hong Kong Dollar
    "HUF" => "Ft" , //Hungarian Forint
    "ILS" => "&#x20aa;" , //Israeli New Sheqel
    "INR" => "&#8377;", //Indian Rupee
    "ILS" => "&#8362;", //Israeli New Shekel
    "JPY" => "&yen;" , //also use &#165; Japanese Yen
    "KZT" => "&#8376;", //Kazakhstan Tenge
    "KRW" => "&#8361;", //Korean Won
    "KHR" => "&#6107;", //Cambodia Kampuchean Riel  
    "MYR" => "RM" , //Malaysian Ringgit 
    "MXN" => "&#36" , //Mexican Peso
    "NOK" => "kr" , //Norwegian Krone
    "NGN" => "&#8358;", //Nigerian Naira
    "NZD" => "&#36" , //New Zealand Dollar
    "PHP" => "&#x20b1;" , //Philippine Peso
    "PKR" => "&#8360;" , //Pakistani Rupees
    "PLN" => "&#122;&#322;" ,//Polish Zloty
    "SEK" => "kr" , //Swedish Krona 
    "TWD" => "&#36;" , //Taiwan New Dollar 
    "THB" => "&#3647;" , //Thai Baht
    "TRY" => "&#8378;", //Turkish Lira
    "USD" => "&#36;" , //U.S. Dollar
    "VND" => "&#8363;"  //Vietnamese Dong
    
    );
    
    //check country code exit in array or not
    if(array_key_exists($countryCode, $currency))
    {
        return $currency[$countryCode];
    } 
    
}

function get_fb_share($postid)
{
	$fbshare='<div id="fb-root"></div>

<div class="fb-share-button" data-size="large" data-href="'.get_permalink($postid).'" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&amp;src=sdkpreparse">Share</a></div>
';
return $fbshare;
}
function get_fb_like($postid)
{
	$fblike='<div id="fb-root"></div><div class="fb-like" 
    data-href="'.get_permalink($postid).'" 
	data-size="large"
    data-layout="button_count" 
    data-action="like">
  </div>';
  return $fblike;
}
function custom_update_user_meta($usermeta_ar,$userid)
{
	foreach($usermeta_ar as $usermeta_key=>$usermeta_value)
	{
		update_user_meta($userid, $usermeta_key, $usermeta_value);
	}
}

function custom_update_post_meta($postmeta_ar,$postid)
{
	foreach($postmeta_ar as $postmeta_key=>$postmeta_value)
	{
		update_post_meta($postid, $postmeta_key, $postmeta_value);
	}
}

function inserting_file_type_form_data($post_file_name,$media_handle_name,$userid)
{
	if (isset($post_file_name)) {
	// The nonce was valid and the user has the capabilities, it is safe to continue.

	// These files need to be included as dependencies when on the front end.
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	require_once( ABSPATH . 'wp-admin/includes/file.php' );
	require_once( ABSPATH . 'wp-admin/includes/media.php' );
	
	// Let WordPress handle the upload.
	// Remember, 'my_image_upload' is the name of our file input in our form above.
	
	$attachment_id = media_handle_upload($media_handle_name, $userid );
	
	
	
	if ( is_wp_error( $attachment_id ) ) {
		// There was an error uploading the image.
	} else {
		// The image was uploaded successfully!
		
	}

} else {

	// The security check failed, maybe show the user an error.
}
return $attachment_id;	
}
// User related function
function get_user_info_by_id($usid,$info='user_login')
{
	$user_info = get_user_by( 'id', $usid );     
	return $user_info->$info;
	
}
function get_user_id_by_array($user_array)
{
	return $user_array[ID];
}
function get_user_id_acc_data($usdata)
{
	if(is_array($usdata))
	{
	$us_id=get_user_id_by_array($usdata);
	}
	else
	{
		$us_id=$usdata;
	}
	return $us_id;
}
function getuser_complete_name($userid)
{
	$firstname=get_user_info_by_id($userid,'first_name');
	$lastname=get_user_info_by_id($userid,'last_name');
	
	$user_login=get_user_info_by_id($userid,'user_login');
	
	if(!empty($firstname))
	{
		$usercomname=$firstname.' '.$lastname;
	}
	else
	{
		$usercomname=$user_login;
	}
	return $usercomname;
}
// User related function ends
function mail_data($mail_message_array,$topmessage='',$to,$subject,$us_name)
{
		
	$message = ' 
			<html>
			<head>
			<title>HTML email</title>
			</head>
			<body>
			<div style="background:#f3f3f3; width:96%; padding:15px ;">
			 <div style="width:96%; padding:15px 10px; background:#e0e0e0; margin-bottom:20px; margin-right:0px !important;float:left;">
			 <div class="mail_logo" style="text-align: center;">
			 <a href="'.site_url().'"><img src="'.wp_get_attachment_url( 51 ).'"></a>
			 </div>
			 
 </div>
			
			<p>
			 <div class="mail_logo_cont" style="display:inline-block;float:left;width:75%;padding-top:15px;">
			 <h2 style="color: #202020;
    font-size: 30px;
    font-weight: 300;
    line-height: 150%;
    margin: 0;
    text-align: left;text-transform: capitalize;">Hi,'.$us_name.'</h2>
			<p style="margin:0 0 16px;line-height: 22px;">'.$topmessage.'</p>
			</div>
			<table border="0" cellpadding="0" cellspacing="0" width="600" style="background-color:#fdfdfd;border:1px solid #dcdcdc;border-radius:3px!important">';
	if($mail_message_array)
	{
	foreach($mail_message_array as $mail_message_key=>$mail_message_value)
	{	
	$message .= '<tr>
			<th scope="row" colspan="2" style="text-align:left;border-top-width:4px;color:#737373;border:1px solid #e4e4e4;padding:12px">'.$mail_message_key.' : </th>
			<td style="text-align:left;vertical-align:middle;border:1px solid #eee;color:#737373;padding:12px">'.$mail_message_value.'</td>
			</tr>';
	}
	}
			
	$message .= '</table>
			</p>
			</div>
			
			</body>
			</html>  
			';
			//$to='votivekirti01@gmail.com';
			
			 mail_user($to,$subject,$message);
}



function mail_user($to,$subject,$message)
{
	$from_email = get_option('from_email_id');
	// Always set content-type when sending HTML email
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	// More headers
	$headers .= 'From: <'.$from_email.'>' . "\r\n";
	

	mail($to,$subject,$message,$headers);
}
add_filter( 'wp_mail_from_name', 'my_mail_from_name' );
function my_mail_from_name( $name )
{
    return get_bloginfo('admin_email');
}
function  get_total_price_using_session_cart($sessionarr,$pricestoragesession,$categoryid)
{ 
	$newcategory=explode(",",$categoryid);
	if($newcategory[0]=='3'){$pricestoragesession=$pricestoragesession[1];}
	if($newcategory[1]=='2'){$pricestoragesession=$pricestoragesession[0];}
	$total='';
	foreach($sessionarr as $productid=>$proqty)
	{
		
		$ktstorage_type_price=get_field($pricestoragesession,$productid);
		$total=$total+$ktstorage_type_price*$proqty;
	}
	return $total;
}


function  get_total_price_using_session($sessionarr)
{
	$total='';
	foreach($sessionarr as $productid=>$proqty)
	{
		$ktstorage_type_price=get_field('ktstorage_type_price',$productid);
		$total=$total+$ktstorage_type_price*$proqty;
	}
	return $total;
}
function check_current_logged_user_role($rolename)
{
	$user_id=get_current_user_id();
	
	
	$user = new WP_User( $user_id );

	$userrolesarray=$user->roles;
	
	if (in_array($rolename, $userrolesarray))
		{
			return 'success';
		}
		else{
			return 'unsuccess';
		} 
}

function get_price_format($price)
{
$currency_set=get_option('currency_set');

$currency=getCurrency_symbol($currency_set);

$cur_format=$currency.$price;

return $cur_format;

	
}
function get_currency()
{
$currency_set=get_option('currency_set');

$currency=getCurrency_symbol($currency_set);


return $currency;

	
}


//custom class for logo

add_filter( 'get_custom_logo', 'change_logo_class' );
function change_logo_class( $html ) {

   
    $html = str_replace( 'custom-logo-link', 'navbar-brand', $html );

    return $html;
}


function deleteimages(){
	
	$oldimagepostids=$_POST['imgid'];
	$post_id=$_POST['posid'];
	$current_userid=$_POST['userid'];
	$catids=$_POST['catids'];
	global $wpdb;
	$table_name = $wpdb->prefix . 'userupload_proimages';
	//echo "select * from $table_name where productid= $post_id and boxid=$catids and customerid=$current_userid";
	$selectimageids=$wpdb->get_results("select * from $table_name where productid= $post_id and boxid=$catids and customerid=$current_userid"); 
	$newids=array();
	$product_image_ids='';

	foreach($selectimageids as $newvals){
	$newvals->productimgids;
	$product_image_ids.= $newvals->productimgids;

	}
	$expvalids = explode(",",$product_image_ids);
	$result='';
	$arr = array_diff($expvalids, array($oldimagepostids));
	foreach($arr as $newvals){
	$result.=$newvals.",";
	}
	foreach($attach_id as $vals){
	$result.=$vals.",";
	}

	$result = rtrim($result,',');
	//update_field('storage_type_gallery', $result, $post_id);

	$count_query = "select count(*) from $table_name where productid= $post_id and boxid=$catids and customerid=$current_userid";
	 $num = $wpdb->get_var($count_query);
	
	if($num >=1){ 
	wp_delete_attachment($oldimagepostids);
	$wpdb->update($table_name, array('productimgids'=>$result), array('productid'=>$post_id,'customerid'=>$current_userid)); 
	}
	die();
}
add_action("wp_ajax_deleteimages", "deleteimages");
add_action("wp_ajax_nopriv_deleteimages", "deleteimages");


/* check email exists or not */
function checkemail(){
	
	$email = $_POST['useremails'];
	if ( email_exists( $email ) ) {
      echo "0";
   }else{
	   
	  echo "1"; 
   }
	
	die();
}
add_action("wp_ajax_checkemail", "checkemail");
add_action("wp_ajax_nopriv_checkemail", "checkemail");

/* eheck users exits or not */

function checkuser(){
	
	$user = trim($_POST['username']);
	if ( username_exists( $user ) ) {
      echo "0";
   }else{
	   
	  echo "1"; 
   }
	
	die();
}
add_action("wp_ajax_checkuser", "checkuser");
add_action("wp_ajax_nopriv_checkuser", "checkuser");

function checkphone(){
	
	global $wpdb;
	$cheeckphone=$_POST['phonecheck'];
	 $rowcount = $wpdb->get_row("SELECT count(*) as count FROM `wp_usermeta` WHERE `meta_key` = 'user_phone' AND `meta_value` =".$cheeckphone);
	 
	if ($rowcount->count>0 ) {
      echo "0";
   }else{
	   
	  echo "1"; 
   }
	die();
}
add_action("wp_ajax_checkphone", "checkphone");
add_action("wp_ajax_nopriv_checkphone", "checkphone");




function booknowprices(){
	
	$booknowcatids=$_POST['booknowcatids'];
	echo $_SESSION['catidsess'] = $booknowcatids;
	unset($_SESSION['hiddenchangeprices']);
	echo $_SESSION['hiddenchangeprices'] = $_POST['changes_prices'];
	die();
}
add_action("wp_ajax_booknowprices", "booknowprices");
add_action("wp_ajax_nopriv_booknowprices", "booknowprices");



function get_prices_by_item() {
$catids=$_POST['catids'];
$datapriceranges=$_POST['datapriceranges'];
$currencyvalue="HKD";
$args1=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => array(3,2),
		),
	));
$the_query1 = new WP_Query( $args1 );
//echo "<pre>"; print_r($the_query1); echo "</pre>";
$home_content='';

$k=1;
$i=0;
// The Loop
$stotypeids = array();
$storetypes = array();
$home_content.= '<tr>';
if ( $the_query1->have_posts() ) {
	
	while ( $the_query1->have_posts() ) {
		 
		$the_query1->the_post();
		$ktstorage_type_price=get_field($datapriceranges);
		$proqty=0;
		$stotypeid=get_the_ID();
		$stotypeids[] = get_the_ID();
		$storetypes[] = $ktstorage_type_price;
		$ktstorage_type_image = get_field('ktstorage_type_image');
		$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
		$ktstorage_gallery_images = get_field('storage_type_gallery'); 
		
		if($pro_qty_array_session)
		{
			$proqty=$pro_qty_array_session[$stotypeid];
			$pro_perprice=$proqty*$ktstorage_type_price;
		}
		$home_content.= '<td class="gllimgs"><div class="cartporimages"><img src="'.$ktstorage_type_image.'" /></div>
		<div class="cartpagetitle"><h5>
		' . get_the_title().'</h5><h6 class="boxpr">'.$currencyvalue ."$".$ktstorage_type_price. '</h6><h6>Max.'.$ktstorage_type_max_weight.'kg</h6>
		<a id="open-pop-up-'.get_the_ID().'" href="javascript:void(0);">Details</a>
		
		<div id="pop-up-'.get_the_ID().'" class="pop-up-display-content">
			<div class="sb_pro_sub">
				<div class="sb_pro_img">
					<div class="popuptit_price">
						<h5 class="popup_title">'.get_the_title().'</h5>
						<span class="prod-price">'.$currencyvalue.'$ <strong>'.$ktstorage_type_price.'</strong></span>
					</div>
					<div class="popupimg"><img src="'.$ktstorage_type_image.'"></div>
				</div>
				<div class="sb_pro_details">
					'.get_the_content().'
					
				</div>
			</div>
		</div>
		<script type="text/javascript">
			jQuery(document).ready(function () {
				//basic pop-up
				jQuery("#open-pop-up-'.get_the_ID().'").click(function(e) {
					e.preventDefault();
					jQuery("#pop-up-'.get_the_ID().'").popUpWindow({action: "open"});
				});

			   
			});
		</script>
		</div>
		
			<div class="sp-quantity">
			<div class="sp-minus fff"> <a class="ddd" href="javascript:void(0);">-</a>
			</div>
			<div class="sp-input">
			<input type="text" class="quntity-input" name="product_qnty[]" value="'.$proqty.'" />
			<input type="hidden"  name="product_ids[]" value="'.get_the_ID().'" />
			<input type="hidden"  name="product_ids_months[]" value="'.$ktstorage_type_price.'" />
			</div>
			<div class="sp-plus fff"> <a class="ddd" href="javascript:void(0);">+</a>
			</div>
			<div class="hiddenprices">
			<input type="hidden" class="price_per_pro price_per_product'.$k.'" value="'.$ktstorage_type_price.'"></div>
			<input type="hidden" class="price_per_pro_total" value="'.$pro_perprice.'">
			</div>
		</td>';
		$k++;
		
	}
	
	
	/* Restore original Post Data */
	wp_reset_postdata();
}
$home_content.='<tr><td class="total_price_cart" colspan="2">Total</td><td colspan="4" class="total_pr">';
if($totalprice) {
	$home_content.=$currencyvalue."$".$totalprice;
	}
	else{
		$home_content.= $currencyvalue."$"."0";
		}
$home_content.='</td></tr>';
$home_content.='
<script>
function form_validationcart(formid)   
{


		var flag = ""; 
		var error_Msg="";
		var error_Msg = "Select Quantity :: Please correct the following : ";
		var myform =jQuery("#"+formid);
		
		var total_price_val =myform.find(".total_pr_input").val();
	
		if((total_price_val=="") || (total_price_val==0))
		{
			flag = 1;
			error_Msg += "\n - Please Select a Product";
		}
		if(flag == 1)
		{

			jAlert(error_Msg, "Required Fields");

		

			return false;

		}

		else{

			

		return true;

		}

		
}
		

jQuery(document).ready(function(){
	var currencylabel = jQuery(".currency_label").val();
	jQuery(".ddd").on("click", function () {

    var $button = jQuery(this);
    var oldValue = $button.closest(".sp-quantity").find("input.quntity-input").val();

    if ($button.text() == "+") {
        var newVal = parseFloat(oldValue) + 1;
    } else {
        
        if (oldValue > 0) {
            var newVal = parseFloat(oldValue) - 1;
        } else {
            newVal = 0;
        }
    }
	

    $button.closest(".sp-quantity").find("input.quntity-input").val(newVal);
	
	//custom js
	var price_per_pro= $button.parent().parent().find(".price_per_pro").val();
	
	var total_per_pro=newVal*price_per_pro;

	var currencylabel = jQuery(".currency_label").val();
	
	$button.parent().parent().find(".price_per_pro_total").val(total_per_pro);
	
	var total = 0;
	var values = jQuery(".price_per_pro_total").map(function() { return this.value; }).get();
	jQuery.each(values , function(i, val) { 
	 addval=values[i];
	  total += addval << 0;
	 
	});
	var oldtotal=jQuery(".total_pr_input").val();
	
	jQuery(".total_pr_input").val(total);
	jQuery(".total_pr").html(currencylabel+"$"+ total);

});

});
</script>
<style>
td.total_price_cart {
    font-weight: 600 !important;
    text-align: right !important;
}
.cartpageordering table tr:last-child td {
    text-align: right !important;
    font-weight: 600 !important;
}
</style>
';
		

	echo $home_content;
   die();

}
add_action("wp_ajax_get_prices_by_item", "get_prices_by_item");
add_action("wp_ajax_nopriv_get_prices_by_item", "get_prices_by_item");



function get_prices() {

   $catids=$_POST['catids'];
   $datapriceranges=$_POST['datapriceranges'];
   $args1=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => $catids,
		),
	));
$the_query1 = new WP_Query( $args1 );
$home_content='';
if ( $the_query1->have_posts() ) {
	
	while ( $the_query1->have_posts() )
	{
		$the_query1->the_post();
		$ktstorage_type_price = get_field($datapriceranges);
		$ktstorage_type_image = get_field('ktstorage_type_image');
		$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
		$home_content .='
						<div class="col-md-4">
							<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="'.$ktstorage_type_image.'">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="'.get_permalink().'">'.get_the_title().'</a></h5>
									<span class="prod-price">HK$ <strong>'.$ktstorage_type_price.'</strong></span>
									<span class="prod-wieght">Max. '.$ktstorage_type_max_weight.'kg</span>
									<a id="open-pop-up-'.get_the_ID().'" href="javascript:void(0);">Details</a>
								<div id="pop-up-'.get_the_ID().'" class="pop-up-display-content">
								<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="'.$ktstorage_type_image.'">
								</div>
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="'.get_permalink().'">'.get_the_title().'</a></h5>
									<span class="prod-price">HK$ <strong>'.$ktstorage_type_price.'</strong></span>
									<span class="prod-wieght">Max. '.$ktstorage_type_max_weight.'kg</span>
									</div>
								</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-'.get_the_ID().'").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-'.get_the_ID().'").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								</div>
							</div>
						</div>';
		
		
	}
		wp_reset_query();
	}
	echo $home_content;
   die();

}
add_action("wp_ajax_get_prices", "get_prices");
add_action("wp_ajax_nopriv_get_prices", "get_prices");




function myStartSession() {
    if(!session_id()) {
        session_start();
    }
}

function myEndSession() {
    session_destroy ();
}
add_action('init', 'myStartSession', 1);
add_action('wp_logout', 'myEndSession');

function getdistricts() {

global $wpdb;
$countryid = $_POST['countryid'];
$args=array('post_type'=>'region','orderby'=> 'title','order'=>	'ASC','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'country',
			'field'    => 'id',
			'orderby'=> 'title',
			'order'	=>	'ASC',
			'terms'    => $countryid,
		),
	));
$the_query = new WP_Query( $args );

$html='';
	if ($the_query->have_posts() ) :
	while ($the_query->have_posts() ) : $the_query->the_post();
	$html.='<option value="'.get_the_ID().'">'.get_the_title().'</option>';
	
	endwhile;
	else:
	$html.='<option value="">
		Select District
		</option>';
	endif; 
	echo $html;
					
die();
}
add_action("wp_ajax_getdistricts", "getdistricts");
add_action("wp_ajax_nopriv_getdistricts", "getdistricts");



function deletetermsbyid() {
$html='';
$categoryid = $_POST['categoryid'];

$taxonomy = $_POST['taxonomy'];

if(wp_delete_term($categoryid,$taxonomy)){
	$terms = get_terms( array(
				'taxonomy' => 'storagetypecat',
				'hide_empty' => false,
				) );  
				$i=1;
				if(!empty($categoryid)){$stylescss= "display:none";} 
	$html.='<table class="table table-striped table-bordered allstoragecatelists" style="'.$stylescss.'">
                    <tbody>
                      <tr></tr>
                      <tr>
                        <th><a href="">Serial No</a></th>
                        <th><a href="">Name</a></th>
                        <th><a href="">Description</a></th>
                        <th><a href="">Slug</a></th>
						<td>Count</td>
						<th><a href="">Edit</a></th>
						<th><a href="">Delete</a></th>
                       </tr>';
					 
					 foreach($terms as $catename){ 
					 $term_id = $catename->term_id;
					  $taxonomyname = $catename->taxonomy;
					  $termname = $catename->name;
					  $termdescription = $catename->description;
					  $postcount = $catename->count;
					  $termslug = $catename->slug;
					$html.='
                      <tr>
                        <td>'.$i.' </td>
                        <td>'.$termname.'</td>
                        <td>'.$termdescription.'</td>
						<td>'.$termslug.'</td>
						<td>'.$postcount.'</td>
						<td><a href="'.get_bloginfo('url').'/admin-dashboard/?type=storagetypecate&cateid='.$term_id.'">Edit</a></td>
						<td><a class="deleteterms" href="javascript:void(0);" data-catid="'.$term_id.'" data-name="'. $taxonomyname.'">Delete</a></td>
                       
					  </tr>';
					 
					 $i++; } 
					$html.='  </tbody>  </table> ';
				
	}else{echo "No";}
	
	echo $html;
	
die();
}
add_action("wp_ajax_deletetermsbyid", "deletetermsbyid");
add_action("wp_ajax_nopriv_deletetermsbyid", "deletetermsbyid");



function deleteRegionsById() {
$html='';
//print_r($_POST);
echo $termId = $_POST['termid'];

$taxonomy = $_POST['taxonomy'];

if(wp_delete_term($termId,$taxonomy)){echo "yes";} else {echo "No";}
	
	
	
die();
}
add_action("wp_ajax_deleteRegionsById", "deleteRegionsById");
add_action("wp_ajax_nopriv_deleteRegionsById", "deleteRegionsById");


function deleteUserById() {
$html='';
$userid = $_POST['userid'];
echo $deleteuser = wp_delete_user( $userid);
	
die();
}
add_action("wp_ajax_deleteUserById", "deleteUserById");
add_action("wp_ajax_nopriv_deleteUserById", "deleteUserById");


add_filter( 'registration_redirect', 'ckc_registration_redirect' );
function ckc_registration_redirect() {
    return home_url( '/odering');
}

function getCartCountUserId($user_id){
	global $wpdb; 
$selectrows = $wpdb->get_row("select * from wp_cart_items where userid =$user_id");
$decodecartitems = json_decode($selectrows->cartitems);
foreach($decodecartitems as $decodeCartitemsqty){
	$product_qnty[] =$decodeCartitemsqty->product_qnty; 
}
foreach($product_qnty[0] as $finalqty){
	$qty[] = $finalqty;
}

foreach($decodecartitems as $decodeCartitemsproduct){
	
$product_ids[] = $decodeCartitemsproduct->product_ids;

}
$j=0;
foreach($product_ids[1] as $finproductids){
	
if($qty[$j]=='1'){
$finproduct_ids[] = $finproductids;
}
$j++;
}
foreach($decodecartitems as $cartitems){
	$cart_ids[] = $cartitems->catids;
	
}
$explode_cartitems = explode(",",$cart_ids[4]);

$args1=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => $explode_cartitems[0],
		),
	));
$the_query1 = new WP_Query( $args1 ); 
if ($the_query1->have_posts() ) :
$k=0;
while ($the_query1->have_posts() ) : $the_query1->the_post();
$postid [] = get_the_ID();

$k++;
endwhile;
else:
$result[]='';
endif;
$results=array_intersect($postid,$finproduct_ids);
foreach($results as $finresult){
	$result[] =$finresult;
}
if(!empty($result)){return $result;}

//return $explode_cartitems[0];
}

/* Delete promotion code and amount */
function updatepromotions() {
$html='';
global $wpdb;
$promotioncode = $_POST['promotioncode'];
if($promotioncode!=''){
	$deletes = $wpdb->delete('freemonthpromptation',array('promotion_id'=>$promotioncode));

}
echo $deletes;

die();
}
add_action("wp_ajax_updatepromotions", "updatepromotions");
add_action("wp_ajax_nopriv_updatepromotions", "updatepromotions");
/* Delete promotion code and amount ends here */


function chageuserstatus() {
$html='';
rint_r($_POST);
$editsuser = $_POST['userid'];
$ja_disable_user = $_POST['userstatus'];
$flag=1;
$disable =0;
if($ja_disable_user=='Enable'){echo $finuser= "'$flag'"; $updatestatus = update_user_meta( $editsuser, 'ja_disable_user',"1" );}
if($ja_disable_user=='disable'){echo $finuser= "'$disable'"; $updatestatus = update_user_meta( $editsuser, 'ja_disable_user', "0");}
if($updatestatus){echo "success";} else {echo "not success";}
die();
}
add_action("wp_ajax_chageuserstatus", "chageuserstatus");
add_action("wp_ajax_nopriv_chageuserstatus", "chageuserstatus");

//12oct code

function selected_district_regions_ajax()
{
	$reg_html='';
	$selecteddistrict=$_POST['selecteddistrict'];
	if(isset($selecteddistrict))
	{
	$args=array(
	'post_type' => 'region',
	'post_status' => 'publish',
	'orderby'=> 'title',
	'order'	=>	'ASC',
	'posts_per_page'=>-1,
	'tax_query' => array(
		array(
			'taxonomy' => 'country',
			'field'    => 'term_id',
			'orderby'=> 'title',
			'order'	=>	'ASC',
			'terms'    => array($selecteddistrict),
		)
),
	);
	$the_query = new WP_Query( $args);

	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$reg_html.='<option>' . get_the_title() . '</option>';
	}
	wp_reset_postdata();
}
echo $reg_html;
die();
}
add_action( 'wp_ajax_selected_district_regions_ajax', 'selected_district_regions_ajax' );
add_action( 'wp_ajax_nopriv_selected_district_regions_ajax', 'selected_district_regions_ajax' );
function regions_add_custom_user_profile_fields( $user ) {


$user_region=get_user_meta($user->ID,'user_region',true);
$user_district=get_user_meta($user->ID,'user_district',true);


?>
	<h3><?php _e('Extra Profile Information', 'your_textdomain'); ?></h3>
	
	<table class="form-table">
		<tr>
			<th>
				<label for="user_region"><?php _e('User Region', 'your_textdomain'); ?>
			</label></th>
			<td>
		<select name="user_region" id="user_region">
														
				<?php
				$regionsold = get_terms( array(
					'taxonomy' => 'country',
					'hide_empty' => false,
					) );
				$regions = get_terms( array(
					'taxonomy' => 'country',
					'hide_empty' => false,
					'include'=>array(56)
					) );
				$a=1;
				
				foreach($regions as $regionsname)
				{
					$usregionactive='';


					if($a==1)
					$termid_show_regions=$regionsname->term_id;
					 $region_name = $regionsname->name;
					 $region_id = $regionsname->term_id;


					 echo '<option value="'.$region_id.'">'.$region_name.'</option>';
				$a++;

				}

				?>
			</select>			
		</td>
		</tr>

		<tr>
			<th>
				<label for="user_district"><?php _e('User District', 'your_textdomain'); ?>
			</label></th>
			<td>

				<select name="user_district" id="user_district">
														
						<?php
						$args=array(
						'post_type' => 'region',
						'post_status' => 'publish',
						'order'	=>	'ASC',
						'posts_per_page'=>-1,
						'tax_query' => array(
							array(
								'taxonomy' => 'country',
								'field'    => 'term_id',
								'terms'    => array($termid_show_regions),
							)
						),
						);
						$the_query = new WP_Query( $args);

						while ( $the_query->have_posts() ) {
							$the_query->the_post();
							$termid_show_district='';
							if($user_district==get_the_ID())
							{
								$termid_show_district='selected';
							}

							echo '<option '.$termid_show_district.'>' . get_the_title() . '</option>';
						}
						wp_reset_postdata();

						?>
					</select>			</td>
		</tr>
	</table>
<?php }

function regions_save_custom_user_profile_fields( $user_id ) {
	
	if ( !current_user_can( 'edit_user', $user_id ) )
		return FALSE;
	
	update_usermeta( $user_id, 'address', $_POST['address'] );
}

add_action( 'show_user_profile', 'regions_add_custom_user_profile_fields' );
add_action( 'edit_user_profile', 'regions_add_custom_user_profile_fields' );

add_action( 'personal_options_update', 'regions_save_custom_user_profile_fields' );
add_action( 'edit_user_profile_update', 'regions_save_custom_user_profile_fields' );
function custom_pagination($numpages = '', $pagerange = '', $paged='',$passedurl) {

  if (empty($pagerange)) {
    $pagerange = 2;
  }

  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {  
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => $passedurl . '%_%',
    'format'          => '&paged12=%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);

  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }

}

/*function to get all order ids at the time of box numbers edit */

function getOrderIds($orderids,$productids){
global $wpdb;
$getoutput = $wpdb->get_results("select * from wp_products_tracking_images where order_id=$orderids AND order_product_id=$productids");

foreach($getoutput as $values){
	$order_product_id=$values->order_product_id;
	$order_id=$values->order_id;
	$productstrackimageid=$values->productstrackimageid;
	$trackingcode=$values->trackingcode;
	$producttitle = get_the_title($productids);
	$newarray=array("orderid" =>$order_id,"productid"=>$order_product_id,"boximages"=>$productstrackimageid,"boxnumber"=>$trackingcode,"producttitle"=>$producttitle);
	return $newarray;
	
}
}
function getBoxImgIds($orderids,$productids){
	global $wpdb; 
	$selects = $wpdb->get_results("select * from wp_boximages where orderid= $orderids AND productid =$productids");
	foreach($selects as $val){
		$imgids[] = $val->attachmentids;
		} 
	
	return $imgids;
}
function getBoxImgSrc($imgsrc){
	global $wpdb;
	foreach($imgsrc as $vals){ //print_r($vals);
	$image_attributesx= wp_get_attachment_image_src( $attachment_id =$vals );
	$image_attributes[]=array("imagesrc"=>$image_attributesx[0],"imageid"=>$vals);
	}
	return $image_attributes;
	
}

/*function to get all order ids at the time of box numbers edit ends here  */

/* Delete box image code */
function removeboximage() {
global $wpdb;
$html.='';
$attachmentid = $_POST['attachmentid'];
$boxorderid = $_POST['boxorderid'];
$boxproductid = $_POST['boxproductid'];
wp_delete_attachment($attachmentid);
$wpdb->delete('wp_boximages', array('attachmentids'=>$attachmentid,'orderid' => $boxorderid,'productid'=>$boxproductid ) );
$imgselects= $wpdb->get_results("select * from wp_boximages where orderid= $boxorderid AND productid= $boxproductid");
if(!empty($imgselects)){
foreach($imgselects as $newimages){ 
$newimgsrc = $newimages->attachmentids;
$boxorderid = $newimages->orderid;
$boxproductid = $newimages->productid;
$boxattachmentid = $newimages->boximageid;
$image_attributesx= wp_get_attachment_image_src( $attachment_id =$newimgsrc );
//print_r($image_attributesx); 
//echo $image_attributesx[0];
//echo '<img src="'.$image_attributesx[0].'">';
	echo $html.='<div class="col-md-3 imagessrcs removefirst"><i class="fa fa-times removeall" data-orderid="'.$boxorderid.'" data-productid="'.$boxproductid.'" data-id="'.$boxattachmentid.'"></i><span class="imgsrcs"><img src="'.$image_attributesx[0].'"></span></div>  ';
}
}
die();
}
add_action("wp_ajax_removeboximage", "removeboximage");
add_action("wp_ajax_nopriv_removeboximage", "removeboximage");
/* Delete Box image code ends here */

/* Delete box number and image code */
function removeboxdetails() {
global $wpdb;
$html.='';
$boxproductid=$_POST['boxproductid'];
$boxorderid=$_POST['boxorderid'];

$imgselects= $wpdb->get_results("select * from wp_boximages where orderid= $boxorderid AND productid= $boxproductid");
if(!empty($imgselects)){
foreach($imgselects as $newimages){ 
$boxattachmentid = $newimages->attachmentids;
$boxorderid = $newimages->orderid;
$boxproductid = $newimages->productid;
$boximageid = $newimages->boximageid;
wp_delete_attachment($boxattachmentid);
$wpdb->delete('wp_boximages', array('attachmentids'=>$boxattachmentid,'orderid' => $boxorderid,'productid'=>$boxproductid ) );
}

}

die();
}
add_action("wp_ajax_removeboxdetails", "removeboxdetails");
add_action("wp_ajax_nopriv_removeboxdetails", "removeboxdetails");
/* box number and image code ends here */



function getboxnumber($orderid,$productid){
global $wpdb;
$selects =$wpdb->get_results("select trackingcode from wp_products_tracking_images where order_id= $orderid AND order_product_id= $productid");
foreach($selects as $val){ $boxname=$val->trackingcode;} return $boxname;
}

function getBoxItemInfo($orderid,$useremail){
global $wpdb;

$selects =$wpdb->get_results("select * from wp_boximages  where orderid=$orderid AND useremail ='$useremail' ", ARRAY_A);

foreach($selects as $selectval){
	$userboxitem[] = $selectval;
}
return $userboxitem;
}

function getMonthDurationByProductId($productid,$productprice){
global $wpdb;
//echo "select * from wp_postmeta where meta_value = ".$productprice." and post_id = ".$productid." ";
$monthdurationperiod = $wpdb->get_results("select * from wp_postmeta where meta_value = ".$productprice." and post_id = ".$productid." ");	

return $monthdurationperiod;
}

function getProductCountByCustomerEmail($email){
	global $wpdb;
	$user_count = $wpdb->get_var("select count(*) from wp_order_products where useremail= '$email' ");
	return $user_count;
}

function getProductPriceByCustomerEmail($email){
	global $wpdb;
	$total_price = $wpdb->get_results("select finalprice from wp_order_products where useremail= '$email' GROUP BY finalprice");
	return $total_price[0]->finalprice;	
}
function getOrdersLists(){
	global $wpdb;
	$orders_lists = $wpdb->get_results("select * from wp_orders where subscr_id!=''", ARRAY_A);
	return $orders_lists;
	
}

function getStorageTypeByUserEmail($orderproductid,$email){
	global $wpdb;
	//echo "select * from wp_order_products where order_product_id= $orderproductid AND useremail='$email'";
	$storage_type = $wpdb->get_results("select * from wp_order_products where order_product_id= $orderproductid AND useremail='$email'", ARRAY_A);
	return $storage_type;
	
}


function getsubimgebyboxid($boximageid){
	global $wpdb;
	$sub_images = $wpdb->get_results("select * from wp_box_images_bycustomer where boximageid=$boximageid", ARRAY_A);
	return $sub_images;
	
}

function getimgedescbyboxid($boximageid){
	global $wpdb;
	$image_description = $wpdb->get_results("select description from wp_box_images_bycustomer where boximageid=$boximageid GROUP BY boximageid", ARRAY_A);
	return $image_description;
	
}

function getStuffByLocation($email){
	global $wpdb;
	$rowcount = $wpdb->get_var("SELECT COUNT(*) FROM wp_schedule_return_history_order INNER JOIN wp_schedule_return_history ON wp_schedule_return_history_order.useremail = wp_schedule_return_history.useremail where wp_schedule_return_history_order.useremail='$email'");
    return $rowcount;
}

function getStuffByStorage($email){
	global $wpdb;
	$rowcount = $wpdb->get_var("SELECT COUNT(*) FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id= wp_order_products.order_id INNER JOIN wp_boximages ON wp_boximages.orderid = wp_order_products.order_id where wp_orders.useremail='$email' AND wp_orders.paymentstatus='paid' AND wp_boximages.boxid!='' GROUP BY wp_boximages.attachmentids ");
    return $rowcount;
}
function getStuffByEmail($email){
	global $wpdb;
	$getstuffbyemailid = $wpdb->get_results("SELECT * FROM wp_orders INNER JOIN wp_order_products ON wp_orders.order_id= wp_order_products.order_id INNER JOIN wp_boximages ON wp_boximages.orderid = wp_order_products.order_id where wp_orders.useremail='$email' AND wp_orders.paymentstatus='paid' GROUP BY wp_boximages.attachmentids",ARRAY_A);
	return $getstuffbyemailid;
}
function countStuffImagesByCustomer($attachmentid,$useremail){
	global $wpdb;
	$getimgaescount=$wpdb->get_var("SELECT COUNT(*) FROM wp_box_images_bycustomer where attachmentids= $attachmentid AND moreattachmentids!='' ");
	return $getimgaescount;
}

function countStuffImages($email){
	global $wpdb;
	$getimgaescountbyadmin=$wpdb->get_var("SELECT COUNT(*) FROM wp_boximages where useremail= '$email' AND attachmentids!='' ");
	return $getimgaescountbyadmin;
}

function getDescriptionByBoxId($boxid){
	global $wpdb;
	$selects = $wpdb->get_results("select * from wp_box_images_bycustomer where boximageid=$boxid GROUP BY description", ARRAY_A);
	return $selects;
}

function getDescriptionByAttachmentId($boxid){
	global $wpdb;
	$selects = $wpdb->get_results("select * from wp_box_sub_images_pick_up where main_image_attachment_id=$boxid GROUP BY description", ARRAY_A);
	return $selects;
}


function getByBoxItem($productid)
{
	global $wpdb;
	$html='';
	$selects = $wpdb->get_results("select * from wp_term_relationships INNER JOIN wp_term_taxonomy ON wp_term_relationships.term_taxonomy_id = wp_term_taxonomy.term_taxonomy_id INNER JOIN wp_terms ON wp_term_taxonomy.term_id = wp_terms.term_id Where wp_term_relationships.object_id =$productid", ARRAY_A);
	return $selects;
}
function getFeeByBox($type){
global $wpdb;
$select = $wpdb->get_results("select * from wp_handling_fee where handlingfeeby='$type'", ARRAY_A);
return $select;
}

function getFeeByItem($type){
global $wpdb;
$select = $wpdb->get_results("select * from wp_handling_fee where handlingfeeby='$type'", ARRAY_A);
return $select;
}

function getFeeByDelivery($type){
global $wpdb;
$select = $wpdb->get_results("select * from wp_handling_fee where handlingfeeby='$type'", ARRAY_A);
return $select;
}

function getAdditonalFee(){
global $wpdb;
$select = $wpdb->get_results("select * from wp_additional_fee ", ARRAY_A);
return $select;	
}	

function getMonthsByPrice($product_id,$price){
	global $wpdb;
	$getprices = $wpdb->get_results("select * from wp_postmeta where post_id=$product_id and meta_value=$price",ARRAY_A);
	return $getprices;
}
function getStorageType($product_id){
	global $wpdb;
	$storagetype = $wpdb->get_results("select * from wp_term_relationships INNER JOIN wp_term_taxonomy ON wp_term_relationships.term_taxonomy_id = wp_term_taxonomy.term_taxonomy_id INNER JOIN wp_terms ON wp_term_taxonomy.term_id=  wp_terms.term_id where wp_term_relationships.object_id=$product_id",ARRAY_A);
	return $storagetype;
}

function getHandlingFeeByBox($boxprice,$boxqty,$boxstoreplan,$boxminprice,$checkincheckoutchoice){
	global $wpdb;
	$boxprice;
	$boxqty;
	$boxstoreplan;
	$boxminprice;
	$checkincheckoutchoice;
	$boxsum=0;
	if($boxstoreplan=='Pay As Your Store'){
		$boxfinaltax = (40) * ($boxqty);
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='3-5 Months'){
		$boxprice=140;
		$boxfinaltax = (20) * ($boxqty);
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='6-11 Months'){
		$perboxprice = ($boxprice / $boxqty) ;
		if($boxqty==1){$boxfinaltax = 0;}else{ $boxfinaltax = (20) * ($boxqty-1);}
		
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='12+ Months'){
		$perboxprice = ($boxprice / $boxqty) ;
		if($boxqty==1 || $boxqty==2){$boxfinaltax = 0;}else{ $boxfinaltax = (20) * ($boxqty-2);}
		
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			  $boxsum = 0;
		}		
	}
	
	
	return $boxsum;
}

function getHandlingFeeByItem($itemprice,$itemqty,$itemstoreplan,$itemminprice){
global $wpdb;
	$itemprice;
	$itemqty;
	 $itemstoreplan;
	$itemminprice;
	
	$itemsum=0;
	if($itemstoreplan=='Pay As Your Store'){ 
		 $itemfinaltax = (20) * ($itemqty);
		if( $itemprice < $itemminprice){
			$itemsum=($itemsum + ($itemfinaltax));	
		}
		else{
			$itemsum=0;
		}	
	}
	if($itemstoreplan =='3-5 Months'){
			$itemfinaltax = (10) * ($itemqty);
			if( $itemprice < $itemminprice){
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
	if($itemstoreplan =='6-11 Months'){
			$peritemprice = ($itemprice / $itemqty) ;
			if($itemqty==1){ $itemfinaltax = 0;}else{  $itemfinaltax = (10) * ($itemqty-1);}
			if( $itemprice < $itemminprice){
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
		
		if($itemstoreplan =='12+ Months'){
			$peritemprice = ($itemprice / $itemqty) ;
			if($itemqty==1 || $itemqty==2){ $itemfinaltax = 0;}else{  $itemfinaltax = (10) * ($itemqty-2);}
			if( $itemprice < $itemminprice){
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
	return  $itemsum;	
}

function getDeliveryFeeByBox($boxprice,$boxqty,$handlingfee,$businessday){
	$boxprice ;
	$boxqty ;
	$businessday;
	$deliveryfeebybusiness = 0;
	//$deliveryperboxprice = $boxprice * $boxqty;
	if($businessday =='samebusinessday'){
		$deliveryfeebybusiness = $deliveryfeebybusiness + ($boxqty * 200);
	}
	if($businessday =='nextbusinessday'){
		$deliveryfeebybusiness = $deliveryfeebybusiness + ($boxqty * 100);
	}
	if($businessday =='inormorethantwobusinessday'){
		$deliveryfeebybusiness = 0;
	}
	if($businessday =='afterhoursdelivery'){
		$deliveryfeebybusiness = $deliveryfeebybusiness + ($boxqty * 200);
	}
	
	
	return $deliveryfeebybusiness;
}


function getDeliveryFeeByItem($itemprice,$itemqty,$handlingfee,$businessday){
	$itemprice ;
	$itemqty ;
	$businessday;
	$deliveryfeebybusinessbyitem = 0;
	//$deliveryperboxpricebyitem = $itemprice * $boxqty;
	if($businessday =='samebusinessday'){
		$deliveryfeebybusinessbyitem = $deliveryfeebybusinessbyitem + ($itemqty * 200);
	}
	if($businessday =='nextbusinessday'){
		$deliveryfeebybusinessbyitem = $deliveryfeebybusinessbyitem + ($itemqty * 100);
	}
	if($businessday =='inormorethantwobusinessday'){
		$deliveryfeebybusinessbyitem = 0;
	}
	if($businessday =='afterhoursdelivery'){
		$deliveryfeebybusinessbyitem = $deliveryfeebybusinessbyitem + ($itemqty * 200);
	}
	
	
	return $deliveryfeebybusinessbyitem;
}
function AdditonalFeeByBox($no_of_floors,$boxqty){
	$perstariprice=10;
	$additonalfeesumbybox = 0;
	if($no_of_floors >=1){
	$additonalfeesumbybox = $additonalfeesumbybox +(($no_of_floors * $perstariprice) * $boxqty);
	}
	else {$additonalfeesumbybox = 0;}
	return $additonalfeesumbybox;
}

function AdditonalFeeByItem($no_of_floors,$itemqty){
	$perstariprice=10;
	$additonalfeesumbybox = 0;
	if($no_of_floors >=1){
	$additonalfeesumbybox = $additonalfeesumbybox +(($no_of_floors * $perstariprice) * $itemqty);
	}
	else {
		$additonalfeesumbybox=0;
	}
	return $additonalfeesumbybox;
}

function getRemoteefee(){
	global $wpdb;
	$remotefee = $wpdb->get_results("SELECT remote_location_delivery FROM `wp_additional_fee`",ARRAY_A);
	return $remotefee;
}

function getHandlingFeeByBoxFrontend($boxprice,$boxqty,$boxstoreplan,$boxminprice){
	global $wpdb;
	$boxprice;
	$boxqty;
	$boxstoreplan;
	$boxminprice;
	$checkincheckoutchoice;
	$boxsum=0;
	if($boxstoreplan=='Store Plan'){
		$get_handlingfee = $wpdb->get_results("SELECT payasyourstore FROM wp_handling_fee where handlingfeeby ='handlingfeebybox'",ARRAY_A);
		$handlingfeebybox = $get_handlingfee[0]['payasyourstore'];
		$boxfinaltax = ($handlingfeebybox) * ($boxqty);
		//$boxfinaltax = (40) * ($boxqty);
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='3-5 Months'){
		$get_threefivemonthsfee = $wpdb->get_results("SELECT threefivemonths FROM wp_handling_fee where handlingfeeby ='handlingfeebybox'",ARRAY_A);
		$handlingfeebybox = $get_threefivemonthsfee[0]['threefivemonths'];
		
		$boxfinaltax = ($handlingfeebybox) * ($boxqty);
		//$boxfinaltax = (20) * ($boxqty);
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='6-11 Months'){
		$perboxprice = ($boxprice / $boxqty) ;
		if($boxqty==1){$boxfinaltax = 0;}
		else{ 
			$get_sixelevenmonthsfee = $wpdb->get_results("SELECT sixelevenmonths FROM wp_handling_fee where handlingfeeby ='handlingfeebybox'",ARRAY_A);
		$handlingfeebybox = $get_sixelevenmonthsfee[0]['sixelevenmonths'];
			$boxfinaltax = ($handlingfeebybox) * ($boxqty-1);
			//$boxfinaltax = (20) * ($boxqty-1);
		}
		
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			$boxsum = 0;
		}		
	}
	
	if($boxstoreplan =='12+ Months'){
		$perboxprice = ($boxprice / $boxqty) ;
		if($boxqty==1 || $boxqty==2){$boxfinaltax = 0;}
		else{ 
		$get_twelvemonthsplusfee = $wpdb->get_results("SELECT twelvemonthsplus FROM wp_handling_fee where handlingfeeby ='handlingfeebybox'",ARRAY_A);
		$handlingfeebybox = $get_twelvemonthsplusfee[0]['twelvemonthsplus'];
			
			$boxfinaltax = ($handlingfeebybox) * ($boxqty-2);
			//$boxfinaltax = (20) * ($boxqty-2);
		}
		
		if( $boxprice < $boxminprice){
			$boxsum=($boxsum + ($boxfinaltax));	
		}
		else{
			  $boxsum = 0;
		}		
	}
	
	
	return $boxsum;
}

function getHandlingFeeByItemFrontend($itemprice,$itemqty,$itemstoreplan,$itemminprice){
global $wpdb;
	$itemprice;
	$itemqty;
	 $itemstoreplan;
	$itemminprice;
	
	$itemsum=0;
	if($itemstoreplan=='Store Plan'){ 
	
	$get_payasyourstorefee = $wpdb->get_results("SELECT payasyourstore FROM wp_handling_fee where handlingfeeby ='handlingfeebyitem'",ARRAY_A);
		$handlingfeebyitem = $get_payasyourstorefee[0]['payasyourstore'];
		
		$itemfinaltax = ($handlingfeebyitem) * ($itemqty);
		 //$itemfinaltax = (20) * ($itemqty);
		if( $itemprice < $itemminprice){
			$itemsum=($itemsum + ($itemfinaltax));	
		}
		else{
			$itemsum=0;
		}	
	}
	if($itemstoreplan =='3-5 Months'){ 
		$get_threefivemonthsfee = $wpdb->get_results("SELECT threefivemonths FROM wp_handling_fee where handlingfeeby ='handlingfeebyitem'",ARRAY_A);
		$handlingfeebyitem = $get_threefivemonthsfee[0]['threefivemonths'];
			
			$itemfinaltax = ($handlingfeebyitem) * ($itemqty);
			//$itemfinaltax = (10) * ($itemqty);
			if( $itemprice < $itemminprice){
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
	if($itemstoreplan =='6-11 Months'){
			$peritemprice = ($itemprice / $itemqty) ;
			if($itemqty==1){ $itemfinaltax = 0;}
			else{  
			$get_sixelevenmonthsfee = $wpdb->get_results("SELECT sixelevenmonths FROM wp_handling_fee where handlingfeeby ='handlingfeebyitem'",ARRAY_A);
		$handlingfeebyitem = $get_sixelevenmonthsfee[0]['sixelevenmonths'];
				
				$itemfinaltax = ($handlingfeebyitem) * ($itemqty-1);
				//$itemfinaltax = (10) * ($itemqty-1);
			}
			if( $itemprice < $itemminprice){
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
		
		if($itemstoreplan =='12+ Months'){
			$peritemprice = ($itemprice / $itemqty) ;
			$get_twelvemonthsplusfee = $wpdb->get_results("SELECT twelvemonthsplus FROM wp_handling_fee where handlingfeeby ='handlingfeebyitem'",ARRAY_A);
			$handlingfeebyitem = $get_twelvemonthsplusfee[0]['twelvemonthsplus'];
			if($itemqty==1 || $itemqty==2){ $itemfinaltax = 0;}
			else{  
				
				$itemfinaltax = ($handlingfeebyitem) * ($itemqty-2);
				//$itemfinaltax = (10) * ($itemqty-2);
			}
			if( $itemprice < $itemminprice){
				
				$itemsum=($itemsum + ($itemfinaltax));	
			}
			else{
				$itemsum = 0;
			}	
		}
	return  $itemsum;	
}


function AdditonalFeeByBoxFrontend($no_of_floors,$boxqty){
	global $wpdb;
	$stairsfee = $wpdb->get_results("select * from wp_additional_fee",ARRAY_A);
	$perstariprice = $stairsfee[0]['stairs'];
	//$perstariprice=10;
	$additonalfeesumbybox = 0;
	if($no_of_floors >=1){
		
	$newmult = $additonalfeesumbybox + ($no_of_floors * $perstariprice);
	$additonalfeesumbybox = $newmult;
	}
	else {$additonalfeesumbybox = 0;}
	//print_r($stairsfee);
	return $additonalfeesumbybox;
}

function AdditonalFeeByItemFrontend($no_of_floors,$itemqty){
	$perstariprice=10;
	$additonalfeesumbybox = 0;
	if($no_of_floors >=1){
	$additonalfeesumbybox = $additonalfeesumbybox +(($no_of_floors * $perstariprice) * $itemqty);
	}
	else {
		$additonalfeesumbybox=0;
	}
	return $additonalfeesumbybox;
}

function getRemoteefeeFrontend(){
	global $wpdb;
	$remotefee = $wpdb->get_results("SELECT remote_location_delivery FROM `wp_additional_fee`",ARRAY_A);
	
	return $remotefee[0]['remote_location_delivery'];
}

function getDeliveryStatusByEmail($email){
	global $wpdb;
	$count_query =$wpdb->get_results("SELECT * FROM wp_schedule_return_history WHERE useremail ='$email'",ARRAY_A);
	$returnflag = 0;
	$returnstatus = 1;
	if($count_query){
		$delivery_status = $count_query[0]['delivery_status'];
		if($delivery_status==0){
			$count_query ="SELECT count(*) AS total FROM wp_schedule_return_history WHERE useremail ='$email' AND delivery_status='0'";
			$num_return = $wpdb->get_var($count_query);
			return $num_return;
			}
			else
			{
				$count_query ="SELECT count(*) AS total FROM wp_schedule_return_history WHERE useremail ='$email' AND delivery_status='1'";
				$num_return = $wpdb->get_var($count_query);
				return $num_return;
			}
	}
	else{ return $returnflag; }

}

/* function to get all schedule a return information lists */
function getScheduleAReturnInformation(){
	global $wpdb;
	$getreturnino = $wpdb->get_results("select * from wp_schedule_return_history",ARRAY_A);
	return $getreturnino;
}
/* function to get all schedule a return information lists */


/* function to get schedule a pickup information lists */
function getScheduleAPickupInformation($pickupid,$email){
	global $wpdb;
	$getpickupdetails = $wpdb->get_results("SELECT * FROM wp_schedule_pickup INNER JOIN wp_schedule_pickup_products ON wp_schedule_pickup.schedule_pickup_id = wp_schedule_pickup_products.schedule_a_pickup_id INNER JOIN wp_schedule_pickup_order ON wp_schedule_pickup_products.schedule_pickup_product_id = wp_schedule_pickup_order.schedule_a_pickup_product_id where wp_schedule_pickup_order.payment_status='paid' AND wp_schedule_pickup_order.user_email_pickup='$email' AND  wp_schedule_pickup_order.schedule_pickup_orderid =$pickupid",ARRAY_A);
	return $getpickupdetails;
}
/* function to get a pickup information lists */


function ChangeReturnAScheduleStatus(){
global $wpdb;
if(isset($_POST['schedulereturnhistoryid'])){
$schedule_return_history_id = $_POST['schedulereturnhistoryid'];
$selects = $wpdb->get_results("select * from wp_schedule_return_history where schedule_return_history_id = $schedule_return_history_id ",ARRAY_A);
//print_r($selects);
$delivelery_stats=$selects[0]['delivery_status'];
if($delivelery_stats == '0'){ $stats = '1'; } else{ $stats = '0'; }

$updates = $wpdb->update('wp_schedule_return_history', array('delivery_status'=>$stats), array('schedule_return_history_id'=>$schedule_return_history_id));


echo $updates;
}
die();
}

add_action("wp_ajax_ChangeReturnAScheduleStatus", "ChangeReturnAScheduleStatus");
add_action("wp_ajax_nopriv_ChangeReturnAScheduleStatus", "ChangeReturnAScheduleStatus");

/* function to update pickup status in pickup order table */

function ChangeSchedulePickupOrderStatus(){
global $wpdb;
if(isset($_POST['schedulepickuporderid'])){
$schedule_order_pickup_id = $_POST['schedulepickuporderid'];
$selects = $wpdb->get_results("select * from wp_schedule_pickup_order",ARRAY_A);
//print_r($selects);
$delivelery_stats=$selects[0]['pickup_status'];
if($delivelery_stats == '0'){ $stats = '1'; } else{ $stats = '0'; }

$updates = $wpdb->update('wp_schedule_pickup_order', array('pickup_status'=>$stats), array('schedule_pickup_orderid'=>$schedule_order_pickup_id));

//echo $stats;
echo $updates;
}
die();
}

add_action("wp_ajax_ChangeSchedulePickupOrderStatus", "ChangeSchedulePickupOrderStatus");
add_action("wp_ajax_nopriv_ChangeSchedulePickupOrderStatus", "ChangeSchedulePickupOrderStatus");


/* function to update pickup status in pickup order table */

/* function to show return a schedule products lists starts here *//* function to get all return products lists with processing */
function getProcessingProductsLists($email){	
global $wpdb;	$getinfo = $wpdb->get_results("select * from wp_schedule_return_history_order INNER JOIN wp_schedule_return_history onwp_schedule_return_history_order.useremail=wp_schedule_return_history.useremail INNER JOIN wp_boximages ONwp_schedule_return_history.useremail= wp_boximages.useremail where wp_schedule_return_history.delivery_status=1 AND wp_schedule_return_history_order.useremail='$email'GROUP BY wp_schedule_return_history_order.wp_schedule_return_history_order_id",ARRAY_A);	return $getinfo;}/* function to get all return products lists with processing */
function showScheduleReturnProcessing($email){
	global $wpdb;
	
	$selets = $wpdb->get_results("select delivery_status from wp_schedule_return_history where useremail='$email'", ARRAY_A);
	return $selets;
}
/* function to show return a schedule products lists ends here */ 

/* function to show pick up schedule products lists starts here */
function getPickUpScheduleItems($email,$userid,$attachid){
	global $wpdb;	$itemhtml = '';	$newhtml='';	
	$schedulereturnbutton='';	
	$getitems = $wpdb->get_results("SELECT * FROM wp_schedulereturninformation INNER JOIN wp_schedule_return_history ON wp_schedulereturninformation.scheduleareturnid= wp_schedule_return_history.schedulereturnid INNER JOIN  wp_product_return_lists ON wp_schedule_return_history.schedulereturnid=wp_product_return_lists.schedule_return_id where wp_schedulereturninformation.useremail='$email' and wp_schedule_return_history.delivery_status='1' ",ARRAY_A);		$getpickupstatus = "select count(*) from wp_schedule_pickup_order where user_email_pickup='$email' AND pickup_status='0'";		
	$pickup_count = $wpdb->get_var($getpickupstatus);	
	if($pickup_count==1){		
	$newhtml ='		<div class="inputcheckboxvals allstatus"><span class="leftstufcheckbox status">Processing</span></div>				';	}	else{		$newhtml ='		<div class="inputcheckboxvals"><input type="checkbox" name="stuffcheckbox" value="'.$order_product_id.'" class="leftstufcheckbox pickupschedule" '.$checked.'>					</div>';		$schedulereturnbutton='		<div class="col-md-4 submitbuttonbystuff no-padding schedulereturn">		<input type="hidden" name="orderproductid" value="" class="userallinformation">		<input class="submitbystuffs" type="submit" name="submit" value="Schedule a pick up">	</div><!-- div class col-md-4 submitbuttonbystuff no-padding schedulereturn -->		';	}	
	$i=0;
	$itemhtml.='
		<div class="col-xs-12 table-responsive no-padding">
			<div class="searchformbystuff no-padding">
				<form method="POST" action="'.get_the_permalink().'?type=schedulecustomerpickup" id="searchbystuf">
				<div class="col-md-8 inputfieldbystuff no-padding">
		';
	
	foreach($getitems as $schedulerpickup){
		//print_r($schedulerpickup);
		$product_name = $schedulerpickup['product_name'];
		if($product_name =='Document Box'){$pro_title = 'AD000'.$userid;}
		if($product_name =='Large Size Items'){$pro_title = 'AL000'.$userid;}
		if($product_name =='Medium Items'){$pro_title = 'AM000'.$userid;}
		if($product_name =='Small Items'){$pro_title = 'AS000'.$userid;}
		if($product_name =='Standard Box'){$pro_title = 'AS000'.$userid;}
		if($product_name =='Wardrobe Box'){$pro_title = 'AW000'.$userid;}
		
		$boximageid=$schedulerpickup['attachment_ids'];
		$order_product_id = $schedulerpickup['order_product_id'];
		$imageattachmentids = $schedulerpickup['attachment_ids'];
		$imageattributes = wp_get_attachment_image_src( $attachment_id =$imageattachmentids,$size = 'full' );
		$product_id=$schedulerpickup['product_id'];
		$protitles = getByBoxItem($product_id);
		$boxtitles = $protitles[0]['name'];
		
		if($boxtitles =='Store by the box')
		{ 	$boxtitles = 'By Box';
			
		}
		if($boxtitles =='Store by the item')
		{ $boxtitles = 'By Item';}
	
	if( strpos($attachid, ',') !== false )
				{
					$checked = "checked";
				}
				else{if($attachid == $order_product_id){ $checked = "checked";} else {$checked='';}}
		$itemhtml.='			<div class="col-md-3 allstuffs no-padding">					<!--<h3 class="boxtypeheader">'.$boxtitles.'</h3>					<div class="inputcheckboxvals"><input type="checkbox" name="stuffcheckbox" value="'.$order_product_id.'" class="leftstufcheckbox pickupschedule" '.$checked.'>					</div>-->';					$itemhtml.=$newhtml;					$itemhtml.='					<img src="'.$imageattributes[0].'">					
		<h5 class="boxid">					
		<a class="viewsubimagespickup" href="'.get_the_permalink().'?type=addmystuffpickupsubimage&attachmentids='.$boximageid.'&protitle='.$product_name.'">'.$pro_title.'</a>											</h5>					
		<!-- add description later 					
		<h5 class="boxid">Coming Soon</h5>';
		$boxdesc = getDescriptionByBoxIdmainid($imageattachmentids);
								
		$main_image_attachment_id= $boxdesc[0]['main_image_attachment_id'];
		
		$sub_image_attachment_id=$boxdesc[0]['sub_image_attachment_id'];
			
		//echo $boxdesc[0]["description"];
			
		$itemhtml.='
		<h5 class="boxid"><a class="viewsubimages" href="'.get_the_permalink().'?type=edit_sub_images_pickup_schedule&mainattachid='.$main_image_attachment_id.'&action=editsubmainimages&amp;editimageid ='.$sub_image_attachment_id.'">'.$boxdesc[0]["description"].'</a></h5>
		<div class="col-md-12 descriptionsbystuff no-padding"></div>
		</div>';		
	}
	$itemhtml.='		</div> <!-- col-md-8 inputfieldbystuff no-padding ends here -->';		$itemhtml.=$schedulereturnbutton;		$itemhtml.='		</form> <!-- form ends here -->		</div><!-- searchformbystuff no-padding ends here -->		</div> <!--  class="col-xs-12 table-responsive no-padding ends here -->		';
	return $itemhtml;

	//getByBoxItem($productid);
}

/* function to show pick up schedule products lists ends here */

/* Function to get billing payment history starts here */

function getBillingPaymentHistory($useremail){
global $wpdb;

$selects =$wpdb->get_results("SELECT * FROM `wp_orders` INNER JOIN wp_order_products ON wp_orders.order_id = wp_order_products.order_id where wp_orders.useremail='$useremail' group by wp_order_products.`useremail`", ARRAY_A);

return $selects;
}
/* Function to get billing payment history starts here */

/* check schedule a pick up sub images table starts here */
function getSchedulePickUpDatas($main_attachment_id){
	global $wpdb;
	$select_schedule_subimges = $wpdb->get_results("select * from wp_box_sub_images_pick_up where main_image_attachment_id= $main_attachment_id",ARRAY_A);
	return $select_schedule_subimges;
}

/* check schedule a pick up sub images table ends here */

/* get schedule pick up category lists */
function getSchedulePickUpCategoryLists(){
	global $wpdb;
	$newHtml = '';
	$getCategory = $wpdb->get_results("SELECT DISTINCT (schedule_category) FROM `wp_schedule_category_keyword`",ARRAY_A);
	$newHtml.='<select name="categorylists" class="category_lits_pickup" required>';
	$newHtml.='<option value="">Select Category</option>';
	foreach($getCategory as $fincatlists){
		//print_r($fincatlists);
		$newHtml.='<option>'.$fincatlists["schedule_category"].'</option>';
	}
	$newHtml.='</select>
	<span class="submit-loading" style="display:none;"><i class="fa fa-refresh fa-spin"></i></span>';
	
	return $newHtml;
}
/* get schedule pick up category lists */

/* get schedule pick up keywords lists */
function getSchedulePickUpKeywordLists(){
	global $wpdb;
	//print_r($_POST);
	$selectcategory = $_POST['selectcategory'];
	
	$newHtml = '';
	$getKeywords = $wpdb->get_results("SELECT DISTINCT (schedule_keyword)
FROM `wp_schedule_category_keyword` where schedule_category ='$selectcategory'",ARRAY_A);
	$newHtml.='<select name="keywordlists[]" class="category_lits_pickup" multiple >';
	foreach($getKeywords as $finkeywordlists){
		$newHtml.='<option>'.$finkeywordlists["schedule_keyword"].'</option>';
	}
	$newHtml.='</select>';
	
	echo $newHtml;
	die();
}

add_action("wp_ajax_getSchedulePickUpKeywordLists", "getSchedulePickUpKeywordLists");
add_action("wp_ajax_nopriv_getSchedulePickUpKeywordLists", "getSchedulePickUpKeywordLists");
/* get schedule pick up keywords lists */

function deleteScheduleImagesRecordsPickup(){
	global $wpdb;
	$picupids = $_POST['pickupids'];
	$subimgid = $_POST['subimgid'];
	
	$deletes = $wpdb->delete('wp_box_sub_images_pick_up', array('pickup_sub_images_id' => $picupids ) );
	wp_delete_attachment($subimgid);
	echo $deletes;
	die();
}
add_action("wp_ajax_deleteScheduleImagesRecordsPickup", "deleteScheduleImagesRecordsPickup");
add_action("wp_ajax_nopriv_deleteScheduleImagesRecordsPickup", "deleteScheduleImagesRecordsPickup");

/* delete upload image by customer in schedule a return section images */
function deleteSchedulereturnimage(){
	global $wpdb;
	$deleteimageid = $_POST['deleteimageid'];
	$deletes = $wpdb->delete('wp_box_images_bycustomer', array('moreattachmentids' => $deleteimageid ) );
	wp_delete_attachment($deleteimageid);
	echo $deletes;
	die();
}

add_action("wp_ajax_deleteSchedulereturnimage", "deleteSchedulereturnimage");
add_action("wp_ajax_nopriv_deleteSchedulereturnimage", "deleteSchedulereturnimage");

/* delete upload image by customer in schedule a return section images */


/* registration function added by kirti mam */
function checkuser_phonenumber($phonenum)
{
	$submitted_user_phone=$phonenum;
	$allusers = get_users(array(
	'meta_key'     => 'user_phone',
	'meta_value'=>$submitted_user_phone
	));
	$usermetaarr=array();
	foreach ($allusers as $alluser) {
		$userphone_meta=get_user_meta( $alluser->ID,'user_phone',true);
		$usermetaarr[]=$userphone_meta;
	}
	
	if(in_array($submitted_user_phone, $usermetaarr))
	{
		return true;

	}
	else
	{
		return false;
	}
}

/* Function to edit sub-images by schedule a return section images */
function editSubImagesSchRetById($mainattachid,$subattachid){
	global $wpdb;
	$getImages = $wpdb->get_results("select * from wp_box_images_bycustomer where attachmentids= $mainattachid AND moreattachmentids = $subattachid",ARRAY_A);
	return $getImages;
}
/* Function to edit sub-images by schedule a return section images */

/* Function to get product id by product title */
function getProductIdByName($proname){
	global $wpdb;
	$productname = $wpdb->get_results("SELECT ID FROM `wp_posts` where post_name='$proname'",ARRAY_A);
	$pro_id= $productname[0]['ID'];
	return $pro_id;
}
/* Function to get product id by product title */

/* getting schedule a return uploaded images by customer in schedule a pick up section */

/* function to get number of products on my stuff page after pickup order pickup status 1*/
function GetPickupStatusDelivery($email)
{
	global $wpdb;
	$count_pickup_order_Delivery = "select count(*) from wp_schedule_pickup_order where user_email_pickup='$email' AND pickup_status='1'";
	
	$pickup_count_Delivery = $wpdb->get_var($count_pickup_order_Delivery);
	return $pickup_count_Delivery;
	
}

/* function to get number of products on my stuff page after pickup order pickup status 1*/


function getScheduleReturnImages($userid,$productid){
	global $wpdb;
	$getSpeciicimages = $wpdb->get_results("SELECT * FROM `wp_boximages` INNER JOIN wp_box_images_bycustomer ON wp_boximages.boximageid=wp_box_images_bycustomer.boximageid where wp_boximages.productid =$productid AND wp_box_images_bycustomer.addedby=$userid",ARRAY_A);
	return $getSpeciicimages;
}
/* getting schedule a return uploaded images by customer in schedule a pick up section */


/*
function registration_email_alert( $user_id ) {
    $user    = get_userdata( $user_id );
    $username   = $user->user_login;
    $email   = $user->user_email;
    $message = "<h3>Please click below link to active Account</h3><a href='".home_url('email-varified')."/?user_username=".base64_encode($username)."&user_email=".base64_encode($email)."&user_status=1'>click here</a>";
    $headers = array('Content-Type: text/html; charset=UTF-8');

    wp_mail( $email, 'New User registration', $message, $headers );
}
add_action('user_register', 'registration_email_alert');
*/



add_action( 'widgets_init', 'create_custom_wpml_sidebar' );
function create_custom_wpml_sidebar() {
    register_sidebar( array(
        'name' => __( 'WPML Sidebar', 'theme-slug' ),
        'id' => 'sidebar-8',
        'description' => __( 'wpml Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
    ) );
}

function getDescriptionByBoxIdmainid($boxid){
	global $wpdb;
	$selects = $wpdb->get_results("SELECT * FROM `wp_box_sub_images_pick_up` where main_image_attachment_id =$boxid group by main_image_attachment_id", ARRAY_A);
	return $selects;
}
/* function to get box image description */

/* function to delete public holidays */

function deletepublicholidays() {
global $wpdb;
$html='';
$holidayid	= $_POST['holidayid'];
$delete = $wpdb->delete('publicholidays', array( 'holidayid' => $holidayid ) );
echo $delete;	
die();
}
add_action("wp_ajax_deletepublicholidays", "deletepublicholidays");
add_action("wp_ajax_nopriv_deletepublicholidays", "deletepublicholidays");


/* function to delete Black days */

function deleteblackdays() {
global $wpdb;
$html='';
$blackdayid	= $_POST['blackdayid'];
$deletes = $wpdb->delete('blackday', array( 'blackdayid' => $blackdayid ) );
echo $deletes;	
die();
}
add_action("wp_ajax_deleteblackdays", "deleteblackdays");
add_action("wp_ajax_nopriv_deleteblackdays", "deleteblackdays");


/* function to check date is same date or another date */

function checkdatetime() {
global $wpdb;
$html='';

$selecteddates	= $_POST['selecteddate'];
date_default_timezone_set("Asia/Kolkata");
$current_time = date("h:i:sa");

$sameday_before_aftertime = "10:00:00am";

$gettimeslots = $wpdb->get_results("select * from  timeblock where status=1 AND timeslot= '$starttime' ",ARRAY_A);


$getholidays = $wpdb->get_results("select time_block  from publicholidays WHERE `holiday_date`='$selecteddates'",ARRAY_A);
$time_block = "time_block";
foreach($getholidays as $newholidays)
{
	
	$blockdayslists[]="'$newholidays[$time_block]'".",";
	
}
//print_r($blockdayslists);
$holidaytime = '';
foreach($blockdayslists as $i=>$k) {
    $holidaytime .=$k;
}
$holidaytime = rtrim($holidaytime,',');

//$holidaytime = $getholidays[0]['time_block'];

$timeblockid= $gettimeslots[0]['timeblockid'];
if($sunday == 'Sunday'){
	$getstarttime = $wpdb->get_results("select * from timeblock where status=1",ARRAY_A);
}
else 
{
if((strtotime($current_time)) <= (strtotime($sameday_before_aftertime)))
{
	$starttime = "1:00pm-5:00pm "; 
	
	$gettimeslots = $wpdb->get_results("select * from  timeblock where status=1 AND timeslot= '$starttime' ",ARRAY_A);

	$timeblockid= $gettimeslots[0]['timeblockid'];
	
		
	$getstarttime = $wpdb->get_results("select * from timeblock where timeblockid >=$timeblockid AND timeslot NOT IN($holidaytime) AND status=1",ARRAY_A);
	
} 

if((strtotime($current_time)) >= (strtotime($sameday_before_aftertime)))
{
	$starttime = "7:00am-9:00am";
	
	$getstarttime = $wpdb->get_results("select * from timeblock where status=1 AND timeslot NOT IN($holidaytime)",ARRAY_A);
}

}

foreach($getstarttime as $timeslotsvals)
{
	
	//print_r($timeslotsvals);
	echo $timeslots= $timeslotsvals['timeslot'];
	
	echo $selectoptions='<option value="'.$timeslots.'" >'.$timeslots.'</option>';
}

	
die();
}
add_action("wp_ajax_checkdatetime", "checkdatetime");
add_action("wp_ajax_nopriv_checkdatetime", "checkdatetime");



/* function to check date is next date or another date */

function checkdatetimenextday() {
global $wpdb;
$html='';

$selecteddates	= $_POST['selecteddate'];
date_default_timezone_set("Asia/Kolkata");
$current_time = date("h:i:sa");

$sameday_before_aftertime = "10:00:00am";


$getholidays = $wpdb->get_results("select time_block  from publicholidays WHERE `holiday_date`='$selecteddates'",ARRAY_A);
//print_r($getholidays);
if(!empty($getholidays)) {
$time_block="time_block";
foreach($getholidays as $newholidays)
{
	
	$blockdayslists[]="'$newholidays[$time_block]'".",";
	
}
//print_r($blockdayslists);
$holidaytime = '';
foreach($blockdayslists as $i=>$k) {
    $holidaytime .=$k;
}
 $holidaytime = rtrim($holidaytime,',');

//$holidaytime = $getholidays[0]['time_block'];
}
else{
	
	$getholidays = $wpdb->get_results("select * from timeblock where status=1",ARRAY_A);
	$holidaytime = $getholidays[0]['timeslot'];
}
if($sunday == 'Sunday'){
	$getstarttime = $wpdb->get_results("select * from timeblock where status=1",ARRAY_A);
}
else 
{
if((strtotime($current_time)) <= (strtotime($sameday_before_aftertime)))
{
	$starttime = "7:00am-9:00am";
	$getstarttime = $wpdb->get_results("select * from timeblock where status=1",ARRAY_A);
	
	
} 

if((strtotime($current_time)) >= (strtotime($sameday_before_aftertime)))
{
	$starttime = "7:00am-9:00am";
	if(!empty($getholidays)) {
		$gettimeslots = $wpdb->get_results("select * from  timeblock where status=1 AND timeslot= '$starttime' AND timeslot NOT IN($holidaytime)",ARRAY_A);

	$timeblockid= $gettimeslots[0]['timeblockid'];
	
	$getstarttime = $wpdb->get_results("select * from timeblock where timeblockid >=$timeblockid AND timeslot NOT IN($holidaytime) AND status=1",ARRAY_A);
	
	}
	else{
		$gettimeslots = $wpdb->get_results("select * from  timeblock where status=1 AND timeslot= '$starttime'",ARRAY_A);

	$timeblockid= $gettimeslots[0]['timeblockid'];
	
	$getstarttime = $wpdb->get_results("select * from timeblock where timeblockid >=$timeblockid AND status=1",ARRAY_A);
	}
	
}

}

$j=0;
foreach($getstarttime as $timeslotsvals)
{
	$timeslots= $timeslotsvals['timeslot'];
	echo $selectoptions='<option value="'.$timeslots.'" >'.$timeslots.'</option>';
$j++;
}

	
die();
}
add_action("wp_ajax_checkdatetimenextday", "checkdatetimenextday");
add_action("wp_ajax_nopriv_checkdatetimenextday", "checkdatetimenextday");
/* function to check date is in one or more than one date or another date */

function checkdatetimetwobusinessday() {
global $wpdb;
$html='';

$selecteddates	= $_POST['selecteddate'];
date_default_timezone_set("Asia/Kolkata");
$current_time = date("h:i:sa");

$getholidays = $wpdb->get_results("select time_block  from publicholidays WHERE `holiday_date`='$selecteddates'",ARRAY_A);

if(!empty($getholidays)){
foreach($getholidays as $blocktimes){
	
	$timblock= $blocktimes['time_block'];
	
	$newtimblock[] = "'$timblock'".",";	
}
$order_product_idresult = '';

foreach($newtimblock as $i=>$k) {
    $order_product_idresult .=$k;
}
$order_product_idresult = rtrim($order_product_idresult,',');

$getunblock = $wpdb->get_results("SELECT timeslot FROM `timeblock` where timeslot NOT IN ($order_product_idresult)",ARRAY_A);
foreach($getunblock as $unblock_times)
{
	$timearray = $unblock_times["timeslot"];
	echo '<option vlaue="'.$unblock_times["timeslot"].'">'.$unblock_times["timeslot"].'</option>';
	
} 
}
else{
$getalltimes = $wpdb->get_results("SELECT timeslot FROM `timeblock` where status=1",ARRAY_A);

foreach($getalltimes as $unblock_times)
{
	$timearray = $unblock_times["timeslot"];
	echo '<option vlaue="'.$unblock_times["timeslot"].'">'.$unblock_times["timeslot"].'</option>';
	
} 	
}
	die();
}
add_action("wp_ajax_checkdatetimetwobusinessday", "checkdatetimetwobusinessday");
add_action("wp_ajax_nopriv_checkdatetimetwobusinessday", "checkdatetimetwobusinessday");

/* front end schedule pickup before payment page datepicker when boxes are not order */

function getdatepickerdates() {
global $wpdb;
$html='';

echo $selecteddates	= $_POST['selecteddate'];
date_default_timezone_set("Asia/Kolkata");
$current_time = date("h:i:sa");

$getholidays = $wpdb->get_results("select time_block  from publicholidays WHERE `holiday_date`='$selecteddates'",ARRAY_A);

if(!empty($getholidays)){
foreach($getholidays as $blocktimes){
	
	$timblock= $blocktimes['time_block'];
	
	$newtimblock[] = "'$timblock'".",";	
}
$order_product_idresult = '';

foreach($newtimblock as $i=>$k) {
    $order_product_idresult .=$k;
}
$order_product_idresult = rtrim($order_product_idresult,',');

$getunblock = $wpdb->get_results("SELECT timeslot FROM `timeblock` where timeslot NOT IN ($order_product_idresult)",ARRAY_A);
foreach($getunblock as $unblock_times)
{
	$timearray = $unblock_times["timeslot"];
	echo '<option vlaue="'.$unblock_times["timeslot"].'">'.$unblock_times["timeslot"].'</option>';
	
} 
}
else{
$getalltimes = $wpdb->get_results("SELECT timeslot FROM `timeblock` where status=1",ARRAY_A);

foreach($getalltimes as $unblock_times)
{
	$timearray = $unblock_times["timeslot"];
	echo '<option vlaue="'.$unblock_times["timeslot"].'">'.$unblock_times["timeslot"].'</option>';
	
} 	
}	
die();
}
add_action("wp_ajax_getdatepickerdates", "getdatepickerdates");
add_action("wp_ajax_nopriv_getdatepickerdates", "getdatepickerdates");
/* front end schedule pickup before payment page datepicker when boxes are not order*/

/* function to delete category/keyword schedule/pickup admin side page */

function deleteCateKeyword() {
global $wpdb;
$html='';
if(isset($_POST['catkeyid'])){
	echo $catkeyid = trim($_POST['catkeyid']);
	
	$delete = $wpdb->delete('wp_schedule_category_keyword', array( 'schedule_category_keyword_id' => $catkeyid ) );
}
	
die();
}
add_action("wp_ajax_deleteCateKeyword", "deleteCateKeyword");
add_action("wp_ajax_nopriv_deleteCateKeyword", "deleteCateKeyword");

/* function to delete category/keyword schedule/pickup admin side page */

/* function for refund process */
/*
function refundPayment() {
global $wpdb;

$html='';
if(isset($_POST['refundid'])){
$refundid = trim($_POST['refundid']);
$product_amts = $wpdb->get_results("SELECT * FROM `wp_schedule_return_history_order` WHERE `transaction_number`='$refundid'"); 
foreach ($product_amts as $product_amt) {
$amt = round($product_amt->item_amount);
}

$sandbox_username = get_option('sandbox_username');
$sandbox_password = get_option('sandbox_password');
$sandbox_signature = get_option('sandbox_signature');
$fields= array(
'METHOD' => urlencode('RefundTransaction'),
'VERSION' => urlencode('124'),
'PWD' => urlencode($sandbox_password),
'USER' => urlencode($sandbox_username),
'SIGNATURE' => urlencode($sandbox_signature),
'TRANSACTIONID' => urlencode($refundid),
'AMT' => urlencode($amt),
'REFUNDTYPE' => urlencode('Full'),
'REFUNDSOURCE' => urlencode('instant'),
//'RETURNURL' => 'http://localhost/klutterclearnew/confirm.php', //without urlencode()
//'CANCELURL' => 'http://localhost/klutterclearnew/cancel.php'  //without urlencode()
);
echo '<pre>';
print_r($fields);
echo '<pre>';
$fields_string=null;
foreach($fields as $key=>$value) {
$fields_string .= $key.'='.$value.'&';
}
rtrim($fields_string, '&');
// create a new cURL resource
$ch = curl_init();

// set URL and other appropriate options
curl_setopt($ch, CURLOPT_URL, "https://api-3t.sandbox.paypal.com/nvp");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch,CURLOPT_VERBOSE ,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

curl_setopt($ch,CURLOPT_POST, count($fields));
curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($fields));
curl_setopt($ch, CURLOPT_HEADER, 0);

// grab URL and pass it to the browser
$retVal=curl_exec($ch);

// close cURL resource, and free up system resources
curl_close($ch);

if(!$retVal)
return array("ERROR_MESSAGE"=>"Refund Transaction failed".
curl_error($ch)."(".curl_errno($curl_var).")");
}
die();
}
add_action("wp_ajax_refundPayment", "refundPayment");
add_action("wp_ajax_nopriv_refundPayment", "refundPayment");
*/
/* function for refund process ends here */

/* Function to get all box/image id by email and order id starts here */

function getIdNumberByEmail($email,$order_product_id){
	global $wpdb;
	$umail="'$email'";
	$proids=array();
	$getidnumber= $wpdb->get_results("SELECT * FROM `wp_boximages` WHERE `order_product_id`=$order_product_id AND `useremail`=".$umail,ARRAY_A);
	foreach($getidnumber as $vals){
	$proids[] = $vals['boxid'];
	$proids[] = $vals['box_add_date'];
	}
	return $proids;
}

function changepaymentstatus(){
	global $wpdb;
	print_r($_POST);
	$tablename = trim($_POST['tablename']);
	$id = trim($_POST['tableordeid']);
	$columnid = trim($_POST['tablecolid']);
	$columnstatus = trim($_POST['tablestatusid']);
	//echo "select paymentstatus from $tablename where paymentstatus!='' AND order_id=$id";
	$getstatus=$wpdb->get_results("select $columnstatus from $tablename where $columnstatus!='' AND $columnid=$id",ARRAY_A);
	
	if(!empty($getstatus)){
		foreach($getstatus as $getvals){
						
			$status = $getvals['paymentstatus'];
			if(($status=='DUE')||($status=='due')){echo $changestatus="paid";}
			$update = $wpdb->update($tablename,array($columnstatus=>"Paid"), array($columnid=>$id));
			echo $update;
			
		}
	}
	
	die();
}
add_action("wp_ajax_changepaymentstatus", "changepaymentstatus");
add_action("wp_ajax_nopriv_changepaymentstatus", "changepaymentstatus");

/* Function to get all box/image id by email and order id ends here */


/*
register_activation_hook(__FILE__, 'my_activation');

function my_activation() {
    if (! wp_next_scheduled ( 'my_hourly_event' )) {
	wp_schedule_event(time(), 'hourly', 'my_hourly_event');
    }
}

add_action('my_hourly_event', 'do_this_hourly');

function do_this_hourly() {
  wp_mail( 'votivewp.bijay@gmail.com', 'Automatic email', 'Automatic scheduled email from WordPress to test cron');
}*/



function getBillingManagementDetails($productid,$orderproductid,$email)
{
	global $wpdb;
	
	$getino=$wpdb->get_results("select * from wp_billingmanagement where product_id=$productid AND order_product_id=$orderproductid AND user_email='$email' ",ARRAY_A);
	if(!empty($getino)){
	return $getino;
	}
}

function deleteBillingManagementTable(){
	global $wpdb;
	//print_r($_POST);
	$billingid = trim($_POST['billingid']);
	$emailid = trim($_POST['emailid']);
	$delete = $wpdb->delete('wp_billingmanagement', array( 'billing_main_id' => $billingid,'user_email'=>$emailid ) );
	echo $delete;
	die();
}
add_action("wp_ajax_deleteBillingManagementTable", "deleteBillingManagementTable");
add_action("wp_ajax_nopriv_deleteBillingManagementTable", "deleteBillingManagementTable");



function deleteOtherBillingManagementTable(){
	global $wpdb;
	//print_r($_POST);
	$billingid = trim($_POST['billingid']);
	$emailid = trim($_POST['emailid']);
	$delete = $wpdb->update('wp_billingmanagement', array( 
	'storage_fee'=>'',
	'handling_fee'=>'',
	'delivery_fee'=>'',
	'additional_fee'=>'',
),array('billing_main_id'=>$billingid));
	echo $delete;
	die();
}
add_action("wp_ajax_deleteOtherBillingManagementTable", "deleteOtherBillingManagementTable");
add_action("wp_ajax_nopriv_deleteOtherBillingManagementTable", "deleteOtherBillingManagementTable");




function tml_title( $title, $action ) {
	if(ICL_LANGUAGE_CODE=='zh-hant'){
		$trans1 = '註冊';
		$trans2 = '忘記密碼';
		$trans3 = '登入';
	}
else{
	$trans1 = 'Sign Up';
	$trans2 = 'Lost Password';
	$trans3 = 'Log In';
}
	switch ( $action ) {
		case 'register' :
			$title = $trans1;
			break;
		case 'lostpassword':
		case 'retrievepassword':
		case 'resetpass':
		case 'rp':
			$title = $trans2;
			break;
		case 'login':
		default:
			$title = 'Sign In';
	}
	return $title;
}
add_filter( 'tml_title', 'tml_title', 11, 2 );


/* Delete promotion code and amount */
function updatecoupandiscount() {$html='';
global $wpdb;
echo $discountids = $_POST['discountids'];
$delete = $wpdb->delete('wp_discountcoupans', array( 'discount_id' => $discountids) );
echo $delete;

die();
}
add_action("wp_ajax_updatecoupandiscount", "updatecoupandiscount");
add_action("wp_ajax_nopriv_updatecoupandiscount", "updatecoupandiscount");
/* Delete promotion code and amount ends here */

/* Delete promotion code and amount */
function deletecashcoupan() {$html='';
global $wpdb;
echo $cashcoupanid = $_POST['cashcoupanid'];
$delete = $wpdb->delete('wp_cashcoupancode', array( 'cashcoupan_id' => $cashcoupanid) );
echo $delete;
die();

}
add_action("wp_ajax_deletecashcoupan", "deletecashcoupan");
add_action("wp_ajax_nopriv_deletecashcoupan", "deletecashcoupan");

/* Front end checkout page schedule a pickup page coupon code */

function couponsCodeCheck() {
$html='';
global $wpdb;
$getdurationsfree = $_POST['getdurationsfree'];
$inuttextvals = $_POST['inuttextvals'];
$timeduration=array(
'1'=>'First Month',
'2'=>'Second Month',
'3'=>'Third Month',
'4'=>'Fourth Month',
'5'=>'Fifth Month',
'6'=>'Sixth Month',
'7'=>'Seventh Month',
'8'=>'Eighth Month',
'9'=>'Nineth Month',
'10'=>'Tenth Month',
'11'=>'Eleventh Month',
'12'=>'Twelveth Month',
);
if($getdurationsfree=='Free Month Code'){

$getrestulsts = $wpdb->get_row("select promotion_duration from freemonthpromptation where promotion_code='$inuttextvals'",ARRAY_A);

$promotionduration = $getrestulsts['promotion_duration'];

if (in_array($promotionduration, $timeduration))
  {
	$key = array_search($promotionduration, $timeduration); 
	echo $key;
} 
}

if($getdurationsfree=='Discount Code'){
	$getrestulstsdiscont = $wpdb->get_row("select * from wp_discountcoupans where discount_coupan_code='$inuttextvals'",ARRAY_A);
	if(!empty($getrestulstsdiscont)){
		$discount_coupan_amount = $getrestulstsdiscont['discount_coupan_amount'];
		echo $discount_coupan_amount;
	}
}

if($getdurationsfree=='Cash Coupon Code')
{
	$getrestulstscashcpn = $wpdb->get_row("select * from wp_cashcoupancode where cashcoupan_code='$inuttextvals'",ARRAY_A);
	if(!empty($getrestulstscashcpn)){
		$cashcoupan_amount	 = $getrestulstscashcpn['cashcoupan_amount'];
		echo $cashcoupan_amount	;
	}
}
die();

}
add_action("wp_ajax_couponsCodeCheck", "couponsCodeCheck");
add_action("wp_ajax_nopriv_couponsCodeCheck", "couponsCodeCheck");

/* Front end checkout page schedule a pickup page coupon code ends here */