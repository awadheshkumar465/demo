<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header();

if(isset($_SESSION['signup_user'])){
$user = wp_get_current_user();
$userid= $_SESSION['signup_user'];

if($user->roles[0]=='customer')
{
	if(!empty($userid)){ ?>
		<script type = "text/javascript" language = "javascript">
jQuery(document).ready(function() {

//alert ("image uploaded successfully");
window.location = "<?php echo get_bloginfo('url');?>/schedule-a-pick-up";

});
</script>
<?php }
}

}
else { 



?>

<section class="inner_page_content">
		<div class="container">
			<div class="row">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>
		</div>
</div>
</section>
<?php } ?>
<?php get_footer(); ?>
