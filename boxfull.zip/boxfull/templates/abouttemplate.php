<?php
/**
Template Name:About Template
 */

get_header();
//post content
$cur_pid = get_the_ID();
$content_post = get_post($cur_pid);
$content = $content_post->post_content;
$content = apply_filters('get_the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
//featured image
$about_image = wp_get_attachment_url( get_post_thumbnail_id($cur_pid), 'large' );
//custom fields
$about_heading = get_field('about_heading');


$about_section ='';
$about_section .='<section class="see_your_items aboutInner">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="syi_img">';
                    if($about_image)
                    {
                        $about_section .='<img src="'.$about_image.'">';
                    }
                    $about_section .='</div>
                </div>
                <div class="col-md-5">
                    <div class="syi_txt">
                        <div class="mi_heading">';
                        if($about_heading)
                        {
                            $about_section .='<h3>'.$about_heading.'</h3>';
                        }
                        $about_section .='</div>';
                        if($content)
                        {
                            $about_section .='<p>'.$content.'</p>';
                        }
                $about_section .='</div>
                </div>
            </div>
        </div>
    </section>';

    echo $about_section;

 ?>



<?php get_footer(); ?>
