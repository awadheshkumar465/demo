<?php 
/* Template Name: Frontend Bank Transfer */
?>

<?php get_header('new'); ?>
<div class="schedule_booking_out">

<div class="main-catgry-sec">
<div class="row">
<?php global $wpdb; 
if(isset($_POST['order_id'])){
	
	$payment_method = trim($_POST['payment_method']);
	
	$order_id = trim($_POST['order_id']);
	
	$amount = trim($_POST['amount']);
	
	$mc_currency = trim($_POST['currency_code']);
	
	$user_emails = trim($_POST['user_emails']);
	
	$subscr_id = trim($_POST['checque_details']);
	
	$updates = $wpdb->update('wp_orders',array(
	'subscr_id' =>$subscr_id,
	'mc_currency' => $mc_currency,
	'payer_email' =>$user_emails,
	'paymentstatus'=>'Due',
	'paymentmode'=>$payment_method
	),array('order_id'=>$order_id));
	
	//echo $redirecturls =bloginfo("url")."/admin-dashboard/?type=showall";
	
	$redirectsurls = bloginfo("url")."/user-dashboard/?type=showprofile";
	wp_redirect(site_url()."/user-dashboard/?type=showprofile");
	exit();
	
	
}

?>
</div>
</div>
</div>
<?php get_footer();?>