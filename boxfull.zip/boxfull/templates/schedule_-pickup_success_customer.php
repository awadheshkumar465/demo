<?php 
/* Template Name: Schedule Success Customer */
?>

<?php get_header('user');?>

<?php
global $wpdb;
 
$transaction_number =trim($_GET['tx']);
$user = wp_get_current_user();
$userId = $user->ID;
$useremailid = $user->user_email;
$updates = $wpdb->update('wp_schedule_pickup_order', array(
'payment_status'=>'paid',
'payment_method'=>'paypal',
'pickup_status'=>'0',
'transaction_number'=>$transaction_number
),array('user_email_pickup'=>$useremailid));
if($updates>=1)
{
	$location=get_bloginfo('url')."/user-dashboard/?type=mystuff";
	wp_redirect($location);
	exit();
}
?>
<?php get_footer('user');?>