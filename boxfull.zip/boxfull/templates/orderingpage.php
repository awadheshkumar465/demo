<?php
/* Template Name: Ordering Page Template */
?>
<?php 
get_header('new'); ?>
<?php 
$url = site_url()."/order";
wp_redirect($url);
exit();
global $wpdb; 

if(isset($_REQUEST['signupusers'])){
	$user = $_REQUEST['signupusers'];
	$finaluserid = base64_decode($user);
	$_SESSION['signup_user'] = $finaluserid;
}

if(is_user_logged_in()){
	$user = wp_get_current_user(); 
	$_SESSION['signup_user'] = $user->ID; 

}

if(isset($_SESSION['signup_user'])){
$lst_registered_userid = $_SESSION['signup_user'];
$lst_inserted_cartid = $_SESSION['lastinsertedid'];

$args=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query = new WP_Query( $args );


$args1=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 3,
		),
	));
$the_query1 = new WP_Query( $args1 ); 
//print_r($_SESSION);
?>


<section class="main_items">
		<div class="container">
		
		<!-- Order by Item starts here -->
		<div class="row">
				<div class="col-md-12">
					<div class="mi_heading">
						<h3><!--Commit to a longer term for more savings!--><?php echo get_the_title(); ?></h3>
					</div>
					<div class="sb_heading">
						<h4 class="text-center">By Item</h4>
								
				</div>
				</div>
			</div>
		<div class="row">
				<div class="col-md-12">
				
					<div class="srch-range byitem_changeprice">
						<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
					</div>
					<div class="col-md-12 text-center">
				
				</div>
				</div>
			</div>
			
			
			<div class="srch_by_box">
				
				
				<div class="sb_products byitem">
					<div class="row">
					<?php 
					if ($the_query1->have_posts() ) :
					while ($the_query1->have_posts() ) : $the_query1->the_post();
					$ktstorage_type_price = get_field('store_plan');
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
					$postid=get_the_ID();
					?>
						<div class="col-md-4">
						<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									
									<a id="open-pop-up-<?php echo get_the_ID();?>" href="javascript:void(0);">Details</a>
								<div id="pop-up-<?php echo get_the_ID();?>" class="pop-up-display-content">
									<div class="sb_pro_sub">
										<div class="sb_pro_img">
										
											<div class="popuptit_price">
												<h5 class="popup_title"><?php echo get_the_title();?></h5>
												<span class="prod-price"><?php echo $currencyvalue;?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
											</div>
											<div class="popupimg">
												<img src="<?php echo $ktstorage_type_image;?>">
											</div>
										</div>
										<div class="sb_pro_details">
											
												<?php echo get_the_content();?>
											
										</div>
									</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-<?php echo get_the_ID();?>").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-<?php echo get_the_ID();?>").popUpWindow({action: "open"});
									});

								   
								});
								</script>	
								</div>
							</div>
						</div>
				
				<?php endwhile;
				else:
				echo 'no posts found';
				endif; ?>
				
				</div>
				</div>
				</div>
		<!-- order by item html end here -->
			<div class="row">
				<div class="col-md-12">
					<!--<div class="mi_heading">
						<h3><?php //echo get_the_title(); ?></h3>
					</div> -->
					<div class="sb_heading">
						<h4 class="text-center">By Box</h4>
								
				</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="srch-range bybox_changeprice">
						<ul class="change_prices">
						<?php
							$store_plan = get_field( "store_plan" );
						?>
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
					</div>
					<div class="col-md-12 text-center">
				
				</div>
				</div>
			</div>
			
			
			<div class="srch_by_box">
				
				
				<div class="sb_products bybox">
					<div class="row">
					<?php 
					if ($the_query->have_posts() ) :
					while ($the_query->have_posts() ) : $the_query->the_post();
					$id= get_the_ID(); 
					$ktstorage_type_price = get_field('store_plan',$id);
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
					$postid=get_the_ID();
					?>
						<div class="col-md-4">
						<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									<a id="open-pop-up-<?php echo get_the_ID();?>" href="javascript:void(0);">Details</a>
								<div id="pop-up-<?php echo get_the_ID();?>" class="pop-up-display-content">
									<div class="sb_pro_sub">
										<div class="sb_pro_img">
										
											<div class="popuptit_price">
												<h5 class="popup_title"><?php echo get_the_title();?></h5>
												<span class="prod-price"><?php echo $currencyvalue;?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
											</div>
											<div class="popupimg">
												<img src="<?php echo $ktstorage_type_image;?>">
											</div>
										</div>
										<div class="sb_pro_details">
											
												<?php echo get_the_content();?>
											
										</div>
									</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-<?php echo get_the_ID();?>").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-<?php echo get_the_ID();?>").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								</div>
							</div>
						</div>
				
				<?php endwhile;
				else:
				echo 'no posts found';
				endif; ?>
				
				</div>
				</div>
				</div>
				<div class="text-center booknowbutton">
				<form action="<?php echo bloginfo('url');?>/order/" method="POST" id="cpa-form">
				<input type="hidden" value="3,2" name="boxcatname" class="boxcatename" />
				<input type="hidden" value="<?php echo $lst_registered_userid; ?>" name="lst_registered_userid" class="hiddlenuserid" />
				<input type="hidden" value="1" name="submitsetbyitem" class="submitsets" >
				<input type="hidden" name="byboxpricemonth" value="store_plan" class="storeplanbybox" >
				<input type="hidden" name="byitempricemonth" value="store_plan" class="storeplanbyitem" >
				<input type="hidden" name="usersids" value="<?php if(isset($_POST['lst_registered_userid'])){ echo $lst_registered_userid;} else { echo $lst_registered_userid; } ?>" class="userids" >
				<input type="submit" name="user_register_subbook_now_bybox" value="Book Now">
				</form> 
				</div>
		</div><!-- container ends here -->
	</section> <!--main_items ends here -->

<?php 

} else {
	?>
	<script type = "text/javascript" language = "javascript">
 jQuery(document).ready(function() {
    
		alert ("Please Register First");
		  window.location = "<?php echo get_bloginfo('url');?>/sign-up";
         
 });
</script>
	<?php
} 


get_footer(); ?>