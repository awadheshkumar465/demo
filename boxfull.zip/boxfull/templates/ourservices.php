<?php
/**
Template Name:Our Services Template
 */

get_header(); 

global $wpdb; 

$args=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query = new WP_Query( $args );


$args1=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 3,
		),
	));
$the_query1 = new WP_Query( $args1 ); 
//print_r($_SESSION);
$kt_business_storage=get_field('kt_business_storage',15);
$kt_business_storage_content=get_field('kt_business_storage_content',15);
$kt_business_storage_image=get_field('kt_business_storage_image',15);

?>


<section class="main_items">
		<div class="container">
		
		<!-- Order by Item starts here -->
		<div class="row">
				<div class="col-md-12">
					<div class="mi_heading">
						<h3><!--Commit to a longer term for more savings!--><a href="<?php bloginfo('url');?>#pricings"><?php echo "Pricing"; ?></a></h3>
					</div>
					<div class="sb_heading">
						<h4 class="text-center">By Item</h4>
								
				</div>
				</div>
			</div>
		<div class="row">
				<div class="col-md-12">
				
					<div class="srch-range byitem_changeprice">
						<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
					</div>
					<div class="col-md-12 text-center">
				
				</div>
				</div>
			</div>
			
			
			<div class="srch_by_box">
				
				
				<div class="sb_products byitem">
					<div class="row">
					<?php 
					if ($the_query1->have_posts() ) :
					while ($the_query1->have_posts() ) : $the_query1->the_post();
					$ktstorage_type_price = get_field('store_plan');
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
					$postid=get_the_ID();
					?>
						<div class="col-md-4">
						<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									<a id="open-pop-up-<?php echo $postid; ?>" href="javascript:void(0);">Details</a>
								<div id="pop-up-<?php echo $postid; ?>" class="pop-up-display-content">
								<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									</div>
								</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-<?php echo $postid; ?>").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-<?php echo $postid; ?>").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								</div>
							</div>
						</div>
				
				<?php endwhile;
				else:
				echo 'no posts found';
				endif; ?>
				
				</div>
				</div>
				</div>
		<!-- order by item html end here -->
			<div class="row">
				<div class="col-md-12">
					<!--<div class="mi_heading">
						<h3><?php //echo get_the_title(); ?></h3>
					</div> -->
					<div class="sb_heading">
						<h4 class="text-center">By Box</h4>
								
				</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div class="srch-range bybox_changeprice">
						<ul class="change_prices">
						<?php
							$store_plan = get_field( "store_plan" );
						?>
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
					</div>
					<div class="col-md-12 text-center">
				
				</div>
				</div>
			</div>
			
			
			<div class="srch_by_box">
				
				
				<div class="sb_products bybox">
					<div class="row">
					<?php 
					if ($the_query->have_posts() ) :
					while ($the_query->have_posts() ) : $the_query->the_post();
					$id= get_the_ID(); 
					$ktstorage_type_price = get_field('store_plan',$id);
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
					$postid=get_the_ID();
					?>
						<div class="col-md-4">
						<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									<a id="open-pop-up-<?php echo $postid; ?>" href="javascript:void(0);">Details</a>
								<div id="pop-up-<?php echo $postid; ?>" class="pop-up-display-content">
								<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="<?php echo $ktstorage_type_image;?>">
								</div>
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);"><?php echo get_the_title(); ?></a></h5>
									<span class="prod-price"><?php echo get_option( 'currency_set' );?>$ <strong><?php echo $ktstorage_type_price;?></strong></span>
									<span class="prod-wieght">Max. <?php echo $ktstorage_type_max_weight; ?>kg</span>
									</div>
								</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-<?php echo $postid; ?>").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-<?php echo $postid; ?>").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								</div>
							</div>
						</div>
				
				<?php endwhile;
				else:
				echo 'no posts found';
				endif; ?>
				
				</div>
				</div>
				</div>
				
		</div><!-- container ends here -->
	</section> <!--main_items ends here -->
	
	<section class="busi_storage">
		<div class="container">
			<div class="row">
			<div class="mi_heading">
						<h3><!--Commit to a longer term for more savings!--><a href="<?php bloginfo('url');?>/#business_storages">Business Storage</a></h3>
					</div>
				<div class="col-md-6">
					<div class="busi_storage_txt">
						<div class="mi_heading">
							<h3><?php echo $kt_business_storage?></h3>
						</div>
						<?php echo $kt_business_storage_content;?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="busi_stor_img">
						<img src="<?php echo $kt_business_storage_image?>">
					</div>
				</div>
			</div>
		</div>
	</section>
	

<?php 
get_footer(); ?>
