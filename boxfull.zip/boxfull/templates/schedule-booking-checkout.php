<?php
/**
 Template Name:Schedule Booking Checkout
 */
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false);
if ( is_user_logged_in() ) {
	
	$user = wp_get_current_user();
	
if($user->roles[0]=='customer'){
}
else{
	wp_redirect(site_url());
	exit();
}
    
	

} else {
    wp_redirect(site_url()."/login/");
	exit();
}
get_header('new');
$adminurl = admin_url('admin-ajax.php'); 
//print_r($_SESSION);
//echo $_SESSION['store_duration_months'];
$terms = get_terms( array(
    'taxonomy' => 'country',
    'hide_empty' => false,
	'order' =>'DESC',
) );

if(is_user_logged_in()){
	$user = wp_get_current_user(); 
	$_SESSION['signup_user'] = $user->ID; 

}
$currencycodes = get_option('currency_set');									
if(!empty($_SESSION['product_id'])){
global $wpdb;

if(isset($_SESSION['signup_user'])){
	$store_plan = $_SESSION['pricestorage_duration'];
	
	$signup_user = $_SESSION['signup_user'];
	$categoryid = $_SESSION['categories_id'];
	$selectUsers = $wpdb->get_results("select * from wp_cart_items where userid=$signup_user");
	foreach ($selectUsers as $vals){
		echo $cartitems = $vals->product_qnty;

		$product_details = json_decode($vals->cartitems);
	}

	$product_id_arr = array();
	foreach ($product_details as $key=>$valfinal){ //echo "<pre>"; print_r($valfinal); echo "</pre>";
	if(!empty($valfinal->product_ids))
	{
		foreach($valfinal->product_ids as $key=>$productids){ 
		$product_id_arr[$key]=$productids;
		}
	}
	if(!empty($valfinal->product_qnty))
	{
		foreach($valfinal->product_qnty as $key=>$finalproduct_qnty){ 
		$product_qty_arr[$key]=$finalproduct_qnty;
		}
	}	
	
	}
	$_SESSION["product_id"] = $product_id_arr;
	$_SESSION["product_qty"]=$product_qty_arr;
}
$pricestoragesession=$_SESSION['pricestorage_duration'];
$categoryids=$_SESSION['categories_id'];

$signup_user=$_SESSION['signup_user'];
$user_id = $signup_user;
  $key = 'nickname';
  $single = true;
  $nickname = get_user_meta( $user_id, $key, $single );  
  $user_phone = get_user_meta( $user_id, 'user_phone', $single ); 
  $user_pickup_address = get_user_meta( $user_id, 'user_pickup_address', $single );
  if($user_pickup_address){ $user_pickup_address = $user_pickup_address;}
  if($user_phone){ $user_phone = $user_phone;}
  if($nickname){ $fullname = $nickname;}
  
//print_r($_POST);
if(isset($_POST['mybooking_continue']))
{
	
	$first_name=$_POST['fullname'];
	//echo $last_name=$_POST['phonenumber'];
	$user_telephone=$_POST['phonenumber'];
	$user_pickup_address=$_POST['fulladdress'];
	//$user_pickup_address2=$_POST['user_pickup_address2'];
	$user_select_region=$_POST['user_select_region'];
	$user_select_district=$_POST['user_select_district'];
	$nickname=$first_name;
	$user_phone = $user_telephone;
	$user_pickup_address = $user_pickup_address;
	
	$_SESSION['user_booking_information'] = array(
    'first_name' => $first_name,
    'last_name' => $last_name,
    'user_telephone' => $user_telephone,
    'user_pickup_address' => $user_pickup_address,
	'user_pickup_address2' => $user_pickup_address2,
	'user_select_region' => $user_select_region,
	'user_select_district' => $user_select_district,
);
}

$special_instructions='';
$how_did_find='';

if($_SESSION['user_booking_information'])
{
	$special_instructions=$_SESSION['user_booking_information']['special_instructions'];
	$how_did_find=$_SESSION['user_booking_information']['how_did_find'];
	
}

//print_r($_POST);
?>

<div class="picBook_schedule">

	<div class="container">
			<div class="row">
				<h2 class="text-center"><?php echo get_the_title();?> </h2>
					<div class="col-md-8">
						
						<div class="contrct-reg">
						<form method="post" action="<?php echo site_url('checkout-page/'); ?>" id="schedule_booking_form_out">
						<div class="row">
						<h3>Personal Details:</h3>
						<div class="col-md-6">
							<div class="form-group">
								
								<input type="text" readonly name="fullname" value="<?php echo $nickname; ?>" class="form-control " id="fullusername" placeholder="Full Name" >
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
							
							<input type="text" readonly  name="phonenumber" value="<?php echo $user_phone; ?>" class="form-control " id="userphone" placeholder="Phone Number" >
							
							</div>
						</div>
						
						</div>
						
						<div class="row">
						<h3>Appointment Address:</h3>
						<div class="col-md-12">
							<div class="form-group">
								
								<textarea rows="10" cols="10" name="fulladdress" class="form-control" placeholder="Full Address"><?php echo $user_pickup_address; ?></textarea>
							</div>
						</div>
						
						
						</div>
						
						<div class="row">
						<h3>Select Regions/District * :</h3>
						<div class="col-md-6">
							<div class="form-group">
								
								<select type="text" name="countrylists" id="country_lists">
								<option value="">Select Region</option>';
								<?php foreach($terms as $countrylists){ //print_r($countrylists);
									echo '<option value="'.$countrylists->term_id.'">'.$countrylists->name.'</option>';
								} ?>
								
							</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								
							
							<select type="text" name="dropoff_select_dist" id="dropoff_select_dist">
								<option value="">
								Select District
								</option>
								
							</select>
							
							
							</div>
						</div>
						
						</div>
						
						
						
						<div class="row">
						<div class="col-md-10 upstairs">
							<div class="form-group">
								<label>Do we need to carry your boxes up the stairs?:</label>
								<input type="checkbox" name="do_we_need_carry_box" value="no"><label>No</label>
								<input type="checkbox" name="do_we_need_carry_box" value="yes"><label>Yes</label>
							</div>
							<?php $divselectfloors = "selectfloors";
							
							$nooffloors=array(
							"1" =>"1 Label",
							"2" =>"2 Label",
							"3" =>"3 Label",
							"4" =>"4 Label",
							"5" =>"5 Label",
							"6" =>"6 Label",
							"7" =>"7 Label",
							"8" =>"8 Label",
							);
							?>
							
							<div class="form-group <?php echo $divselectfloors;?>">
							<label>Select Floor (<a href="<?php echo site_url();?>/faq">see stair fee here):</a></label>
							<select name="selectfloor">
							<?php 
							foreach($nooffloors as $key=>$floors){ ?>
							<option value="<?php echo $key;?>"><?php echo $floors;?></option>
							<?php } ?>
							</select>
							</div>
						</div>

						
						</div>
						<?php 
					$totalsessionprice='';
					$tetings='';
					if($_SESSION["product_id"])
					{
						$pro_pricemonth_array_session=array_combine($_SESSION["product_months"],$_SESSION["product_qty"]);
						//print_r($pro_pricemonth_array_session);
						$total='';
						$totfinal=array();
						$priceshtmls=array();

						$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);
						$totalsessionprice=get_total_price_using_session_cart($pro_qty_array_session,$pricestoragesession,$categoryids); 

						$i=1;
						$s=0;
						global $wpdb; $signup_user = $_SESSION['signup_user'];
						$finprice = 0;

						foreach($pro_pricemonth_array_session as $proprice=>$proqty){

						if($proqty==0){} else{
						$totsum[]=$proprice*$proqty;
						$pricepro[]=$proprice;
						$selects = $wpdb->get_results("select checkcartitemsid from checkoutcartitems where userid = $signup_user");

						}
						}
						$j=0; $sum=0;
						foreach($pro_qty_array_session as $proid=>$proqty)
						{ 
							if($proqty==0){} else{
								$sum=$sum+($totsum[$j]);
								$titles=get_the_title($proid);
								$testings.=$proqty.",".$titles.",";
								$testing[]=array('qty'=>$proqty,'proitem'=>$titles);
						$termsids = wp_get_post_terms($proid,'storagetypecat');
						//print_r($termsids);
						 $posttermids[] = $termsids[0]->term_id;
								$mduration = getMonthDurationByProductId($proid,$pricepro[$j]);

								foreach($mduration as $montduration){
								$storagedurations = $montduration->meta_key;
								if($storagedurations=='store_plan'){$storageduration[]="Store Plan";}
								if($storagedurations=='ktstorage_type_price'){$storageduration[]="3-5 Months";} 
								if($storagedurations=='storage_type_price_six'){$storageduration[]="6-11 Months";} 
								if($storagedurations=='storage_type_price_twelve'){$storageduration[]="12+ Months";} 
								}
								$pronames[] = get_the_title($proid);
								$j++;
							}
						}
					}
					
					
					if(in_array('3',$posttermids)){
						
						date_default_timezone_set("Asia/Kolkata");
						//date_default_timezone_set("Asia/Hong_Kong");

						$current_time_nextschedule = date("h:i:sa");

						$sunday = date("l");

						$sameday_before_aftertime = "10:00:00am";

						$beforeten = "10:00:00am";

						if($sunday == 'Sunday'){
						$samemindays = "new Date()";
						$mindays = "new Date()"; 
						$maxdays = "new Date()";
						}
						else 
						{
						if((strtotime($current_time_nextschedule)) <= (strtotime($sameday_before_aftertime)))
						{
						$samemindays = "new Date()"; 

						} 

						if((strtotime($current_time_nextschedule)) >= (strtotime($sameday_before_aftertime)))
						{
						$samemindays = "+1";
						}

						if((strtotime($current_time_nextschedule)) <= (strtotime($beforeten)))
						{
						$mindays = 1; 
						$maxdays = 1; 
						} 

						if((strtotime($current_time_nextschedule)) >= (strtotime($beforeten)))
						{
						$mindays = 2;
						$maxdays = 2; 
						} 
						}



						$getblackdate = $wpdb->get_results("select * from publicholidays ",ARRAY_A);


						if(!empty($getblackdate)){
						foreach($getblackdate as $blackdayvals){  
						$blackday_date = $blackdayvals['holiday_date'];

						$getblackdate_1 = $wpdb->get_results("select * from publicholidays where holiday_date='$blackday_date' ",ARRAY_A);
						if(count($getblackdate_1)==5){
						$alldates[] = $blackday_date;
						}
						}
						}

						if(!empty($alldates)){
						foreach($alldates as $dvals){
						$datehtml[]="'$dvals'".",";	
						$newexp = explode("/",$dvals);

						$newdate = ltrim($newexp[1],0)."-".ltrim($newexp[2],0)."-".$newexp[0];
						$newdates[]="'$newdate'".",";

						}
						}

						$result = array_unique($newdates);


						$datehtmlsresults = '';
						if(!empty($result)){
						foreach($result as $i=>$k) {
						$datehtmlsresults .=$k;
						}
						}
						$datehtmls = '';
						if(!empty($datehtml)){
						foreach($datehtml as $i=>$k) {
						$datehtmls .=$k;
						}
						}

						$adminajax = admin_url('admin-ajax.php');
						$datehtmls = "[".rtrim($datehtmls,',')."]";

						$resultdatehtml = "[".rtrim($datehtmlsresults,',')."]";
						$adminajax = admin_url('admin-ajax.php');
						?>
						<script type="text/javascript">
						var unavailableDates = <?php echo $datehtmls;?>;
						var disabledDays =<?php echo $resultdatehtml;?>;
						
						function nationalDays(date) {
						var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
						//console.log("Checking (raw): " + m + "-" + d + "-" + y);
						for (i = 0; i < disabledDays.length; i++) {
						if(jQuery.inArray((m+1) + "-" + d + "-" + y,disabledDays) != -1 || new Date() > date) {
						console.log("bad:  " + (m+1) + "-" + d + "-" + y + " - " + disabledDays[i]);
						return [false];
						}
						}
						//console.log("good:  " + (m+1) + "-" + d + "-" + y);
						return [true];
						}
						function unavailable(date) {
						dmy = date.getFullYear()+ "/" + (date.getMonth() + 1) + "/" + date.getDate() ;

						if (jQuery.inArray(dmy, unavailableDates) == -1) {
						return [true, ""];
						} else {
						return [false, "", "Unavailable"];
						}
						}

						jQuery(function() {
						jQuery("#select_pickup_schedule_date").datepicker({
						minDate: "0",
						dateFormat: "yy/mm/dd",
						constrainInput: true,
						beforeShowDay: nationalDays,
						onSelect: function(defaultDate, instance) {
						
						jQuery.ajax({
						url: "<?php echo $adminajax;?>",
						type: "POST",
						dataType: "html",
						data: { action:"getdatepickerdates", selecteddate:defaultDate},
						success : function(data){
						//alert (data);
						console.log (data);
						jQuery("select#dropoff_selectschedule_time").html(data);


						}
						}); 
						}

						});

						});
						</script>
						
						
						<div class="row schedulefrontend">
							<h3>Schedule A Pick Up *:</h3>
							<div class="col-md-6">
								<div class="form-group">
									<input type="text" readonly name="select_schedule_pick_off_date" class="form-control date_pickersd" id="select_pickup_schedule_date"  placeholder="Select Date">
								</div>
							</div>
							
							<div class="col-md-6">
								<div class="form-group">
									<select type="text" name="dropoff_schedule_pick_off_time" id="dropoff_selectschedule_time">
										<option value="">
										Select Time
										</option>
									</select>
								</div>
							</div>
						
						</div>
					<?php } ?>
					
					<?php
										
					if(in_array('2',$posttermids))
					{ ?>
						<script type="text/javascript">
					jQuery(document).ready(function(){
						var getlabelstext = jQuery('.row.schedulefrontend h3').html();
						
						if(getlabelstext=='Schedule A Pick Up *:'){
							//alert ("gettings" + getlabelstext);
							jQuery('.row.schedulefrontend').css('display','none');
						}
					});
					</script>
						<?php 
						date_default_timezone_set("Asia/Kolkata");
						//date_default_timezone_set("Asia/Hong_Kong");

						$current_time_nextschedule = date("h:i:sa");

						$sunday = date("l");

						$sameday_before_aftertime = "10:00:00am";

						$beforeten = "10:00:00am";

						if($sunday == 'Sunday'){
						$samemindays = "new Date()";
						$mindays = "new Date()"; 
						$maxdays = "new Date()";
						}
						else 
						{
						if((strtotime($current_time_nextschedule)) <= (strtotime($sameday_before_aftertime)))
						{
						$samemindays = "new Date()"; 

						} 

						if((strtotime($current_time_nextschedule)) >= (strtotime($sameday_before_aftertime)))
						{
						$samemindays = "+1";
						}

						if((strtotime($current_time_nextschedule)) <= (strtotime($beforeten)))
						{
						$mindays = 1; 
						$maxdays = 1; 
						} 

						if((strtotime($current_time_nextschedule)) >= (strtotime($beforeten)))
						{
						$mindays = 2;
						$maxdays = 2; 
						} 
						}



						$getblackdate = $wpdb->get_results("select * from publicholidays ",ARRAY_A);


						if(!empty($getblackdate)){
						foreach($getblackdate as $blackdayvals){  
						$blackday_date = $blackdayvals['holiday_date'];

						$getblackdate_1 = $wpdb->get_results("select * from publicholidays where holiday_date='$blackday_date' ",ARRAY_A);
						if(count($getblackdate_1)==5){
						$alldates[] = $blackday_date;
						}
						//else{$alldates[] = $blackday_date;}
						}
						}

						if(!empty($alldates)){
						foreach($alldates as $dvals){
						$datehtml[]="'$dvals'".",";	
						$newexp = explode("/",$dvals);

						$newdate = ltrim($newexp[1],0)."-".ltrim($newexp[2],0)."-".$newexp[0];
						$newdates[]="'$newdate'".",";

						}
						}

						$result = array_unique($newdates);


						$datehtmlsresults = '';
						if(!empty($result)){
						foreach($result as $i=>$k) {
						$datehtmlsresults .=$k;
						}
						}
						$datehtmls = '';
						if(!empty($datehtml)){
						foreach($datehtml as $i=>$k) {
						$datehtmls .=$k;
						}
						}

						$adminajax = admin_url('admin-ajax.php');
						$datehtmls = "[".rtrim($datehtmls,',')."]";

						$resultdatehtml = "[".rtrim($datehtmlsresults,',')."]";
						$adminajax = admin_url('admin-ajax.php');
						?>
						
						<script type="text/javascript">
						var unavailableDates = <?php echo $datehtmls;?>;
						var disabledDays =<?php echo $resultdatehtml;?>;
						
						function nationalDays(date) {
						var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
						//console.log("Checking (raw): " + m + "-" + d + "-" + y);
						for (i = 0; i < disabledDays.length; i++) {
						if(jQuery.inArray((m+1) + "-" + d + "-" + y,disabledDays) != -1 || new Date() > date) {
						console.log("bad:  " + (m+1) + "-" + d + "-" + y + " - " + disabledDays[i]);
						return [false];
						}
						}
						//console.log("good:  " + (m+1) + "-" + d + "-" + y);
						return [true];
						}
						function unavailable(date) {
						dmy = date.getFullYear()+ "/" + (date.getMonth() + 1) + "/" + date.getDate() ;

						if (jQuery.inArray(dmy, unavailableDates) == -1) {
						return [true, ""];
						} else {
						return [false, "", "Unavailable"];
						}
						}

						jQuery(function() {
						jQuery("#select_drop_off_date").datepicker({
						minDate: "0",
						dateFormat: "yy/mm/dd",
						constrainInput: true,
						beforeShowDay: nationalDays,
						onSelect: function(defaultDate, instance) {
						
						jQuery.ajax({
						url: "<?php echo $adminajax;?>",
						type: "POST",
						dataType: "html",
						data: { action:"getdatepickerdates", selecteddate:defaultDate},
						success : function(data){
						//alert (data);
						console.log (defaultDate);
						jQuery("select#dropoff_select_time").html(data);
						var date2 = defaultDate + '+7d';
						var arr = defaultDate.split('/');
						var otherincome=1;
						var totalincome = parseInt(arr[2]) + parseInt(otherincome);
						
						var newdates = arr[0]+"/"+arr[1]+"/"+totalincome;
						
						jQuery("#pickupdated").datepicker('option', 'minDate', newdates);
						
						}
						}); 
						}

						});

						});
						</script>
						<div class="row emptyboxesdropoff">
						<h3>Drop Off Empty Boxes *:</h3>
						<div class="col-md-6">
							<div class="form-group">
								
								<input type="text" readonly name="select_drop_off_date" class="form-control date_pickervv" id="select_drop_off_date"  placeholder="Select Date">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								
							
							<select type="text" name="dropoff_select_time" id="dropoff_select_time">
								<option value="">
								Select Time
								</option>
								<?php
								// check if the repeater field has rows of data
									if( have_rows('drop_of_off_empty_boxes_timings') ):

										// loop through the rows of data
										while ( have_rows('drop_of_off_empty_boxes_timings') ) : the_row();

											// display a sub field value
											$drop_of_off_empty_boxes_timing=get_sub_field('drop_of_off_empty_boxes_timing');
											echo '<option value="'.$drop_of_off_empty_boxes_timing.'">'.$drop_of_off_empty_boxes_timing.'</option>';

										endwhile;

									
									endif;
								
								
								?>
								</select>
							
							
							</div>
						</div>
						
						</div>
						<script type="text/javascript">
						

						jQuery(function() {
						
						jQuery("#pickupdated").datepicker({
						//minDate: "0",
						dateFormat: "yy/mm/dd",
						constrainInput: true,
						beforeShowDay: nationalDays,
						onSelect: function(defaultDate, instance) {
						
						jQuery.ajax({
						url: "<?php echo $adminajax;?>",
						type: "POST",
						dataType: "html",
						data: { action:"getdatepickerdates", selecteddate:defaultDate},
						success : function(data){
						//alert (data);
						console.log (data);
						jQuery("select#pickuptime").html(data);


						}
						}); 
						}

						});

						});
						</script>
						<div class="row">
						<h3>Pick-up Boxes for Storage(Please Select One)*:</h3>
						
						<div class="col-md-12">
							<div class="form-group">
								
								<input type="radio" id="pickup_of_boxes" name="pickup_of_boxes" class="pickoption" value="20 minutes">
								<label>In 20 minutes after drop off</label>
								
								<div class="pickup_hidden" style="display:none;">
								Our driver will wait for up to 20 minutes while you pack your boxes
								</div>
							</div>
							<div class="form-group">
								
								<input type="radio" name="pickup_of_boxes" class="pickoption">
								<label>Schedule another pick-up time now</label>
								<div class="pickup_hidden" style="display:none;">
								<div class="col-md-6">
								<input type="text" id="pickupdated" name="pick_select_date" readonly placeholder="Appointment Date" class="date_pickerhh">
								</div>
								<div class="col-md-6">
								<select type="text" id="pickuptime"  name="pick_select_time">
								<option value="">
								Select Time
								</option>
								<?php
								// check if the repeater field has rows of data
									if( have_rows('pick-up_of_boxes_for_storage_timings') ):

										// loop through the rows of data
										while ( have_rows('pick-up_of_boxes_for_storage_timings') ) : the_row();

											// display a sub field value
											$pick_of_off_empty_boxes_timing=get_sub_field('pick_of_off_empty_boxes_timing');
											
											echo '<option  value="'.$pick_of_off_empty_boxes_timing.'">'.$pick_of_off_empty_boxes_timing.'</option>';

										endwhile;

									
									endif;
								
								
								?>
								</select>
								</div>
								<div class="comment_text scheduledatetime">
								Please schedule a pick-up within 2 weeks after receiving your boxes.<br>
								Your billing cycle will begin when your boxes/items have been picked up or 2 weeks after dropoff, whichever is earlier.
								
								</div>
								</div>

							</div>
							<div class="form-group">
								
								<input type="radio" id="pickup_of_boxeslater"  name="pickup_of_boxes" class="pickoption">
								<label>Schedule another pick-up time Later</label>
								<div class="pickup_hidden" style="display:none;">Please schedule a pick-up within 2 weeks after receiving your boxes.<br>
								Your billing cycle will begin when your boxes/items have been picked up or 2 weeks after dropoff, whichever is earlier.</div>
							</div>
						</div>
						</div>
					<?php } ?>
					
					
						
						<div class="row">
						<div class="col-md-12">
						
						<label>Special Instructions</label>
						<textarea name="special_instructions" class="form-control" placeholder="e.g.: “Door bell broken, please call on arrival.”"><?php echo $special_instructions; ?></textarea>
						
						</div>
						
						</div>
						
						<div class="row">
						<div class="col-md-12 tops">
						<label>How did you find us?</label><br/>
						<select class="how_did_find" name="how_did_find">
						<option value="">Select One</option>
						<?php
						if( have_rows('add_schedule_booking_options') ):

							// loop through the rows of data
							while ( have_rows('add_schedule_booking_options') ) : the_row();

								
								$schedule_booking_options=get_sub_field('schedule_booking_options');
								$selected='';
											if($how_did_find==$schedule_booking_options)
											{
												$selected='selected';
											}
								echo '<option '.$selected.' value="'.$schedule_booking_options.'">'.$schedule_booking_options.'</option>';

							endwhile;

					

						endif;
						?>
						
						
						</select>
						
						</div>
						
						</div>
						
						
						<div class="row">
						<div class="col-md-12">
						<div class="user_reg_sub_out">
						
						<?php 
					$totalsessionprice='';
					$tetings='';
					if($_SESSION["product_id"])
					{
						$pro_pricemonth_array_session=array_combine($_SESSION["product_months"],$_SESSION["product_qty"]);
						//print_r($pro_pricemonth_array_session);
						$total='';
						$totfinal=array();
						$priceshtmls=array();
						
					
					$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);
					$totalsessionprice=get_total_price_using_session_cart($pro_qty_array_session,$pricestoragesession,$categoryids); 
					
					$i=1;
					$s=0;
					global $wpdb; $signup_user = $_SESSION['signup_user'];
					$finprice = 0;
					
					foreach($pro_pricemonth_array_session as $proprice=>$proqty){
						
						if($proqty==0){} else{
							$totsum[]=$proprice*$proqty;
							$pricepro[]=$proprice;
							$selects = $wpdb->get_results("select checkcartitemsid from checkoutcartitems where userid = $signup_user");
							
							//$wpdb->update('checkoutcartitems', array('price'=>$proprice), array('userid'=>$signup_user));
							
						}
						}
						$j=0; $sum=0;
					foreach($pro_qty_array_session as $proid=>$proqty)
					{ 
						if($proqty==0){} else{
						$sum=$sum+($totsum[$j]);
						$titles=get_the_title($proid);
						$testings.=$proqty.",".$titles.",";
						$testing[]=array('qty'=>$proqty,'proitem'=>$titles);
						echo '<input type="hidden" name="productids[]" value="'.$proid.'">';
						echo '<input type="hidden" name="productqtynames[]" value="'.get_the_title($proid).'">';
						echo '<input type="hidden" name="productprices[]" value="'.$totsum[$j].'">';
						echo '<input type="hidden" name="productqtys[]" value="'.$proqty.'">';
						$j++;
						}
						
					}
					

					}
					
					
					?>
					
					<input type="hidden" class="hiddencoupons" name="hiddencouponsvals" value="">
					
					<input type="hidden" class="hiddencoupons_code" name="hiddencouponscodes" value="">
					
					<input type="hidden" class="schedule_ajax_url" name="ajax_url_admin_side" value="<?php echo admin_url("admin-ajax.php");?>">

						<input type="submit" name="mybooking_continue" value="Continue" onclick="return form_validation('schedule_booking_form_out');">
						</div>  
						</div>
						
						</div>	
						
						
						</div>
					</div>
					
<div class="col-md-4 cartpurchase"><!-- div class col-md-4 cartpurchase starts here -->
<?php

include( locate_template( 'includes/purchase_section.php', false, false ) );

?>
<div class="row">
<div class="col-md-12 checkoutpromoform">
<div class="form-group">
<div class="couponcodemessage"></div>
<label >Select Promocode </label>

<select name="changecoupons" class="form-control changecuponscontrols">
<option value="">Select Coupons</option>
<option value="Free Month Code">Free Month Code</option>
<option value="Cash Coupon Code">Cash Coupon Code</option>
<option value="Discount Code">Discount Code</option>
</select>
<div class="couponsareas">
</div>

</div>
</div>
</div>
</div><!-- div class col-md-4 cartpurchase ends here -->	
<input type="hidden" class="ajaxurladmins" name="ajaxurladmin" value="<?php echo $adminurl;?>">	

				
</form>					
</div>			
</div>
</div>
<script>
jQuery(document).ready(function(){
	
	
	/*
	jQuery('select#country_lists').on('change', function() {
		var country= (this.value);
		jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'getdistricts', countryid:country},
			success : function(data){
				//alert (data);
				console.log (data);
				jQuery('select#dropoff_select_dist').html(data);
				
			}
		})
})*/

/* schedule a page promo code starts here hidden text box area */

//jQuery("#promocode_free_monthly").on("input", function() {
	//alert ("tesings");
	//
   // jQuery(".hidden.promocodetext").fadeIn();
    
 //});//
/* schedule a page promo code ends here hidden text box area */	
});
function form_validation(formid)   
{


		var flag = ''; 
		var error_Msg='';
		var error_Msg = "Please correct the following : ";
		var myform =jQuery('#'+formid);
		
		var select_drop_off_date =myform.find('#select_drop_off_date').val();
		var dropoff_select_time =myform.find('#dropoff_select_time').val();
		//var dropoff_select_time =myform.find('#country_lists').val();
		var country = document.getElementById("country_lists");
		var countryval = country.options[country.selectedIndex].value;
		var pickupafterdropoff = document.getElementById('pickup_of_boxes').checked;
		var select_pickupdate =myform.find('#pickupdate').val();
		var schedulelater =document.getElementById('pickup_of_boxeslater').checked;
		
		
		if(select_drop_off_date=='')
		{
			flag = 1;
			error_Msg += "\n - Please Select Drop Off Date.";
		}
		if(dropoff_select_time=='')
		{
			flag = 1;
			error_Msg += "\n - Please Select Drop Off Time.";
		}
		
		if(countryval=='')
		{
			flag = 1;
			error_Msg += "\n - Please Select Country.";
		}
		
		if((select_pickupdate=='')&&(pickupafterdropoff===false)&&(schedulelater===false))
			{
			flag = 1;
			error_Msg += "\n - Please Select Pickup Schedule.";
		}
		
		
		
		if(flag == 1)
		{

			jAlert(error_Msg, 'Required Fields');

		

			return false;

		}

		else{

			

		return true;

		}

		
	}

</script>
<?php
}
else{ ?>
	<script type = "text/javascript" language = "javascript">
 jQuery(document).ready(function() {
    
		alert ("Visit Order page");
		  window.location = "<?php echo get_bloginfo('url');?>/order";
         
 });
</script>

<?php 

get_footer();

 }

?>