<?php
/**
 Template Name:Billing Checkout Template
 */
session_start();
get_header();

if($_SESSION['user_booking_information'])
{
	$session_first_name=$_SESSION['user_booking_information']['first_name'];
	$session_last_name=$_SESSION['user_booking_information']['last_name'];
	
	$session_user_telephone=$_SESSION['user_booking_information']['user_telephone'];
	$session_user_pickup_address=$_SESSION['user_booking_information']['user_pickup_address'];
	
	
	$session_user_pickup_address2=$_SESSION['user_booking_information']['user_pickup_address2'];
	$session_user_select_region=$_SESSION['user_booking_information']['user_select_region'];
	$session_user_select_district=$_SESSION['user_booking_information']['user_select_district'];
	
}

if(isset($_POST['mybooking_continue']))
{
	$_SESSION['user_booking_information']['special_instructions']=$_POST['special_instructions'];
	$_SESSION['user_booking_information']['how_did_find']=$_POST['how_did_find'];
}


if(isset($_POST['mybooking_continue']))
{
	//Drop Off
	$select_drop_off_date=$_POST['select_drop_off_date'];
	$dropoff_select_time=$_POST['dropoff_select_time'];
	
	//Pick Up
	$pick_select_date=$_POST['pick_select_date'];
	$pick_select_time=$_POST['pick_select_time'];
}
?>

<div class="billing_out">
<div class="container">

<div class="row">
<div class="col-md-8">
<?php
				
				$paypal_seller_mail=get_option('paypal_seller_mail');
				$paypal_pay_mode=get_option('paypal_pay_mode');
				
				$paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr?custom=YOUR_VAR'; 
				
				if($paypal_pay_mode=='livemode')
				{
					$paypalURL='https://www.paypal.com/cgi-bin/webscr?custom=YOUR_VAR';
				}
				$paypalID = $paypal_seller_mail; 
				
				$payment_success_url=site_url('dress-payment-complete');
				$currency_set=get_option('currency_set');
				
				?>
				<div class="pric-pay-sec">
					<div class="row">
						<div class="col-md-6">  
							<div class="pps-sub">
							
					<form action="<?php echo $paypalURL; ?>" method="post">
						<input type="hidden" name="cmd" value="_xclick">
						<input type="hidden" name="business" value="<?php echo $paypalID ; ?>">
						<input type="hidden" name="item_name" value="<?php echo $dress_title; ?>">
						<input type="hidden" name="item_number" value="<?php echo $dressid; ?>">
						<input type="hidden" name="amount" value="<?php echo $sw_plan_price; ?>">
						<input type="hidden" name="no_shipping" value="0">
						<input type="hidden" name="no_note" value="1">
						<input type="hidden" name="currency_code" value="<?php echo $currency_set; ?>">
						<input type="hidden" name="lc" value="AU">
						<input type="hidden" name="bn" value="BuyNow">
						<input type="hidden" name="custom" value="<?php echo $dresspaymentid;?>">
						<input type="hidden" name="return" value="<?php echo $payment_success_url; ?>">
						<label class="paypal_sub">
						<i class="fa fa-paypal"></i><input type="submit" class="btn btn-default" value="Pay By Paypal"  name="submit" alt="PayPal - The safer, easier way to pay online.">
						</label>
					</form> 
				
							
							
								
							</div>
						</div>
						
						
					</div>
				</div>
</div>
<div class="col-md-4">
<?php
include( locate_template( 'includes/purchase_section.php', false, false ) );

?>
</div>


</div>

<div class="row">
<div class="col-md-8">
<div class="booking_details_out">
<h3>Booking Details</h3>

<div class="booking_details_in1">
<div class="col-md-8">
<h3>Appointment Address</h3>
<div class="pickadd1"><?php echo $session_user_pickup_address; ?></div>
<div class="pickadd2"><?php echo $session_user_pickup_address2; ?></div>
<?php
if($session_user_telephone)
{
	?>
	<div class="pickusertele"><span>Phone Number :</span><?php echo $session_user_telephone; ?></div>
	
	<?php
}

?>

</div>

<div class="col-md-4">
<div class="myaccount_check"><a href="<?php echo site_url('my-account-checkout'); ?>">Edit</a></div>

</div>
</div>

<div class="booking_details_in2">
<div class="col-md-8">
<h3>Drop-off of boxes</h3>
<div class="drop_date"><?php echo $select_drop_off_date; ?></div>
<div class="drop_time"><?php echo $dropoff_select_time; ?></div>


</div>

<div class="col-md-4">
<div class="myaccount_check"><a href="<?php echo site_url('schedule-a-booking'); ?>">Edit</a></div>

</div>
</div>

<div class="booking_details_in2">
<div class="col-md-8">
<h3>Pick-up of boxes for storage</h3>
<div class="drop_date"><?php echo $pick_select_date; ?></div>
<div class="drop_time"><?php echo $pick_select_time; ?></div>


</div>

<div class="col-md-4">
<div class="myaccount_check"><a href="<?php echo site_url('schedule-a-booking'); ?>">Edit</a></div>

</div>
</div>

</div>
</div>




</div>
</div>
<?php

get_footer();


?>