<?php
/**
 Template Name:Cart Template
 */
if ( is_user_logged_in() ) {
	
	$user = wp_get_current_user();
	
if($user->roles[0]=='customer'){
}
else{
	wp_redirect(site_url());
	exit();
}
    
	

} else {
    wp_redirect(site_url()."/login/");
	exit();
}
get_header('new');
global $wpdb;
$newpriceduration='';

if(isset($_POST['usersids'])){  $_SESSION['signup_user'] = $_POST['usersids'];
$_POST['usersids'] = $_POST['usersids'];
}

if(isset($_POST['submitsetbyitem'])){ 
	$byboxpricemonth=$_POST['byboxpricemonth'];
	$byitempricemonth = $_POST['byitempricemonth'];
	$newpriceduration.= $byboxpricemonth.",".$byitempricemonth;
	$boxcat= $_POST['boxcatname'];
	$exppricemonth=explode(",",$newpriceduration);
	$_SESSION['pricestorage_duration'] = $exppricemonth;
	$userid = $_SESSION['signup_user'];
	
	$cartupdates=$wpdb->update('wp_cart', array('categoryId'=>$boxcat,'monthdurationPrice'=>$newpriceduration), array('userid'=>$_SESSION['signup_user']));
	
}

if(isset($_SESSION['signup_user'])){
	$signup_user= $_SESSION['signup_user'];

 
	$selectstatements=$wpdb->get_results("select * from wp_cart where userid=$signup_user");

	foreach($selectstatements as $cusdetails){  
	$box_category_id=$cusdetails->categoryId; 
	$price_storage_month= $cusdetails->monthdurationPrice;
			
	}
	$box_category_id_exp=explode(",",$box_category_id);

$_SESSION['pricestorage_duration'] =explode(",",$price_storage_month); 	
}
if(isset($_SESSION['pricestorage_duration'])){
$byboxpricemonth=	$_SESSION['pricestorage_duration'][0];
$byitempricemonth=	$_SESSION['pricestorage_duration'][1];
}

$currencyvalue = get_option( 'currency_set' );
$args=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query = new WP_Query( $args );


$args1=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => array(3,2),
		),
	));
$the_query1 = new WP_Query( $args1 );

//If session has been created combine both ids and quantity Session arrays
if($_SESSION["product_id"])
{
$pricestoragesession=$_SESSION['pricestorage_duration'];
if((!empty($_SESSION["product_id"])) ||($_SESSION["product_qty"]))
{
	//print_r($_SESSION);
if((!empty($_SESSION["product_id"])&& ($_SESSION["product_qty"]))){	
$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);
}
}
$totalsessionprice = $_SESSION['totprices'];
}
?>

<div class="thankyou_out">

<div class="container">
<form method="post" action="<?php echo site_url('order'); ?>" id="selectservice_form_out">
<div class="table-responsive cartpageordering">
<div class="srch-range byitem_changeprice">
<?php 
//print_r($_SESSION);

if($_SESSION['store_duration_months']==''){?>
	<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3,2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
<?php }
if($_SESSION['store_duration_months']=='3-5 Months'){?>
	<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3,2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
<?php } 

if($_SESSION['store_duration_months']=='6-11 Months'){?>
	<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3,2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
<?php } 

if($_SESSION['store_duration_months']=='12+ Months'){ ?>
	<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3,2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
<?php } 

if($_SESSION['store_duration_months']=='store plan'){?>
	<ul class="change_prices">
							<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="3,2" data-attr="store_plan">Pay as you store plan</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default" data-value="3,2" data-attr="ktstorage_type_price">3-5 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="storage_type_price_six">6-11 Months</a></li>
							<li><a href="javascript:void(0);" class="btn btn-default " data-value="3,2" data-attr="storage_type_price_twelve">12+ Months</a></li>
						</ul>
<?php } 

 ?>
						
					</div>
<table class="table table-striped table-bordered">


<?php
$k=1;
$i=0;
// The Loop
$stotypeids = array();
$storetypes = array();
echo '<tr>';
if ( $the_query1->have_posts() ) {
	
	while ( $the_query1->have_posts() ) {
		 
		$the_query1->the_post();
		
		$stotypeid=get_the_ID();
		
		$termsids = wp_get_post_terms($stotypeid,'storagetypecat');
		//print_r($termsids);
		$posttermids = $termsids[0]->term_id;
		$value = get_field( "text_field", 123 );
		
		$newprice = get_field("store_plan",get_the_ID());
		$byitempricemonth = $newprice;
		$ktstorage_type_price=$newprice;
		$proqty=0;
		
		$stotypeids[] = get_the_ID();
		$storetypes[] = $ktstorage_type_price;
		$ktstorage_type_image = get_field('ktstorage_type_image');
		$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
		$ktstorage_gallery_images = get_field('storage_type_gallery'); 
		
		if($pro_qty_array_session)
		{
			$proqty=$pro_qty_array_session[$stotypeid];
			$pro_perprice=$proqty*$ktstorage_type_price;
		}
		echo '<td class="gllimgs"><div class="cartporimages"><img src="'.$ktstorage_type_image.'" /></div>
		<div class="cartpagetitle"><h5>
		' . get_the_title().'</h5><h6 class="boxpr">'.$currencyvalue ."$".$ktstorage_type_price. '</h6><h6>Max.'.$ktstorage_type_max_weight.'kg</h6>
		<a id="open-pop-up-'.get_the_ID().'" href="javascript:void(0);">Details</a>
		
		<div id="pop-up-'.get_the_ID().'" class="pop-up-display-content">
			<div class="sb_pro_sub">
				<div class="sb_pro_img">
					<div class="popuptit_price">
						<h5 class="popup_title">'.get_the_title().'</h5>
						<span class="prod-price">'.$currencyvalue.'$ <strong>'.$ktstorage_type_price.'</strong></span>
						
					</div>
					<div class="popupimg"><img src="'.$ktstorage_type_image.'"></div>
				</div>
				<div class="sb_pro_details">
					'.get_the_content().'
					
				</div>
			</div>
		</div>
		<script type="text/javascript">
			jQuery(document).ready(function () {
				//basic pop-up
				jQuery("#open-pop-up-'.get_the_ID().'").click(function(e) {
					e.preventDefault();
					jQuery("#pop-up-'.get_the_ID().'").popUpWindow({action: "open"});
				});

			   
			});
		</script>
		</div>
		
			<div class="sp-quantity">
			<div class="sp-minus fff"> <a class="ddd" href="javascript:void(0);">-</a>
			</div>
			<div class="sp-input">
			<input type="text" class="quntity-input" name="product_qnty[]" value="'.$proqty.'" />
			<input type="hidden"  name="product_ids[]" value="'.get_the_ID().'" />
			<input type="hidden"  name="product_ids_months[]" value="'.$ktstorage_type_price.'" />
			</div>
			<div class="sp-plus fff"> <a class="ddd" href="javascript:void(0);">+</a>
			</div>
			<div class="hiddenprices">
			<input type="hidden" class="price_per_pro price_per_product'.$k.'" value="'.$ktstorage_type_price.'"></div>
			<input type="hidden" class="price_per_pro_total" value="'.$pro_perprice.'">
			<input type="hidden" class="product_terms_ids" value="'.$posttermids.'">
			
			</div>
			
		</td>';
		
		$k++;
		
	}
	
	
	/* Restore original Post Data */
	wp_reset_postdata();
}
echo '</tr>';

$totalprice='';
if($pro_qty_array_session)
{
	$totalprice=$totalsessionprice;
}
?>



<tr><td class="total_price_cart" colspan="2">Total</td><td colspan="4" class="total_pr"><?php if($totalprice) {echo $currencyvalue."$".$totalprice;}else{echo $currencyvalue."$"."0";}?>

</td></tr>
</table>
</div>
<input type="hidden" value="<?php echo $totalprice; ?>" class="total_pr_input" name="totalprice">
<input type="hidden" name="signupuser" value="<?php if(isset($_POST['totalprice'])){echo $_POST['signupuser'];} else { echo $signup_user; } ?>" id="usrid">
<input type="hidden" name="catids" value="<?php if(isset($_POST['totalprice'])){echo $_POST['catids'];} else { echo $box_category_id; } ?>">
<input type="hidden" name="pricestorenames" value="<?php if(isset($_POST['submitsetbyitem'])){ echo $newpriceduration; } else {$_POST['pricestorename']; }?>">
<input type="hidden" value="<?php echo $currencyvalue;?>" name="hidden_currency_label" class="currency_label"> 
<?php  
if($_SESSION['store_duration_months']!=''){ ?>
	<input type="hidden" class="hiddenpricedurations" name="hiddendurations" value="<?php echo $_SESSION['store_duration_months'];?>" />
<?php
}else { 
?>
<input type="hidden" class="hiddenpricedurations" name="hiddendurations" value="store plan" />
<?php } ?>
<?php $_SESSION['product_id'] = $stotypeids; ?>
<input type="submit" name="proselect_sub" class="cartsubmit"  value="Submit Order" onclick="return form_validationcart('selectservice_form_out');">
</form>

<?php
if(isset($_POST['totalprice'])){ //print_r($storetypes); 

$hiddendurations = $_POST['hiddendurations'];
$_SESSION["product_id"]= $_POST['product_ids'];
$_SESSION["product_qty"]= $_POST['product_qnty'];
$_SESSION["product_months"]= $storetypes;
$_SESSION["store_duration_months"]= $hiddendurations;
$_SESSION["product_terms_id_cats"]=$_POST['product_terms_ids'];

$arr=array();
foreach ($_POST as $key=>$value){
	if($key=='signupuser'){} 
	else{
	$arr[] = array($key => $value);
	$encodejson = json_encode($arr);
	}
	
}
$signup_user = $_POST['signupuser'];
$_SESSION['signup_user'] = $_POST['signupuser'];
$_SESSION["product_qty"] = $_POST['product_qnty'];
$categoryid = $_POST['catids']; 

global $wpdb;
$selects=$wpdb->get_results("select * from wp_cart_items where userid=$signup_user AND categoryid IN($categoryid)");
$counter=0;
foreach($selects as $userdetails){

	$counter++;
}

if($counter>=1){ 
 
$updatesx = $wpdb->update('wp_cart_items', array('userid'=>$signup_user,'cartitems'=>$encodejson,'categoryid'=>$categoryid), array('userid'=>$signup_user,'categoryid'=>$categoryid));
$_SESSION['categories_id'] = $categoryid; 

?>
<script type = "text/javascript" language = "javascript">
jQuery(document).ready(function() {

//alert ("image uploaded successfully");
window.location = "<?php echo get_bloginfo('url');?>/schedule-a-pick-up/";

});
</script>
<?php 	

}
else{ 

	$insert = $wpdb->insert('wp_cart_items', array(
				'userid' =>$signup_user,
				'cartitems' =>$encodejson,
				'categoryid' => $categoryid,
				)); 
	
				
				$lastid = $wpdb->insert_id;

if($insert){ $_SESSION['categories_id'] = $categoryid;  ?> 

<script type = "text/javascript" language = "javascript">
jQuery(document).ready(function() {

window.location = "<?php echo get_bloginfo('url');?>/login";

});
</script>
<?php }
}
}
?>

<script>
function form_validationcart(formid)   
{


		var flag = ''; 
		var error_Msg='';
		var error_Msg = "Select Quantity :: Please correct the following : ";
		var myform =jQuery('#'+formid);
		
		var total_price_val =myform.find('.total_pr_input').val();
	
		if(total_price_val=='' || total_price_val==0)
		{
			flag = 1;
			error_Msg += "\n - Please Select a Product";
		}
		if(flag == 1)
		{

			jAlert(error_Msg, 'Required Fields');

		

			return false;

		}

		else{

			

		return true;

		}

		
}
		

jQuery(document).ready(function(){
	var currencylabel = jQuery('.currency_label').val();
	jQuery(".ddd").on("click", function () {

    var $button = jQuery(this);
    var oldValue = $button.closest('.sp-quantity').find("input.quntity-input").val();

    if ($button.text() == "+") {
        var newVal = parseFloat(oldValue) + 1;
    } else {
        // Don't allow decrementing below zero
        if (oldValue > 0) {
            var newVal = parseFloat(oldValue) - 1;
        } else {
            newVal = 0;
        }
    }
	

    $button.closest('.sp-quantity').find("input.quntity-input").val(newVal);
	
	//custom js
	var price_per_pro= $button.parent().parent().find('.price_per_pro').val();
	//alert (oldValue + price_per_pro);
	var total_per_pro=newVal*price_per_pro;

	var currencylabel = jQuery('.currency_label').val();
	
	$button.parent().parent().find('.price_per_pro_total').val(total_per_pro);
	
	var total = 0;
	var values = jQuery('.price_per_pro_total').map(function() { return this.value; }).get();
	jQuery.each(values , function(i, val) { 
	 addval=values[i];
	  total += addval << 0;
	 
	});
	var oldtotal=jQuery('.total_pr_input').val();
	
	jQuery('.total_pr_input').val(total);
	jQuery('.total_pr').html(currencylabel+"$"+ total);

});



});


</script>



</div>
</div>
	
<?php	
 get_footer(); ?>