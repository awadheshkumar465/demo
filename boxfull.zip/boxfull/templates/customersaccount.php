<?php
/**
 Template Name:Customers Account Template
 */

get_header();
print_r($_SESSION);
if(isset($_SESSION['catidsess']) && isset($_SESSION['postupdtedid'])){
	 $catids = $_SESSION['catidsess'];
	 //print_r($_SESSION);
	 $hidden_change_prices= $_SESSION['hiddenchangeprices'];

	 global $wpdb;
	 $productsids=$_SESSION['postupdtedid'];
	$current_users = wp_get_current_user();
	$selectstatements=$wpdb->get_results("select productid,productimgids from wp_userupload_proimages where customerid=$current_user->ID and productid=$productsids");
	
	foreach($selectstatements as $cusdetails){  //print_r($cusdetails);
		$productids.=$cusdetails->productimgids.",";
		$postupdtedidss[] = $cusdetails->productid;
			
	} 
	$postupdtedids= array_unique($postupdtedidss);
	//print_r($postupdtedids);
	$productimages= array_unique($productids);
	$expval = explode(",",$productids);
	

}
?>
<div class="container">
<div class="row">
<div class="col-md-12">

<?php
echo '<h2 class="text-center">'.get_the_title().'</h2>';
$myarray = array($_SESSION['postupdtedid']); 
$args = array(
   'post_type' => 'storagetype',
   'post__in'      => $myarray
);
$the_query = new WP_Query( $args ); 
if ( $the_query->have_posts() ) {
	echo '<table class="table table-bordered">
			<thead>
				<tr>
				<th>Image</th>
				<th>Box Name</th>
				<th>Add To Cart</th>
				</tr>
			</thead>
				
				<tbody>';
					while ( $the_query->have_posts() ) {

					$the_query->the_post();
					$stotypeid=get_the_ID();
					$ktstorage_type_price = get_field('ktstorage_type_price');
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
					$ktstorage_gallery_images = get_field('storage_type_gallery');
					$ktstorage_gallery_images_exp = explode(",",$ktstorage_gallery_images);
					$htmls='';
					$currencyvalue = get_option( 'currency_set' );
					$cartimgeid_new.='';
					foreach($expval as $attachimage){
						
						$image_attributes = wp_get_attachment_image_src( $attachimage );
						if($image_attributes){
						$cartimgeid_new.=$attachimage.",";	
						$htmls.='<div class="col-md-4 imageslists"><a class="editdelete href="javascript:void(0);" data-value="'.$attachimage.'" ><img class="" src="'.$image_attributes[0].'" width="'.$image_attributes[1].'" height="'.$image_attributes[2].'" /><div class="hiddenfields"><span class="edit" data-actions="edit" data-value="'.$attachimage.'" data-attr="'.$stotypeid.' ">Edit</span> &nbsp;/ <span class="delete" data-value="'.$attachimage.'" data-attr="'.$stotypeid.'" data-user="'.$current_user->ID.'"data-category="'.$catids.'">Delete</span></div></div></a>';
						
						//$htmls.='<input type="hidden" class="hiddenvalsids" name="hiddenvals[]" value="'.$attachimage.'" />';
					}
					
					 
					}
					echo '<tr>
						<td><img src="'.$ktstorage_type_image.'" />
						<div class="add_more_images"><button class="btn btn-default addmoreimg" data-categoryid="'.$catids.'" data-userid="'.$current_user->ID.'" data-productid="'.$stotypeid.'">Add More Images</button></div>
						<br/>
						<div class="formshiddenadd">
							<form id="featured_upload" method="post" action="" enctype="multipart/form-data">
							  <input type="file" name="my_image_upload[]" id="my_image_upload[]"  multiple="true" required/>
							  '.wp_nonce_field("'my_image_upload", "my_image_upload_nonce" ).'
							  <input id="submit_my_image_upload" name="submit_my_image_upload" type="submit" value="Upload" />
							  <input type="hidden" class="hidden_postids" name="post_ids" value="'.$stotypeid.'" />
							 
							</form>
						</div>
						<h5>Product Images</h5>'//.do_shortcode('[gallery ids="'.$ktstorage_gallery_images.'"]')
						.'<br/>'.$htmls.'
						<div class="formshidden">
							<form id="featured_upload" method="post" action="" enctype="multipart/form-data">
							  <input type="file" name="my_image_upload[]" id="my_image_upload[]"  multiple="true" required />
							  '.wp_nonce_field("'my_image_upload", "my_image_upload_nonce" ).'
							  <input id="submit_my_image_upload" name="submit_my_image_upload" type="submit" value="Upload" />
							  <input type="hidden" class="hidden_postids" name="post_ids" value="" />
							  <input type="hidden" class="hidden_oldimgpostids" name="old_img_post_ids" value="" />
							  <input type="hidden" class="hidden_editimgpostids" name="edit_img_post_ids" value="" />
							  <input type="hidden" class="hidden_addimgpostids" name="add_img_post_ids" value="" />
							</form>
						</div>
						</td>
						<td>'.get_the_title().'<br/>'.$currencyvalue ."$".$hidden_change_prices.'/box per month'.'</td>
						<td><form action="'.get_bloginfo("url").'/cart" method="POST" name="addtocart">
						<input type="hidden" name="cart_post_id" value="'.$stotypeid.'" class="cartpost_id" /> 
						<input type="hidden" name="cart_prod_img_id" value="'.$cartimgeid_new.'" class="cart_product_imagaids" >
						<input type="hidden" name="cart_cat_id" value="'.$catids.'" class="cart_cateids" >
						<input type="submit" name="cart_submit" value="Add To Cart" class="btn btn-default cartsumbit" /> 
						</form>
						</td>
					</tr>';
					
					}
					echo '</tbody></table>';
					/* Restore original Post Data */
					wp_reset_postdata();
					
					
					if(isset($_POST['post_ids'])) { 
					$post_id=$_POST['post_ids'];
					$oldimagepostids=$_POST['old_img_post_ids'];
					
					if (isset( $_POST['my_image_upload_nonce']))
					{
						require_once( ABSPATH . 'wp-admin/includes/image.php' );
						require_once( ABSPATH . 'wp-admin/includes/file.php' );
						require_once( ABSPATH . 'wp-admin/includes/media.php' );


						$files = $_FILES["my_image_upload"]; 
						$attach_id=[];  
						foreach ($files['name'] as $key => $value) {            
						if ($files['name'][$key]) { 
						$file = array( 
						'name' => $files['name'][$key],
						'type' => $files['type'][$key], 
						'tmp_name' => $files['tmp_name'][$key], 
						'error' => $files['error'][$key],
						'size' => $files['size'][$key]
						); 
						$_FILES = array ("my_image_upload" => $file); 


						foreach ($_FILES as $file => $array) {              

						$attach_id[]= media_handle_upload( $file,$post_id );



						}
						} 
						}
						if ( is_wp_error( $attachment_id ) ) {
   
						} else {


						//$edit_img_post_ids=$_POST['edit_img_post_ids'];
						global $wpdb;
						$table_name = $wpdb->prefix . 'userupload_proimages';
						$selectimageids=$wpdb->get_results("select * from $table_name where productid= $post_id and boxid=$catids and customerid=$current_user->ID"); 
						$newids=array();
						$product_image_ids='';
						
						foreach($selectimageids as $newvals){
							//print_r($newvals);
							$newvals->productimgids;
							$product_image_ids.= $newvals->productimgids;
							
						} 
						
						$result='';
						if(isset($oldimagepostids)){ 
						$expvalids = explode(",",$product_image_ids);
						$arr = array_diff($expvalids, array($oldimagepostids));
						foreach($arr as $newvals){
							$result.=$newvals.",";
						}
						}
						else {
							$result.=$product_image_ids.",";
							
						}
						
						foreach($attach_id as $vals){
						$result.=$vals.",";
						}
						
						$result = rtrim($result,',');
						
						update_field('storage_type_gallery', $result, $post_id);
						
						
						$count_query = "select count(*) from $table_name where productid= $post_id and boxid=$catids and customerid=$current_user->ID";
						$num = $wpdb->get_var($count_query);

						
						if($num >=1){ 
						$wpdb->update($table_name, array('productimgids'=>$result), array('productid'=>$post_id,'customerid'=>$current_user->ID)); 
						$_SESSION['postupdtedid'] = $post_id;
						?>
						<script type = "text/javascript" language = "javascript">
						jQuery(document).ready(function() {

						alert ("image updated successfully");
						window.location = "<?php echo get_bloginfo('url');?>/customers-account";

						});
						</script>
						<?php
						}
						else{ exit();
						$insertdb= $wpdb->insert('wp_userupload_proimages', array(
						'customername' => $current_user->user_firstname,
						'customerid' => $current_user->ID,
						'boxid' => $catids,
						'boxidprefix' => $boxid,
						'productimgids' => $result,
						'productid' => $post_id,	// ... and so on
						));
						$lastInsertId = $wpdb->useruploadproimgid; 
						$_SESSION['postupdtedid'] = $post_id;

						}


						if($insertdb==1){ ?>
						<script type = "text/javascript" language = "javascript">
						jQuery(document).ready(function() {

						alert ("image uploaded successfully");
						window.location = "<?php echo get_bloginfo('url');?>/customers-account";

						});
						</script>
						<?php

						}
						//var_dump($attachment_id);
						}
					}
					}
					} 
					
					
					
					
					else {
					echo "no posts found";
					}
					
					
?>
</div>
</div>
</div>
<?php	
 get_footer(); ?>