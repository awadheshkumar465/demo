<?php 
/* Template Name: Success Page Template */
get_header('new');
global $wpdb;
$site_admin_email = get_bloginfo('admin_email');
$subscr_id=$_POST['subscr_id'];
$residence_country=$_POST['residence_country'];
$mc_currency=$_POST['mc_currency'];
$payer_email=$_POST['payer_email'];
$payer_id=$_POST['payer_id'];
$payer_status="paid";
$paymentmode="Paypal";
$current_user=get_currentuserinfo();
$current_user_email = $current_user->user_email;

$wpdb->update('wp_orders', array('subscr_id'=>$subscr_id, 'residence_country'=>$residence_country, 'mc_currency'=>$mc_currency, 'payer_email'=>$payer_email, 'payer_id'=>$payer_id,'paymentstatus'=>$payer_status,'paymentmode'=>$paymentmode,'stufflocation' =>'home'), array('useremail'=>$current_user_email)); ?>
<div class="container"><div class="row"><!--<a class="btn btn-default" href="<?php echo get_bloginfo('url');?>/user-home/?type=order">Click to see orders</a>-->
<?php $location=get_bloginfo('url')."/user-dashboard/?type=showall";
$getcartdetails = $wpdb->get_results("SELECT * FROM `wp_orders` inner join wp_order_products ON  wp_orders.order_id= wp_order_products.order_id WHERE wp_orders.useremail='$current_user_email' AND wp_orders.paymentstatus='paid'"); ?>
	<?php
	if($getcartdetails){
		$to = $site_admin_email;
		$subject ='New Order Product';
		$topmessage='Your New Product is Ordered';
		$subject = 'New Order';
		$message = "";
		$message = '<html>
		<head>
		<title>HTML email</title>
		</head>
		<body>';
		$message.='<table>';
		$message.='<tr>
			<th>Product Name</th>
			<th>Product QTY</th>
			<th>Product Price</th>
			<th>Product Final Price</th>
			<th>Date/Time</th>
		';
		$message.='</tr>';
		foreach ($getcartdetails as $value) 
		{
			$message.='<tr>
				<td>'.$value->productname.'</td>
				<td>'.$value->productqty.'</td>
				<td>'.$value->productprice.'</td>
				<td>'.$value->finalprice.'</td>
				<td>'.$value->datetime.'</td>
			</tr>';
		}
		$message.='</table>';
		$new_order_message = trim(get_option('new_order_message'));
		$from_email = get_option('from_email_id');
		$message.=$new_order_message.'<br/>This Order confirms on KlutterClear.';
		$message.'</body></html>';
 		$multiple_recipients = array(
            $current_user_email,
            $to
            ); 
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: <'.$from_email.'>' . "\r\n";
		$endmails = wp_mail( $multiple_recipients, $subject, $message, $headers);
		if($endmails){echo "send";}else{echo "notsend";} 
		//exit();?>
		<script type = "text/javascript" language = "javascript">
			jQuery(document).ready(function() {
			alert ("New product Order Successfully");
			window.location = "<?php bloginfo('url');?>/user-dashboard?type=showprofile";
			});
		</script>
	
		<?php 

	} 
	else 
	{
		echo 'error';
	}
 //wp_redirect($location); ?>
</div></div>
<?php
get_footer();
?>