<?php
/* Template Name: Login Page */
?>

<?php get_header('new');

//print_r($_SESSION);
if(is_user_logged_in()){
	$user = wp_get_current_user();
if(isset($_SESSION['categories_id'])){
$user = wp_get_current_user();


$catid= $_SESSION['categories_id'];

if($user->roles[0]=='author')
{
	if(!empty($catid)){ ?>
		<script type = "text/javascript" language = "javascript">
jQuery(document).ready(function() {

//alert ("image uploaded successfully");
window.location = "<?php echo get_bloginfo('url');?>/schedule-a-pick-up"; 

});
</script>
<?php }
}

}
}
else { 



?>

<section class="inner_page_content">
		<div class="container">
			<div class="row">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}

			// End of the loop.
		endwhile;
		?>
		</div>
</div>
</section>
<?php } ?>
<?php get_footer(); ?>