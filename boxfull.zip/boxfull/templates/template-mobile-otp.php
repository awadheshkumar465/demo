<?php
/*
Template Name: Mobile OTP
*/

// Get the PHP helper library from twilio.com/docs/php/install
require_once 'Twilio/autoload.php'; // Loads the library
use Twilio\Rest\Client;

// Your Account Sid and Auth Token from twilio.com/user/account
$sid = "ACdeb8553570d084a08ce56f2e53ff5304";
$token = "5e9dc5cdab924908b8a2d16339f2d589";
$client = new Client($sid, $token);
print_r($client);
$client->messages
    ->create(
        "+917987126210",
        array(
            "from" => "+919981261974",
            "body" => "Jenny please?! I love you <3",
            "mediaUrl" => "http://www.example.com/hearts.png"
        )
    );