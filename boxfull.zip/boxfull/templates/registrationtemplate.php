<?php
/**
 Template Name:User Registration
 */

get_header('new');
if(ICL_LANGUAGE_CODE=='zh-hant'){
	$trans1 = '個人';
	$trans2 = '公司';
	$trans3 = '用戶名（顯示名稱）';
	$trans4 = '名字';
	$trans5 = '姓';
	$trans6 = '電話';
	$trans7 = '電郵';
	$trans8 = '輸入密碼';
	$trans9 = '確認你的密碼';
	$trans10 = '驗證碼';
	$trans11 = '輸入驗證碼';
	$trans12 = '我已閱讀並同意';
	$trans13 = '服務條例和私隱條例';
	$trans14 = '用戶名';
	
}
else{
	$trans1 = 'Personal';
	$trans2 = 'Business';
	$trans3 = 'Username (Display Name)';
	$trans4 = 'First Name';
	$trans5 = 'Last Name';
	$trans6 = 'Telephone';
	$trans7 = 'Email';
	$trans8 = 'Enter a Password';
	$trans9 = 'Confirm your password';
	$trans10 = 'Captcha';
	$trans11 = 'Enter Captcha';
	$trans12 = 'I have read and agree';
	$trans13 = 'Terms of Use and the Privacy Polic';
	$trans13 = 'Username';
}
global $wpdb;
$user_type = 'personal';

?>
			<?php
					if(isset($_POST['user_register_sub'])){
						$user_name = trim($_POST['user_username']);
						$first_name= $_POST['user_firstname'];
						$user_lastname = $_POST['user_lastname'];
						$user_phone = $_POST['user_telephone'];
						$user_email = trim($_POST['user_email']);
						$user_pwd = $_POST['user_password'];
						$user_profile_image= $_FILES['user_profile_image']['name'];
						$user_id = username_exists( $user_name );
						$user_type = "personal";

							if ( !$user_id and email_exists($user_email) == false ) 
							{ 
							    global $wpdb;
							   $user_id = wp_create_user( $user_name, $user_pwd, $user_email );

									 $insert = $wpdb->insert('wp_cart', array(
									'categoryId' =>'',
									'postId' =>'',
									'storeplan' =>'',
									'PostimgId' =>'',
									'countryIp' =>'',
									'cartSession' =>'',
									'price' =>'',
									'monthdurationPrice' =>'',
									'userid' => $user_id,
									'userimgprodileid' => '',
									'username' => $user_name,
									'useremail' => $user_email,
									)); 
									//echo $insert; exit();
									$lastid = $wpdb->insert_id; 
							  	//}
								//}					   
							    $userdata_ar=array('first_name'=>$first_name,'last_name'=>$user_lastname,'user_phone'=>$user_phone,'user_email'=>$user_email,'user_personal'=>$user_type);
							    custom_update_user_meta($userdata_ar,$user_id);
							    $url=site_url('order');
							  
							    $to = $user_email;
							  
							    $subject = get_bloginfo("name").' User Registration';
							    $topmessage='Thankyou for your recent registration on our '.get_bloginfo("name").'.
											This email confirms our receipt of your registration.You will be able to login on our site after admin Approval.';
								
								mail_data('',$topmessage,$to,$subject,$user_name);			
								$_SESSION['lastinsertedid'] = $lastid; 			
							 	$selectusers = $wpdb->get_results("select userid from wp_cart where userid=$user_id ");		
								$redurl=site_url('order');			
								 wp_set_auth_cookie( $user_id );
							    wp_set_current_user( $user_id );
							    $custom_page_url = home_url( '/order');
							    wp_redirect( $custom_page_url );
							    exit;
								?>        
						         <?php		
								}
								else
								{
									$_SESSION['signup_user'] = $user_id;
									$random_password = __('Email Id or Username already exists.');
									echo '<div class="error-div-main"><p class="reg_error exits">'.$random_password.'</p></div>';								
								}
							} 
						?>
			

						<!-- Business Form -->
						<?php
					if(isset($_POST['business_register_sub'])){
						$company_name = $_POST['company_name'];
						$office_number = $_POST['office_number'];
						$user_name = trim($_POST['business_username']);
						$first_name= $_POST['business_firstname'];
						$user_lastname = $_POST['business_lastname'];
						$user_phone = $_POST['business_telephone'];
						$user_email = trim($_POST['business_email']);
						$user_pwd = $_POST['business_password'];
						$user_profile_image= $_FILES['business_profile_image']['name'];
						$user_id = username_exists( $user_name );
						$user_type = "business";
							if ( !$user_id and email_exists($user_email) == false ) 
							{ 
							    global $wpdb;
							   $user_id = wp_create_user( $user_name, $user_pwd, $user_email );
									 $insert = $wpdb->insert('wp_cart', array(
									'categoryId' =>'',
									'postId' =>'',
									'storeplan' =>'',
									'PostimgId' =>'',
									'countryIp' =>'',
									'cartSession' =>'',
									'price' =>'',
									'monthdurationPrice' =>'',
									'userid' => $user_id,
									'userimgprodileid' => '',
									'username' => $user_name,
									'useremail' => $user_email,
									)); 
									//echo $insert; exit();
									$lastid = $wpdb->insert_id; 
							  	//}
								//}					   
							    $userdata_ar=array('first_name'=>$first_name,'last_name'=>$user_lastname,'user_phone'=>$user_phone,'user_email'=>$user_email,'user_business'=>$user_type,'company_name'=>$company_name,'office_number'=>$office_number);
							    custom_update_user_meta($userdata_ar,$user_id);
							    $url=site_url('order');
							  
							    $to = $user_email;
							  
							    $subject = get_bloginfo("name").' User Registration';
							    $topmessage='Thankyou for your recent registration on our '.get_bloginfo("name").'.
											This email confirms our receipt of your registration.You will be able to login on our site after admin Approval.';
								
								mail_data('',$topmessage,$to,$subject,$user_name);			
								$_SESSION['lastinsertedid'] = $lastid; 			
							 	$selectusers = $wpdb->get_results("select userid from wp_cart where userid=$user_id ");		
								$redurl=site_url('order');			
								 wp_set_auth_cookie( $user_id );
							    wp_set_current_user( $user_id );
							    $custom_page_url = home_url( '/order');
							    wp_redirect( $custom_page_url );
							    exit;
								?>        
						         <?php		
								}
								else
								{
									$_SESSION['signup_user'] = $user_id;
									$random_password = __('Email Id or Username already exists.');
									echo '<div class="error-div-main"><p class="reg_error exits">'.$random_password.'</p></div>';								
								}
} 

if($user_type == 'business'){ ?>
<style>
#personal_user{

	display: none;
}
</style>
<?php }else{ ?>
<style>
#business_user{

	display: none;
}
</style>

<?php }
?>
<div class="main-category-cont">
	
	<section class="categry-main registerout">
		<div class="container">
			<div class="row">
				<div class="sign-up-tapage">
	                <div class="cntct-head ragi">
	                  	<div class="col-md-12 no-padding">
	                      	<div class="md-heading text-center">
	                        	<h1>Register</h1>
	                      	</div>
	                      	<div class="cntct-head-txt text-center">
					            <p>Please fill in the following fields and click on submit button to start using our services</p>
					            <p>Do you want to set up a personal or a business account?</p>
	                      	</div>
	                      	<!-- start 14-12-2017 -->
							<div class="rlt-form">
														
								<div class="lft">
									<label for="personal">
									<input type="radio" id="personal" name="user_type" value="personal" <?php if($user_type == 'personal'){ echo "checked";}?> />
									<span><?php echo $trans1; ?></span>
									</label>
								</div>
								<div class="rgt">
									<label for="business">
									<input type="radio" id="business" name="user_type" value="business" <?php if($user_type == 'business'){ echo "checked"; } ?>  />
									<span><?php echo $trans2; ?></span>
									</label>
								</div>
							</div>
							<!-- Ending -->
	                  	</div>
	                </div>
					<div class="main-catgry-sec">
						<div class="row">
							<div class="col-md-12">
								<div class="contrct-reg personal" id="personal_user">
									<form method="post" action="" id="user_registrations" enctype="multipart/form-data" name="signup" >
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label for="user_username"><?php echo $trans3; ?>:<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $first_name; ?>" name="user_username" class="form-control" id="user_username" placeholder="<?php echo $trans14; ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_firstname"><?php echo $trans4; ?> :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $first_name; ?>" name="user_firstname" class="form-control" id="user_firstname" placeholder="<?php echo $trans4; ?>">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_lastname"><?php echo $trans5; ?> :<span class="requiredpart">*</span>:</label>
													<input type="text" value="<?php echo $user_lastname; ?>" name="user_lastname" class="form-control" id="user_lastname" placeholder="<?php echo $trans5; ?>">
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_telephone"><?php echo $trans6; ?> :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $user_phone; ?>" name="user_telephone" class="form-control" id="user_telephone" placeholder="<?php echo $trans6; ?>">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_email"><?php echo $trans7; ?> :<span class="requiredpart">*</span></label>
													<input type="email" value="<?php echo $user_email; ?>" name="user_email" class="form-control" id="user_email" placeholder="<?php echo $trans7; ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_password"><?php echo $trans8; ?> :<span class="requiredpart">*</span></label>
													<input type="password" value="<?php echo $user_pwd; ?>" name="user_password" class="form-control" id="user_password" placeholder="<?php echo $trans8; ?>">
												</div>
												
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="user_confirm_password"><?php echo $trans9; ?> :<span class="requiredpart">*</span></label>
													<input type="password" name="user_confirm_password" class="form-control" id="user_confirm_password" placeholder="<?php echo $trans9; ?>">
												</div>
											</div>						
										</div>	
							
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="contr_captcha"><?php echo $trans10; ?> :<span class="requiredpart">*</span></label><br/>
													<?php
													$rand=substr(rand(),0,4);
													?>
													
													<input type="text" value="<?php echo $rand;?>" id="ran" readonly="readonly" class="captcha" disabled="disabled">
													<!--<input type="button" class="refer_captcha" value="Refresh" onclick="captch()" />-->
													<i class="fa fa-refresh" onclick="captch()" title="Refresh"></i>
												</div>
												</div>
												<div class="col-md-6">
												<div class="form-group">
													<label for="contr_captcha"><?php echo $trans11; ?> :<span class="requiredpart">*</span></label>
													<input type="text" name="contr_captcha" class="form-control" id="contr_captcha" placeholder="<?php echo $trans11; ?>">
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
												<input type="checkbox" name="termsouse" id="termsouse" class="termsofuse"><?php echo $trans12; ?><a href="<?php echo get_bloginfo('url');?>/terms-of-use/" target="_blank"><?php echo $trans13; ?></a><span class="requiredpart">*</span>
												</div>
											</div>
										</div>
									
										<div class="row">
											<div class="col-md-12">
												<div class="user_reg_sub_out">
													<input type="hidden" name="type" value="personal">
													<input type="submit" name="user_register_sub" value="Submit" />
													<input type="hidden" id="ajaxUrl" value="<?php echo admin_url('admin-ajax.php'); ?>" />
												</div>  
											</div>
										</div>					
									</form>
						    </div>						
						    <!-- Create new Business Form -->
						    <div class="contrct-reg" id="business_user">
									<form method="post" action="" id="business_registrations" enctype="multipart/form-data" name="business_signup" >
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="company_name">Company Name :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $company_name; ?>" name="company_name" class="form-control" id="company_name" placeholder="Company Name">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="office_number">Office Number :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $office_number; ?>" name="office_number" class="form-control" id="office_number" placeholder="Office Number">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label for="business_username"><?php echo $trans3; ?> :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $user_name; ?>" name="business_username" class="form-control" id="business_username" placeholder="<?php echo $trans14; ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_firstname"><?php echo $trans4; ?> :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $first_name; ?>" name="business_firstname" class="form-control" id="business_firstname" placeholder="<?php echo $trans4; ?>">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_lastname"><?php echo $trans5; ?> :<span class="requiredpart">*</span></label>
													<input type="text" value="<?php echo $user_lastname; ?>" name="business_lastname" class="form-control" id="business_lastname" placeholder="<?php echo $trans5; ?>">
												</div>
											</div>
										</div>
										
										
											
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_telephone">Mobile Number :</label>
													<input type="text" value="<?php echo $user_phone; ?>" name="business_telephone" class="form-control" id="business_telephone" placeholder="Telephone">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_email"><?php echo $trans7; ?> :<span class="requiredpart">*</span></label>
													<input type="email" value="<?php echo $user_email; ?>" name="business_email" class="form-control" id="business_email" placeholder="<?php echo $trans7; ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_password"><?php echo $trans8; ?> :<span class="requiredpart">*</span></label>
													<input type="password" value="<?php echo $user_pwd; ?>" name="business_password" class="form-control" id="business_password" placeholder="<?php echo $trans8; ?>">
												</div>
												
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_confirm_password"><?php echo $trans9; ?> :<span class="requiredpart">*</span></label>
													<input type="password" name="business_confirm_password" class="form-control" id="business_confirm_password" placeholder="<?php echo $trans9; ?>">
												</div>
											</div>						
										</div>	
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="business_captcha"><?php echo $trans10; ?> :<span class="requiredpart">*</span></label><br/>
													<?php
													$rand=substr(rand(),0,4);
													?>
													
													<input type="text" value="<?php echo $rand;?>" id="business_ran" readonly="readonly" class="captcha" disabled="disabled">
													<!--<input type="button" class="refer_captcha" value="Refresh" onclick="captch()" />-->
													<i class="fa fa-refresh" onclick="captch()" title="Refresh"></i>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="contr_captcha"><?php echo $trans11; ?> :<span class="requiredpart">*</span></label>
													<input type="text" name="business_captcha" class="form-control" id="business_captcha" placeholder="<?php echo $trans11; ?>">
												</div>
												
												
											</div>
										
											<div class="col-md-12">
												<div class="form-group">
												
												<input type="checkbox" name="termsouse" id="termsouse" class="termsofuse"><?php echo $trans12; ?> <a href="<?php echo get_bloginfo('url');?>/terms-of-use/" target="_blank"><?php echo $trans13; ?></a><span class="requiredpart">*</span>
													
												</div>
											</div>
										</div>
									
										
											
										<div class="row">
											<div class="col-md-12">
												<div class="user_reg_sub_out">
													<input type="hidden" name="type" value="business">
													<input type="submit" name="business_register_sub" value="Submit" />
													<input type="hidden" id="ajaxUrl" value="<?php echo admin_url('admin-ajax.php'); ?>" />
												</div>  
											</div>
										</div>					
									</form>
						        </div>	


						       <!-- End Business Form -->	
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('input[type=radio][name=user_type]').change(function() {
	    if (this.value == 'personal') {
	        jQuery("#personal_user").show();
	       jQuery("#business_user").hide();
	    }
	    else if (this.value == 'business') {
	        jQuery("#personal_user").hide();
	         jQuery("#business_user").show();
	    }
	});

  	jQuery("#user_registrations").validate({
     	rules: {                   
					user_username: {
						required: true
					},
					termsouse:"required",
					user_firstname: "required",
					user_lastname: "required",
					user_telephone: {
						required: true,
						number: true,
						phonenumber: true
					},
					user_pickup_address: "required",
					user_email:{
						required: true,
						emailvalidation: true
		   			 },
					user_password:{
						required: true,
						minlength: 7
					},
					user_confirm_password: {
						equalTo : "#user_password"
					},
					contr_captcha: {
						equalTo : "#ran"
					},
					user_profile_image: "required"  
				},  
			errorElement: "span" ,                              
			messages: {
				user_firstname: "Please Enter First Name.",
				user_lastname: "Please Enter Last Name.",
				user_pickup_address: " Enter User Pick up address",
				email: "Please Enter Email",
				user_password: "Please Enter Password.",
				user_confirm_password: "Password and Confirm Password are not matching",
				contr_captcha: "Please Enter Captcha Code.",
				termsouse : "Please check terms & condition.",
				user_profile_image: "Please upload image."
			},
			submitHandler: function(form) {
            	form.submit();
           }
 	});

	jQuery.validator.addMethod("emailvalidation",function(value,element){
	 return value.match(/^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i);
       },"Please Enter Valid Email.");

	jQuery.validator.addMethod("phonenumber",
       function(value, element) {
           return value.match(/^(\s*|\d+)$/);
       },"Please type correct phone number");
	   
	jQuery.validator.addMethod("checkAvailability",function(value,element){
		var result = false;
   		var useremail = value;
		var ajax_url = jQuery('#ajaxUrl').val();
		if(useremail != ''){
	 		jQuery.ajax({
          		url: ajax_url,
          		type: "post",
          		async: false,
          		data: { action: 'checkemail', useremails: useremail},
            	success: function(response) { //alert(response);
				result = (response == "0")? false : true;
			  //alert(result);
			} 			
      	});
	}	
	 return result; 
},"Email Already Exists");

	jQuery.validator.addMethod("validatephone",function(value,element){
		var result = false;
		var ajax_url = jQuery('#ajaxUrl').val();
   		var chk_phone_number = jQuery("#user_telephone").val();
			jQuery.ajax({
	          url: ajax_url,
	          type: "POST",
	          async: false,
	          data: { action: 'checkphone', phonecheck: chk_phone_number},
	            success: function(response) { //alert(response);
				result = (response == "1") ? true : false;
			} 			
    });
	 return result; 
},"Phone Number Already Exists");

jQuery.validator.addMethod("checkUsername",function(value,element){
	var result = false;
    var userName = value; 
	var ajax_url = jQuery('#ajaxUrl').val();
	if(userName != ''){
	 jQuery.ajax({
          url: ajax_url,
          type: "POST",
          data: { action: 'checkUser', userName: userName},
            success: function(response) { 
			   result = (response == "1") ? true : false;
			} 			
      });
	}	
	
return result; 
},"User Already Exists");


/* registrationpage form validation using jquery and ajax ends here */	

/* customer and admin side (left sidebar) menu toggle section starts here  15-12-2017*/

  jQuery("#business_registrations").validate({
     rules: {                   
				business_username: {
					required: true
					
				},
			termsouse:"required",
			business_firstname: "required",
			business_lastname: "required",
			company_name: "required",

			office_number: {
			required: true,
			//minlength: 10,
			number: true,
			phonenumber: true
			},

			business_telephone: {
			required: true,
			//minlength: 10,
			number: true,
			phonenumber: true
			},
			user_pickup_address: "required",
			business_email:{
			required: true,
			//email: true,
			emailvalidation: true
		    },
	
			business_password:{
			required: true,
			minlength: 7
			},
			business_confirm_password: {
			required: true,
			equalTo : "#business_password"
			},
			business_captcha: {
			equalTo : "#business_ran"
			},
			user_profile_image: "required"  
		},  
			errorElement: "span" ,                              
		messages: {
			company_name: "Please Enter Company Name.",
			business_firstname: "Please Enter First Name.",
			business_lastname: "Please Enter Last Name.",
			business_pickup_address: " Enter User Pick up address",
			email: "Please Enter Email",
			business_password: "Please Enter Password.",
			business_confirm_password: "Password and Confirm Password are not matching",
			business_captcha: "Please Enter Captcha Code.",
			termsouse : "Please check terms & condition.",

			},
			submitHandler: function(form) {
            form.submit();
			
           }
 });
 });
/* registration page Region field on change function starts here */
</script>
<?php get_footer(); ?>

