<?php
/* Template Name: Final Checkout Page Template */ ?>
<?php 
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_DISPLAY', false);
if ( is_user_logged_in() ) {
	
	$user = wp_get_current_user();
	
if($user->roles[0]=='customer'){
}
else{
	wp_redirect(site_url());
	exit();
}
    
	

} else {
    wp_redirect(site_url()."/login/");
	exit();
}
get_header('new'); 
global $wpdb;

$currency_set = get_option('currency_set',true);
//print_r($_POST);exit();
if(is_user_logged_in()){
	
	$user = wp_get_current_user(); 
	$useremail = $user->user_email;
	$_SESSION['signup_user'] = $user->ID; 

}
//print_r($_POST);

if(!empty($_SESSION['product_id'])){


if(isset($_SESSION['signup_user'])){
	$store_plan = $_SESSION['pricestorage_duration'];
	
	$signup_user = $_SESSION['signup_user'];
	$categoryid = $_SESSION['categories_id'];
	$selectUsers = $wpdb->get_results("select * from wp_cart_items where userid=$signup_user");
	foreach ($selectUsers as $vals){
		echo $cartitems = $vals->product_qnty;

		$product_details = json_decode($vals->cartitems);
	}

	$product_id_arr = array();
	if(!empty($product_details))
	{
		foreach ($product_details as $key=>$valfinal){ 
		if(!empty($valfinal->product_ids))
		{
			foreach($valfinal->product_ids as $key=>$productids){ 
			$product_id_arr[$key]=$productids;
			}
		}
		if(!empty($valfinal->product_qnty))
		{
			foreach($valfinal->product_qnty as $key=>$finalproduct_qnty){ 
			$product_qty_arr[$key]=$finalproduct_qnty;
			}
		}
			
		
		}
	}
	$_SESSION["product_id"] = $product_id_arr;
	$_SESSION["product_qty"]=$product_qty_arr;
}
$pricestoragesession=$_SESSION['pricestorage_duration'];
$categoryids=$_SESSION['categories_id'];

$signup_user=$_SESSION['signup_user'];
$user_id = $signup_user;
  $key = 'nickname';
  $single = true;
  $nickname = get_user_meta( $user_id, $key, $single );  
  $user_phone = get_user_meta( $user_id, 'user_phone', $single ); 
  $user_pickup_address = get_user_meta( $user_id, 'user_pickup_address', $single );
  if($user_pickup_address){ $user_pickup_address = $user_pickup_address;}
  if($user_phone){ $user_phone = $user_phone;}
  if($nickname){ $fullname = $nickname;}
  

if(isset($_POST['mybooking_continue']))
{
	
	$first_name=$_POST['fullname'];
	//echo $last_name=$_POST['phonenumber'];
	$user_telephone=$_POST['phonenumber'];
	$user_pickup_address=$_POST['fulladdress'];
	//$user_pickup_address2=$_POST['user_pickup_address2'];
	$user_select_region=$_POST['user_select_region'];
	$user_select_district=$_POST['user_select_district'];
	$nickname=$first_name;
	$user_phone = $user_telephone;
	$user_pickup_address = $user_pickup_address;
	
	$_SESSION['user_booking_information'] = array(
    'first_name' => $first_name,
    'last_name' => $last_name,
    'user_telephone' => $user_telephone,
    'user_pickup_address' => $user_pickup_address,
	'user_pickup_address2' => $user_pickup_address2,
	'user_select_region' => $user_select_region,
	'user_select_district' => $user_select_district,
);

}


$special_instructions='';
$how_did_find='';

if($_SESSION['user_booking_information'])
{
	$special_instructions=$_SESSION['user_booking_information']['special_instructions'];
	$how_did_find=$_SESSION['user_booking_information']['how_did_find'];
	
}
}
?>
<?php
//print_r($_POST); 

$fullname = trim($_POST['fullname']);
$phonenumber = trim($_POST['phonenumber']);
$fulladdress = trim($_POST['fulladdress']);
$countrylists = trim($_POST['countrylists']);
$regionname = get_term_by('id', $countrylists, 'country');
$region_name = $regionname->name;
$dropoff_select_dist = trim($_POST['dropoff_select_dist']);
$select_drop_off_date = trim($_POST['select_drop_off_date']);
$dropoff_select_time = trim($_POST['dropoff_select_time']);
$pickup_of_boxes = trim($_POST['pickup_of_boxes']);
$pick_select_dates = trim($_POST['pick_select_date']);
$pick_select_times = trim($_POST['pick_select_time']);
$special_instructions = trim($_POST['special_instructions']);
$how_did_find = trim($_POST['how_did_find']);
$dt = new DateTime();
$finaldate = $dt->format('Y-m-d H:i:s');
$selectfloor = trim($_POST['selectfloor']);
$countrylists = (int)trim($_POST['countrylists']);

$store_monthsduration = $_POST['store_monthsduration'];
$hiddencouponscodes = trim($_POST['hiddencouponscodes']);

if($hiddencouponscodes=='Free Month Code'){
	
	$billingdates = 'Free Month Code';
	$hiddencoupons = trim($_POST['hiddencouponsvals']);
}

if($hiddencouponscodes=='Cash Coupon Code'){
	$hiddencoupons = trim($_POST['hiddencouponsvals']);
	$billingdates = 'Cash Coupon Code';
}

if($hiddencouponscodes=='Discount Code'){
	$hiddencoupons = trim($_POST['hiddencouponsvals']);
	$billingdates = 'Discount Code';
}

if($store_monthsduration==''){$store_monthsdurations= $store_monthsduration;}else{ $store_monthsdurations=$_SESSION['store_duration_months'];}

$promocoe = trim($_POST['promocoe']);

$countryname = get_term($countrylists,'country');
//print_r($countryname);
$country_names = $countryname->name;

if($country_names =='Remote Location (see FAQ for fee)'){
	$countryflags = "1";
}

$finalamount = trim($_POST['finalamount']);

if(!empty($pick_select_dates)){
	$select_schedule_pick_off_date = trim($_POST['pick_select_date']);
	$dropoff_schedule_pick_off_time = trim($_POST['pick_select_time']);
}
else{
$select_schedule_pick_off_date = trim($_POST['select_schedule_pick_off_date']);
$dropoff_schedule_pick_off_time = trim($_POST['dropoff_schedule_pick_off_time']);
}

get_currentuserinfo();
$current_user_email = $current_user->user_email;
$displayname = $current_user->display_name;
$count_query ="SELECT count(*) AS total FROM wp_orders WHERE useremail ='$current_user_email'";
$num = $wpdb->get_var($count_query);
if($num == 0){
$insert = $wpdb->insert('wp_orders', array(
'fullname' =>$fullname,
'phonenumber' =>$phonenumber,
'fulladdress' =>$fulladdress,
'region' =>$region_name,
'district' =>$dropoff_select_dist,
'select_drop_off_date' =>$select_drop_off_date,
'dropoff_select_time' =>$dropoff_select_time,
'pickup_of_boxes' =>$pickup_of_boxes,
'pick_select_date' => $select_schedule_pick_off_date,
'pick_select_time' => $dropoff_schedule_pick_off_time,
'special_instructions' => $special_instructions,
'how_did_find' =>$how_did_find,
'useremail' =>$current_user_email,
'datetime' =>$finaldate,
'subscr_id' =>'',
'residence_country' =>'',
'mc_currency' =>'',
'payer_email' =>'',
'payer_id' =>'',
'paymentstatus' =>'',
'paymentmode' =>'',
'stufflocation' =>'',
)); 
 
$lastid = $wpdb->insert_id;  
$j=0;
foreach($_POST['productqtynames'] as $productsvals){
$insert = $wpdb->insert('wp_order_products', array(
'order_id' =>$lastid,
'productname' =>$productsvals,
'productqty' =>$_POST['productqtys'][$j],
'productprice' =>$_POST['productprices'][$j],
'finalprice' =>$_SESSION['totprices'],
'useremail' =>$current_user_email,
'productids' =>$_POST['productids'][$j],
'store_month_duration'=>$store_monthsdurations,
'billingdates'=>$billingdates,
'discount_amount'=>$hiddencoupons,

));
$j++;
}

}
else{
	//print_r($_POST); exit();
	if(!empty($_POST['phonenumber'])){

	$wpdb->update('wp_orders', array(
'fullname' =>$fullname,
'phonenumber' =>$phonenumber,
'fulladdress' =>$fulladdress,
'region' =>$region_name,
'district' =>$dropoff_select_dist,
'select_drop_off_date' =>$select_drop_off_date,
'dropoff_select_time' =>$dropoff_select_time,
'pickup_of_boxes' =>$pickup_of_boxes,
'pick_select_date' => $select_schedule_pick_off_date,
'pick_select_time' => $dropoff_schedule_pick_off_time,
'special_instructions' => $special_instructions,
'how_did_find' =>$how_did_find,
'useremail' =>$current_user_email,
'datetime' =>$finaldate,
'subscr_id' =>'',
'residence_country' =>'',
'mc_currency' =>'',
'payer_email' =>'',
'payer_id' =>'',
'paymentstatus' =>'',
'paymentmode' =>'',
'stufflocation' =>'',
), array('useremail'=>$current_user_email)); 

$deletes = $wpdb->delete('wp_order_products', array('useremail'=>$current_user_email) );
$newselects = $wpdb->get_results("select order_id from wp_orders where useremail ='$current_user_email'");
foreach($newselects as $newids){$ids=$newids->order_id;}
 
$counts_querys ="SELECT count(*) AS total FROM wp_order_products WHERE order_id =$ids";
$nums = $wpdb->get_var($counts_querys);
if($nums == 0){
$j=0;
foreach($_POST['productqtynames'] as $productsvals){
$insert = $wpdb->insert('wp_order_products', array(
'order_id' =>$ids,
'productname' =>$productsvals,
'productqty' =>$_POST['productqtys'][$j],
'productprice' =>$_POST['productprices'][$j],
'finalprice' =>$_SESSION['totprices'],
'useremail' =>$current_user_email,
'productids' =>$_POST['productids'][$j],
'store_month_duration'=>$store_monthsdurations,
'billingdates'=>$billingdates,
'discount_amount'=>$hiddencoupons,
));
$j++;
}	
}
}
}

$newproductlists = explode(",",$productsnames);
//$data['product_name'] = $newproductlists;
if(isset($_POST['promocodefieldval'])){
$promocodefieldval = trim($_POST['promocodefieldval']);
$finalpriceval=$_POST['finalpriceval'];
$currency = $_POST['currency'];
if($promocodefieldval=='FREEMONTH'){ 

 $finalprice = $_SESSION['totprices'];
$freeprice = get_option('freepromotionamount');
$newtotprice = $finalprice - $freeprice;
$_SESSION['totprices'] = $newtotprice;

$wpdb->update('wp_order_products', array(
'finalprice' =>$_SESSION['totprices'],
), array('useremail'=>$useremail)); 
}
else{
	$finalprice = $_SESSION['totprices'];
	
	}
}
else{
	
	$wpdb->update('wp_order_products', array(
'finalprice' =>$_SESSION['totprices'],
), array('useremail'=>$useremail));
}

$paypalmode = get_option( 'paypal_pay_mode' );
$paypal_seller_mail = get_option( 'paypal_seller_mail' );
$selectsorderproduct = $wpdb->get_results("select * from wp_order_products WHERE useremail ='$current_user_email'");
$thanks_page=get_bloginfo('url')."/success-payment/";
$notify_url=get_bloginfo('url')."/ipn/";


?>


<div class="schedule_booking_out">

<div class="container">
<div class="row">
<h2 class="text-center paymentoptions">Payment Options</h2>
<div class="col-md-12">
<div class="col-md-6 cartpurchase"><!--cartpurchase section starts here -->


<div class="cartdetailslists">			
					
					<div class="purchase_out_sec"> <?php //print_r($_SESSION); ?>
					<div class="purchase_outmain">
					<div class="purchase_out">
					<h3>Storage</h3>
					<div class=""></div>
					
					<?php 
					$currencycodes = get_option('currency_set');
					$totalsessionprice='';
					$tetings='';
					$all_stairs_fees = 0;
						$hdndlingfeebyboxsums=0;
						$boxqtysum = 0;
					if($_SESSION["product_id"])
					{
						$hdndlingfeebyboxsums=0;
						$pro_pricemonth_array_session[]=array_combine($_SESSION["store_duration_months"],$_SESSION["product_qty"]);
						//print_r($pro_pricemonth_array_session);
						$total='';
						$totfinal=array();
						$priceshtmls=array();
						
					
					$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);
					$totalsessionprice=get_total_price_using_session_cart($pro_qty_array_session,$pricestoragesession,$categoryids); 
					
					$i=1;
					$s=0;
					global $wpdb; $signup_user = $_SESSION['signup_user'];
					$finprice = 0;
					
					foreach($pro_pricemonth_array_session as $proprice=>$proqty){
						
						if($proqty==0){} else{
							
							$totsum[]=$proprice*$proqty;
							$pricepro[]=$proprice;
							$selects = $wpdb->get_results("select checkcartitemsid from checkoutcartitems where userid = $signup_user");
							
							//$wpdb->update('checkoutcartitems', array('price'=>$proprice), array('userid'=>$signup_user));
							
						}
						}
						$j=0; $sum=0; $tot=0;
						
					foreach($pro_qty_array_session as $proid=>$proqty)
					{ 
						if($proqty==0){} else{ 
						
						if($_SESSION["store_duration_months"]=='store plan'){
							$storefields = 'store_plan';
						}
						
						if($_SESSION["store_duration_months"]=='3-5 Months'){
							$storefields = 'ktstorage_type_price';
						}
						
						if($_SESSION["store_duration_months"]=='6-11 Months'){
							$storefields = 'storage_type_price_six';
						}
						
						if($_SESSION["store_duration_months"]=='12+ Months'){
							$storefields = 'storage_type_price_twelve';
						}
						
						$newprice = get_field($storefields,$proid);
						$tot = $newprice*$proqty;
						$totsum[]=$newprice*$proqty;
						$sum=$sum+($tot);
						$titles=get_the_title($proid);
						$testings.=$proqty.",".$titles.",";
						$testing[]=array('qty'=>$proqty,'proitem'=>$titles);
						
						
						//echo $proqty;
						//echo $pricepro[$j];
						//echo "select * from wp_postmeta where meta_value = ".$pricepro[$j]." and post_id = ".$proid." ";
						$mduration = getMonthDurationByProductId($proid,$pricepro[$j]);
						
						foreach($mduration as $montduration){
							$storagedurations = $montduration->meta_key;
							if($storagedurations=='store_plan'){$storageduration[]="Store Plan";}
							if($storagedurations=='ktstorage_type_price'){$storageduration[]="3-5 Months";} 
							if($storagedurations=='storage_type_price_six'){$storageduration[]="6-11 Months";} 
							if($storagedurations=='storage_type_price_twelve'){$storageduration[]="12+ Months";} 
						}
						$storeby = getStorageType($proid);
						$storeboxitems = $storeby[0]['name'];
						$no_of_floors = $selectfloor;
						/*
						if($storeboxitems=='Store by the item')
						{
							;
						$itemminprice = 80;
						
						$hdndlingfeebyitems = getHandlingFeeByItemFrontend($pricepro[$j],$proqty,$storageduration[$j],$itemminprice);
						
						
						}
						
						if($storeboxitems=='Store by the box')
						{
							;
						$boxminprice = 100;
						
						$hdndlingfeebyboxs = getHandlingFeeByBoxFrontend($pricepro[$j],$proqty,$storageduration[$j],$boxminprice);
						
						
						}
						$hdndlingfeebyboxsums = $hdndlingfeebyboxsums + $hdndlingfeebyitems +$hdndlingfeebyboxs;*/
						
						$all_stairs_fees = $all_stairs_fees + $stairs_addfeeitems + $stairs_addfee_box;
						
						if($countryflags=='1'){
						$remotee_fee = getRemoteefeeFrontend();
						}
						
						echo '<div class="str_dtls">';
						echo '<div class="odrDtls">'.$_SESSION["store_duration_months"].'</div>';
						echo '<div class="odrDtls">'.$proqty.' * '.get_the_title($proid).'</div>';
						echo '<div class="odrDtls">'.$currencycodes.'$'.$tot.'</div>';
						echo "</div>";
						$j++;
						}
						
					}
					

					}
					
					?>
					
					</div>
					</div>
					<div class="total_out minicart">
					<div class="total_out_left minicart">
					Total:
					
					</div>
					<div class="total_out_right">
					<?php echo $currency_set."$".$sum;  ?>
					</div>
					
					<div class="total_out_left minicart" style="clear: left;">
					Additional Fee:
					
					</div>
					<?php 
					$discountamount = 0;
					
					$stairs_fee = AdditonalFeeByBoxFrontend($no_of_floors,$boxqtysum);
					
					$additionals_fee = $stairs_fee + $remotee_fee;
					
					if($hiddencouponscodes=='Free Month Code'){
							
					}
					if($hiddencouponscodes=='Cash Coupon Code'){
						$hiddencoupons = trim($_POST['hiddencouponsvals']);
						$labels = "Cash Discount";	
						$discountamount = $hiddencoupons;
					}
					if($hiddencouponscodes=='Discount Code'){
						
						$hiddencoupons = trim($_POST['hiddencouponsvals']);	
						$labels = "Discount Amount";
						$getdiscountamo = round(($sum * $hiddencoupons)/100,2);
						$discountamount = $getdiscountamo;
						
					}

					?>
					<div class="total_out_right" style="clear: right;">
					<?php echo $currency_set."$".$additionals_fee;  ?>
					</div>
					
					<?php if($labels) { ?>
					<div class="total_out_left minicart" style="clear: left;">
					<?php echo $labels.":"; ?>
					
					</div>
					
					<div class="total_out_right" style="clear: right;">
					<?php echo $currency_set."$".$discountamount;  ?>
					</div>
					<?php } ?>
					
					<div class="total_out_left minicart" style="clear: left;">
					Final Price:
					
					</div>
					<div class="total_out_right" style="clear: right;">
					
						<?php $finprice =round($sum - ($additionals_fee + $discountamount),2); 
						if (strpos($finprice, '-') !== false) {
							$finprice =0;
						}
						//$_SESSION['totprices'] = $sum;
						$updateinfos = $wpdb->get_results("select * from wp_orders where useremail='$useremail'",ARRAY_A);
						$order_ids =$updateinfos[0]['order_id']; 
						$updateordrs = $wpdb->update('wp_order_products', array('finalprice'=>$finprice), array('order_id'=>$order_ids));
						echo $currency_set."$".$finprice; $_SESSION['totprices'] = $finprice; ?>
					
					</div>
					
					<?php 
					foreach($selectsorderproduct as $productsdetails){
					//echo "<pre>"; print_r($productsdetails); echo "</pre>";
					
						$productsnames.= $productsdetails->productname.",";
						$price = $productsdetails->finalprice;
						if($price ==0){$price=floatval(0.1);}else{$price=$productsdetails->finalprice;}
						
						$paypal_seller_mail = get_option('paypal_seller_mail'); 
						$data=array(
						'merchant_email'=>$paypal_seller_mail,
						'product_name'=>"$productsnames",
						'f_amount'=>$price, 	// trail Period Amount
						'f_cycle'=>'M',		// trail Period M=montrh,Y=year ,D=Days, W='week'
						'f_period'=>1, 	// trail Cycle
						's_amount'=>$price,		// Second` Amount
						's_cycle'=>'M',		// Second Period M=montrh,Y=year ,D=Days, W='week'
						's_period'=>1,		// Second Cycle
						'currency_code'=>'HKD',
						'thanks_page'=>$thanks_page,
						'notify_url'=>$notify_url,
						'cancel_url'=>get_the_permalink(),
						'currency_symbole'=>'HKD$'
						);
						//print_r($data);
					}

					?>
					
					</div>
					
					
					
					</div>
					
					
					<script type="text/javascript">
					jQuery(document).ready(function(){
						jQuery('div.left>div').each(function(){
							var i=0;
						//var intext[i] = jQuery(this).text(); 
						//jQuery('.col-md-4.largefonts').html(intext);
						});
						//alert (intext);
						
					});
					
					</script>
</div><!-- div cart toggle section starts here -->	
</div> <!--cartpurchase section starts here -->	

 


<div class="col-md-6 payment_optn <?php //echo $class;?>"><!-- div class all payment parts starts here -->	
<div class="col-sm-3 swipecard" ><!-- credit card starts here -->
<div id="credit-card-option" class="selected">
<!--<input type="radio" name="payment-option" id="credit-card" value="credit-card" checked="checked">-->
<label class="creditcardlabel" for="credit-card"><img id="master-img" src="<?php echo get_stylesheet_directory_uri(); ?>/images/master1.png" ><img id="visa-img" src="<?php echo get_stylesheet_directory_uri(); ?>/images/visas_change.png"></label>
<div class="check"></div>
</div>
</div><!-- credit card ends hre -->
<!-- paypal logo starts here -->
<div class="col-sm-3 papaloptions">
<div id="paypal-option" class="">
<!--<input type="radio" name="payment-option" id="paypal" value="paypal">-->
<label class="paypallabel" for="paypal"><img id="paypal-img" src="<?php echo get_stylesheet_directory_uri(); ?>/images/paypal_change.png"></label>
<div class="check"></div>
</div>
</div>
<!-- paypal logo ends here -->	
<!-- checque payment starts here -->
<div class="col-md-3 chequepayments">
<div id="toggle_checquepayment" class="chequepayment_label">
<label class="checquelabel"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/Check_change.png" class="img-responsive"></label>
</div>

</div>
<!-- checque payment ends here -->


<!-- checque payment starts here -->
<div class="col-md-3 bankpayments">
<div id="toggle_bankpayment" class="bankpayment_label">
<label class="banklabel"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/Bank_change.png" class="img-responsive"></label>
</div>

</div>
<!-- checque payment ends here -->



<!-- visa card form starts here -->

<div class="col-md-12 crditcard"  style="margin-top:40px;"> 

<?php echo do_shortcode('[simpay id="1016"]'); 
 ?>              
</div>
<!-- visa card form ends here -->

<?php 	
if(isset($_POST['pay_now'])){
echo '<link rel="stylesheet" type="text/css" href="style.css" />';
echo '<div class="wait">PayPal is processing the payment, please wait...</div>';
echo '<div class="loader">
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</div>'; 
echo infotutsPaypal($data);
}else{
$periods=array('M'=>'months','Y'=>'years','D'=>'days','W'=>'weeks');
$period=array('M'=>'month','Y'=>'year','D'=>'day','W'=>'week');

$fullperiod=(isset($data['f_period']) && $data['f_period']>1)?$data['f_period'].' '.$periods[$data['f_cycle']]:$period[$data['f_cycle']];
$fullperiod2=(isset($data['s_period'])	&& $data['s_period']>1)?$data['s_period'].' '.$periods[$data['s_cycle']]:$period[$data['s_cycle']];
?>
<div id="product" class="col-md-12">
<form id='paypal-info' method='post' action='#'>

<label>	Product Name : <?php echo $data['product_name']; ?>
</label></br>
<label>Product Price : <b><?php echo $data['currency_symbole'].$data['f_amount'] . ' '.
"for the first ". $fullperiod. " Then ". $data['currency_symbole'].$data['s_amount'] . ' '." for each " .$fullperiod2; ?></b></label>

<input type='submit' name='pay_now' id='pay_now' value='Pay' />
</form>
</div>
<?php } ?>

<!-- div class checque payment starts here -->
<div class="col-md-12 checquepaymentby" id="allchecquepayments">
<div class="cahecque checque_details">
<?php echo get_option('cheque_credentials'); ?>
<?php 
$selects_checque = $wpdb->get_results("select * from wp_order_products WHERE useremail ='$current_user_email'");


foreach($selects_checque as $productsdetails){
	//print_r($productsdetails);
	$order_id = $productsdetails->order_id;
	$productname[] = $productsdetails->productname.",";
	$useremail = $productsdetails->useremail;
if(isset($_POST['promocodefieldval'])){
	 $price = $productsdetails->finalprice;
}
else{
	$price = $_SESSION['totprices'];
}
}

$itemnames = '';
		foreach($productname as $i=>$k) {
			$itemnames .=$k;
		}
		$itemnames = rtrim($itemnames,',');
		
?>

		<form method="POST" action="<?php bloginfo('url');?>/new-order-checque-payment/" >
			
		<input type="hidden" name="payment_method" value="Checque Payment">
			
		<input type="hidden" name="item_name" value="<?php echo $itemnames; ?>"> 

        <input type="hidden" name="order_id" value="<?php echo $order_id;?>"> 

        <input type="hidden" name="amount" value="<?php echo $price;?>"> 

        <input type="hidden" name="currency_code" value="<?php echo $currency_set;?>">
		
		<input type="hidden" name="user_emails" value="<?php echo $useremail;?>">
		
		<input type="hidden" name="checque_details" value="<?php echo get_option('cheque_credentials'); ?>"/>
		
		<input type="submit" name="submit" value="Pay Using Cheque" >
		
		</form>
</div>
</div>
<!-- checque payment ends here -->


<!-- div class checque payment starts here -->
<div class="col-md-12 bankpaymentby" id="allbankpayments">
<div class="cahebank bank_details">
<?php echo get_option('bank_credentials'); ?>
<?php 
$selects_bank = $wpdb->get_results("select * from wp_order_products WHERE useremail ='$current_user_email'");


foreach($selects_bank as $productsdetailsbank){
	//print_r($productsdetails);
	$order_id = $productsdetailsbank->order_id;
	$productnamebank[] = $productsdetailsbank->productname.",";
	$useremail = $productsdetailsbank->useremail;
if(isset($_POST['promocodefieldval'])){
	 $price = $productsdetailsbank->finalprice;
}
else{
	$price = $_SESSION['totprices'];
}
}

$itemnamesbank = '';
		foreach($productnamebank as $i=>$k) {
			$itemnamesbank .=$k;
		}
		$itemnamesbank = rtrim($itemnamesbank,',');
		

?>

		<form method="POST" action="<?php bloginfo('url');?>/new-order-bank-transfer/" >
			
		<input type="hidden" name="payment_method" value="Bank Transfer">
			
		<input type="hidden" name="item_name" value="<?php echo $itemnamesbank; ?>"> 

        <input type="hidden" name="order_id" value="<?php echo $order_id;?>"> 

        <input type="hidden" name="amount" value="<?php echo $price;?>"> 

        <input type="hidden" name="currency_code" value="<?php echo $currency_set;?>">
		
		<input type="hidden" name="user_emails" value="<?php echo $useremail;?>">
		
		<input type="hidden" name="checque_details" value="<?php echo get_option('bank_credentials'); ?>"/>
		
		<input type="submit" name="submit" value="Bank Transfer" >
		
		</form>
</div>
</div>
<!-- checque payment ends here -->



</div><!-- div class all payment parts ends here -->


	
		
</div>					
</div>
</div>
</div>

<?php

	function infotutsPaypal( $data) {

			
			define( 'SSL_URL', 'https://www.paypal.com/cgi-bin/webscr' );
			define( 'SSL_SAND_URL', 'https://www.sandbox.paypal.com/cgi-bin/webscr' );

			$action = '';
			//Is this a test transaction? 
			
			$paypal_pay_mode = get_option( 'paypal_pay_mode' ); 
			if($paypal_pay_mode=='testmode'){$action ="https://www.sandbox.paypal.com/cgi-bin/webscr";}
			if($paypal_pay_mode=='livemode'){$action ="https://www.paypal.com/cgi-bin/webscr";}
			
			//$action = ($data['paypal_mode']) ? SSL_SAND_URL : SSL_URL;

			$form = '';

			$form .= '<form name="frm_payment_method" action="'.$action.'" method="post">';
			$form .= '<input type="hidden" name="business" value="' . $data['merchant_email'] . '" />';
			// Instant Payment Notification & Return Page Details /
			$form .= '<input type="hidden" name="notify_url" value="' . $data['notify_url'] . '" />';
			$form .= '<input type="hidden" name="cancel_return" value="' . $data['cancel_url'] . '" />';
			$form .= '<input type="hidden" name="return" value="' . $data['thanks_page'] . '" />';
			$form .= '<input type="hidden" name="rm" value="2" />';
			// Configures Basic Checkout Fields -->
			$form .= '<input type="hidden" name="lc" value="" />';
			$form .= '<input type="hidden" name="no_shipping" value="1" />';
			$form .= '<input type="hidden" name="no_note" value="1" />';
			// <input type="hidden" name="custom" value="localhost" />-->
			$form .= '<input type="hidden" name="currency_code" value="' . $data['currency_code'] . '" />';
			$form .= '<input type="hidden" name="page_style" value="paypal" />';
			$form .= '<input type="hidden" name="charset" value="utf-8" />';
			$form .= '<input type="hidden" name="item_name" value="' . $data['product_name'] . '" />';
			//$form .= '<input type="hidden" value="_xclick" name="cmd"/>';
			//Recurring  Price
			 $form .= '<input type="hidden" name="cmd" value="_xclick-subscriptions" />';
 			/* Customizes Prices, Payments & Billing Cycle */
 			$form .= '<input type="hidden" name="src" value="1" />';
			/* Value for each installments */
 			$form .= '<input type="hidden" name="srt" value="0" /> ';
			//$form .= '<input type="hidden" name="custom" value="'.$current_user_email.'"> ';
			
			$form .= '<input type="hidden" name="a1" value="'. $data['f_amount'] . '" />';
			/** First Period 	*/
			$form .=  '<input type="hidden" name="p1" value="'. $data['f_period'] . '" />';
			/** First Period Cycle e.g: Days,Months	*/
			$form .= '<input type="hidden" name="t1" value="'. $data['f_cycle'] . '"/>';
			/** Second Period Price	*/
			 $form .= '<input type="hidden" name="a3" value="'. $data['s_amount'] . '" />';
			/** Second Period 	*/
			 $form .= '<input type="hidden" name="p3" value="'. $data['s_period'] .'" />';
			/** Second Period Cycle 	*/
			$form .= '<input type="hidden" name="t3" value="'. $data['s_cycle'] . '" />';
			$form .= '</form>';
			$form .= '<script>';
			$form .= 'setTimeout("document.frm_payment_method.submit()", 0);';
			$form .= '</script>';
			return $form;
		}
?>

<?php get_footer();?>
<script type="text/javascript">
jQuery('#credit-card-option').click(function(){
	jQuery('.crditcard').addClass('show');
	jQuery('.crditcard').removeClass('showhide');
	jQuery('#product').removeClass('show');
	
});
jQuery('#paypal-option').click(function(){
	
	//jQuery('#paypal-info').toggle('slow');
	//jQuery('#card_frm').toggle('slow');
	jQuery('#product').addClass('show');
	jQuery('.crditcard').addClass('showhide');
	
	
});
</script>
