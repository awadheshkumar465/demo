<?php
/* Template Name: Admin Dashboard */

?>

<?php get_header('user');  //echo session_status();
if(is_user_logged_in()){
	$user = wp_get_current_user(); 
	//$user_country = get_user_meta($user->ID,'country_code',true);
$type=$_GET['type'];
$editpostid=$_GET['post'];
$posttype=$_GET['post_type'];
$cateid=$_GET['cateid'];

?>

<div class="col-md-3 dashboard_sidebar">

      <ul class="resp-tabs-list hor_1">
        <h3>My Account</h3>
        <li id="storagetypes"><i class="fa clickplus <?php if(($type=='showall' || $type=='') ||($type=='edit') ||($type=='addnewstorage')||($type=='storagetypecate')||($type=='storagetypecat')){echo "fa-expand";}else{ echo "fa-plus";} ?>"></i>Storage Types    
		<ul class="sub-child showmenu <?php if(($type=='showall' || $type=='') ||($type=='edit') ||($type=='addnewstorage')||($type=='storagetypecate')||($type=='storagetypecat')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=showall">All Storage Types</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addnewstorage">Add New</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=storagetypecate">Storage Type Categories</a></li>
		</ul>
		</li>
        <li><i class="fa clickplus <?php if(($type=='alldistricts')||($type=='editdistrict') ||($type=='addnewdistrict') ||($type=='allregions')||($type=='addnewregion')||($type=='editregion')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Regions  
		<ul class="sub-child showmenu <?php if(($type=='alldistricts')||($type=='editdistrict') ||($type=='addnewdistrict') ||($type=='allregions')||($type=='addnewregion')||($type=='editregion')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=alldistricts">All Districts</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addnewdistrict">Add New Districts</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=allregions">All Regions Lists</a></li>
		</ul>
		</li>
		 <li><i class="fa clickplus <?php if(($type=='allusers')||($type=='editUsers')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Users
		<ul class="sub-child showmenu <?php if(($type=='allusers')||($type=='editUsers')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=allusers">All Users</a></li>
			 
		</ul>
		</li>
		<li><i class="fa clickplus <?php if(($type=='orders')){echo "fa-expand";}else{ echo "fa-plus";} ?>"></i> Orders
		<ul class="sub-child showmenu <?php if(($type=='orders')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=orders">All Orders</a></li>
		</ul>
		
		</li>
		 <li><i class="fa clickplus <?php if(($type=='allboxes')||($type=='inventorymanagement')||($type=='outstandingboxes')||($type=='deliveredscheduled')||($type=='editboxid') ||($type=='addboxid')||($type=='transaction_history')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Inventory Management 
		<ul class="sub-child showmenu <?php if(($type=='allboxes')||($type=='inventorymanagement')||($type=='editboxid') ||($type=='outstandingboxes') ||($type=='deliveredscheduled')||($type=='addboxid')||($type=='transaction_history')){echo "showallsubchild";}?>">
			<li>
				<a href="<?php echo get_the_permalink();?>?type=inventorymanagement">Inventory Management </a>
			</li>
			<li>
				<a href="<?php echo get_the_permalink();?>?type=allboxes">All Box Numbers</a>
			</li>
			<li>
				<a href="<?php echo get_the_permalink();?>?type=outstandingboxes">Outstanding Boxes</a>
			</li>
			<li>
				<a href="<?php echo get_the_permalink();?>?type=deliveredscheduled">Delivered Schedule</a>
			</li>
			<!--<li><a href="<?php echo get_the_permalink();?>?type=editboxid">Edit Box</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addnewboxno">Add New Box Number</a></li>-->
			
		</ul> 
		</li>
		
		
		<li><i class="fa clickplus <?php if(($type=='billingmanagement')|| ($type=='mannualbillings')|| ($type=='showbillproductslists')||($type=='editmannualbillings')|| ($type=='addotherbills')||($type=='editotherbillingid')||($type=='viewbillingtemplate')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Billing Management 
		<ul class="sub-child showmenu <?php if(($type=='billingmanagement')|| ($type=='mannualbillings')|| ($type=='showbillproductslists')||($type=='editmannualbillings')|| ($type=='addotherbills')||($type=='editotherbillingid')){echo "showallsubchild";}?>">
			<li>
				<a href="<?php echo get_the_permalink();?>?type=billingmanagement">Billing Management </a>
			</li>
			
			<li>
				<a href="<?php echo get_the_permalink();?>?type=showbillproductslists">Show Products Lists </a>
			</li>
			
			<!--* <li>
				<a href="<?php //echo get_the_permalink();?>?type=mannualbillings">Manual Billing </a>
			</li> -->
			
			
		</ul> 
		</li>
		
		
		  <li><i class="fa clickplus <?php if(($type=='allpromotions')||($type=='editpromotions') ||($type=='cashcoupancode') ||($type=='addfreemonthpromotion')|| ($type=='freepromotioncode')|| ($type=='editdiscountcoupan') || ($type=='editcashcoupan') ){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> All Promotions  
		<ul class="sub-child showmenu <?php if(($type=='allpromotions')||($type=='editpromotions') ||($type=='cashcoupancode') ||($type=='addfreemonthpromotion')|| ($type=='freepromotioncode')|| ($type=='editdiscountcoupan') || ($type=='editcashcoupan')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=allpromotions">All Promotions</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addfreemonthpromotion">Add Free Month Promotion</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=cashcoupancode">Add Cash Coupan Code</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=adddiscountcoupon">Add Discount Coupon</a></li>
			
		</ul>
		</li>
		
		<li><i class="fa clickplus <?php if(($type=='feetypes')||($type=='addbyboxhandlingfee') ||($type=='addbyitemhandlingfee')||($type=='addbyitemhandlingfee')  ||($type=='adddeliveryfee')  ||($type=='editbyboxhandlingfee')||($type=='addadditonalfee')||($type=='editdeliveryfee')||($type=='editadditionalfee')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> All Fee Types  
		<ul class="sub-child showmenu <?php if(($type=='feetypes')||($type=='addbyboxhandlingfee') ||($type=='addbyitemhandlingfee') ||($type=='adddeliveryfee')||($type=='addadditonalfee') ||($type=='editbyboxhandlingfee')||($type=='editbyitemhandlingfee')||($type=='editdeliveryfee')||($type=='editadditionalfee')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=feetypes">Fee Types</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addbyboxhandlingfee">Add Handling Fee By Box</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addbyitemhandlingfee">Add Handling Fee By Items</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=adddeliveryfee">Add Delivery Fee</a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addadditonalfee">Add Additional Fee</a></li>
		</ul> 
		</li>
		<li><i class="fa clickplus <?php if(($type=='datetimeavailability') || ($type=='adddatetimeavailability') ||($type=='editatetimeavailability')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Date Time Availability  
		<ul class="sub-child showmenu <?php if(($type=='datetimeavailability') || ($type=='adddatetimeavailability') ||($type=='editatetimeavailability')){echo "showallsubchild";}?>">
			
			<li><a href="<?php echo get_the_permalink();?>?type=adddatetimeavailability">Add Available Date And Time</a></li>
			
		</ul> 
		</li>
		
		<li><i class="fa clickplus <?php if(($type=='addschedulecategory') || ($type=='show_schedule_category_keyword_lists') || ($type=='editschedulecategory')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Category / Keywords  
		<ul class="sub-child showmenu <?php if(($type=='addschedulecategory') || ($type=='show_schedule_category_keyword_lists') || ($type=='editschedulecategory')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=show_schedule_category_keyword_lists">Category / Keywords Lists  </a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=addschedulecategory">Add Category / Keywords </a></li>
		</ul> 
		</li>
		</li>
		
		<li><i class="fa clickplus <?php if(($type=='scheduleareturninfo') ||($type=='editstatus')|| ($type=='editstatusreturnschedule')||($type=='showallprolists')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> All Schedule Information  
		<ul class="sub-child showmenu <?php if(($type=='scheduleareturninfo') ||($type=='editstatus')||($type=='showallprolists')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=scheduleareturninfo">All Schedule Information </a></li>
			
			
		</ul> 
		</li>
		
		<li><i class="fa clickplus <?php if(($type=='setupadminmessages')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i> Messages Set Up 
		<ul class="sub-child showmenu <?php if(($type=='setupadminmessages')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=setupadminmessages">All Messages Set Up </a></li>
			
			
		</ul> 
		</li>
		
		<!-- 07-01-2018 Start -->
		<li><i class="fa clickplus <?php if(($type=='bankandchecque') ||($type=='paymentdetails')){echo "fa-expand";}else{ echo "fa-plus";}?>"></i>Bank & Cheque Details
		<ul class="sub-child showmenu <?php if(($type=='bankandchecque') ||($type=='paymentdetails')){echo "showallsubchild";}?>">
			<li><a href="<?php echo get_the_permalink();?>?type=bankandchecque">Add Bank & Cheque Details </a></li>
			<li><a href="<?php echo get_the_permalink();?>?type=paymentdetails">All Payment Details </a></li>
			
			
		</ul> 
		</li>
		<!-- 07-01-2018 End-->


		
		</li>
	</ul>
	
    </div>
    <div class="dashboard_rig_main">
      <div class="resp-tabs-container hor_1">
	  <div>
          <div class="Schedule_main">
            <div class="Schedule_main_one">
              <div class="dash-counter users-main">
				<h2><?php if($type=='alldistricts'){echo "All District";}if($type=='addnewdistrict'){echo "Add New District";}
				if($type=='editdistrict'){echo "Edit District";} if($type=='allregions'){ echo 'All Regions';
				echo '<a href="'.get_the_permalink().'/?type=addnewregion" class="addnewregions">Add New</a>';
				}
				if($type=='editregion'){echo "Edit Region";}
				if($type=='addnewregion'){echo "Add New Region";}
				if($type=='edit'){echo 'Edit Storage';} if($type=='addnewstorage'){echo 'Add New Storage';} if($type=='showall') { echo 'Storage Types';}if($type=='storagetypecate') { echo 'Storage Category';?><button class="addnewcate">Add New</button><?php }
				if($type=='allusers'){echo "Users";}
				if($type=='editUsers'){
					if(!empty($_GET['userId'])){ echo "Edit User";}
				}
				if($type =='orders'){echo "Orders";}
				?>
				
				</h2>
                <div class="user-table ">
				<!--Showing all storage types posts lists -->
				<?php //print_r($_REQUEST); ?>
				<?php include( locate_template( 'includes/show_all_storagetypes_posts.php', false, false ) ); ?>
				
				<!--Showing all storage types posts lists -->
				<?php 
				if($type =='addnewstorage'){
					include( locate_template( 'includes/add_post_type_storages.php', false, false ) );
					}
					
				/*Add storage type posts section HTML ends  here */
					?>
					
				<?php 
				if($type=='storagetypecate'){
				
				include( locate_template( 'includes/show_storage_categories.php', false, false ) );
				include( locate_template( 'includes/add_storage_category.php', false, false ) );
				include( locate_template( 'includes/edit_storage_category.php', false, false ) );
				} 
				
				/* All districts HTMl starts here */
				include( locate_template( 'includes/show_all_districts.php', false, false ) );
				/* All districts HTMl ends here */
				
				/*edit section starts here */
				 include( locate_template( 'includes/edit_storage_post.php', false, false ) );
				/* edit storage posts ends here */
				
				/* Edit district starts here */ 
				include( locate_template( 'includes/edit_district.php', false, false ) );
				/* Edit district ends here */
				
				/* Add District Starts Here */
				include( locate_template( 'includes/add_new_district.php', false, false ) );
				/* Add District Ends Here */
				
				/* Show all Regions starts here */
				include( locate_template( 'includes/all_regions.php', false, false ) );
				/* Show all Regions ends here */
				
				/* Edit Region Starts Here */
				include( locate_template( 'includes/edit_region.php', false, false ) );
				/* Edit Region Ends Here */
				
				/* Add New Post and edit region Form Starts here */
				include( locate_template( 'includes/add_new_region.php', false, false ) );
				/* Add New Post and edit region Form Ends here */
				
				/* show all users html starts here */
				include( locate_template( 'includes/show_all_users.php', false, false ) );
				/*show all users html ends here */
				
				/*edit user html starts here */				
				include( locate_template( 'includes/edit_user.php', false, false ) );
				/*edit user html ends here */
				
				/* Listing order starts here */
				if($type=='orders'){
					include( locate_template( 'includes/show_all_orders.php', false, false ) );	
				}
				/* Listing Orders end here */
				
				/* show order lists details */
				if(($type=='orderdetailslists') || ($type=='schedulereturnhistory') || ($type=='scheduleapickuplist')) { 
						include( locate_template( 'includes/show_orders_details.php', false, false ) );
				}
				
				
				
				/* Show inventory management code lists here */
				if(($type=='inventorymanagement')){ 
				include( locate_template( 'includes/inventorymanagement.php', false, false ) );
				}
				if(($type=='transaction_history_lists')){ 
				include( locate_template( 'includes/transaction_history_lists.php', false, false ) );
				
				}
				
				
				/* show All Transction History List details */
				if($type=='transaction_history'){ 
						include( locate_template( 'includes/transaction_history.php', false, false ) );
				}
				
				/* Show All Transction History lists here */
				
				/* Show inventory management code lists here */
				
				/* Billing Management starts here */
				if(($type=='billingmanagement')){
					include( locate_template( 'includes/billingmanagement.php', false, false ) );
				}
				
				if($type=='mannualbillings'){
					include( locate_template( 'includes/mannual_billings.php', false, false ) );
				}
								
				
				if($type=='editmannualbillings'){
					include( locate_template( 'includes/edit_manual_billing.php', false, false ) );
				}
				
				if($type=='showbillproductslists'){
					include( locate_template( 'includes/show_manual_billslists.php', false, false ) );
				}
				
				if($type=='addotherbills'){
					include( locate_template( 'includes/add_other_bills.php', false, false ) );
				}
				
				if($type=='editotherbillingid'){
					include( locate_template( 'includes/edit_other_bills.php', false, false ) );
				}
				
				
				/* Billing Management ends here */
				
				/* Show all products box number code lists here */
				if(($type=='allboxes')){ 
				include( locate_template( 'includes/allboxes.php', false, false ) );
				}
				/* Show all products box number code lists here */

				/* Show alloutstandingboxes code lists here */
				if(($type=='outstandingboxes')){ 
				include( locate_template( 'includes/outstandingboxes.php', false, false ) );
				}
				/* Show all outstandingboxes code lists here */
				/* Show all deliveredscheduled code lists here */
				if(($type=='deliveredscheduled')){ 
				include( locate_template( 'includes/deliveredscheduled.php', false, false ) );
				}
				/* Show all deliveredscheduled code lists here */


				/* Edit box starts here */
				if($type=='editboxid'){
					include( locate_template( 'includes/editbox.php', false, false ) );
				}
				/* Edit box ends here */
				/* Add products Box Id code lists here */
				if(($type=='addboxid')){ 
				include( locate_template( 'includes/addboxnumber.php', false, false ) );
				}
				/* Add products Box Id code lists here */
				
				
				/* show all promotions */
				if(($type=='allpromotions')|| ($type=='promotioncode')|| ($type=='freepromotioncode')){
				include( locate_template( 'includes/showallpromotions.php', false, false ) );
				}
				
				/*Show all promotions ends here */
				/* Add free month promotion code */
				if($type=='addfreemonthpromotion'){
					include( locate_template( 'includes/addfreemonthpromotion.php', false, false ) );
				}
				/* Add free month promotion code ends here */
				
				/* Add new cash coupon section starts here */
				if($type=='cashcoupancode'){
				include( locate_template( 'includes/cashcoupancode.php', false, false ) );
				}
				/* Add new cash coupon section ends here */
				
				/* View all types of fee */
				if($type=='feetypes'){
				include( locate_template( 'includes/feetypes.php', false, false ) );
				}
				/*View all types of fee ends here */
				
				/* Add Fee By BOx */
				if($type=='addbyboxhandlingfee'){
				include( locate_template( 'includes/addfeebybox.php', false, false ) );
				}
				
				if($type=='addbyitemhandlingfee'){
				include( locate_template( 'includes/addfeebyitem.php', false, false ) );
				}
				
				if($type=='adddeliveryfee'){
				include( locate_template( 'includes/adddeliveryfee.php', false, false ) );
				}
				
				if($type=='editbyboxhandlingfee'){
				include( locate_template( 'includes/edithandlingfee.php', false, false ) );
				}
				
				if($type=='editbyitemhandlingfee'){
				include( locate_template( 'includes/edithandlingfee.php', false, false ) );
				}
				
				if($type=='editdeliveryfee'){
				include( locate_template( 'includes/edithandlingfee.php', false, false ) );
				}
				
				if($type=='addadditonalfee'){
				include( locate_template( 'includes/addadditionalfee.php', false, false ) );
				}
				/*View all types of fee ends here */
				
				
				if($type=='adddatetimeavailability'){
				include( locate_template( 'includes/adddatetimeschedule.php', false, false ) );
				}
				
				if($type=='editatetimeavailability'){
				include( locate_template( 'includes/editdatetimeschedule.php', false, false ) );
				}
				
				
				/* set available date and time */
				
				
				if($type=='editadditionalfee'){
				include( locate_template( 'includes/edit_additional_fee.php', false, false ) );
				}
				
				/* show order lists details ends here */
				
				/* Show schedule a return info lists */
				if($type=='scheduleareturninfo'){
				include( locate_template( 'includes/schedule_a_return_info.php', false, false ) );
				}
				/* Show schedule a return info lists ends here */
				
				/* show all delivery listings */
				if($type=='showallprolists'){
				include( locate_template( 'includes/show_pro_lists_info.php', false, false ) );
				}
				/* showing all delivery listings ends here */
				
				
				
				/* Show schedule a return info lists */
				if($type=='editstatusreturnschedule'){
				include( locate_template( 'includes/edit_schedule_a_return.php', false, false ) );
				}
				
				/* Show schedule a pickup info lists */
				if($type=='editstatus'){
				include( locate_template( 'includes/edit_schedule_a_pickup.php', false, false ) );
				}
				/* Show schedule a pickup info lists ends here */
				
				/* Show all Schedule pick up category and keywords lists */
				if($type=='show_schedule_category_keyword_lists'){
				include( locate_template( 'includes/show_all_schedule_pickup_categories_keyword.php', false, false ) );
				}
				/* show all schedule pick up category and keywords lists ends here */
				
				
				/* Add schedule category section starts here */
				
				if($type=='addschedulecategory'){
				include( locate_template( 'includes/add_schedule_category_keyword.php', false, false ) );
				}
				
				/* Add schedule category section ends here */
				
				/* Add schedule category section starts here */
				
				if($type=='setupadminmessages'){
				include( locate_template( 'includes/set_up_admin_messages.php', false, false ) );
				}
				
				/* Add schedule category section ends here */




				/* Create a menu bank and checque section starts here */
				
				if($type=='bankandchecque'){
				include( locate_template( 'includes/bankandchecque.php', false, false ) );
				}
				
				/* Create a menu bank and checque section ends here */
				/* Create a menu payment details section starts here */
				if($type=='paymentdetails'){
				include( locate_template( 'includes/paymentdetails.php', false, false ) );
				}
				/* Create a menu payment details section ends here */
				
				/* Create view-billing-template-email section starts here */
				if($type=='viewbillingtemplate'){
				include( locate_template( 'includes/view-billing-template-email.php', false, false ) );
				}
				/* Create view-billing-template-email section ends here */
				
				
				if($type=='adddiscountcoupon'){
				include( locate_template( 'includes/adddiscountcoupon.php', false, false ) );
				}
				
if($type=='scheduleapickinfo'){wp_redirect(site_url('admin-dashboard/?type=scheduleareturninfo')); }
				if($type=='editdiscountcoupan'){
					include( locate_template( 'includes/editdiscountcoupan.php', false, false ) );
				}
				if($type=='editcashcoupan'){
					include( locate_template( 'includes/editcashcoupan.php', false, false ) );
				}
				if($type=='userorderlists'){
					include( locate_template( 'includes/userorderlists.php', false, false ) );
				}
				?>
			
        </div>
		
		</div>
		</div>
		</div></div>
        
        
      </div>
    </div>
	<?php
	} else{ wp_redirect( home_url() ); exit; ?>
	
<?php }?>
<?php get_footer('user'); 
