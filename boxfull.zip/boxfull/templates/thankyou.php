<?php
/**
 Template Name:Thankyou Template
 */
get_header();

?>
<div class="thankyou_out">

<?php

	 echo '<div class="success_notification">You have successfully registered on Our Site,Please check Your mail for the confirmation.</div>';

	 
	 $redurl=site_url('login');
	echo '<META HTTP-EQUIV=REFRESH CONTENT="12; '.$redurl.'">';
?>


</div>
	
<?php	
 get_footer(); ?>