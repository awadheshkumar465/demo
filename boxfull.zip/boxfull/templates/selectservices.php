<?php
/**
 Template Name:Select Services Template
 */
 session_start();
get_header();
//print_r($_SESSION);
if(isset($_SESSION['catidsess'])){
	 $catids = $_SESSION['catidsess'];
	global $wpdb;
	$current_users = wp_get_current_user();
	//echo "select productid,productimgids from wp_userupload_proimages where customerid=$current_user->ID";
	$selectstatements=$wpdb->get_results("select productid,productimgids from wp_userupload_proimages where customerid=$current_user->ID");
$newarra=array();
	foreach($selectstatements as $cusdetails){ 
		$productids[$cusdetails->productid]=$cusdetails->productimgids;
		$postupdtedidss[] = $cusdetails->productid;
			
	} 
	$postupdtedids= array_unique($postupdtedidss);
	$productimages= array_unique($productids);
	$expval = explode(",",$productids);
	

}


$currencyvalue = get_option( 'currency_set' );
$args=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => $catids,
		),
	));
$the_query = new WP_Query( $args );


$args1=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query1 = new WP_Query( $args1 );
?>
<?php

//print_r($_SESSION);

//If session has been created combine both ids and quantity Session arrays
if($_SESSION["product_id"])
{
$pro_qty_array_session=array_combine($_SESSION["product_id"],$_SESSION["product_qty"]);

$totalsessionprice=get_total_price_using_session($pro_qty_array_session);
}
//print_r($pro_qty_array_session);
?>

<div class="thankyou_out">

<div class="container">
<form method="post" action="<?php echo site_url('my-account-checkout'); ?>" id="selectservice_form_out">
<table>
<tr>
<td class="showcenter">Image</td>
<td class="showcenter">Product Name</td>
<td class="showcenter">Product Quantity</td>

</tr>

<?php
$k=1;
$i=0;
// The Loop
if ( $the_query->have_posts() ) {
	
	while ( $the_query->have_posts() ) {
		 
		$the_query->the_post();
		$ktstorage_type_price=get_field('ktstorage_type_price');
		$proqty=0;
		$stotypeid=get_the_ID();
		$ktstorage_type_price = get_field('ktstorage_type_price');
		$ktstorage_type_image = get_field('ktstorage_type_image');
		$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
		$ktstorage_gallery_images = get_field('storage_type_gallery'); 
		if($pro_qty_array_session)
		{
			$proqty=$pro_qty_array_session[$stotypeid];
			$pro_perprice=$proqty*$ktstorage_type_price;
		}
		echo '<tr><td class="gllimgs"><img src="'.$ktstorage_type_image.'" /><br/>';
		echo '<h6>Products Images</h6>';
		echo do_shortcode('[gallery ids="'.$ktstorage_gallery_images.'"]');
		echo '</td>';
		echo '<td class="prod_details">' . get_the_title().'<br/>'.$currencyvalue ."$".$ktstorage_type_price.'/box per month' . '</td>';
		echo '<td class="selfqty">
		<div class="sp-quantity">
		<div class="sp-minus fff"> <a class="ddd" href="javascript:void(0);">-</a>
		</div>
		<div class="sp-input">
        <input type="text" class="quntity-input" name="product_qnty[]" value="'.$proqty.'" />
		<input type="hidden"  name="product_ids[]" value="'.get_the_ID().'" />
		</div>
		<div class="sp-plus fff"> <a class="ddd" href="javascript:void(0);">+</a>
		</div>
		<input type="hidden" class="price_per_pro price_per_product'.$k.'" value="'.$ktstorage_type_price.'">
		<input type="hidden" class="price_per_pro_total" value="'.$pro_perprice.'">
		</div>
		
		
		</td>
		
		</tr>';
		$k++;
		
	}
	
	
	/* Restore original Post Data */
	wp_reset_postdata();
}
$totalprice='';
if($pro_qty_array_session)
{
	$totalprice=$totalsessionprice;
}
?>



<tr><td>Total</td><td colspan="2" class="total_pr"><?php echo $totalprice;?></td></tr>
</table>
<input type="hidden" value="<?php echo $totalprice; ?>" class="total_pr_input">
<input type="submit" name="proselect_sub" onclick="return form_validation('selectservice_form_out');">
</form>



<script>
function form_validation(formid)   
{


		var flag = ''; 
		var error_Msg='';
		var error_Msg = "Select Services :: Please correct the following : ";
		var myform =jQuery('#'+formid);
		
		var total_price_val =myform.find('.total_pr_input').val();
	
		if(total_price_val=='' || total_price_val==0)
		{
			flag = 1;
			error_Msg += "\n - Please Select any Service";
		}
		if(flag == 1)
		{

			jAlert(error_Msg, 'Required Fields');

		

			return false;

		}

		else{

			

		return true;

		}

		
}
		

jQuery(document).ready(function(){
	jQuery(".ddd").on("click", function () {

    var $button = jQuery(this);
    var oldValue = $button.closest('.sp-quantity').find("input.quntity-input").val();

    if ($button.text() == "+") {
        var newVal = parseFloat(oldValue) + 1;
    } else {
        // Don't allow decrementing below zero
        if (oldValue > 0) {
            var newVal = parseFloat(oldValue) - 1;
        } else {
            newVal = 0;
        }
    }
	

    $button.closest('.sp-quantity').find("input.quntity-input").val(newVal);
	
	//custom js
	var price_per_pro= $button.parent().parent().find('.price_per_pro').val();
	
	var total_per_pro=newVal*price_per_pro;
	
	//var oldperproprice=$button.parent().parent().find('.price_per_pro_total').val();
	//var total_per_pro=parseInt(total_per_pro)+parseInt(oldperproprice);
	
	$button.parent().parent().find('.price_per_pro_total').val(total_per_pro);
	
	var total = 0;
	var values = jQuery('.price_per_pro_total').map(function() { return this.value; }).get();
	jQuery.each(values , function(i, val) { 
	 addval=values[i];
	  total += addval << 0;
	 
	});
	var oldtotal=jQuery('.total_pr_input').val();
	//alert(oldtotal+'adding'+total);
	//var newtotal=parseInt(oldtotal)+parseInt(total);
	jQuery('.total_pr_input').val(total);
	jQuery('.total_pr').html(total);

});
});


</script>



</div>
</div>
	
<?php	
 get_footer(); ?>