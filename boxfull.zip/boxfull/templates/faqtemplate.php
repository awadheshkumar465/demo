<?php
/**
Template Name:FAQ Template
 */

get_header();
$custom_terms = get_terms('faqcategory');

 ?>

<div class="main-content">
	<section class="faq_sect">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="faq_heading">
						<h1><?php echo get_the_title();?></h1>
					</div>
				</div>
			</div>
			<?php
			foreach($custom_terms as $custom_term) { 
			$taxonomy= $custom_term->taxonomy;
			$taxonomyslug= $custom_term->slug;
			wp_reset_query();
			$args = array('post_type' => 'faq',
			'posts_per_page'   => 3,
			'tax_query' => array(
			array(
			'taxonomy' => 'faqcategory',
			'field' => 'id',
			'terms' => $custom_term->term_id,
			'order' =>'DESC'
			),
			),
			);

			$loop = new WP_Query($args);
			if($loop->have_posts()) {
			$loopcounts=1;	
			?>
			<div class="col-md-3 col-sm-6">
				<div class="faq_sub">
					<div class="faq_s_icon ">
					<h4><?php echo $custom_term->name;?></h4>
					<?php
					$imgsrc= do_shortcode('[wp_custom_image_category onlysrc="false" size="full" term_id='.$custom_term->term_id.' alt="alt :)"]');
					echo '<div class="faq_s_icon_img"><img src="'.$imgsrc.'" /></div>';
					?>
					</div>
					
						<div class="faq_s_heading ">
							
							

							<div class="box_faq">
							<?php while($loop->have_posts()) : $loop->the_post(); ?>
								<div class="demo">    
									<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
										<div class="panel panel-default">
											<div class="panel-heading" role="tab" id="headingOne">
											<h5 class="faq_titles_inner">
											<?php echo get_the_title();?>
											</h5>
											</div>
												<div id="collapse<?php echo get_the_ID();?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false">
												<div class="panel-body">
												<?php echo get_the_content();?>
												</div>
												</div>
										</div>
									</div>
								</div>
								
								<?php    endwhile; ?>
								<!--<div class="btn_seeAll"><a href="<?php echo get_bloginfo('url');?>/<?php echo $taxonomy;?>/<?php echo $taxonomyslug;?>" class="get-started-link btn btn-default">See All</a></div>-->
								
								<div class="btn_seeAll"><a href="<?php echo get_term_link($custom_term->slug, 'faqcategory');?>" class="get-started-link btn btn-default">See All</a></div>
								
							</div>

						

						</div> 
						
				</div>

			</div>
			<?php if($loopcounts%4==0){echo '<div class="clear"></div>'; } $loopcounts++; } } ?>
		</div> 
	</section>
</div>

<?php get_footer(); ?>

