<?php
/**
 Template Name:Choose Items Template
 */
 session_start();
get_header();
?>

<h2 class="uploadtitles">Upload images to selected boxes</h2>
<?php

if(isset($_SESSION['catidsess'])){
	 $catids = $_SESSION['catidsess'];
	 if(isset($_POST['hiddenchangeprice'])){
		unset($_SESSION['hiddenchangeprices']);
		$_SESSION['hiddenchangeprices'] = $_POST['hiddenchangeprice']; 
	 }
	  $current_user = wp_get_current_user();
  $boxid="SB000000";
	
echo '<div class="col-md-12 userboxdetails">
<div class="col-md-3">Customer Name</div><div class="col-md-8">'. ucfirst($current_user->user_firstname).'</div>
<div class="col-md-3">Customer ID</div><div class="col-md-8">'.$current_user->ID.'</div>
<div class="col-md-3">Box ID</div><div class="col-md-8">'.$boxid.$catids.'</div>
</div>';
$args=array('post_type'=>'storagetype','posts_per_page'=>-1,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => $catids,
		),
	));
$the_query = new WP_Query( $args );

?>
<div class="thankyou_out">

<div class="container">
<?php if ( $the_query->have_posts() ) : ?>

	<!-- pagination here -->

	<!-- the loop -->
	<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
		<?php $stotypeid=get_the_ID();
		$ktstorage_type_image = get_field('ktstorage_type_image');
		?>
		<div class="col-md-4">
		<input type="checkbox" class="postids" name="postids" value="<?php echo $stotypeid; ?>"><img src="<?php echo $ktstorage_type_image; ?>" class="img-responsive" width="150" height="150"/>
		<span><?php echo get_the_title(); ?></span>
		</div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>


<div class="formshidden">
<form id="featured_upload" method="post" action="" enctype="multipart/form-data">
  <input type="file" name="my_image_upload[]" id="my_image_upload[]"  multiple="true" />
  <?php wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
  <input id="submit_my_image_upload" name="submit_my_image_upload" type="submit" value="Upload" />
  <input type="hidden" class="hidden_postids" name="post_ids" value="" />
</form>
</div>
</div>
</div>
<?php 
// Check that the nonce is valid, and the user can edit this post.

if(isset($_POST['post_ids'])) {
	$post_id=$_POST['post_ids'];
if (   isset( $_POST['my_image_upload_nonce']) )
 {
 
  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  require_once( ABSPATH . 'wp-admin/includes/media.php' );
  
  
  $files = $_FILES["my_image_upload"]; 
$attach_id=[];  
    foreach ($files['name'] as $key => $value) {            
            if ($files['name'][$key]) { 
                $file = array( 
                    'name' => $files['name'][$key],
                    'type' => $files['type'][$key], 
                    'tmp_name' => $files['tmp_name'][$key], 
                    'error' => $files['error'][$key],
                    'size' => $files['size'][$key]
                ); 
                $_FILES = array ("my_image_upload" => $file); 
       
		
                foreach ($_FILES as $file => $array) {              
                   
          $attach_id[]= media_handle_upload( $file,$post_id );
		  
		 
          
                }
            } 
        } 
    
  if ( is_wp_error( $attachment_id ) ) {
   
  } else {
	 
	
	 $result='';
	 foreach($attach_id as $vals){
		 $result.=$vals.",";
	 }
	  $result = rtrim($result,',');
	 update_field('storage_type_gallery', $result, $post_id);
	 global $wpdb;
	 $table_name = $wpdb->prefix . 'userupload_proimages';
    $count_query = "select count(*) from $table_name where productid= $post_id and boxid=$catids and customerid=$current_user->ID";
    $num = $wpdb->get_var($count_query);

    
	if($num >=1){
		$wpdb->update($table_name, array('productimgids'=>$result), array('productid'=>$post_id,'customerid'=>$current_user->ID)); 
		$_SESSION['postupdtedid'] = $post_id;
		?>
		<script type = "text/javascript" language = "javascript">
 jQuery(document).ready(function() {
    
		alert ("image uploaded successfully");
		  window.location = "<?php echo get_bloginfo('url');?>/customers-account";
         
 });
</script>
		<?php
	}
	else{
		$insertdb= $wpdb->insert('wp_userupload_proimages', array(
    'customername' => $current_user->user_firstname,
    'customerid' => $current_user->ID,
	'boxid' => $catids,
	'boxidprefix' => $boxid,
	'productimgids' => $result,
	'productid' => $post_id,	// ... and so on
));
 $lastInsertId = $wpdb->useruploadproimgid; 
$_SESSION['postupdtedid'] = $post_id;

	}
	
	
if($insertdb==1){ ?>
<script type = "text/javascript" language = "javascript">
 jQuery(document).ready(function() {
    
		alert ("image uploaded successfully");
		  window.location = "<?php echo get_bloginfo('url');?>/customers-account";
         
 });
</script>
<?php
	
}
    //var_dump($attachment_id);
  }
} else {
  
}
}
?>


	
<?php
} else { //echo "outside"; ?>
<script type = "text/javascript" language = "javascript">
 jQuery(document).ready(function() {
    
           window.location = "<?php echo site_url("/edit-profile"); ?>";
         
 });
</script>
<?php
	//$page = get_page_by_title('edit-profile');
	 wp_redirect( site_url("/edit-profile") );
    exit;
}
?>

<?php	
 get_footer(); ?>
 <script type="text/javascript">
 jQuery(document).ready(function(){ 
jQuery('.col-md-4 .postids').change(function(){
        if(this.checked){
          
			var postids= jQuery(this).val();
			jQuery('#featured_upload .hidden_postids').attr('value',postids);
			jQuery('.formshidden').toggle();
			//alert ("testchecked" + vals);
		}
        

    });
 /*jQuery('.postids').click(function(){
		alert ("testingsxxx");
	var vals= jQUery(this).val();
	alert (vals);
	});	*/
 });
 </script>