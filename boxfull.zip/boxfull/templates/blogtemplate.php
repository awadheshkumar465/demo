<?php
/**
 Template Name:Blog Page
 */
get_header();
?>
<section class="categry-main">
<div class="main-news-page">
			<div class="container">
				<div class="row">
					<div class="col-md-8">

<?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array( 'post_type' => 'post', 'posts_per_page' => 5, 'paged' => $paged );
$wp_query = new WP_Query($args);
while ( have_posts() ) : the_post(); ?>
   
<?php endwhile; ?>

<!-- then the pagination links -->
<?php 

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_args = array(
            'post_type' => 'post',
            'posts_per_page' => 5,
            'paged' => $paged
        );
        $post_loop = new WP_Query( $post_args );
        if($post_loop->have_posts()):
        $i=1;
    	while ( $post_loop->have_posts() ) : $post_loop->the_post(); 
       	$post_image_n ='';
       
		
       	$title = get_the_title();
       	$link = get_permalink(get_the_ID());
       	$excerpt =get_excerpt(250);
    	
		

	echo '
						<div class="othr-sec-sub">';
		if(has_post_thumbnail())
		{
			$post_image_n = wp_get_attachment_url( get_post_thumbnail_id(), 'full' );
			$postid=get_the_ID();
			echo '<div class="othr-image-main">
								<img src="'.$post_image_n.'">
							</div>';
		}
	
	echo '<div class="othr-txt">
								<div class="othr-txt-head">
									<h1><a href="'.$link.'">'.$title.'</a></h1>
									<div class="col-md-12 nopadding"><span class="postsdate">'.get_the_date("F j, Y")." ".get_the_time().'</span><span style="width:10px;"></span><span><i class="genericon genericon-comment"></i> '.get_comments_number($postid).'</span></div>
									<p>'.$excerpt.'</p>
									<span class="blog_fb_share">'.get_fb_share(get_the_ID()).'</span>
									<span class="blog_fb_like">'.get_fb_like(get_the_ID()).'</span>
								</div>
								 
							</div>
						</div>
					';
	$i++;
	endwhile;
	echo '<section class="cstm_pagination"><div class="pagi">';
          wp_pagenavi(); 
    echo '</div></section>';
    wp_reset_query();
    endif;

	
	
	?>
	</div>
	<div class="col-md-4">
		<?php
		dynamic_sidebar('blog-sidebar');
		
		?>
	</div>
	</div>
			</div>
		</div>
	</section>
	
	<?php
	
	
 get_footer(); ?>