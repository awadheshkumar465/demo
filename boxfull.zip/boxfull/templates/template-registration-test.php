<?php
/*
Template Name: Registration Test
*/
get_header(); 
if (!is_user_logged_in()) {
	$err = '';
	$success = '';

	global $wpdb, $PasswordHash, $current_user, $user_ID;

	if(isset($_POST['createUser']) && $_POST['createUser'] == 'Submit' ) {

		$user_username = $wpdb->escape(trim($_POST['user_username']));
		$user_email = $wpdb->escape(trim($_POST['user_email']));
		$user_pass = $wpdb->escape(trim($_POST['user_pass']));
		$user_phone = $wpdb->escape(trim($_POST['user_phone']));

		if( $user_username == "" || $user_email == "" || $user_pass == "" || $user_phone == "" ) {
			$err = 'Please don\'t leave the required fields.';
		} else if(username_exists($user_username)) {
			$err = 'Username already exist.';
		} else if(email_exists($email) ) {
			$err = 'Email already exist.';
		} 
		else {
			//print_r($_POST);die;

			$userdata = array ('user_login' => $user_username, 'user_email' => $user_email, 'user_phone' => $user_phone, 'user_pass' => $user_pass,  'role' => 'subscriber' );

			
			$user_id = wp_insert_user( $userdata );
			if( is_wp_error($user_id) ) {
				$err = 'User already exists.';
			} else {
				$sent_mail = registration_email_alert($user_id);
				$success = 'You\'re successfully register. A link sent to your email to active your Account';
				/*wp_set_auth_cookie( $user_id );
				wp_set_current_user( $user_id );
				//do_action('user_register', $user_id);
				wp_redirect( home_url('wp-admin/profile.php') );
				ob_flush();
				exit;*/
			}

		}

	}
	?>

        <!--display error/success message-->
	<div id="message">
		<?php
			if(! empty($err) ) :
				echo '<p class="error">'.$err.'';
			endif;
		?>

		<?php
			if(! empty($success) ) :
				echo '<p class="error">'.$success.'';
			endif;
		?>
	</div>
<div class="container">
	<form method="post" name="registertest" id="registertest" novalidate="novalidate">
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<label for="user_username">Username (Display Name) *:</label>
					<input type="text" name="user_username" class="form-control" id="user_username" placeholder="Username">
				</div>
				<div class="form-group">
					<label for="user_email">Email *:</label>
					<input type="text" name="user_email" class="form-control" id="user_email" placeholder="Email">
				</div>
				<div class="form-group">
					<label for="user_pass">Password *:</label>
					<input type="text" name="user_pass" class="form-control" id="user_pass" placeholder="Password">
				</div>
				<div class="form-group">
					<label for="confirm_pass">Confirm Password *:</label>
					<input type="text" name="confirm_pass" class="form-control" id="confirm_pass" placeholder="Password">
				</div>
				<div class="form-group">
					<label for="user_phone">Phone *:</label>
					<input type="text" name="user_phone" class="form-control" id="user_phone" placeholder="Phone">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="user_reg_sub_out">
					<input type="submit" name="createUser" class="btn btn-default" value="Submit">
				</div>  
			</div>
		</div>
	</form>
</div>
	<?php
}
else{
	//echo "You have already Logged In!";
	$user = get_userdata( 138 );
	$email   = $user->user_email;
    $username   = $user->user_login;
	echo "<h3>Please click below link to active Account</h3><a href='".home_url('email-varified')."/?user_username=".base64_encode($username)."&user_email=".base64_encode($email)."&user_status=1'>click here</a>";
}
?>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js" /></script>

<script>
jQuery(document).ready(function(){
	jQuery("#registertest").validate({
		rules: {                   
			user_username: {
				required: true,
			},
			user_email: {
				required: true,
				email: true,
			},
			user_pass: {
		        required: true,
		        minlength: 5
		    },
		    confirm_pass : {
		        equalTo : "#user_pass",
		    },
			user_phone: {
				required: true,
			},
			agree: "required"
		},
		submitHandler: function(form) {
            form.submit();
        }
    });

});
</script>

<?php get_footer(); ?>