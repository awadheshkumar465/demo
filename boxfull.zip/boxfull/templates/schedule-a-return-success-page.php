<?php
/* Template Name: Schedule Return Success Page */
?>

<?php get_header('user');?>
<?php 
//print_r($_GET); 
//exit();
global $wpdb;
$user = wp_get_current_user();
$userId = $user->ID;
$useremailid = $user->user_email;
$currency_set = get_option('currency_set',true);
$amount =trim($_GET['amt']);
$currency =trim($_GET['cc']);
$item_name =trim($_GET['item_name']);
$status =trim($_GET['st']);
$transaction_number =trim($_GET['tx']);
$orderid= $_GET['item_number'];

$itemname = explode(",",$item_name);

foreach($itemname as $scheduleorderreturn){
	if($scheduleorderreturn!=''){
		$itemnames=$scheduleorderreturn;
		$insert = $wpdb->insert ('wp_schedule_return_history_order',array(
			'item_name' =>$itemnames,
			'item_amount' =>$amount,
			'order_id' =>$orderid,
			'transaction_number' =>$transaction_number,
			'useremail' =>$useremailid,
			'userid' =>$userId,
			'status' =>'paid',
			'payment_method'=>'paypal',
			'return_status'=>'0',
		));
	
	}
	
}
$lastid = $wpdb->insert_id; 
if($lastid>=1){
	$location=get_bloginfo('url')."/user-dashboard/?type=mystuff";
	wp_redirect($location);
	exit();
}

$insert = $wpdb->insert ('',array(

));
?>
<?php get_footer('user');?>