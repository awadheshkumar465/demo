<?php
/**
Template Name:Home Template
 */
//session_start();
get_header(); 
//print_r($_SESSION);
$currencyvalue = get_option( 'currency_set' );
$args=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 3,
		),
	));
$the_query = new WP_Query( $args );

$args1=array('post_type'=>'storagetype','posts_per_page'=>3,
'tax_query' => array(
		array(
			'taxonomy' => 'storagetypecat',
			'field'    => 'id',
			'terms'    => 2,
		),
	));
$the_query1 = new WP_Query( $args1 );

//all custom fields

$kt_how_it_works_section_main_heading=get_field('kt_how_it_works_section_main_heading');
$how_it_works_section_main_image=get_field('how_it_works_section_main_image');


$kt_see_your_items_heading=get_field('kt_see_your_items_heading');
$kt_see_your_items_content=get_field('kt_see_your_items_content');
$see_your_items_section_image=get_field('see_your_items_section_image');
$kt_business_storage=get_field('kt_business_storage');
$kt_business_storage_content=get_field('kt_business_storage_content');
$kt_business_storage_image=get_field('kt_business_storage_image');
$user = wp_get_current_user();
if ( in_array( 'customer', (array) $user->roles ) ) {
	if(ICL_LANGUAGE_CODE=='en'){
   		$link='<a href="'.get_bloginfo('url').'/ordering/" class="btn btn-default">Get Started</a>';
	}
	if(ICL_LANGUAGE_CODE=='zh-hant'){
		$link='<a href="'.get_bloginfo('url').'/ordering/" class="btn btn-default">開始使用</a>';
	}
}
else{
		if(ICL_LANGUAGE_CODE=='en'){
			$link='<a href="'.get_bloginfo('url').'/sign-up/" class="btn btn-default">Get Started</a>';
		}
		if(ICL_LANGUAGE_CODE=='zh-hant'){
			$link='<a href="'.get_bloginfo('url').'/sign-up/" class="btn btn-default">開始使用</a>';
		}
	}

$home_content='';

$home_content .='<section class="home_content" id="how-it-works">
		<div class="container">
			<div class="row">
				<div class="col-md-8">

					';
$home_content .='<div class="hc_heading"><h3>'.$kt_how_it_works_section_main_heading.'</h3></div>';

if( have_rows('kt_how_it_works_sections') ):
$home_content .='<div class="row">';
 	// loop through the rows of data
    while ( have_rows('kt_how_it_works_sections') ) : the_row();

        // display a sub field value
        $kt_how_it_works_section_image=get_sub_field('kt_how_it_works_section_image');
		$kt_how_it_works_section_title=get_sub_field('kt_how_it_works_section_title');
		$how_it_works_section_content=get_sub_field('how_it_works_section_content');
		
		$home_content .='<div class="col-md-4">
							<div class="hc_cont_sub">';
							
		if($kt_how_it_works_section_image)	
		{			
		$home_content .='<div class="hc_sub_ico">
									<img src="'.$kt_how_it_works_section_image.'">
								</div>';
		}
		$home_content .='<div class="hc_sub_txt">
									<h3>'.$kt_how_it_works_section_title.'</h3>
									<p>'.$how_it_works_section_content.'</p>
								</div>
							</div>
						</div>';

    endwhile;

$home_content .='</div>';

endif;


					
	$home_content .='<div class="hc_sub_FAQ">For more detail, see our <a href="'.site_url('faq').'">FAQs</a>.</div>
				</div>
				<div class="col-md-4">
					<div class="hc_img">
						<img src="'.$how_it_works_section_main_image.'">
					</div>
				</div>
			</div>
		</div>
	</section>';


$home_content .='<div id="pricings"></div>
<section class="main_items" id="pricing">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="mi_heading">';
						if(ICL_LANGUAGE_CODE=='en'){
							$home_content .='<h3 ><!--Commit to a longer term for more savings!-->Pricing</h3>';
						}
						if(ICL_LANGUAGE_CODE=='zh-hant'){
							$home_content .='<h3 ><!--Commit to a longer term for more savings!-->價目表</h3>';
						}
					$home_content .='</div>
				</div>
			</div>';
			if(ICL_LANGUAGE_CODE=='en'){
				$home_content .='<div class="row">
					<div class="col-md-12">
						<div class="srch-range homepage">
							<ul class="change_prices">
								<li></li>
								<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="2" data-attr="store_plan">Pay as your store</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="ktstorage_type_price">3-5 Months</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_six">6-11 Months</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_twelve">12+ Months</a></li>
							</ul>
						</div>
					</div>
				</div>';
			}
			if(ICL_LANGUAGE_CODE=='zh-hant'){
				$home_content .='<div class="row">
					<div class="col-md-12">
						<div class="srch-range homepage">
							<ul class="change_prices">
								<li></li>
								<li><a href="javascript:void(0);" class="btn btn-default active_m" data-value="2" data-attr="store_plan">彈性計劃</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="ktstorage_type_price">3-5個月</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_six">6-11個月</a></li>
								<li><a href="javascript:void(0);" class="btn btn-default" data-value="2" data-attr="storage_type_price_twelve">12個月</a></li>
							</ul>
						</div>
					</div>
				</div>';
			}
			
			if ( $the_query->have_posts() ) {	 
			$home_content .='<div class="srch_by_item">
				<div class="sb_heading">';
				if(ICL_LANGUAGE_CODE=='en'){
					$home_content .='<h4>By Item</h4>';
				}
				if(ICL_LANGUAGE_CODE=='zh-hant'){
					$home_content .='<h4>逐件儲存</h4>';
				}
				$home_content .='</div>
				<div class="sb_products byitems">
					<div class="row">';
						while ( $the_query->have_posts() )
					{
					$the_query->the_post();
					$ktstorage_type_price = get_field('store_plan');
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
						$home_content .='
						<div class="col-md-4">
							<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="'.$ktstorage_type_image.'">
								</div>
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);">'.get_the_title().'</a></h5>
									<span class="prod-price">HKD$ <strong>'.$ktstorage_type_price.'</strong></span>
									<span class="prod-wieght">Max. '.$ktstorage_type_max_weight.'kg</span>
									
									<a id="open-pop-up-'.get_the_ID().'" href="javascript:void(0);">Details</a>
								<div id="pop-up-'.get_the_ID().'" class="pop-up-display-content">
								<div class="sb_pro_sub">
								<div class="sb_pro_img">
								
									<div class="popuptit_price">
									<h5 class="popup_title">'.get_the_title().'</h5>
									<span class="prod-price">'.$currencyvalue.'$ <strong>'.$ktstorage_type_price.'</strong></span>
									</div>
									<div class="popupimg"><img src="'.$ktstorage_type_image.'"></div>
								</div>
								<div class="sb_pro_details">
									
										'.get_the_content().'
										
									
								</div>
								</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-'.get_the_ID().'").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-'.get_the_ID().'").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								
								</div>
							</div>
						</div>';
					}
					wp_reset_query();
						
					$home_content .='</div>
				</div>
			</div>';
			//print_r($user);
		}
		
if ( $the_query1->have_posts() ) {
	
	$home_content .='<div class="srch_by_box">
				<div class="sb_heading">';
				if(ICL_LANGUAGE_CODE=='en'){
					$home_content .='<h4>By Box</h4>';	
				}
				if(ICL_LANGUAGE_CODE=='zh-hant'){
					$home_content .='<h4>逐箱儲存</h4>';	
				}	
				$home_content .='</div>
				<div class="sb_products bybox">
					<div class="row">';
					while ( $the_query1->have_posts() )
					{ 
					$the_query1->the_post();
					$ktstorage_type_price = get_field('store_plan');
					$ktstorage_type_image = get_field('ktstorage_type_image');
					$ktstorage_type_max_weight = get_field('ktstorage_type_max_weight');
						$home_content .='
						<div class="col-md-4">
							<div class="sb_pro_sub">
								<div class="sb_pro_img">
									<img src="'.$ktstorage_type_image.'">
								</div>
								
								<div class="sb_pro_details">
									<h5 class="prod-name"><a href="javascript:void(0);">'.get_the_title().'</a></h5>
									<span class="prod-price">HKD$ <strong>'.$ktstorage_type_price.'</strong></span>
									<span class="prod-wieght">Max. '.$ktstorage_type_max_weight.'kg</span>
									<a id="open-pop-up-'.get_the_ID().'" href="javascript:void(0);">Details</a>
								<div id="pop-up-'.get_the_ID().'" class="pop-up-display-content">
								<div class="sb_pro_sub">
								<div class="sb_pro_img">
								
									<div class="popuptit_price">
									<h5 class="popup_title">'.get_the_title().'</h5>
									<span class="prod-price">'.$currencyvalue.'$ <strong>'.$ktstorage_type_price.'</strong></span>
									</div>
									<div class="popupimg"><img src="'.$ktstorage_type_image.'"></div>
								</div>
								<div class="sb_pro_details">
									
										'.get_the_content().'
									
								</div>
								</div>
								</div>
								<script type="text/javascript">
								jQuery(document).ready(function () {
									//basic pop-up
									jQuery("#open-pop-up-'.get_the_ID().'").click(function(e) {
										e.preventDefault();
										jQuery("#pop-up-'.get_the_ID().'").popUpWindow({action: "open"});
									});

								   
								});
								</script>
								</div>
							</div>
						</div>';
					}
					wp_reset_query();
					$home_content .='</div>
				</div>
			</div>';
		}
		
			$home_content .='<div class="get-started-link">'.$link.'
			</div>
		</div>
	</section>';
	
	$home_content .='<section class="why_us_security">
		<div class="container">
			<div class="row">';
	if( have_rows('kt_why_us_section_contents') ):
	$home_content .='<div class="col-md-5">
					<div class="why_us_sec">
						<div class="mi_heading">';
							if(ICL_LANGUAGE_CODE=='en'){
								$home_content .='<h3>Why us</h3>';
							}
							if(ICL_LANGUAGE_CODE=='zh-hant'){
								$home_content .='<h3>點解揀我地?</h3>';
							}
						$home_content .='</div>
						<div class="wus_cont">
							<ul>';
 	// loop through the rows of data
    while ( have_rows('kt_why_us_section_contents') ) : the_row();
		
        // display a sub field value
        $kt_why_us_section_content=get_sub_field('kt_why_us_section_content');
		$home_content .='
								<li>'.$kt_why_us_section_content.'</li>
								
							';

    endwhile;

	$home_content .='</ul>
						</div>
					</div>
				</div>';

	endif;
	
	
	if( have_rows('kt_security_section_contents') ):
	$home_content .='<div class="col-md-7">
					<div class="why_us_sec">
						<div class="mi_heading">';
							if(ICL_LANGUAGE_CODE=='en'){
								$home_content .='<h3>Security</h3>';
							}
							if(ICL_LANGUAGE_CODE=='zh-hant'){
								$home_content .='<h3>保安?</h3>';
							}
						$home_content .='</div>
						<div class="secu_cont">
							<ul>';
 	// loop through the rows of data
    while ( have_rows('kt_security_section_contents') ) : the_row();

        // display a sub field value
       $kt_security_section_image= get_sub_field('kt_security_section_image');
	   $kt_security_section_headings= get_sub_field('kt_security_section_headings');
	   $kt_security_section_contents= get_sub_field('kt_security_section_contents');
	   
	   $home_content .='<li>
							<div class="secu-img"><img src="'.$kt_security_section_image.'"></div>
							<div class="secu_txt">
								<h4>'.$kt_security_section_headings.'</h4>
								<span>'.$kt_security_section_contents.'</span>	
							</div>
						</li>';

    endwhile;
	$home_content .='</ul>
						</div>
					</div>';

	endif;
	
	
	
	
	$home_content .='
			</div>
		</div>
	</section>';
	
	$args=array('post_type'=>'kttestimonials','posts_per_page'=>-1);
	$the_query = new WP_Query( $args ); 
	if ( $the_query->have_posts() ) {
	$home_content .='<section class="main_testimnials">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="mi_heading">';
						if(ICL_LANGUAGE_CODE=='en'){
							$home_content .='<h3>Testimonials</h3>';
						}
						if(ICL_LANGUAGE_CODE=='zh-hant'){
							$home_content .='<h2>顧客回饋</h2>';
						} 
					$home_content .='</div>
				</div>
			</div>
	        <div class="slider center">';
	while ( $the_query->have_posts() ) {
		$the_query->the_post();
		$kt_testimonial_text=get_field('kt_testimonial_text');
		$kt_testimonial_designation=get_field('kt_testimonial_designation');
		$kt_testimonial_rating=get_field('kt_testimonial_rating');
		$kt_testimonial_image=get_field('kt_testimonial_image');
		$home_content .='<div>
	        		<div class="test_msec">';
					if($kt_testimonial_image)
					{
	    $home_content .='<div class="test_msec_img">
	        				<img src="'.$kt_testimonial_image.'">
	        			</div>';
					}
	    $home_content .='<div class="test_msec_txt">
	        				<div class="test_txt_cont">
	        					<p>'.$kt_testimonial_text.'</p>
	        				</div>
	        				<div class="test_author">
	        					<h4>'.get_the_title().'</h4>
	        					<span>'.$kt_testimonial_designation.'</span>
	        				</div>
	        				<div class="rating_test">
	        					<ul>';
							for($i=1;$i<=$kt_testimonial_rating;$i++)
							{
							$home_content .='<li><i class="fa fa-star" aria-hidden="true"></i></li>';
							}
	        						
	    $home_content .='</ul>
	        				</div>
	        			</div>
	        		</div>
	        	</div>';
	}
	
		wp_reset_postdata();
		$home_content .='';
	} 
	
	$home_content .='</div>
	        <div class="get-started-link">';
	        	if(ICL_LANGUAGE_CODE=='en'){
					$home_content .='<a href="'.get_bloginfo('url').'/sign-up/" class="btn btn-default">Get Started</a>';
				}
				if(ICL_LANGUAGE_CODE=='zh-hant'){
					$home_content .='<a href="'.get_bloginfo('url').'/sign-up/" class="btn btn-default">開始使用</a>';
				} 
			$home_content .='</div>
	    </div>
	</section>';

	$home_content .='<section class="see_your_items">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="syi_img">
						<img src="'.$see_your_items_section_image.'">
					</div>
				</div>
				<div class="col-md-5">
					<div class="syi_txt seeyouritemsheading">
						<div class="mi_heading">
							<h3>'.$kt_see_your_items_heading.'</h3>
						</div>
						<p>'.$kt_see_your_items_content.'</p>
					</div>
				</div>
			</div>
		</div>
	</section>';
	
	$home_content .='<section class="busi_storage" id="business_storages">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="busi_storage_txt">
						<div class="mi_heading">
							<h3>'.$kt_business_storage.'</h3>
						</div>
						'.$kt_business_storage_content.'
					</div>
				</div>
				<div class="col-md-6">
					<div class="busi_stor_img">
						<img src="'.$kt_business_storage_image.'">
					</div>
				</div>
			</div>
		</div>
	</section>';
?>

<div class="main-content">
	
	<?php
	
	echo $home_content;
	
	
	
	?>
	
	
	
	

	
	
</div>



<?php get_footer(); ?>
