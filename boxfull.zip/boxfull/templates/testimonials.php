<?php
/* Template Name: Testimonials Page Template */
?>
<?php get_header();


?>

<div class="container content">
    <div class="row">
	<h3 class="testimonialspage"><?php echo get_the_title();?></h3>
		<?php 
// the query
$wpb_all_query = new WP_Query(array('post_type'=>'kttestimonials', 'post_status'=>'publish', 'posts_per_page'=>-1)); ?>

<?php if ( $wpb_all_query->have_posts() ) : ?>


	<!-- the loop -->
	<?php $counter=1; while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post(); 
	$testimonial_image=get_field('kt_testimonial_image');
	$kt_testimonial_designation=get_field('kt_testimonial_designation');
	$kt_testimonial_rating=get_field('kt_testimonial_rating');
	$kt_see_your_items_content=get_field('kt_testimonial_text');
	?>
		<div class="col-md-6 letline">
			<div class="testimonials">
				<div class="active item">
					<blockquote><p><?php echo $kt_see_your_items_content; ?></p></blockquote>
						<div class="carousel-info">
						<img alt="" src="<?php echo $testimonial_image;?>" class="pull-left">
							<div class="pull-left">
							<span class="testimonials-name"><?php echo get_the_title();?></span>
							<span class="testimonials-post"><?php echo $kt_testimonial_designation;?></span>
							<div class="rating_test">
							<ul>
							<?php for($i=1;$i<=$kt_testimonial_rating;$i++)
							{ ?>
							<li><i class="fa fa-star" aria-hidden="true"></i></li>
							<?php } ?>

							</ul>
							</div>
							</div>
						</div>

				</div>
			</div>
		</div>
	<?php if($counter%2==0){echo '<div class="clearleft"></div>'; }$counter++; endwhile; ?>
	<!-- end of the loop -->



	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>
    </div>
</div>

<?php get_footer();?>
