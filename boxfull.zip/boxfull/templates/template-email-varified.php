<?php
/*
Template Name: Email Varified
*/
global $wpdb;
$status = $_GET['user_status'];
$user_username = base64_decode($_GET['user_username']);
$user_email = base64_decode($_GET['user_email']);

$user = get_user_by('login',$user_username);

if(!empty($user))
{
   $user_id = $user->ID;
   //echo $update_id = wp_update_user( array( 'ID' => $user_id, 'user_status' => $status ) );

  	$update_id = $wpdb->update( 'wp_users', 
		array( 'user_status' => $status), 
		array( 'ID' => $user_id ), 
		array( '%d')
	);

	if ( is_wp_error( $update_id ) ) {
		echo "There was an error, probably that user doesn't exist";
	} else {
		echo "User ".$user_username." is successfully Varified your Email is ".$user_email;
	}
}
else{
	echo "User empty;";
}

	