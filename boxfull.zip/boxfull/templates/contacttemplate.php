<?php
/*
Template Name:Contact Template
*/

get_header(); 

//Contact Fields
$kt_contact_information=get_field('kt_contact_information');
$kt_contact_address=get_field('kt_contact_address');
$kt_contact_number=get_field('kt_contact_number');
$kt_contact_number_link=get_field('kt_contact_number_link');

$kt_contact_mail_id=get_field('kt_contact_mail_id');


 
?>

	
	<section class="contct-us-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5">
					<div class="cntct-txt">
						<div class="contac-details">
							
							<div class="abt-sub-sec">
								<?php 
								if(ICL_LANGUAGE_CODE=='en'){
							   		 echo '<h2>Contact Information</h2>';
							 	 }
							  	if(ICL_LANGUAGE_CODE=='zh-hant'){
							    	echo '<h2>聯絡資料</h2>';
							 	 } 
								?>
								<?php
								if($kt_contact_information)
								{
									echo '<p>'.$kt_contact_information.'</p>';
								}
								
								
								?>
							</div>
							<ul>
							<?php
							if($kt_contact_address)
							{
								echo '<li>
									<span><i class="fa fa-map-marker"></i>'.$kt_contact_address.'</span>
								</li>';
							}
							if($kt_contact_number)
							{
								echo '<li>
									<span><i class="fa fa-phone"></i><a href="tel:'.$kt_contact_number_link.'">'.$kt_contact_number.'</a></span>
								</li>';
							}
							
							if($kt_contact_mail_id)
							{
								echo '<li>
									<span><i class="fa fa-envelope"></i><a href="mailto:'.$kt_contact_mail_id.'">'.$kt_contact_mail_id.'</a></span>
								</li>';
							}
							
							
							
							?>
								
								
							</ul>
						</div>
					
						
					</div>
				</div>
				<div class="col-md-offset-1 col-md-6">
					<div class="cntct-form">
						<div class="abt-sub-sec">
							<?php if(ICL_LANGUAGE_CODE=='en'){
							    echo '<h2>Send us a message</h2>';
							  }
							  if(ICL_LANGUAGE_CODE=='zh-hant'){
							    echo '<h2>請同我地聯繫</h2>';
							  } 
							?>
							
						</div>
						<?php
						echo do_shortcode('[contact-form-7 id="78" title="Contact form 1"]');
						?>
					</div>
				</div>
			</div>
		</div>
	</section>


	




<?php get_footer(); ?>



