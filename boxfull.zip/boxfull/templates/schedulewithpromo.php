<?php 
/* Template Name: Submit Schedule With Promo */
get_header();
?>

<?php get_footer();?>