<?php
/**
 Template Name:My Account Checkout
 */
 session_start();
get_header();
if(isset($_POST['proselect_sub']))
{
$pro_qty_array=array_combine($_POST['product_ids'],$_POST['product_qnty']);
foreach($pro_qty_array as $pro_id=>$pro_qty_value)
{
	
	
		if(is_array($_SESSION['product_id']) && in_array($pro_id, $_SESSION['product_id']))
		{
			$matched_keys_pro=array_keys($_SESSION['product_id'], $pro_id, true);
			//print_r($matched_keys_pro);
			foreach($matched_keys_pro as $matched_keys_pro_val)
			{
				$previous_qty=$_SESSION["product_qty"][$matched_keys_pro_val];
				$newqty=$pro_qty_value;
				$_SESSION["product_qty"][$matched_keys_pro_val]=$newqty;
			}
		}
		else
		{
		$_SESSION["product_id"][] = $pro_id;
		$_SESSION["product_qty"][] = $pro_qty_value;
		}
		
	
	
}

}
$currentuserid=get_current_user_id();

$user_pickup_address=get_user_meta($currentuserid,'user_pickup_address',true);
$user_telephone=get_user_meta($currentuserid,'user_phone',true);

$first_name=get_user_meta($currentuserid,'first_name',true);
$last_name=get_user_meta($currentuserid,'last_name',true);


//For session data
$session_user_pickup_address2='';
$session_user_select_region='';
$session_user_select_district='';


if($_SESSION['user_booking_information'])
{
	$session_first_name=$_SESSION['user_booking_information']['first_name'];
	$session_last_name=$_SESSION['user_booking_information']['last_name'];
	if(!empty($session_first_name))
	{
		$first_name=$session_first_name;
	}
	if(!empty($session_last_name))
	{
		$last_name=$session_last_name;
	}
	
	$session_user_telephone=$_SESSION['user_booking_information']['user_telephone'];
	$session_user_pickup_address=$_SESSION['user_booking_information']['user_pickup_address'];
	
	if(!empty($session_user_pickup_address))
	{
		$user_pickup_address=$session_user_pickup_address;
	}
	if(!empty($session_user_pickup_address))
	{
		$user_telephone=$session_user_telephone;
	}
	
	
	$session_user_pickup_address2=$_SESSION['user_booking_information']['user_pickup_address2'];
	$session_user_select_region=$_SESSION['user_booking_information']['user_select_region'];
	$session_user_select_district=$_SESSION['user_booking_information']['user_select_district'];
	
}


?>

<div class="account_details_out">

<div class="main-catgry-sec">
				<div class="row">
					<div class="col-md-12">
						
						<div class="contrct-reg"> 
						<form method="post" action="<?php echo site_url('schedule-a-booking'); ?>" id="my_account_form">
						<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="first_name">First Name *:</label>
								<input type="text" name="first_name" class="form-control" id="first_name" placeholder="First Name" value="<?php echo $first_name; ?>">
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<label for="last_name">Last Name *:</label>
								<input type="text" name="last_name" class="form-control" id="last_name" value="<?php echo $last_name; ?>" placeholder="Last Name">
							</div>
						</div>
						</div>
						<div class="row">
						

						<div class="col-md-6">
							<div class="form-group">
								<label for="user_telephone">Phone Number*:</label>
								<input type="text" name="user_telephone" class="form-control" id="user_telephone" value="<?php echo $user_telephone; ?>" placeholder="Phone Number">
							</div>
						</div>
						</div>
						<div class="row">
						<h3>Pickup Address</h3>
						<div class="col-md-6">
							<div class="form-group">
								<label for="user_pickup_address">Address Line1 *:</label>
								<input type="text" name="user_pickup_address" class="form-control" value="<?php echo $user_pickup_address; ?>" id="user_pickup_address" placeholder="Address Line1">
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="form-group">
								<label for="user_pickup_address2">Address Line2 :</label>
								<input type="text" value="<?php echo $session_user_pickup_address2; ?>" name="user_pickup_address2" class="form-control" id="user_pickup_address2" placeholder="Address Line2">
							</div>
						</div>
						</div>
						
						<div class="row">
						
						<div class="col-md-6">
							<div class="form-group">
								<label for="user_select_region">Select Region *:</label>
								<select  name="user_select_region" class="form-control" id="user_select_region">
								<option></option>
								<option></option>
								</select>
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group">
								<label for="user_select_district">Select District *:</label>
								<select  name="user_select_district" class="form-control" id="user_select_district">
								<option></option>
								<option></option>
								</select>
							</div>
						</div>
						</div>
						
						
						
						
						<div class="row">
						<div class="col-md-12">
						<div class="user_reg_sub_out">
						<input type="submit" name="myaccount_continue" value="Continue" onclick="return form_validation('my_account_form');">
						</div>  
						</div>
						
						</div>	
						
						</form>
						</div>
					</div>
				</div>
</div>
</div>
<script>
function form_validation(formid)   
{


		var flag = ''; 
		var error_Msg='';
		var error_Msg = "Account Information :: Please correct the following : ";
		var myform =jQuery('#'+formid);
		
		var first_name =myform.find('#first_name').val();
		var last_name =myform.find('#last_name').val();
		var user_telephone=myform.find('#user_telephone').val();
		var user_pickup_address=myform.find('#user_pickup_address').val();
		var user_select_region=myform.find('#user_select_region').val();
		var user_select_district=myform.find('#user_select_district').val();
		
		if(first_name=='')
		{
			flag = 1;
			error_Msg += "\n - Please Enter First Name.";
		}
		if(last_name=='')
		{
			flag = 1;
			error_Msg += "\n - Please Enter Last Name.";
		}
		if(user_telephone=='')
		{
			flag = 1;
			error_Msg += "\n - Please Enter Telephone.";
		}
		if(user_pickup_address=='')
		{
			flag = 1;
			error_Msg += "\n - Please Enter Pickup Address.";
		}
		/*
		if(user_select_region=='')
		{
			flag = 1;
			error_Msg += "\n - Please Select Region.";
		}
		if(user_select_district=='')
		{
			flag = 1;
			error_Msg += "\n - Please Select District.";
		}
		*/
		
		
		
		if(flag == 1)
		{

			jAlert(error_Msg, 'Required Fields');

		

			return false;

		}

		else{

			

		return true;

		}

		
	}

</script>
<?php
get_footer();


?>