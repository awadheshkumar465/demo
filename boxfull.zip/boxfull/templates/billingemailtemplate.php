<?php 
/* Template Name: Billing Template */
?>
<section class="invoice" id="invoices" style="margin: 15px 0; display:block;box-sizing: border-box;">
                        <!-- title row -->
                        <div class="row" style="margin-right: -15px;margin-left: -15px;">
                            <div class="col-xs-12" style="width: 100%;">
                                <h2 class="page-header" style="    padding-top: 5px;border-right: 1px solid #eee;border-left: 1px solid #eee;padding-left: 0;margin-top: 0;margin-left: 0;">
                                    <img src="http://localhost/klutterclearnew/wp-content/uploads/2017/10/cropped-logo.png" style="max-width: 100%;">
                                    <small class="pull-right" style="float: right!important;padding: 30px 20px 0 0;">Date: 2018-01-23</small>
                                </h2>
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                        <!-- info row -->
                        <div class="row invoice-info" style="margin: 0 auto;width: 100%;">
						<div class="col-sm-4 invoice-col" style="width: 30%;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px; display: inline-block;">
                                <strong style="font-weight: 700;">Personnal Details</strong>
                                <address style="margin-bottom: 20px;font-style: normal;  line-height: 1.42857143;">
                                    <b style="font-size: 11px;">Name: </b> 
									<span style="font-size: 12px;">Bijay</span>
                                    <br>
                                    <b style="font-size: 11px;">Address:</b> 
									<span style="font-size: 12px;">House no 121 indore Ajay Bagh</span><br>
                                    <b style="font-size: 11px;">Phone:</b> 
									<span style="font-size: 12px;">8109110098 </span><br>
                                    <b>Email:</b> 
									<span style="font-size: 12px;">bijay.softelixir@gmail.com</span>                                
								</address>
                            </div><!-- /.col -->
                            <div class="col-sm-4 invoice-col" style="width: 30%;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px; display: inline-block;">
                               <strong style="font-weight: 700;"> Drop off/ Pickup Details</strong>
                                <address style="margin-bottom: 20px;font-style: normal;  line-height: 1.42857143;">
                                    <b style="font-size: 11px;">Delivery Date: </b> 
									<span style="font-size: 12px;">25-2018-01</span>
                                    <br>
                                    <b style="font-size: 11px;">Delivery Time: </b> 
									<span style="font-size: 12px;">7:00am-9:00am</span>
                                    <br>
                                    <b style="font-size: 11px;">Pickup Date: </b> 
									<span style="font-size: 12px;">30-2018-01</span>
                                    <br>
									<b style="font-size: 11px;">Pickup Time: </b> 
									<span style="font-size: 12px;">7:00am-9:00am</span>
									                               
								</address>
                            </div><!-- /.col -->
                            <div class="col-sm-4 invoice-col" style="width: 30%;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px; display: inline-block;">
                                 <strong style="font-weight: 700;"> Order Details Details</strong>
                                 <address style="margin-bottom: 20px;font-style: normal;  line-height: 1.42857143;">
                                    <b style="font-size: 11px;">Invoice: </b> 
									<span style="font-size: 12px;">#AXt614YV</span>
                                    <br>
                                    <b style="font-size: 11px;">Order ID: </b> 
									<span style="font-size: 12px;">#O1</span>
                                    <br>
                                    <b style="font-size: 11px;">Payment Due: </b> 
									<span style="font-size: 12px;">2018-02-23</span>
									                               
								</address>
							</div>
							</div><!-- /.row .invoice-info -->

                        <!-- Table row -->
                        
                            <div class="table-responsive" style="padding: 0 15px;clear: both;min-height: .01%;overflow-x: auto;">
                                <table class="table table-striped" style="width: 100%;max-width: 100%;margin-bottom: 20px;    background-color: transparent;border-spacing: 0;border-collapse: collapse;border-width: 1px 0 0 1px; margin: 0 0 1.75em;table-layout: fixed;border: 1px solid #d1d1d1;display: table;">
                                    <thead style="display: table-header-group;vertical-align: middle;border-color: inherit;">
                                        <tr style="display: table-row;vertical-align: inherit;border-color: inherit;">
                                            <th style="vertical-align: bottom;border-bottom: 2px solid #ddd;border: 1px solid #d1d1d1;">
											Product Name
											</th>
                                            <th style="vertical-align: bottom;border-bottom: 2px solid #ddd;border: 1px solid #d1d1d1;">
											Item/Box ID
											</th>
											
											<th style="vertical-align: bottom;border-bottom: 2px solid #ddd;border: 1px solid #d1d1d1;">
											Storage Plan
											</th>
                                             <th style="vertical-align: bottom;border-bottom: 2px solid #ddd;border: 1px solid #d1d1d1;">
											 Price
											 </th>
                                            <th style="vertical-align: bottom;border-bottom: 2px solid #ddd;border: 1px solid #d1d1d1;">
											Sub Total
											</th>
                                        </tr>
                                    </thead>
                                    <tbody style="display: table-row-group;vertical-align: middle;border-color: inherit;">
									<tr style="display: table-row;vertical-align: inherit;border-color: inherit;">
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">Standard Box</td>
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">3</td>
											
											<td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">3-5 Months</td>
											
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$49</td>
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$147</td>
                                    </tr>
									<tr style="display: table-row;vertical-align: inherit;border-color: inherit;">
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">Document Box</td>
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">2</td>
											
											<td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">3-5 Months</td>
											
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$29</td>
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$58</td>
                                    </tr>
									<tr style="display: table-row;vertical-align: inherit;border-color: inherit;">
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">Large Items</td>
											
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">1</td>
											
											<td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">3-5 Months</td>
											
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$189</td>
                                            <td style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align: center;">HKD$189</td>
                                    </tr>
									<tr style="display: table-row;vertical-align: inherit;border-color: inherit;">
										<td colspan="4" style="padding-right: 8px !important;padding: 8px;line-height: 1.42857143;vertical-align: top;border-top: 1px solid #ddd;white-space: normal;word-break: break-word;vertical-align: top !important;border-width: 0 1px 1px 0;font-weight: normal;text-align: left;border: 1px solid #d1d1d1;display: table-cell;text-align:right;"><strong>Total</strong></td><td>HKD$394
										</td>
									</tr></tbody>
                                </table>
                            </div><!-- /.col -->
                        <!-- /.row -->

                        
                    </section>
