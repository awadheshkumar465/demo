</div>
</div>
</div>
<?php wp_footer(); ?>
<script type="text/javascript">
    jQuery(document).ready(function() {
		
		/* Delete by box and by items category code starts here */
		jQuery('a.deleteterms').click(function(){ //alert ("testing");
			var termid = jQuery(this).attr('data-catid');
			var taxonomyname = jQuery(this).attr('data-name');
			//alert(termid+'_'+taxonomyname);
			alert ("Do you want to delete?");
			jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'deletetermsbyid', categoryid: termid,taxonomy: taxonomyname},
			success : function(data){
				//alert (data);
				console.log (data);
				alert ("Category deleted");
				jQuery('.allstoragecatelists').html(data);
				window.location =  "<?php echo bloginfo('url');?>/admin-dashboard/?type=storagetypecate";
				
				
			}
			});
		});
		/* Delete by box and by items category code starts here */
		
		jQuery('a.deleteregions').click(function(){
			var regiontermname = jQuery(this).attr('data-regionname');
			var regiontaxonomy = jQuery(this).attr('data-regiontaxonomy');
			alert ("Do you want to delete?");
			jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'deleteRegionsById', termid: regiontermname,taxonomy: regiontaxonomy},
			success : function(data){
				//alert (data);
				
				alert ("Category deleted");
				console.log (data);
				//jQuery('.allstoragecatelists').html(data);
				window.location =  "<?php echo bloginfo('url');?>/admin-dashboard/?type=allregions";
				
				
			}
			});
			
		});
		
		jQuery('.changepasswordbutton').click(function(){
			jQuery('.changepassword').addClass('showtext');
			jQuery('.cancelpassword').addClass('showtext');
			var rString = randomString(32, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');
			jQuery('.changepassword').val(rString);
			
			return false;
			
		});
		jQuery('.cancelpassword').click(function(){
			jQuery('.changepassword').val('');
			jQuery('.changepassword').removeClass('showtext');
			jQuery('.cancelpassword').removeClass('showtext');
			return false;
		});
		
		jQuery(".changeuserimage").click(function(){
			
			//jQuery('.changeuserimage').addClass('showall');
			jQuery('.upload-file.userimagechange').toggle();
			jQuery('.userimageids').toggle();
			//jQuery('.changeuserimage.showall').html('Cancel');
			//
		});
		
		jQuery('.deleteusersbyid').click(function(){
			var deluserid = jQuery(this).attr('data-userid');
			alert ("do you want to delete user " +deluserid);
			jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'deleteUserById', userid: deluserid},
			success : function(data){
				//alert (data);
				
				alert ("User deleted");
				console.log (data);
				window.location =  "<?php echo get_the_permalink();?>?type=allusers";
				
				
			}
			});
			
		});
		
		
		/* edit posts ends here*/
		
		/* change status jquery starts here */
jQuery('.changestatususer').click(function(){
	var datavalue = jQuery(this).attr('data-status');
	var datauserid = jQuery(this).attr('data-userid');
	alert ("Do you want to Change the status of this user");
	jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'chageuserstatus', userid: datauserid ,userstatus: datavalue},
			success : function(data){
				//alert (data);
				
				alert ("User status updated");
				console.log (data);
				window.location =  "<?php echo get_the_permalink();?>?type=allusers";
				
				
			}
			});
	
	
});
/* change status jquery ends here */
/* add promotion form validate number less than 10  function code starts here */
jQuery( "#promotioncode" ).on('input', function() {
    if (jQuery(this).val().length>10) {
        alert('you have reached a limit of 3');       
    }
});

/* add promotion form validate number less than 10  function code ends here */


/*frontend promocode plus click code starts here */
jQuery('.open-close-btn.plus').click(function(){
	jQuery('.open-content').addClass('show');
});

/* rontend promocode plus click ends here */

jQuery('.faprintbutton').click(function(){
	jQuery('.btn.btn-primary.pull-right.generatepdf').css('display','none');
	jQuery('.btn.btn-default.faprintbutton').css('display','none');
	var divToPrint = jQuery('.My_Stuff_main').html();

        var mode = 'iframe'; //popup
        var close = mode == "popup";
        var options = { mode : mode, popClose : close};
        jQuery("div.My_Stuff_main").printArea( options );
		
		setTimeout(function() {
  jQuery('.btn.btn-primary.pull-right.generatepdf').css('display','block');
	jQuery('.btn.btn-default.faprintbutton').css('display','inline-block');
}, 3000);


});

/* download pdf starts here */
jQuery('.btn.btn-primary.pull-right.generatepdf').click(function(event){
	var useremail=jQuery(this).attr('data-email');
	var usereid=jQuery(this).attr('data-userid');
	event.preventDefault();
	//alert ("Click here to download " +useremail +" Invoice.");
	jQuery( "#invoiceform" ).submit();
	
});
/* download pdf ends here */
/* Edit product box image and box number */
jQuery( ".fa.fa-times.removeall" ).click( function() {
	var imgid = jQuery(this).attr('data-id');
	var orderid = jQuery(this).attr('data-orderid');
	var prodid = jQuery(this).attr('data-productid');
	alert ("image id = " + imgid + "order id = " +orderid + "prodi" + prodid);
	jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'removeboximage', attachmentid: imgid ,boxorderid: orderid,boxproductid:prodid},
			success : function(data){
				alert ("Box image deleted successully");
				console.log (data);
				//jQuery('.col-sm-9.userimagesuploads').html(data);
				location.reload();
				
			}
			});
  });
/* edit product box image and box number ends here */ 
  
 /* delete box number and box sub images */
jQuery('.deleteorderdetails').click(function(){
	
	var productid = jQuery(this).attr('data-productid');
	var orderid = jQuery(this).attr('data-orderid');
	alert ("want to delete product having order id = " + orderid + "And product id = " + productid);
	jQuery.ajax({
			url: '<?php echo admin_url('admin-ajax.php'); ?>',
			type: 'POST',
			dataType: "html",
			data: { action: 'removeboxdetails', boxproductid: productid ,boxorderid: orderid},
			success : function(data){
				alert ("Box image deleted successully");
				console.log (data);
				//jQuery('.col-sm-9.userimagesuploads').html(data);
				window.location =  "<?php echo get_the_permalink();?>?type=allboxes";
				
			}
			});
});
/*delete box number and box sub images*/ 
/* edit/add/delete checkbox customer section */

jQuery('input.checkaddeditdelete').on('change', function() {
    jQuery('input.checkaddeditdelete').not(this).prop('checked', false); 
	
});
/* edit/add/delete checkbox customer section */
/* download pdf ends hrere*/
    });
	function randomString(length, chars) {
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}
</script>


<script type="text/javascript">
jQuery(document).ready(function(){
	


/* admin dashboard all boxes section starts here */
jQuery('.table tr.allboxeslists ').each(function(index){
		 var checkedval ="";
		jQuery('tr.allboxeslists .checkaddeditdelete').on('change', function() {
			jQuery('tr.allboxeslists .checkaddeditdelete').not(this).prop('checked', false); 
			
		});
		jQuery(this).find(('input[type="checkbox"]')).click(function(){
            if(jQuery(this).prop("checked") == true){
                var checkedval = "chcking";
				
            }
            else{
                var checkedval = "not checking";
            }
			if(checkedval== "chcking"){
			var getvals = jQuery(this).attr('value');
			var res = getvals.split(",");

		}
        });
		
	});
/* admin dashboard all boxes section ends here */



});
function form_validation(formid)   
{ 

var flag = ''; 
		var error_Msg='';
		var error_Msg = "Please correct the following : ";
		var myform =jQuery('#schedule_booking_form_out');
		
		var pickupafterdropoff = document.getElementById('pickup_of_boxes').checked;
		var pickupdate = document.getElementById('pick_up_date').checked;
		var select_pickupdate =myform.find('#pickupdate').val();
		var schedulelater = document.getElementById('pickup_of_boxeslater').checked;
		var pickupoffinalcheckout = document.getElementById('pickup_of_finalcheckout').checked;
		
		if((pickupafterdropoff===false)&&(pickupdate===false)&&(schedulelater===false)&&(pickupoffinalcheckout===false))
			{
			flag = 1;
			error_Msg += "\n - Please Select Any One Schedule recheck-in/Final check-out.";
			//alert ("testing" +error_Msg); return false;
		}
		
		if(flag == 1)
		{
			jAlert(error_Msg, 'Required Fields');
		return false;
		}

		else{
			return true;
		}
		
		
}



</script>
