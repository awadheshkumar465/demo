<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
	<!--<link rel="shortcut icon" type="image/png" href="<?php //echo get_stylesheet_directory_uri(); ?>/favicon.ico"/>  -->
</head>

<body <?php body_class(); ?>>
<?php 
//echo session_status();
if(is_user_logged_in()){

}
else{
   
unset($_SESSION['signup_user']);
unset($_SESSION['product_id']);
unset($_SESSION['product_qty']);
unset($_SESSION['pricestorage_duration']);
unset($_SESSION['categories_id']);
}


?>
<!-- 		<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentysixteen' ); ?></a> -->
<?php 
//custom fields
/*$head_contact_number=get_option('head_contact_number');
$head_contact_number_link=get_option('head_contact_number_link');
$inactive = 7200; 
ini_set('session.gc_maxlifetime', $inactive); // set the session max lifetime to 2 hours

session_start();

if (isset($_SESSION['testing']) && (time() - $_SESSION['testing'] > $inactive)) {
   
    session_unset();    
    session_destroy();  
}
$_SESSION['testing'] = time(); */
if(is_user_logged_in()){

}
else{session_unset();    
    unset($_SESSION['signup_user']);
unset($_SESSION['product_id']);
unset($_SESSION['product_qty']);
unset($_SESSION['pricestorage_duration']);
unset($_SESSION['categories_id']);
	}

	
?>
		<header class="main-header">
		
	<div class="header-middle">
		<nav class="navbar navbar-default">
		  <div class="container ">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <?php twentysixteen_the_custom_logo();  ?>
			 
		    </div>
 <?php
			  if(is_user_logged_in()){
				echo '<div class="text-right logout"><ul class="main-httop"><li id="menu-item-logout" class="menu-item menu-item-type-post_type menu-item-object-page">'.wp_loginout($_SERVER['REQUEST_URI'], false).'</li></ul></div>'; 
			 
			  } 
			  else {
				 echo '<div class="text-right login"><ul class="main-httop"><li id="menu-item-login" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="'.site_url().'/login"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li></ul></div>'; 
			  } 
		  
		  ?>
		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      
		  
			  
		    </div><!-- /.navbar-collapse -->
		  </div><!-- /.container-fluid -->
		</nav>
	</div>
</header>

<?php
$home_slider='';
if(is_front_page())
{
	
	// check if the repeater field has rows of data
	
if( have_rows('kt_header_slider_settings') ):
$home_slider .='<section class="top-slider" id="home">
		<div id="owl-demo" class="owl-demo owl-carousel owl-theme">';
 	// loop through the rows of data
    while ( have_rows('kt_header_slider_settings') ) : the_row();

        // display a sub field value
        $kt_home_slide_image=get_sub_field('kt_home_slide_image');
		$kt_home_slide_heading=get_sub_field('kt_home_slide_heading');
		$kt_home_slide_subheading=get_sub_field('kt_home_slide_subheading');
		$home_slider .='<div class="item">
                <div class="st-div">
                    <div class="slidetop-img">
                        <img src="'.$kt_home_slide_image.'">
                    </div>
                    <div class="st-txt">
                    	<h3>'.$kt_home_slide_heading.'</h3>
                    	<p>'.$kt_home_slide_subheading.'</p>
                    </div>
                    <span class="slide-top-link"><a href="#">Get Started</a></span>
                </div>
            </div>';

    endwhile;
$home_slider .=' </div>
	</section>';

endif;

}
echo $home_slider;	


?>

