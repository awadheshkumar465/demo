(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function validateEmail(u_email)

	{

	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

	//var address = document.forms[form_id].elements[email].value;

	var address=u_email;
 
	//alert(address);

	if(reg.test(address) == false)

		{return false;}

	else{

		return true;

	}

	};

function checkPhone(u_phone) {

       
		var phonen = u_phone;
		var phonelength=phonen.length;
		var phoneNum = /^[+-]?\d+(\.\d+)?([eE][+-]?\d+)?$/; 
		

            if(phonen.match(phoneNum) && phonelength>=8 && phonelength<=15) {

                return true;

            }

            else {

                return false;

            }

        };

function captch() {
	var x = document.getElementById("ran")
	x.value = Math.floor((Math.random() * 10000) + 1);
}
jQuery(document).ready(function(){
	jQuery(window).scroll(function() {   
       if (jQuery(window).scrollTop() >=100) { 
	   
          if(jQuery('.navbar-default').hasClass( "nav-fixed-top" ))
  {
  //jQuery('#header').removeClass("fixed-theme");
  }
  else
  {
  jQuery('.main-header').addClass("nav-fixed-top");
  }
       }
else{
jQuery('.main-header').removeClass("nav-fixed-top");

}
if (jQuery(window).scrollTop() >=400) { 
          if(jQuery('.main-header').hasClass( "navi-top" ))
  {
  //jQuery('#header').removeClass("fixed-theme");
  }
  else
  {
  jQuery('.main-header').addClass("navi-top");
  }
       }
else{
jQuery('.main-header').removeClass("navi-top");
if(jQuery('body').hasClass('scrollpricing')){
jQuery('body').removeClass("scrollpricing");
}
if(jQuery('body').hasClass('scrollhow')){
jQuery('body').removeClass("scrollhow");

}

}
   });

/*edit user jquery starts here */
jQuery('#open-pop-ups').click(function(){
	jQuery('.pop-up-display-content-none').addClass('show');
});
/*var maxField = 10; //Input fields increment limitation
    var addButton = jQuery('.add_button'); //Add button selector
    var wrapper = jQuery('.field_wrapper'); //Input field wrapper
    var fieldHTML = '<div class="form-group"><label for="titles">Upload Box image:</label><div class="image-upload"><label for="file-input"><i class="fa fa-plus" ></i></label> <input id="file-input" type="file"/></div><label for="titles">Enter Item Id :</label><input type="text" class="itemidname" name="field_name[]" value=""/><a href="javascript:void(0);" class="remove_button" title="Remove field"><img src="http://votivewordpress.in/klutterclear/wp-content/themes/boxfull/images/remove-icon.png"/></a></div>'; //New input field html 
    var x = 1; //Initial field counter is 1
    jQuery(addButton).click(function(){ //Once add button is clicked
        if(x < maxField){ //Check maximum number of input fields
            x++; //Increment field counter
            jQuery(wrapper).append(fieldHTML); // Add field html
        }
    });
    jQuery(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
        e.preventDefault();
        jQuery(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });*/

/* edit user jqeury ends here */  
/* customer and admin side (left sidebar) menu toggle section starts here */


	jQuery('#user_region').change(function()
		{
			var selecteddistrict=jQuery(this).val();
			var ajax_url = jQuery('#ajaxUrl').val();
			jQuery('.submit-loading').show();
			
			jQuery('#user_district').empty();
			jQuery.ajax({

			         type: "post",
			         url: ajax_url,
			        data: {
				            action:'selected_district_regions_ajax',
				            selecteddistrict : selecteddistrict
				        	},
			         success: function(data){
			         	
			         
			         	jQuery('#user_district').append(data);
			         	jQuery('.submit-loading').hide();
			         }
			         
				});     

		});
/* registration page Region field on change function starts here */

/* Registration page image section starts here */
jQuery("#file-input").change(function() {
 jQuery('img#blah').css('display','block');
  readURL(this);
});
/* Registration page image section starts here */

/* schedule a pick up date picker and toggle */
/*jQuery("[name=pickup_of_boxes_datetime]").click(function(){
            jQuery('.col-md-12.scheduleapickupdate').toggle();
            //jQuery("#blk-"+$(this).val()).show('slow');
});*/
jQuery("#startschedulepickupdates").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0,
            
        });
jQuery('input#schedulepickuptime').timepicker({ minTime: '9:00:00',maxHour: 12,'step': 15 });
/* schedule a pick up date picker and toggle */
/* admin side schedule start and end date */
	jQuery("#startscheduledate").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0,
            onSelect: function (date) {
                var date2 = jQuery('#startscheduledate').datepicker('getDate');
                date2.setDate(date2.getDate() + 1);
                jQuery('#endscheduledate').datepicker('setDate', date2);
                //sets minDate to dt1 date + 1
                jQuery('#endscheduledate').datepicker('option', 'minDate', date2);
            }
        });
        
		
		jQuery('#endtimedisableTimeRangesExample').timepicker({
			'disableTimeRanges': [
			['1am', '2am'],
			['3am', '4:01am']
			]
		});
		jQuery('input#stepExample1').timepicker({ minTime: '9:00:00',maxHour: 12,'step': 15 });
		jQuery('input#stepExample2').timepicker({ minTime: '9:15:00',maxHour: 12,'step': 15 });
	/* admin side schedule start and end date ends here */
	
	
	
	/* admin side edit schedule start and end date */
	jQuery("#editstartscheduledate").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: jQuery('#editstartscheduledate').val(),
            onSelect: function (date) {
				var seconddate = jQuery('#editendscheduledate').val();
                var date2 = jQuery('#editstartscheduledate').datepicker('getDate');
                date2.setDate(date2.getDate() + 1);
                jQuery('#editendscheduledate').datepicker('setDate', seconddate);
                //sets minDate to dt1 date + 1
                jQuery('#editendscheduledate').datepicker('option', 'minDate', seconddate);
            }
        });
        jQuery('#editendscheduledate').datepicker({
           dateFormat : 'yy/mm/dd',
            onClose: function () {
                var dt1 = jQuery('#editstartscheduledate').datepicker('getDate');
                console.log(dt1);
                var dt2 = jQuery('#editendscheduledate').datepicker('getDate');
                if (dt2 <= dt1) {
                    var minDate = jQuery('#editendscheduledate').datepicker('option', 'minDate');
                    jQuery('#editendscheduledate').datepicker('setDate', minDate);
                }
            }
        });
		
		jQuery('#endtimedisableTimeRangesExample').timepicker({
			'disableTimeRanges': [
			['1am', '2am'],
			['3am', '4:01am']
			]
		});
		jQuery('#starttimedisableTimeRangesExample').timepicker({
			'disableTimeRanges': [
			['1am', '2am'],
			['3am', '4:01am']
			]
		});
	/* admin side schedule start and end date ends here */
	
	
	
	jQuery(function() {
		/* admin page set date time datepicker starts here */
		 jQuery( "#datepickerstartdate" ).datepicker({
            dateFormat : 'yy/mm/dd',
			'minDate': new Date()
			 
        });
		/* admin page set date time datepicker ends here */
		
		/* admin page set date time datepicker end date starts here */
		
		 jQuery( "#datepickerenddate" ).datepicker({
			 dateFormat : 'yy/mm/dd',
			'minDate': new Date()
        });
		
		/* admin page set date time datepicker end date ends here */
		
		
    jQuery( "#datepicker" ).datepicker({
            dateFormat : 'mm/dd/yy',
			'minDate': new Date(),
			'maxDate': "11/25/2017 00:53"
        });
  });



/* Edit Box ID admin section starts here */
	jQuery("input.editboxitemsnoids").click(function(e){
		
            var favorite = [];
            jQuery.each(jQuery("input[name='checkboxorderids']:checked"), function(){ 
			var putidg = favorite.push(jQuery(this).val());
			jQuery('.hiddeneditboxid_ids').val(favorite);
            });
			if(favorite==''){
				alert ("Please select a product.");
				e.preventDefault();
				return false;
			}
			else{
				
			}
			
            
        });
/* Edit Box ID admin section ends here */

/* Mystuff section starts here */
	jQuery("input.submitbystuffs").click(function(e){
            var favorite = [];
            jQuery.each(jQuery("input[name='stuffcheckbox']:checked"), function(){ 
			favorite.push(jQuery(this).val());
			jQuery('.userallinformation').val(favorite); 
            });
			if(favorite==''){
				alert ("Please select a product.");
				e.preventDefault();
				return false;
			}
			else{
				
			}
			
            
        });
/* Mystuff section ends here */

/* schedule a return page change region select box ajax run here */
	jQuery('select#country_lists').on('change', function() {
		var country = jQuery(this).val();
		var ajaxurl = jQuery('input.schedule_ajax_url').val();
		
		jQuery.ajax({
			url: ajaxurl,
			type: 'POST',
			dataType: "html",
			data: { action: 'getdistricts', countryid:country},
			success : function(data){
				jQuery('select#dropoff_select_dist').html(data);
				
			}
		});
	});
/* schedule a return page change region select box ajax code ends here */

/* schedule a return schedule delivery days section starts here */
jQuery('.col-md-12 .form-group #scheduleday').click(function(){
	var schedulevals = jQuery(this).val();
	
	if(schedulevals=='samebusinessday'){
		jQuery('div.same_business_day').toggle();
		jQuery('div.editnextbusinessday').css('display','none');
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.editinormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').css('display','none');
		
		jQuery('input#scheduledaynextbusinessday').attr('value','');
		jQuery('input#scheduledayinormorethantwobusinessday').attr('value','');
		
		jQuery('input#editscheduledayinormorethantwobusinessday').attr('value','');
		jQuery('input#editscheduletimescheduledayinormorethantwobusinessday').attr('value','');
		jQuery('input#editscheduletimenextbusinessday').attr('value','');
		jQuery('input#editscheduletimenextbusinessday').attr('value','');
		
		jQuery('select#scheduletimescheduledayinormorethantwobusinessday').html('<option value="">Select Time</option>');
		
		jQuery('select#scheduletimenextbusinessday').html('<option value="">Select Time</option>');
		
		
		
	}
	 if(schedulevals=='nextbusinessday'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.editsame_business_day').css('display','none');
		jQuery('div.editsame_business_day').css('display','none');
		jQuery('div.nextbusinessday').toggle();
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.editinormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').css('display','none');
		jQuery('input#editscheduledaysamebusinessday').attr('value','');
		jQuery('input#editscheduletimesamebusinessday').attr('value','');
		jQuery('input#editscheduledayinormorethantwobusinessday').attr('value','');
		jQuery('input#editscheduletimescheduledayinormorethantwobusinessday').attr('value','');
		jQuery('input#editscheduledaysamebusinessday').attr('value','');
		jQuery('input#editscheduletimesamebusinessday').attr('value','');
		jQuery('input#editscheduletimenextbusinessday').attr('value','');
		jQuery('input#editscheduletimenextbusinessday').attr('value','');
		
		jQuery('input#scheduledaysamebusinessday').attr('value','');
		jQuery('input#scheduledayinormorethantwobusinessday').attr('value','');
		
		jQuery('select#scheduletimescheduledayinormorethantwobusinessday').html('<option value="">Select Time</option>');
		
		jQuery('select#scheduletimesamebusinessday').html('<option value="">Select Time</option>');
		
	}
	if(schedulevals=='inormorethantwobusinessday'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.editsame_business_day').css('display','none');
		jQuery('div.editnextbusinessday').css('display','none');
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.inormorethantwobusinessday').toggle();
		jQuery('div.afterhoursdelivery').css('display','none');
		jQuery('input#editscheduledaysamebusinessday').attr('value','');
		jQuery('input#editscheduletimesamebusinessday').attr('value','');
		
		jQuery('input#scheduledaysamebusinessday').attr('value','');
		jQuery('input#scheduledaynextbusinessday').attr('value','');
		
		jQuery('select#scheduletimesamebusinessday').html('<option value="">Select Time</option>');
		
		jQuery('select#scheduletimenextbusinessday').html('<option value="">Select Time</option>');
		
	}
	if(schedulevals=='afterhoursdelivery'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.editsame_business_day').css('display','none');
		jQuery('div.editnextbusinessday').css('display','none');
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').toggle();
		jQuery("#scheduledayafterhoursdelivery").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });
		jQuery('#scheduletimesafterhoursdelivery').timepicker({
			minTime: '9:00:00',
			maxHour: 14
		});
	}
		
});
/* schedule a return schedule delivery days section starts here */



/* schedule a return editschedule delivery days section starts here */
jQuery('.col-md-12 .form-group #editscheduleday').click(function(){
	var schedulevals = jQuery(this).val();
	//alert (schedulevals);
	if(schedulevals=='samebusinessday'){
		jQuery('div.editsame_business_day').toggle();
		
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').css('display','none');
		jQuery("#scheduledaysamebusinessday").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });
		/*jQuery('#scheduletimesamebusinessday').timepicker({
			minTime: '9:00:00',
			maxHour: 14
		});*/
	}
	 if(schedulevals=='nextbusinessday'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.editsame_business_day').css('display','none');
		jQuery('div.editnextbusinessday').toggle();
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').css('display','none');
		
		jQuery("#scheduledaynextbusinessday").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });
		/*jQuery('#scheduletimenextbusinessday').timepicker({
			minTime: '9:00:00',
			maxHour: 14
			'disableTimeRanges': [
			['1am', '2am'],
			['3am', '4:01am']
			]
		});*/
	}
	if(schedulevals=='inormorethantwobusinessday'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.editinormorethantwobusinessday').toggle();
		
		
		jQuery('div.afterhoursdelivery').css('display','none');
		
		jQuery("#scheduledayinormorethantwobusinessday").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });
		/*jQuery('#scheduletimescheduledayinormorethantwobusinessday').timepicker({
			minTime: '9:00:00',
			maxHour: 14
		});*/
	}
	if(schedulevals=='afterhoursdelivery'){
		jQuery('div.same_business_day').css('display','none');
		jQuery('div.nextbusinessday').css('display','none');
		jQuery('div.inormorethantwobusinessday').css('display','none');
		jQuery('div.afterhoursdelivery').toggle();
		jQuery("#scheduledayafterhoursdelivery").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });
		/*jQuery('#scheduletimesafterhoursdelivery').timepicker({
			minTime: '9:00:00',
			maxHour: 14
		});*/
	}
	
});
/* schedule a return editschedule delivery days section starts here */



/* stais checkbox starts here */
	var lastChecked = null;
	jQuery("input[name='do_we_need_carry_box']").on("change", function () {
		if(lastChecked && lastChecked != jQuery(this)){
			lastChecked.prop("checked", false);
		}
		if (jQuery(this).prop("checked", true)) {
			lastChecked = jQuery(this);
		}
	
	});
	
	jQuery('.upstairs input[type=checkbox]').click(function(){
		
		var getvals = jQuery(this).val();
		if(getvals=='yes'){
			var checkal = jQuery('.upstairs input[type=checkbox]').attr('checked');
			jQuery('.upstairs input[type=checkbox]').removeAttr('checked');
			jQuery('.upstairs input[type=checkbox]').find
			jQuery('.form-group.selectfloors').css('display','block');
			jQuery('.form-group.editselectfloors').css('display','block')
		}
		if(getvals=='no'){
			var checkal = jQuery('.upstairs input[type=checkbox]').attr('checked');
			jQuery('.upstairs input[type=checkbox]').removeAttr('checked');
			jQuery('.form-group.editselectfloors').css('display','none');
			jQuery('.form-group.selectfloors').css('display','none');
			
		}
		
		
	});
	/* stais checkbox ends here */

/* Schedule recheck-in/Final check-out both front-end and customer section starts here */
		jQuery('.date_picker').datepicker({
            dateFormat : 'mm/dd/yy',
			minDate:1
        });
		
		jQuery("#pickupdate").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0
            
        });

	jQuery('.pickoption').click(function(){
		jQuery('.pickup_hidden').hide('slow');
		jQuery(this).parent().find('.pickup_hidden').show('slow');
	});
	
/* Schedule recheck-in/Final check-out both front-end and customer section ends here */	

/*schedule a return final payment tabs starts here */
jQuery('.col-md-12.paypal_payment h2.payment_header').click(function(){
	jQuery('.col-md-12.paypal_payment .payment_using_paypal').css('display','block');
	jQuery('.col-md-12.credit_card_payment p.creditcards').css('display','none');
	jQuery('.col-md-12.cheque_payment .cheque_header').css('display','none');
	jQuery('.col-md-12.bank_transfer .bank_transfer_para').css('display','none');
});

jQuery('.col-md-12.credit_card_payment h2.credit_card_payment_header').click(function(){
	jQuery('.col-md-12.paypal_payment .payment_using_paypal').css('display','none');
	jQuery('.col-md-12.cheque_payment .cheque_header').css('display','none');
	jQuery('.col-md-12.bank_transfer .bank_transfer_para').css('display','none');
	jQuery('.col-md-12.credit_card_payment p.creditcards').css('display','block');
});

jQuery('.col-md-12.cheque_payment h2.cheque_payment_header').click(function(){
	jQuery('.col-md-12.cheque_payment .payment_using_paypal').css('display','none');
	jQuery('.col-md-12.paypal_payment .payment_using_paypal').css('display','none');
	jQuery('.col-md-12.credit_card_payment p.creditcards').css('display','none');
	jQuery('.col-md-12.bank_transfer .bank_transfer_para').css('display','none');
	jQuery('.col-md-12.cheque_payment .cheque_header').css('display','block');
});


jQuery('.col-md-12.bank_transfer h2.bank_transfer_header').click(function(){
	jQuery('.col-md-12.paypal_payment .payment_using_paypal').css('display','none');
	jQuery('.col-md-12.cheque_payment .payment_using_paypal').css('display','none');
	jQuery('.col-md-12.credit_card_payment p.creditcards').css('display','none');
	jQuery('.col-md-12.cheque_payment .cheque_header').css('display','none');
	jQuery('.col-md-12.bank_transfer .bank_transfer_para').css('display','block');
});


/*schedule a return final payment tabs starts here */

/* admin side schedule a return history information starts here */
jQuery('a.change_returning_schedule_status').click(function() {
	var schedule_return_history_id = jQuery(this).attr('data-schedulehistoryid');
	var ajax_url = jQuery('input.adminurls').val();
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'ChangeReturnAScheduleStatus', schedulereturnhistoryid: schedule_return_history_id},
		success : function(data){
			//alert (data);
			console.log (data);
			var statushtml = jQuery('.admin_schedule_return_status .col-md-8.delivery_status').html();
			
				var statushtmls = 'Delivered';
				jQuery('.admin_schedule_return_status .col-md-8.delivery_status').html(statushtmls);
				alert ("Schedule A Return Status Updated Successfully");
				window.location =  "?type=scheduleareturninfo";
			 	
		}
	});

	
});
/* admin side schedule a return history information ends here */


/* admin side pickup delivery status starts here */
jQuery('a.change_pickup_status').click(function() {
	//alert ("testings");
	var schedule_pickup_id = jQuery(this).attr('data-schedulepickupid');
	
	var ajax_url = jQuery('input.adminurls').val();
	//alert (schedule_pickup_id +ajax_url );
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'ChangeSchedulePickupOrderStatus', schedulepickuporderid: schedule_pickup_id},
		success : function(data){
			//alert (data);
			console.log (data);
			alert ("Schedule A Pick-up Status Updated Successfully");
			window.location =  "?type=scheduleareturninfo";
			 	
		}
	});

	
});
/*  admin side pickup delivery status ends here */


/* getting schedule pick up upload images get keywords of category starts here */
jQuery('.category_lits_pickup').change(function()
{
	var selectcategory=jQuery(this).val();
	var ajax_url = jQuery('.ajaxurls_chedule').val();
	jQuery('.submit-loading').show();
	//alert (selectcategory);
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'getSchedulePickUpKeywordLists', selectcategory: selectcategory},
		success : function(data){
			//alert (data);
			//console.log (data);
			jQuery('.submit-loading').hide();
			jQuery('.pickupschedulecatkeywords').html(data);
			
			 	
		}
	});
});
/* getting schedule pick up upload images get keywords of category starts here */	
 var max_fields_limit      = 10; //set limit for maximum input fields
    var x = 1; //initialize counter for text box
    jQuery('.add_more_button').click(function(e){
        e.preventDefault();
        if(x < max_fields_limit){ 
            x++; 
            jQuery('.input_fields_container').append('<div><input type="text" name="schedulekeyword[]"/><a href="#" class="remove_field" style="margin-left:10px;">Remove</a></div>'); //add input field
        }
    });  
    jQuery('.input_fields_container').on("click",".remove_field", function(e){ //user click on remove text links
        e.preventDefault(); jQuery(this).parent('div').remove(); x--;
    })

/* remove edit schedule pick up edit image section */
jQuery('.change_image_edit').click(function(){
jQuery('.editsubimages').toggle();
jQuery('.image-upload.hiddens').toggle();


});	

/* delete sub images all records schedule pick up section */
jQuery('.deletesubimagesrecord').click(function(){
	var datadeletes = jQuery(this).attr('data-deletes');
	var ajax_url = jQuery(this).attr('data-urls');
	var data_subimgid = jQuery(this).attr('data-subimgid');
	//alert (datadeletes + ajax_url);
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'deleteScheduleImagesRecordsPickup', pickupids: datadeletes,subimgid:data_subimgid},
		success : function(data){
			alert ("Image Deleted Successfully");
			var re = new RegExp(/^.*\//);
			window.location = re.exec(window.location.href)+"?type=mystuff";
			console.log (data);
			 	
		}
	});
});


/* admin side public holidate date datepicker starts here */
jQuery("#blackdateslists").datepicker({
            dateFormat : 'yy/mm/dd',
            minDate: 0,
            
        });
/* Admin side public holidate date datepicker ends here */


/* delete public holidays date */
jQuery('a.btn.btn-default.deletepublicholidays').click(function(){
	
	var dataid = jQuery(this).attr('data-id');
	var ajax_url = jQuery(this).attr('data-ajaxurl');
	//alert (dataid + ajax_url);
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'deletepublicholidays', holidayid: dataid},
		success : function(data){
			alert ("Holiday Deleted Successfully");
			var re = new RegExp(/^.*\//);
			window.location = re.exec(window.location.href)+"?type=adddatetimeavailability";
			console.log (data);
			 	
		}
	});
});
/* delete public holidays date */


/* delete Black days date */
jQuery('a.btn.btn-default.blackdays').click(function(){
	
	var blackdayid = jQuery(this).attr('data-blackdayid');
	var ajax_url = jQuery(this).attr('data-ajaxurl');
	//alert (blackdayid + ajax_url);
	jQuery.ajax({
		url: ajax_url,
		type : 'POST',
		dataType: "html",
		data: { action: 'deleteblackdays', blackdayid: blackdayid},
		success : function(data){
			alert ("Blackdate Deleted Successfully");
			var re = new RegExp(/^.*\//);
			window.location = re.exec(window.location.href)+"?type=adddatetimeavailability";
			console.log (data);
			 	
		}
	});
});
/* delete Black days date */

/*left sidebar tab section toggle section */
jQuery('.resp-tabs-list.hor_1 li').click(function(e){
			 
			jQuery(this).children('ul').slideToggle('slow');
			
			if(jQuery(this).find('i').hasClass('fa-expand'))
			{
				
				jQuery(this).find('i').removeClass('fa-expand').addClass('fa-plus');
			}
            else
            {
				
				jQuery(this).find('i').removeClass('fa-plus').addClass('fa-expand');
			}				
			
			
			
			//jQuery(this).siblings('li').find('ul').hide('slow');
			jQuery(this).siblings('li').find('i').removeClass('fa-expand').addClass('fa-plus');
			e.stopPropagation();
		});
		
		    jQuery('.dashboard_sidebar .resp-tabs-list.hor_1 li#storagetypes').hover(function(){ //alert("mouseenter");
		    jQuery('.dashboard_sidebar .resp-tabs-list.hor_1 ul.sub-child').addClass('showmenu');
		});
/*left sidebar tab section toggle section ends here */
       
		
		jQuery('button.addnewcate').click(function(){
			jQuery('#editforms').css('display','block');
			jQuery('.allstoragecatelists').css('display','none');
			
		});
		
/* delete Category/Keyword lists from admin section (schedule/pickup) */

jQuery('.btn.btn-default.deletecategory_keywords').click(function(){
	$cate_keyword_id = jQuery(this).attr('data-catkeyid');
	$cate_keyword_ajaxurl = jQuery(this).attr('data-ajaxurl');
	jQuery.ajax({
		url: $cate_keyword_ajaxurl,
		type: 'POST',
		dataType: "html",
		data:{action: 'deleteCateKeyword', catkeyid:$cate_keyword_id,ajaxurl:$cate_keyword_ajaxurl},
		success: function(data){
			console.log (data);
			alert ("Category/Keyword deleted Successfully");
				
				var re = new RegExp(/^.*\//);
				
				window.location = re.exec(window.location.href)+"?type=show_schedule_category_keyword_lists";
		}
		
		
	});
});
/* delete Category/Keyword lists from admin section (schedule/pickup) */		

/* refund process starts here */
/*
jQuery('.trans_refund').click(function(){
var transid = jQuery(this).attr('data-transid');
var ajaxurl = jQuery(this).attr('data-ajaxurl');

jQuery.ajax({
		url: ajaxurl,
		type: 'POST',
		dataType: "html",
			data: { action: 'refundPayment', refundid: transid },
			success : function(data){
				console.log (data);

				alert ("Schedule Category deleted");
				
				var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=show_schedule_category_keyword_lists";
					
			}
		});
});
*/

/* refund process ends here  */

jQuery('#credit-card-option').click(function(){
	jQuery('.crditcard').addClass('show');
	jQuery('.crditcard').removeClass('showhide');
	jQuery('#product').removeClass('show');
	jQuery('#allchecquepayments').removeClass('show');
	jQuery('#allchecquepayments').addClass('showhide');
	jQuery('#allbankpayments').addClass('showhide');
	jQuery('#allbankpayments').removeClass('show');
	
});
jQuery('#paypal-option').click(function(){
	
	//jQuery('#paypal-info').toggle('slow');
	//jQuery('#card_frm').toggle('slow');
	jQuery('#product').addClass('show');
	jQuery('.crditcard').addClass('showhide');
	jQuery('#allchecquepayments').addClass('showhide');
	jQuery('#allchecquepayments').removeClass('show');
	jQuery('#allbankpayments').addClass('showhide');
	jQuery('#allbankpayments').removeClass('show');
	
	
});

jQuery('#toggle_checquepayment').click(function(){
	
	jQuery('#allchecquepayments').addClass('show');
	jQuery('#product').addClass('showhide');
	jQuery('.crditcard').addClass('showhide');
	jQuery('#product').removeClass('show');
	jQuery('#allbankpayments').addClass('showhide');
	jQuery('#allbankpayments').removeClass('show');
	
});


jQuery('#toggle_bankpayment').click(function(){
	
	jQuery('#allbankpayments').addClass('show');
	jQuery('#allchecquepayments').removeClass('showhide');
	jQuery('#allchecquepayments').removeClass('show');
	jQuery('#product').removeClass('showhide');
	jQuery('#product').removeClass('show');
	jQuery('.crditcard').addClass('showhide');
	jQuery('.crditcard').removeClass('show');
	jQuery('#product').addClass('showhide');
	
	
});

jQuery(".how_it_works_menu").click(function() { 
    jQuery('html, body').animate({
        scrollTop: jQuery("#how-it-works").offset().top
    }, 2000);
	jQuery(window).scroll(function() {    
    var scroll = jQuery(window).scrollTop(),
    		headH = jQuery("#how-it-works").height();

    if (scroll >= headH) {
        jQuery("body").addClass("addheightdisp");
    } else {
    		jQuery("body").removeClass("addheightdisp");
    }
});
	//jQuery('body').removeClass('scrollpricing');
  jQuery('body').addClass('scrollhow');
  if(jQuery('body').hasClass('scrollpricing')){
		jQuery('body').removeClass('scrollpricing');
	}
  //jQuery('body').css('margin-top','180px');

	
});
jQuery(".pricing_menu").click(function() { 
    jQuery('html, body').animate({
        scrollTop: jQuery("#pricing").offset().top
    }, 2000);
	
	jQuery('body').addClass('scrollpricing');
	if(jQuery('body').hasClass('scrollhow')){
		jQuery('body').removeClass('scrollhow');
	}
});
jQuery("#add_warehouseid").on('keyup', function(e) {
    var val = jQuery(this).val();
   if (val.match(/[^a-zA-Z]/g)) {
       jQuery(this).val(val.replace(/[^a-zA-Z]/g, ''));
   }
   
});

jQuery("#add_warehouse_sections").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if (jQuery.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
	
jQuery("#add_warehouse_location").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if (jQuery.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
});	

jQuery("#addwarehouse_item_wieght").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if (jQuery.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
});	


/* update payment status checque and banks */
jQuery('.changepaymentstaus').click(function(){
	var tablename=jQuery(this).attr('data-tablenames');
	var tableorderid=jQuery(this).attr('data-orderid');
	var tablecolid=jQuery(this).attr('data-tablecolumns');
	var tablecolstatus=jQuery(this).attr('data-tablecolstatus');
	var ajaxurl=jQuery(this).attr('data-adminurl');
	//alert ("table name" + tablename + "table orderid" + tableorderid + "table columnid" +  tablecolid + "table column status" +  tablecolstatus + ajaxurl);
	
	jQuery.ajax({
		url: ajaxurl,
		type: 'POST',
		dataType: "html",
			data: { action: 'changepaymentstatus', tablename: tablename,tableordeid:tableorderid,tablecolid:tablecolid,tablestatusid:tablecolstatus},
			success : function(data){
				console.log (data);
				//jQuery('a.changepaymentstaus').removeClass('changepaymentstaus');
				//jQuery('a.changepaymentstaus').html('Paid');
				alert ("payment status changed successfully");
				var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=paymentdetails";

			}
		});
});
/* delete billing management table */

jQuery('.delbillingmana').click(function(){
	var billingmanageid= jQuery(this).attr('data-billingid');
	var emailid= jQuery(this).attr('data-emailid');
	var ajaxurl= jQuery(this).attr('data-ajaxurl');
	//alert (billingmanageid + emailid + ajaxurl);
	jQuery.ajax({
		url:ajaxurl,
		type:'POST',
		dataType: "HTML",
		data:{action:'deleteBillingManagementTable',billingid:billingmanageid,emailid:emailid},
		success: function(data){
			console.log(data);
			alert ("Billing Deleted Successfully");
			var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=billingmanagement";
		}
		
	});
});
/* Delete billing management table */


/* delete other billing management table */

jQuery('.deleteotherbillsbut').click(function(){
	
	var otherbillingid= jQuery(this).attr('data-otherbillingid');
	var otheremailid= jQuery(this).attr('data-otheremailid');
	var ajaxurl= jQuery(this).attr('data-otherajaxurl');
	alert (otherbillingid + otheremailid + ajaxurl);
	jQuery.ajax({
		url:ajaxurl,
		type:'POST',
		dataType: "HTML",
		data:{action:'deleteOtherBillingManagementTable',billingid:otherbillingid,emailid:otheremailid},
		success: function(data){
			console.log(data);
			alert ("Other Billing Deleted Successfully");
			var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=showbillproductslists";
		}
		
	});
});
/* Delete other billing management table */
/* cancel orders starts here */
jQuery('.cancel_orders').click(function(){
	var titlesod = jQuery(this).attr("title");
	var result = confirm("Want To Refund?");
	if (result) {
		alert ("Thanks");
	}
});
/* Cancel orders ends here */

/*delete promotion code starts here */
jQuery('.deletepromotioins').click(function(){
	
	var promocode = jQuery(this).attr('data-promotionid');
	var adminurls = jQuery(this).attr('data-ajaxurls');
	//alert (adminurls);
	jQuery.ajax({
			url: adminurls,
			type: 'POST',
			dataType: "html",
			data: { action: 'updatepromotions', promotioncode: promocode},
			success : function(data){
				//alert (data);
				
				alert ("Promotion deleted successully");
				console.log (data);
				var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=allpromotions";
				
				
			}
			});
});
/* Delete promotion code ends here */

/*delete discount coupan code starts here */
jQuery('.deletecoupans').click(function(){
	var discountid = jQuery(this).attr('data-coupandisid');
	var adminurl = jQuery(this).attr('data-ajaxurls');
	//alert("Test"+coupancode+coupandiscount);
	jQuery.ajax({
			url: adminurl,
			type: 'POST',
			dataType: "html",
			data: { action: 'updatecoupandiscount', discountids: discountid},
			success : function(data){
				//alert (data);
				alert ("Coupan Discount deleted successully");
				console.log (data);
				var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=allpromotions";
				
			}
			});
});
/* Delete discount coupan code ends here */

/*delete Cash coupan code starts here */
jQuery('.deletecashcoupans').click(function(){
	var cashcoupan_id = jQuery(this).attr('data-cashcoupan_id');
	var adminurl = jQuery(this).attr('data-ajaxurls');
	jQuery.ajax({
			url: adminurl,
			type: 'POST',
			dataType: "html",
			data: { action: 'deletecashcoupan', cashcoupanid: cashcoupan_id},
			success : function(data){
				//alert (data);
				alert ("Cash Coupan Deleted Successully");
				console.log (data);
				var re = new RegExp(/^.*\//);
				window.location = re.exec(window.location.href)+"?type=allpromotions";
				
			}
			});
});
/* Delete Cash coupan code ends here */

/* front end schedule a pick up cart cash coupon code starts here */
jQuery('select.form-control.changecuponscontrols').on('change', function() {
var getdurations = ( this.value );
var adminurl = jQuery('input.ajaxurladmins').val();
if(getdurations==''){
jQuery('.couponsareas').html('');	
}
if(getdurations=='Free Month Code'){
	jQuery('.couponsareas').html('<label >Enter Promocode </label><input type="text" name="promocoe" value="" class="form-control " id="promocode_free_monthly" placeholder="Enter Promocode FREEMONTH">');
jQuery('input#promocode_free_monthly').keyup(function(){
	
	if(jQuery(this).val().length > 3)
	{
		var inputvals = jQuery(this).val();
		jQuery.ajax({
			url: adminurl,
			type: 'POST',
			dataType: "html",
			data: { action: 'couponsCodeCheck', getdurationsfree: getdurations, inuttextvals:inputvals},
			success : function(data){
				console.log (data);
				jQuery('.couponcodemessage').css('display','block');
				jQuery('.couponcodemessage').html('<span class="promocodetexts">FREE storage for the '+data+' months.</span><span class="promocodetextbillings">Billing cycle will begin 30 days after the pick-up</span>');
				jQuery('input.hiddencoupons').val(data);

				jQuery('input.hiddencoupons_code').val(getdurations);
			}
		});	
	}

});


}

if(getdurations=='Cash Coupon Code'){
	jQuery('.couponcodemessage').css('display','none');
	jQuery('.couponsareas').html('<label >Enter Cash Coupon Code</label><input type="text" name="promocoe" value="" class="form-control " id="couponcodes" placeholder="Enter Cash Coupon Code">');
jQuery('input#couponcodes').keyup(function(){
	
	var inputvals = jQuery(this).val();
	//alert (inputvals);
	jQuery.ajax({
		url: adminurl,
		type: 'POST',
		dataType: "html",
		data: { action: 'couponsCodeCheck', getdurationsfree: getdurations, inuttextvals:inputvals},
		success : function(data){
			console.log (data);
			jQuery('input.hiddencoupons').val(data);	
			jQuery('input.hiddencoupons_code').val(getdurations);			
		}
	});
});
}
if(getdurations=='Discount Code'){
	jQuery('.couponcodemessage').css('display','none');
	jQuery('.couponsareas').html('<label >Enter Discount Code</label><input type="text" name="promocoe" value="" class="form-control " id="discount_couponcode" placeholder="Discount Code">');
jQuery('input#discount_couponcode').keyup(function(){
	
	var inputvals = jQuery(this).val();
	
	jQuery.ajax({
		url: adminurl,
		type: 'POST',
		dataType: "html",
		data: { action: 'couponsCodeCheck', getdurationsfree: getdurations, inuttextvals:inputvals},
		success : function(data){
			console.log (data);
			jQuery('input.hiddencoupons').val(data);
			
			jQuery('.couponcodemessage').css('display','block');
			
			jQuery('.couponcodemessage').html(data+ '% discount will be applied.');
			
			jQuery('input.hiddencoupons_code').val(getdurations);
			
		}
	});
});
}
});
/* front end schedule a pick up cart cash coupon code starts here */
});

function form_validation_schedule(formid)   
{ 

var flag = ''; 
		var error_Msg='';
		var error_Msg = "Please correct the following : ";
		var myform =jQuery('#schedule_booking_form_out');
		
		var pickupafterdropoff = document.getElementById('pickup_of_boxes').checked;
		var pickupdate = document.getElementById('pick_up_date').checked;
		var select_pickupdate =myform.find('#pickupdate').val();
		var schedulelater = document.getElementById('pickup_of_boxeslater').checked;
		var pickupoffinalcheckout = document.getElementById('pickup_of_finalcheckout').checked;
		
		if((pickupafterdropoff===false)&&(pickupdate===false)&&(schedulelater===false)&&(pickupoffinalcheckout===false))
			{
			flag = 1;
			error_Msg += "\n - Please Select Any One Schedule recheck-in/Final check-out.";
			//alert ("testing" +error_Msg); return false;
		}
		
		if(flag == 1)
		{
			jAlert(error_Msg, 'Required Fields');
		return false;
		}

		else{
			return true;
		}
		
		
}
function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      jQuery('#blah').attr('src', e.target.result);
	 }
    reader.readAsDataURL(input.files[0]);
  }
}














	