jQuery(document).ready(function () {
    //basic pop-up
    jQuery('#open-pop-up-1').click(function(e) {
        e.preventDefault();
        jQuery('#pop-up-1').popUpWindow({action: "open"});
    });

   
});