<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<?php wp_head(); ?>
	<!--<link rel="shortcut icon" type="image/png" href="<?php //echo get_stylesheet_directory_uri(); ?>/favicon.ico"/>-->  
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
</head>

<body <?php body_class(); ?>>
<?php 
//echo session_status();
if(is_user_logged_in()){

}
else{
   
unset($_SESSION['signup_user']);
unset($_SESSION['product_id']);
unset($_SESSION['product_qty']);
unset($_SESSION['pricestorage_duration']);
unset($_SESSION['categories_id']);
}


?>
<!-- 		<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'twentysixteen' ); ?></a> -->
<?php 
//custom fields
/*$head_contact_number=get_option('head_contact_number');
$head_contact_number_link=get_option('head_contact_number_link');
$inactive = 7200; 
ini_set('session.gc_maxlifetime', $inactive); // set the session max lifetime to 2 hours

session_start();

if (isset($_SESSION['testing']) && (time() - $_SESSION['testing'] > $inactive)) {
   
    session_unset();    
    session_destroy();  
}
$_SESSION['testing'] = time(); */
if(is_user_logged_in()){
//echo $userid=get_current_user_id()."hello bijay";
}
else{session_unset();    
    unset($_SESSION['signup_user']);
unset($_SESSION['product_id']);
unset($_SESSION['product_qty']);
unset($_SESSION['pricestorage_duration']);
unset($_SESSION['categories_id']);
	}

	
?>
<div class="main_dashboard_sec">
<?php if(is_page('user-home')){$class="customersection";} else {?>
<div class="dashboard_top_bar">
  <div class="dash_logo"><a href="<?php bloginfo('url');?>"><?php twentysixteen_the_custom_logo();  ?></a></div>
  <div class="desh_menu">
  <?php
			  if(is_user_logged_in()){ $user = wp_get_current_user(); $currency_set = get_option( 'currency_set' );
			  
			  $attachment_ids = get_user_meta($user->ID, 'user_profile_image', true );
			  $image_attributes = wp_get_attachment_image_src( $attachment_ids);			  
			  
			  $user_country = get_user_meta($user->ID,'country_code',true);
				/*if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
				foreach ( $user->roles as $role )
				$userrole= $role;
				if($userrole ==''}{}else{$sequenceno}
				}*/			  
				echo '
				<ul class="nav navbar-nav navbar-right" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                
                                
                				
                				<li class="dropdown">
								 <span class="avatarimage"><i class="fa fa-user-o"></i></span>
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">'.$user->display_name.'</a>
                					<ul class="dropdown-menu profile-dropdown">
                						<li class="profile-menu bg-gray">
                						    <div class="inneravatar">
                						        <img src="'.$image_attributes[0].'" class="img-circle profile-img">
                                                <div class="profile-name">
                                                    <h5>'.$user->display_name.'</h5>
													<h6>
                                                    '.$user_country.date('y')."000".$user->ID.'</h6>
                                                </div>
                                                <div class="clearfix"></div>
                						    </div>
                						</li>
                						
                						<li role="separator" class="divider"></li>
                						<li class="login_logouts">'.wp_loginout($_SERVER['REQUEST_URI'], false).'</li>
                					</ul>
                				</li>
                                <!-- /.dropdown -->
                               
                			</ul>
				
				';
			 
			  } 
			  else {
				 echo '<div class="text-right login"><ul class="main-httop"><li id="menu-item-login" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="'.site_url().'/login"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li></ul></div>'; 
			  } 
			  
			   
				 
				
		  
		  ?>
		  </div>
</div>
<?php } ?>

<div class="dashboard_cont_bar <?php echo $class; ?>">
  <div id="parentVerticalTab">		


