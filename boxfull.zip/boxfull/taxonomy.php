<?php
get_header(); ?>
<div class="main-content">
	<section class="faq_sect">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="faq_heading">
						<h1><?php echo $current_term = single_term_title("", false);?></h1>
					</div>
				</div>
			</div>
			<?php 
			if(have_posts()) {
			$loopcounts=1;	
			?>
			<div class="col-md-12">
				<div class="faq_sub">
					
					
						<div class="faq_s_heading">
							<!--<h4><?php //echo $custom_term->name;?></h4>-->
							

							<div class="box_faq">
							<?php while(have_posts()) : the_post(); ?>
								<div class="demo">    
									<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
										<div class="panel panel-default">
											<div class="panel-heading" role="tab" id="headingOne">
											<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo get_the_ID();?>" aria-expanded="false" aria-controls="collapseOne" class="collapsed">
											<i class="more-less glyphicon glyphicon-triangle-right"></i>
											<?php echo get_the_title();?>
											</a>
											</h4>
											</div>
												<div id="collapse<?php echo get_the_ID();?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false">
												<div class="panel-body">
												<?php echo get_the_content();?>
												</div>
												</div>
										</div>
									</div>
								</div>
	
								<?php    endwhile; ?>
							</div>

						

						</div> 
						
				</div>

			</div>
			<?php if($loopcounts%4==0){echo '<div class="clear"></div>'; } $loopcounts++; }
 /*echo '<div class="col-md-12">';
 echo '<div class="paginatefaq">';
echo $pagination = get_the_posts_pagination( array(
    'mid_size' => 2,
    'prev_text' => __( 'Newer', 'textdomain' ),
    'next_text' => __( 'Older', 'textdomain' ),
) );

echo '</div></div>'*/
			echo '<section class="cstm_pagination"><div class="pagi">';
          wp_pagenavi(); 
    echo '</div></section>';?>
			
			</div> 
	</section>
</div>

<?php get_footer(); ?>