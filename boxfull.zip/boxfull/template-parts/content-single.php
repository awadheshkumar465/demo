<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
	</header><!-- .entry-header -->

	<?php twentysixteen_post_thumbnail(); ?>
	<div class="blog-post-date">
		<span class="postsdate"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo get_the_date("F j, Y");?></span>
		<span class="poststime"><i class="fa fa-clock-o" aria-hidden="true"></i><?php  echo get_the_time(); ?></span>
	</div>
	<div class="entry-content">
		<?php
			the_content();

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );

			if ( '' !== get_the_author_meta( 'description' ) ) {
				get_template_part( 'template-parts/biography' );
			}
			
			
			echo get_fb_share(get_the_ID());
			
			echo get_fb_like(get_the_ID());
		?>
			</div><!-- .entry-content -->

	
</article><!-- #post-## -->
