<?php
/*
Plugin Name: icarousel Posts Slider Plugin
Plugin URI: http://example.com
Description: Simple non-bloated WordPress Custom icarousel Posts Type Slider 
Version: 1.0
Author: Awadhesh Kumar
Author URI: http://w3guy.com
*/
class Icarousel
{
		static $_instance = null;
		function __construct(){
			add_action('init', array( &$this, 'create_icarousel_post_type'));
			add_action( 'wp_enqueue_scripts', array( &$this, 'register_plugin_style') );
			add_shortcode('icarousel-slider', array( &$this, 'custom_icarousel_shortcode'));
		}
		static function get_instance(){
			if(!isset(self::$_instance)){
				self::$_instance = new self;
			}
			return self::$_instance;
		}
		function register_plugin_style() {
			wp_register_style( 'demo3', plugins_url( 'icarousel/css/demo3.css' ) );
			wp_register_style( 'icarousel', plugins_url( 'icarousel/css/icarousel.css' ) );
			wp_register_style( 'reset', plugins_url( 'icarousel/css/reset.css' ) );
			wp_register_style( 'styles', plugins_url( 'icarousel/css/styles.css' ) );
			wp_enqueue_style( 'styles' );
			wp_enqueue_style( 'reset' );
			wp_enqueue_style( 'icarousel' );
			wp_enqueue_style( 'demo3' );
	
			wp_register_script( 'icarousel-js', plugins_url( 'icarousel/js/icarousel.js' ) );
			wp_register_script( 'easing', plugins_url( 'icarousel/js/jquery.easing.1.3.js' ) );
			wp_register_script( 'mousewheel', plugins_url( 'icarousel/js/jquery.mousewheel.js' ) );
			wp_register_script( 'jquery-min', plugins_url( 'icarousel/js/jquery-1.7.1.min.js' ) );
			wp_register_script( 'raphael-min', plugins_url( 'icarousel/js/raphael-min.js' ) );
			wp_enqueue_script('raphael-min');
			wp_enqueue_script('jquery-min');
			wp_enqueue_script('mousewheel');
			wp_enqueue_script('easing');
			wp_enqueue_script('icarousel-js');
			

		}
	   function create_icarousel_post_type(){
						$labels = array(
									'Name' => 'icarousel',
									'Singular_Name' => 'icarousel',
									'add_new' => 'Add New',
									'menu_name' => 'icarousel',
									'all_items' => 'All icarousel'
									);
						register_post_type(
								'icarousel',
								 array(
									  'labels' =>$labels,
									  'public' => true,
									  'supports' => array('title','editor','thumbnail'),
									  'capability_type' => 'post',
									  'has_archive' => false,
									  'hierarchical' => true,
								  	)
								 );

		}   
		
		function custom_icarousel_shortcode($args){
			$results = NULL;
			ob_start();
				$args = array( 'post_type' => 'icarousel', 'posts_per_page' => 5 );
				$query = new WP_Query( $args ); ?>
					<div id="cont">
						<div class="carousel-container">
							<div id="icarousel">
								<?php
								while ( $query->have_posts() ) : $query->the_post(); ?>
										<a href="#" target="_self" class="slide">
								        <?php echo get_the_post_thumbnail( $id, array( 480, 360 ) ); ?>
								        <h1 style="color: #ffffff; text-align: center; font-size: 18px; line-height: 20px;">
								        	<span><?php the_title();  ?></span>
								        </h1>
								        </a>
								        
								<?php endwhile; ?>
							</div>
						</div>
					</div><?php
				$results = ob_get_clean();
		    return $results;
			
		}

}

$Icarousel = Icarousel::get_instance();