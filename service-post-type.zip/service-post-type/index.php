<?php
/*
Plugin Name: Service Posts Plugin
Description: Simple non-bloated WordPress Custom Service Type
Author: Awadhesh Kumar
*/
class Services
{
		static $_instance = null;

		function __construct(){

			add_action('init', array( &$this, 'create_services_post_type'));
			add_shortcode('custom_services_shortcode', array( &$this, 'custom_services_shortcode'));

		}
		static function get_instance(){
			if(!isset(self::$_instance)){
				self::$_instance = new self;
			}
			return self::$_instance;
		}
	   function create_services_post_type(){
						$labels = array(
									'Name' => 'Services',
									'Singular_Name' => 'Services',
									'add_new' => 'Add New',
									'menu_name' => 'Services',
									'all_items' => 'All Services'
									);
						register_post_type(
								'services',
								 array(
									  'labels' =>$labels,
									  'public' => true,
									  'supports' => array('title','editor','thumbnail'),
									  //'taxonomies' => array( 'post_tag', 'category' ),
									  'capability_type' => 'post',
									  'has_archive' => true,
									  'hierarchical' => true,
								  	)
								 );

		}   
		function custom_services_shortcode($args){
			$attr = shortcode_atts(
				array(
					'posts_per_page'	=> -1,
				),
				$args, 'custom_services_shortcode'
			);
			extract($attr);
			$query_args = array(
				'post_type'			=> 'services',
				'publish'			=> true,
				'posts_per_page'	=> $posts_per_page,
				'paged' 			=> $paged,
				'order'				=> 'DESC'
			);
			$query = new WP_QUERY($query_args); ?>
				<div class="all-services">
					<h1 class="ser-heading">Our Services</h1>
					<ul>
			         <?php while ($query->have_posts()) : $query->the_post(); ?>
						<li class="comn-cervices">
						  <div class="thub-services">
						  <a href="<?php the_permalink(); ?>">
						        <?php the_post_thumbnail(array(100, 100, true)); ?>
						  </a>
						  </div>
						<div class="service-content-area">
						<div class="service-title">
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						</div>
						<div class="service-content"><?php echo get_excerpt(12); ?></div>
						</div>
						</li>
				    <?php endwhile; ?>
				    </ul>
				</div>
		<?php }

}

$Services = Services::get_instance();
