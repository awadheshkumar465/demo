<?php
if($_POST['action'] == 'Swip'){
   $pairvalue = $_POST['Pair'];
   $ValS = explode('_',$pairvalue);

   
		$leftSymb = strtoupper($ValS[0]);
		$rightSymb = strtoupper($ValS[1]);


		$url = 'https://shapeshift.io/marketinfo/'.$pairvalue;
        
		
		$curl = curl_init(); 
		// set url 
	    curl_setopt($curl, CURLOPT_URL,  $url); 
	    //return the transfer as a string 
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
		$resp = curl_exec($curl); 
		curl_close($curl);
		$arrayvalues = json_decode($resp);
		
        $rate = $arrayvalues->rate;
        $minerFee = $arrayvalues->minerFee.' '.$rightSymb;
        $maxLimit = $arrayvalues->maxLimit.' '.$leftSymb;
        $minimum = $arrayvalues->minimum.' '.$leftSymb;

        $toprate = $leftSymb.' = '.$arrayvalues->rate.'&nbsp;'.$rightSymb;
     

       echo $toprate.'##'.$minimum.'##'.$maxLimit.'##'.$minerFee.'##'.$rate.'##'.$arrayvalues->minimum.'##'.$arrayvalues->maxLimit.'##'.$arrayvalues->minerFee;
}
?>