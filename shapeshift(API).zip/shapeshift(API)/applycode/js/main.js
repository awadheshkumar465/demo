
// Build the chart
Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotBorder: 0,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: ''
    },
    tooltip: {
        pointFormat: '<b>{series.name}</b>: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: false
            },
        }
    },

    colors: ['#97bbcd', '#dcdcdc', '#28394d'],
    series: [{
        name: 'point',
        data: [{
            name: '<b>BTC to ALT</b>',
            y: 29
        }, {
            name: '<b>ALT To BTC</b>',
            y: 31
        }, {
            name: '<b>ALT to ALT</b>',
            y: 40       
        }]
    }]
});



// Build the chart
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: ''
    },
    tooltip: {
        pointFormat: '<b>{series.name}</b>: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: false
            },
        }
    },
    colors: ['#97bbcd', '#dcdcdc', '#28394d'],
    series: [{
        name: 'point',
        data: [{
            name: '<b>BTC to ALT</b>',
            y: 29
        }, {
            name: '<b>ALT To BTC</b>',
            y: 31
        }, {
            name: '<b>ALT to ALT</b>',
            y: 40       
        }]
    }]
});