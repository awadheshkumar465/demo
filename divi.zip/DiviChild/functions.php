<?php
function divi_child_enqueue_styles() {
	    wp_enqueue_style( 'divi-parent-style', get_template_directory_uri() . '/style.css' );
	    wp_enqueue_style( 'divi-child-style', get_stylesheet_directory_uri() . '/style.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'animate-style', get_stylesheet_directory_uri() . '/css/animate.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'bootstrap-min-style', get_stylesheet_directory_uri() . '/css/bootstrap.min.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'font-awesome-style', get_stylesheet_directory_uri() . '/css/font-awesome.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'master-style', get_stylesheet_directory_uri() . '/css/master.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'owl-carousel-style', get_stylesheet_directory_uri() . '/css/owl.carousel.css', wp_get_theme()->get('Version') );
		wp_enqueue_style( 'owl-theme-style', get_stylesheet_directory_uri() . '/css/owl.theme.css', wp_get_theme()->get('Version') );

	/**Scripts**/
	   wp_enqueue_script( 'bootstrap-min-script', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', wp_get_theme()->get('Version') );
	   wp_enqueue_script( 'jquery-min-script', get_stylesheet_directory_uri() . '/js/jquery-3.2.1.min.js', wp_get_theme()->get('Version') );
	   wp_enqueue_script( 'owl-carousel-min-script', get_stylesheet_directory_uri() . '/js/owl.carousel.min.js', wp_get_theme()->get('Version') );
	   wp_enqueue_script( 'wow-min-script', get_stylesheet_directory_uri() . '/js/wow.min.js', wp_get_theme()->get('Version') );
	}
	add_action( 'wp_enqueue_scripts', 'divi_child_enqueue_styles' );

	/**widgets register**/
	function bettern_widget_area() {
  register_sidebar(array(
    'name' => 'Top Header Sidebar',
    'id' => 'top-header',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
  register_sidebar(array(
    'name' => 'Copyright',
    'id' => 'copyright',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
  register_sidebar(array(
    'name' => 'Top Footer One',
    'id' => 'top-footer-one',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
  register_sidebar(array(
    'name' => 'Top Footer Two',
    'id' => 'top-footer-two',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
  register_sidebar(array(
    'name' => 'Top Footer Three',
    'id' => 'top-footer-three',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
}
add_action('widgets_init', 'bettern_widget_area');

/**Menu register**/
function wpb_custom_new_menu() {
  register_nav_menus(
    array(
      'my-custom-menu' => __( 'My Custom Menu' ),
      'extra-menu' => __( 'Extra Menu' )
    )
  );
}
add_action( 'init', 'wpb_custom_new_menu' );

/**woocommerce mini-cart**/
// Add Shortcode
function custom_mini_cart() {
  echo '<li>';
	echo '<a href="'.WC_Cart::get_cart_url().'"> ';
	    echo '<i class="fa fa-shopping-bag" aria-hidden="true"></i>';
	    echo '<div class="basket-item-count" style="display: inline;">';
	        echo '<span class="cart-items-count count">';
	            echo WC()->cart->get_cart_contents_count();
	        echo '</span>';
	    echo '</div>';
	echo '</a>';
  echo '</li>';
	echo '<ul class="dropdown-menu dropdown-menu-mini-cart">';
	        echo '<li> <div class="widget_shopping_cart_content">';
	                  woocommerce_mini_cart();
	       echo '</div></li></ul>';

}
add_shortcode( 'custom-mini-cart', 'custom_mini_cart' );

?>
