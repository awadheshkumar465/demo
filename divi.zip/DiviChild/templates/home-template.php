<?php
/**
Template Name: Home Page
**/

get_header();
while(have_posts()):the_post();
$lft_img = get_field('left_image');
$rht_img = get_field('right_image');
$product_section = get_field('heading',102);
$pro_lft_title = get_field('left_title',102);
$pro_lft_content = get_field('left_content',102);
$pro_lft_btn_lnk = get_field('left_button_link',102);
$pro_lft_btn = get_field('left_button_text',102);
$bottom_title = get_field('bootom_title');
$bottom_content = get_field('bottom_content');
$bottom_link = get_field('bottom_link');
$bottom_btn= get_field('bottom_button_text');
?>

<div class="main-content" id="contant-p">
	<section class="popu-countries">
		<div class="container">
			<div class="mapdiv">
				<div class="col-sm-6">
					<div class="img-er wow slideInLeft animated">
						<img src="<?php echo $lft_img ;?>">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="img-er wow slideInRight animated">
						<img src="<?php echo $rht_img;?>">
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="box_servies">
		<div class="container">
			<div class="box_welcome">
				<div class="heading-section">
					<h2 class="wow fadeInDown animated">Our <span class="yellow"><?php echo $product_section;?></span></h2>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-3 wow fadeInLeft animated">
					<div class="new-collection">
						<h2><?php echo $pro_lft_title;?></h2>
						<p><?php echo $pro_lft_content;?></p>
						<a href="<?php echo $pro_lft_btn_lnk;?>"><button class="shop-now"><?php echo $pro_lft_btn;?></button></a>
					</div>
				</div>
				<div class="col-sm-9 wow fadeInRight animated">
					<div id="demo">
						<div id="owl-demo-pro" class="owl-carousel">
						<?php
						$pro_arg = array('post_type'=>'product', 'posts_per_page'=>-1, 'order'=>'ASC');
						$pro_query = new WP_Query( $pro_arg );
						if ( $pro_query->have_posts() ):
						while ( $pro_query->have_posts() ) :
		$pro_query->the_post();
						$pro_btn = get_field('cart_button');
						$pro_rate = get_post_meta( get_the_ID(), '_regular_price', true );
						$pro_image = wp_get_attachment_url( get_post_thumbnail_id() );
						?>
							<div class="item">
								<div class="pro-item">
									<img src="<?php echo $pro_image;?>">
								</div>
								<div class="pro-containt">
									<a href="<?php echo get_permalink()?>" target="_blank"><button class="ad-cart"><?php the_title(); ?></button></a>
									<p><?php the_excerpt();?></p>
									<?php
									if($pro_rate)
									{
									?>
									<h5><?php echo 'FROM';?>&nbsp;<?php echo $pro_rate;?>&nbsp; <?php echo get_woocommerce_currency_symbol();?></h5>
									<?php
									}
									?>
								</div>
							</div>
							<?php
							endwhile;
							endif;
							?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="our-work">
	    <div class="details">
	        <div class="container">
	        	<div class="box_welcome">
					<div class="heading-section">
						<h2 class="wow fadeInDown animated">Popular <span class="yellow">Categories</span></h2>
					</div>
				</div>
	            <div class="row">
				<?php
					$arg = array('post_type'=>'popularpost','posts_per_page'=>-1,'order'=>'ASC');
					$the_query = new WP_Query($arg);
					if ( $the_query->have_posts() ):
						while ( $the_query->have_posts() ) :
		$the_query->the_post();
		            $feat_image = wp_get_attachment_url( get_post_thumbnail_id() );
					?>
	                <div class="col-sm-3">

	                    <div class="box wow slideInLeft animated">
	                       	<img src="<?php echo $feat_image;?>">
	                       	<a href="<?php the_permalink(); ?>">
		                       	<div class="overlay-img">
		                    		<h4><?php the_title();?></h4>
		                       	</div>
	                       	</a>
	                    </div>
	                </div>
					<?php
					endwhile;
					endif;
					?>
	            </div>
	        </div>
	    </div>
	</section>

	<section class="our-client">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="demo">
						<div id="owl-demo-client" class="owl-carousel">
						<?php
						$logo = array('post_type'=>'logo', 'posts_per_page'=>-1, 'order'=>'ASC');
						$logo_query = new WP_Query($logo);
					if ( $logo_query->have_posts() ):
						while ( $logo_query->have_posts() ) :
		$logo_query->the_post();
		            $logo_image = wp_get_attachment_url( get_post_thumbnail_id() );

						?>
							<div class="item">
								<div class="pro-item">
									<img src="<?php echo $logo_image;?>">
								</div>
							</div>
						<?php
					endwhile;
					endif;
					?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="center-sec">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="center-s">
						<h1 class="wow fadeInDown animated"><?php echo $bottom_title;?></h1>
						<?php echo $bottom_content?>
						<div class="read-btd">
							<button><?php echo $bottom_btn;?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php
endwhile;
get_footer();
?>
