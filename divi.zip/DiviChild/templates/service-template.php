<?php
/**
Template Name: Services Page
**/

get_header();
while(have_posts()):the_post();
?>
<section class="service_sec">
		<div class="service_sec_main">
			<div class="container">
			
				<div class="row">
				<?php 
				$service = array('post_type'=>'service', 'posts_per_page'=>-1, 'order'=>'ASC');
				$service_query = new WP_Query( $service );
						if ( $service_query->have_posts() ):
						while ( $service_query->have_posts() ) :
		$service_query->the_post();
		        $service_img = wp_get_attachment_url( get_post_thumbnail_id() );
				?>
                <div class="col-sm-4 col-md-4">
                    <div class="img-gallery wow bounceIn animated">
                        <div class="img_glry_img">
                            <img src="<?php echo $service_img;?>">
                        </div>
                        <div class="content-gall">
                            <h4><a href="<?php the_permalink(); ?>" class="service-name"><?php the_title();?></a></h4>
                             <?php the_excerpt();?>   
                            <a href="<?php the_permalink(); ?>">Read More</a>
                        </div>
                    </div>
                </div>
				<?php
							endwhile;
							endif;
							?>
			</div>
			
			</div>
		</div>
	</section>
  
<?php
endwhile;
get_footer();
?>