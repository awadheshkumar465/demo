<?php
/**
Template Name: Offers Page
**/

get_header();
$top_title =get_field('title');
$bottom_banner_img = get_field('banner_image');
?>
<div class="container">
    <div class="heading-section">
      <h2 class="wow fadeInDown animated animated" style="visibility: visible; animation-name: fadeInDown;"><?php echo $top_title;?></h2>
    </div>
  </div>
    <div class="container">
    <div class="row">
	<?php
	$args = array(
    'order'      => 'ASC',
    'hide_empty' => $hide_empty,
);
$product_categories = get_terms( 'product_cat', $args );
$count = count($product_categories);
if ( $count > 0 ){
    foreach ( $product_categories as $product_category ) {
        $args = array(
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $product_category->slug
                )
            ),
            'post_type' => 'product',
        );
        $products = new WP_Query( $args ); 
		while ( $products->have_posts() ) {
            $products->the_post();
			$pro_img = wp_get_attachment_url( get_post_thumbnail_id() );
			$sale_price = get_post_meta( get_the_ID(), '_sale_price', true );
		?>
	
      <div class="col-md-4">
        <div class="box_offerMain">
          <div class="box_offerImg"> <img src="<?php echo $pro_img;?>" alt="" title=""/> </div>
          <div class="box_offerF">
            <h4><?php the_title();?></h4>
            <?php echo '<h3><a href="' . get_term_link( $product_category ) . '">' . $product_category->name . '</a></h3>' ?>
            <p>UP TO</p>
            <span>10%<em>AUS</em></span> <a href="<?php echo get_permalink();?>" class="btn_shop">Jetzt einkaufen</a> </div>
        </div>
      </div>
      
     <?php
	}
	}
}
	 ?>
    </div>
  </div>
	
  <section>
    <div class="offer-img"> <img src="<?php echo $bottom_banner_img;?>"> </div>
  </section>
  
<?php

get_footer();
?>