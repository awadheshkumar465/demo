<?php
/**
Template Name: Team Page
**/

get_header();
while(have_posts()):the_post();
$Right_icon = get_field('icon_right');
$Right_title = get_field('title_right');
$Right_content = get_field('content_right');
$Left_icon = get_field('left_icon');
$Left_title = get_field('left_title');
$Left_content = get_field('left_content');
?>
<section class="profecer-sec">
		<div class="profecer-sec-box">
			<div class="container">
				<div class="row">
				<?php 
				$team_arg = array('post_type'=>'ourteam', 'posts_per_page'=>-1, 'order'=>'ASC' );
				$team_query = new WP_Query($team_arg);
				if($team_query->have_posts()):
				while($team_query->have_posts()):$team_query->the_post();
				$author_img = wp_get_attachment_url( get_post_thumbnail_id() );
				$author_name = get_field('author_name');
				$author_designation = get_field('author_designation');
				?>
					<div class="col-sm-3">
						<div class="pg-group-profile wow bounceIn animated">
							<div class="img-pr-hero">
								<img src="<?php echo $author_img;?>">
								<div class="pg-overlay">
									<p>
										<b><?php echo $author_name;?><span><?php echo $author_designation;?></span></b>
										<?php the_excerpt();?>
									<a href="<?php echo get_permalink();?>"><button class="video-pop-btn theme-btn">
										Read More
									</button></a>
									</p>
								</div>
							</div>
						</div>
					</div>
					<?php
					endwhile;
					endif;
					?>
				</div>
			</div>
		</div>
	</section>	
<section class="the-master_edu-sec">
		<div class="the-master_edu-col">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="row">
						<?php
						if( have_rows('section_third', 70) ):
							while ( have_rows('section_third', 70) ) : the_row();
							$left_img = get_sub_field('image');
							$left_title = get_sub_field('title');
							$left_sub_title = get_sub_field('sub_title');
							$left_content = get_sub_field('content');
						?>
							<div class="col-sm-6">
								<div class="hero-pro wow bounceIn animated">
									<div class="pro-pic-for-hero">
										<img src="<?php echo $left_img;?>">
									</div>
									<div class="conta-for-hero">
										<h3><?php echo $left_title;?></h3>
										<p><?php echo $left_sub_title;?></p>
										<?php echo $left_content;?>
										<div class="read-more-btn-box">
											<a href="#">Read More</a>
										</div>
									</div>
								</div>
							</div>
						<?php
						endwhile;
						endif;
						?>	
							
						</div>
					</div>
					<div class="col-sm-6 wow fadeInRight animated">
						<div class="gtco-heading inner-head animate-box" data-animate-effect="fadeIn">
							<div class="icons-heros">
								<img src="<?php echo $Right_icon;?>">
							</div>
							<h2><?php echo $Right_title;?></h2>
							<p><?php echo $Right_content;?></p>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>
<section class="the-master_edu-sec whit-sec">
		<div class="the-master_edu-col">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 wow fadeInRight animated">
						<div class="text-right gtco-heading inner-head animate-box" data-animate-effect="fadeIn">
							<div class="icons-heros">
								<img src="<?php echo $Left_icon;?>">
							</div>
							<h2><?php echo $Left_title;?></h2>
							<p><?php echo $Left_content;?></p>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="row">
						<?php
						if( have_rows('section_four', 70) ):
							while ( have_rows('section_four', 70) ) : the_row();
							$right_img = get_sub_field('image_right');
							$right_title = get_sub_field('title_right');
							$right_sub_title = get_sub_field('sub_title_right');
							$right_content = get_sub_field('content_right');
						?>
							<div class="col-sm-6">
								<div class="hero-pro wow bounceIn animated">
									<div class="pro-pic-for-hero">
										<img src="<?php echo $right_img;?>">
									</div>
									<div class="conta-for-hero">
										<h3><?php echo $right_title;?></h3>
										<p><?php echo $right_sub_title;?></p>
										<p><?php echo $right_content;?></p>
										<div class="read-more-btn-box">
											<a href="#">Read More</a>
										</div>
									</div>
								</div>
							</div>
							<?php
						endwhile;
						endif;
						?>	
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>

<?php
endwhile;
get_footer();

?>