<?php
/**
Template Name: About Page
**/

get_header();
while(have_posts()):the_post();
$top_section_image = get_field('top_section_image');
$top_title = get_field('top_title');
$top_sub_title = get_field('top_sub_title');
$second_section_title = get_field('second_section_title');
$second_section_content = get_field('second_section_content');
$who_we_are_left_image = get_field('who_we_are_left_image');
$who_ae_are_lists = get_field('who_ae_are_lists');
$testinomial_title = get_field('testimonial_title');
$testinomial_content = get_field('testimonial_content');
?>

	<section class="form-sec">
		<div class="container">			
			<div class="row">
				<div class="col-sm-12">
					<div class="about_contant wow fadeInUp animated">
						<p>
						<?php the_content();?>	
						</p>
						<img src="<?php echo $top_section_image;?>" class="wow fadeInDown animated">
						<h2 class="wow fadeInDown animated"><?php echo $top_title;?><span><?php echo $top_sub_title;?></span></h2>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="who_we">
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<div class="about-who">
						<div class="heading-section">
							<h2 class="wow fadeInDown animated"><?php echo $second_section_title;?></h2>
						</div>
						<p class="wow fadeInUp animated"><?php echo $second_section_content;?></p>
						<?php echo $who_ae_are_lists;?>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="who-we-img wow slideInRight animated">
						<img src="<?php echo $who_we_are_left_image;?>">
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="head-main-sec">
						<div class="heading-section">
							<h2 class="wow fadeInDown animated"><?php echo $testinomial_title;?></h2>
							<?php echo $testinomial_content;?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="slider-test">
			<div class="slider-back">
				<div class="container">
					<div id="demo">      
			            <div id="owl-test" class="owl-carousel">
							<?php
							$testimonials = array('post_type'=>'testimonial', 'Posts_per_page'=>-1, 'order'=>'ASC');
							$test_query = new WP_Query( $testimonials );
							if ( $test_query->have_posts() ):
							while ( $test_query->have_posts() ) :
							$test_query->the_post();
							?>
							<div class="item">
								<div class="item-cont">
									<p>
									<?php the_content();?>	
									</p>
									<h3>- <?php the_title();?></h3>
								</div>
							</div>
							<?php
							endwhile;
							endif;
							?>
				
			            </div>         
			    	</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php
endwhile;
get_footer();
?>
