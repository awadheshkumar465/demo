<?php
/**
Template Name: Contact Page
**/

get_header();
while(have_posts()):the_post();
$testinomial_title = get_field('testimonial_title');
$testinomial_content = get_field('testimonial_content');
$address_title = get_field('address_title');
$address_content = get_field('address_content');
$lft_top = get_field('top_left_section');
$phone_number = get_field('phone_number');
$fax_number  = get_field('fax_number');
$middle_top = get_field('top_middle_section');
$last_top = get_field('top_last_section');
?>
<section class="form-sec">
		<div class="container">
			<div class="form-box">
				<div class="row">
					<div class="col-sm-7">
						<?php echo do_shortcode('[contact-form-7 id="174" title="Kontaktformular"]');?>
					</div>
					<div class="col-sm-5">
						<div class="add wow bounceIn animated add1">
								<p class="add_title"><b><i class="fa fa-map-marker"></i> <?php echo $address_title; ?></b></p>
								<?php echo $address_content; ?>
								<p class="phone_no"><a href="tel:<?php echo $phone_number; ?>"><i class="fa fa-phone"></i> <?php echo $phone_number; ?></a>
								<a href="tel:<?php echo $fax_number; ?>"><i class="fa fa-phone"></i> <?php echo $fax_number; ?></a></p>
							<?php //echo $lft_top;?>
						</div>
						<div class="add wow bounceIn animated add2">
							<?php echo $middle_top;?>
						</div>

						<div class="add wow bounceIn animated add3">
							<?php echo $last_top;?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="head-main-sec">
						<div class="heading-section">
							<h2 class="wow fadeInDown animated"><?php echo $testinomial_title;?></h2>
							<?php echo $testinomial_content;?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="slider-test">
			<div class="slider-back">
				<div class="container">
					<div id="demo">
			            <div id="owl-test" class="owl-carousel">

							<?php
							$testimonials = array('post_type'=>'testimonial', 'Posts_per_page'=>-1, 'order'=>'ASC');
							$test_query = new WP_Query( $testimonials );
							if ( $test_query->have_posts() ):
							while ( $test_query->have_posts() ) :
							$test_query->the_post();
							?>
							<div class="item">
								<div class="item-cont">
									<p>
									<?php the_content();?>
									</p>
									<h3>- <?php the_title();?></h3>
								</div>
							</div>
							<?php
							endwhile;
							endif;
							?>
		            </div>
			    	</div>
				</div>
			</div>
		</div>
	</section>
<?php
endwhile;
get_footer();
?>
