<?php if ( 'on' == et_get_option( 'divi_back_to_top', 'false' ) ) : ?>

	<span class="et_pb_scroll_top et-pb-icon"></span>

<?php endif;

if ( ! is_page_template( 'page-template-blank.php' ) ) : ?>

<section>
	<div class="bottom-section">
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<?php dynamic_sidebar('Top Footer One');?>
				</div>

				<div class="col-sm-4">
					<?php dynamic_sidebar('Top Footer Two');?>
				</div>

				<div class="col-sm-4">
					<?php dynamic_sidebar('Top Footer Three');?>
				</div>

			</div>
		</div>
	</div>
</section>
			<footer class="main_footer">	   
	<div class="container">
		<div class="row">
			<div class="f_middle wow fadeInDown animated">
				<div class="col-md-4 col-sm-4">
					<?php dynamic_sidebar('sidebar-2');?>
				</div>
				<div class="col-md-8 col-sm-8">
					<div class="working_hours">
						<div class="row">
							<div class="col-sm-4">
								<div class="f_heading">
									<h3>Information</h3>
								</div>
								<?php dynamic_sidebar('sidebar-3');?>
							</div>
							<div class="col-sm-4">
								<div class="f_heading">
									<h3>KATEGORIEN</h3>
								</div>
								<?php dynamic_sidebar('sidebar-4');?>
							</div>
							<div class="col-sm-4">
								<div class="f_heading footer-add">
									<h3>Professionelle Konten</h3>
									<?php dynamic_sidebar('sidebar-5');?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="copyright">
					<div class="col-sm-12">
						<div class="f_follow text-center"><?php dynamic_sidebar('Copyright');?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
		</div> <!-- #et-main-area -->

<?php endif; // ! is_page_template( 'page-template-blank.php' ) ?>

	</div> <!-- #page-container -->

	<?php wp_footer(); ?>
	<script src="<?php echo get_stylesheet_directory_uri();?>/js/owl.carousel.min.js"></script>
<script>
    jQuery(document).ready(function() {
    	jQuery("#owl-test").owlCarousel({
			navigation : false,
			slideSpeed : 300,
			pagination : false,
			singleItem : true,
			autoPlay : true
		});
    });
</script>
<script>
   wow = new WOW(
     {
       animateClass: 'animated',
       offset: 100
     }
   );
   wow.init();
</script>
<script>
    jQuery(document).ready(function() {
      jQuery("#owl-demo").owlCarousel({
        navigation : true,
        slideSpeed : 300,
        paginationSpeed : 400,
        singleItem : true,
        pagination : false,
        autoPlay:false
      });
    });
    jQuery(document).ready(function() {
      jQuery("#owl-demo-pro").owlCarousel({
        items : 3,
        itemsDesktop : [1100,3],
        itemsDesktopSmall : [900,2],
        itemsTablet: [600,2],
        itemsMobile : [500,1],
        lazyLoad : true,
        navigation : true,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    }); 
    jQuery(document).ready(function() {
      jQuery("#owl-demo-client").owlCarousel({
        items : 7,
        itemsDesktop : [1100,6],
        itemsDesktopSmall : [900,5],
        itemsTablet: [600,4],
        itemsMobile : [500,3],
        lazyLoad : true,
        navigation : true,
        pagination : false,
        autoPlay:true,
	    autoplayHoverPause:true
      });
    });    
</script>
<script>
	jQuery(document).ready(function(){
	  jQuery("#slide-btn").on('click', function(event) {
	    if (this.hash !== "") {
	      	jQuery('html, body').animate({
	        	scrollTop: jQuery("#contant-p").offset().top
	      		}, 800, function(){
	      	});
	    	}
	  	});
	});
</script>
<script type="text/javascript">
	jQuery(window).scroll(function() {   
	    if (jQuery(window).scrollTop() >=50) { 
	    if(jQuery('#nav-top').hasClass( "navi" ))
	  	{
	  		//jQuery('#header').removeClass("fixed-theme");
	  	}
	  	else
	  	{
	  		jQuery('#nav-top').addClass("navi");
	  	}
	    }
		else{
			jQuery('#nav-top').removeClass("navi");
		}
	 });
</script>

</body>
</html>