<?php
/*
 * Template Name: Single Team Post
 */
  
get_header();  
while(have_posts()):the_post(); ?>
<div id="main-content">
	<div class="container our-team-container">
		<div id="content-area" class="clearfix our-team-content">
			<div id="left-area" class="our-team-area">
				<article id="post" class="our-team-post">
					<div class="et_post_meta_wrapper">
						<?php the_post_thumbnail(); ?>
					</div>
					<div class="our-team-content">
						<h1 class="our-team-title"><?php the_title(); ?></h1>
						<span><?php the_content(); ?></span>
					</div> <!-- .entry-content -->
					<div class="et_post_meta_wrapper"></div>
				</article> <!-- .et_pb_post -->
			</div> <!-- #left-area -->
				<?php get_sidebar(); ?>
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div>
<?php endwhile;
get_footer(); ?>