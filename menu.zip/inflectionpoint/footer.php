<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */
?>
</div><!-- #content -->
	<footer class="ftr">
  		<div class="container">
		    <div class="row">
		      <div class="col-md-8 col-sm-6">
		        <div class="copyright">
		          <p>&copy Inflectionpoint 2014 | Inflection Point</p>
		        </div>
		      </div>
		      <div class="col-md-4 inline text-right col-sm-6">
		        <div class="social text-right">
		        	 <?php wp_nav_menu( array(
		                'theme_location' => 'social',
		                'container' => false,
		                'menu_class' => 'social-menu-link'
		            ) ); ?>
		        </div>
		        <div class="prtnr_logo">
		          <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ibm_logo.gif" class="img-responsive">
		        </div>
		      </div>
		    </div>
  		</div>
	</footer>
 	</body>
</html>