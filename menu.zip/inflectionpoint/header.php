<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>InflectionPoint</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <?php wp_head(); ?>
 </head>
<body <?php body_class(); ?>>
    <nav class="navbar navbar-default">
        <div class="container">
            <div class="prnt">
                <div class="navbar-header">
                    <?php the_custom_logo(); ?>
                 

                </div>
                <div class="dropdown right">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/menu.png">
                    </button>
                    <?php wp_nav_menu( array(
                        'theme_location' => 'top',
                        'container' => 'ul',
                        'menu_class' => 'custom'
                    ) ); ?>
                    <?php wp_nav_menu( array(
                        'theme_location' => 'dropdown-menu',
                        'container' => 'ul',
                        'menu_class' => 'dropdown-menu'
                    ) ); ?>
                   <!--  <ul class="dropdown-menu">
                      <li><a href="#">HTML</a></li>
                      <li><a href="#">CSS</a></li>
                      <li><a href="#">JavaScript</a></li>
                    </ul> -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </nav>