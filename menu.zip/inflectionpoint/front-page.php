<?php
/**
Template Name: Front Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php $ids =  get_the_ID(); ?>
	<section class="data">
	  	<div class="container">
		    <div class="col-md-12">
		      	<div class="data-head">
		        	<h1><?php the_field ('page_title', $ids); ?></h1>
		      	</div>
		      	<div class="boxes">
			       <div class="row text-center">
				      	<?php 
				      	$args = array(
			                'order'             => 'DESC',
			                'orderby'           => 'id',
			                'hide_empty'        => true, 
			                'number'            => 3, 
			                'fields'            => 'all' 
			            ); 
		            	$terms = get_terms('making_sense_cat', $args);
		            	foreach ( $terms as $term ) {
			            	//echo "<pre>"; print_r($term);
			            	$term_link = get_term_link( $term );
			            	$term_id = $term->term_id;
							$term_meta = the_field( 'making_sense_category_image',$term_id );
							$cat_image = get_field('making_sense_category_image', 'making_sense_cat_' . $term_id );
							print_r($image); ?>
			          		<div class="col-md-4 col-sm-4">
					            <div class="box">
					            	<h4><?php echo $term->name; ?></h4>
					              	<div class="animate shake">
					              		<img src="<?php echo $cat_image; ?>" class="img-responsive center ">
					            	</div>
			            		</div>
			          		</div>
					    <?php } ?>
					</div>
				</div>
		    </div>
	  	</div>
	</section>


	<section class="insights">
 		<div class="container">
    		<div class="row">
      			<div class="col-md-12">
        			<div class="para">
        				<p><?php echo get_field('bottom_title',$ids); ?></p>
      				</div>
      			</div>
    		</div>
   	 		<div class="insight_box">
		      	<div class="row text-center">

		      		<?php if( have_rows('page_link') ): ?>
                            <?php while( have_rows('page_link') ): the_row(); ?>
                                    <div class="col-md-4 col-sm-4">
								        <div class="box_grd">
								          <a href="<?php echo get_sub_field('page_link'); ?>"><?php echo get_sub_field('page_title'); ?></a>
								        </div>
					      			</div>
                                    
                            <?php endwhile; ?>
                        <?php endif; ?>
	    		</div>
  			</div>
		</div>
	</section>

<?php endwhile; 
endif; ?>

<?php get_footer();
