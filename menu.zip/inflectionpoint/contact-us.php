<?php
/**
Template Name: Contact-Us Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php $ids =  get_the_ID(); ?>
	<section class="contactus">
  		<div class="container">
		    <div class="row">
		      	<div class="col-md-12">
			        <div class="cnt_head">
			          <h4><?php the_field('page_title',$ids); ?></h4>
			        </div>
		      	</div>
		    </div>
		    <div class="tb-view">
		      	<div class="row">
		        	<div class="col-md-6 col-sm-6">
		          		<div class="adrs">
				            <div class="ad-icon sz">
				              <i class="fa fa-paper-plane adfa" aria-hidden="true"></i>
				            </div>
				            <div class="ad-icon size">
				              <?php the_field('first_section',$ids); ?>
				            </div>
		          		</div>
		        	</div>
			        <div class="col-md-6 col-sm-6">
			          	<div class="adrs">
				            <div class="ad-icon sz">
				              <i class="fa fa-home adfa" aria-hidden="true"></i>
				            </div>
				            <div class="ad-icon size">
				              <p><?php the_field('second_section',$ids); ?></p>
				            </div>
			          	</div>
			        </div>
		      	</div>
		    </div>
  		</div>
	</section>
	<section class="frm">
	  	<div class="container">
	    	<?php echo do_shortcode('[contact-form-7 id="42" title="Contact Form"]'); ?>
	  	</div>
	</section>
<?php endwhile; 
endif; ?>
<?php get_footer();
