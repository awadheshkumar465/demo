<?php
/**
Template Name: Inner Page
**/

get_header(); ?>
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<?php $ids =  get_the_ID(); ?>
	<section class="we_are">
  		<div class="container">
		    <div class="row">
		      <div class="col-md-12">
		        <div class="cnt_head">
		          <h4>Who <span>we are</span></h4>
		          <div class="cnt_head-para">
		         <?php the_content(); ?>
		        </div>
		        </div>
		      </div>
		    </div>
  		</div>
	</section>
<?php endwhile; 
endif; ?>

<?php get_footer();
