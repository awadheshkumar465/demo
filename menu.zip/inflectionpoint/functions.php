<?php

function mychildtheme_enqueue_styles() {
    $parent_style = 'parent-style';
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ));
    wp_enqueue_style('bootstrap-min-style',get_stylesheet_directory_uri() .'/css/bootstrap.min.css');
    wp_enqueue_style('font-awesome-style',get_stylesheet_directory_uri() .'/css/font-awesome.min.css');
    wp_enqueue_style('master-style',get_stylesheet_directory_uri() .'/css/style.css');

    wp_enqueue_script( 'jquery-min', get_stylesheet_directory_uri() .'/js/jquery-3.3.1.min.js', false );
    wp_enqueue_script( 'bootstrap-min-script', get_stylesheet_directory_uri() .'/js/bootstrap.min.js', false );
}
add_action( 'wp_enqueue_scripts', 'mychildtheme_enqueue_styles' );



add_action( 'init', 'register_my_menu' );

function register_my_menu() {
    register_nav_menu( 'dropdown-menu', __( 'DropDown Menu' ) );
}
/* Create Custom Shortcode for Events post in home-page */
add_shortcode('display_our_team','create_custom_our_team');
function create_custom_our_team(){
	$results = NULL;
	ob_start();
		$args = array( 'post_type' => 'making_sense', 'posts_per_page' => 2 );
		$query = new WP_Query( $args );?>
		<section class="team">
		  	<div class="container">
			    <div class="row">
			    	<div class="col-md-12">
				        <div class="cnt_head">
				          <h4>Our <span>Team</span></h4>
				        </div>
			      	</div>
			    </div>
			    <div class="thumbneil">
      				<div class="row">
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
							<a href="<?php the_permalink(); ?>#<?php echo get_the_id(); ?>" class="custom-block-link service-item">
						    	<div class="col-sm-6 col-md-1-5 text-center img-hover-zoom">
						    	<h1><?php the_title(); ?></h1>
						        <?php echo get_the_post_thumbnail(get_the_id(), 'thumbnail', array('class' => 'img-responsive center-block')); ?>
						        <h2 class="m_title"><?php the_content(); ?></h2>
						    	</div>
						    </a>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</section>
	<?php
	$results = ob_get_clean();
    return $results;
}





/*function register_my_custom_menu_page() {
 add_menu_page( 'custom menu title', 'custom menu', 'manage_options', 'admin.php?page=pmxi-admin-import', '', 'dashicons-admin-site', 6 );
}
add_action( 'admin_menu', 'register_my_custom_menu_page' );*/