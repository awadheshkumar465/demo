<?php
/*
Plugin Name: Hospitals Posts And Category Plugin
Plugin URI: http://example.com
Description: Simple non-bloated WordPress Custom Hospitals Type
Version: 1.0
Author: Awadhesh Kumar
Author URI: http://w3guy.com
*/
class Hospitals
{
		static $_instance = null;

		function __construct(){

			add_action('init', array( &$this, 'create_hospitals_post_type'));
			add_action('init', array( &$this,'create_treatments_category_taxonomies'));
			add_action( 'wp_enqueue_scripts', array( &$this, 'register_plugin_style') );
			add_shortcode('custom_hospitals_shortcode', array( &$this, 'custom_hospitals_shortcode'));
			add_action( 'add_meta_boxes', array( $this, 'my_custom_meta_box' ) );
			add_action( 'save_post', array( $this, 'save_our_custom_data' ) );

			//add_action('add_meta_boxes', array( &$this, 'my_custom_meta_box'));
			//add_action('save_post', array( &$this, 'save_our_custom_data'));
			add_shortcode('shortcode-meta-fields', array( &$this,'hospitals_shortcode_query'));

			add_shortcode('shortcode_treatments_category',array($this, 'get_category'));
			add_shortcode('shortcode_treatments_home_category',array($this, 'put_category'));
			add_action( 'treatments_edit_form_fields',array( &$this,'presenters_taxonomy_custom_fields')); 
			add_action( 'treatments_add_form_fields',array( &$this,'presenters_taxonomy_custom_fields' ));  
			add_action( 'edited_treatments',array( &$this,'save_taxonomy_custom_fields' ), 10, 2);  
	        add_action( 'create_treatments',array( &$this,'save_taxonomy_custom_fields'), 10, 2 );

		}
		static function get_instance(){
			if(!isset(self::$_instance)){
				self::$_instance = new self;
			}
			return self::$_instance;
		}
		function register_plugin_style() {
			wp_register_style( 'my-plugin', plugins_url( 'hospitals-post-type/css/plugin.css' ) );
			wp_enqueue_style( 'my-plugin' );
		}
	   function create_hospitals_post_type(){
						$labels = array(
									'Name' => 'Hospitals',
									'Singular_Name' => 'Hospitals',
									'add_new' => 'Add New',
									'menu_name' => 'Hospitals',
									'all_items' => 'All Hospitals'
									);
						register_post_type(
								'hospitals',
								 array(
									  'labels' =>$labels,
									  'public' => true,
									  'supports' => array('title','editor','thumbnail','excerpt'),
									  //'taxonomies' => array( 'post_tag', 'category' ),
									  'capability_type' => 'post',
									  'has_archive' => false,
									  'hierarchical' => true,
								  	)
								 );

		}   
		function create_treatments_category_taxonomies(){
							$labels = array(
							'Name' =>  'Treatments',
							'Singular_Name' => 'Treatments',
							'parents_item_colon' => 'Parent Treatments:',
							'add_new_item' => 'Add New Treatments',
							'update_item'  => 'Update Treatments',
							'edit_item'    => 'Edit Treatments',
							'new_item_name' => 'New Treatments',
							'menu_name' => 'Treatments',
							);
					register_taxonomy(
							'treatments',
							'hospitals',
							 array(
							 	'labels' => $labels,
							 	'hierarchical' => true,
							 	'query_var' => true,
								'rewrite' => true,
								'show_admin_column' => true,
								'rewrite'=> array( 'slug' => 'treatment' ),
							 	 )
						);
		}

		function custom_hospitals_shortcode($args){
			$return = '';

			$attr = shortcode_atts(
				array(
					'posts_per_page'	=> 4,
				),
				$args, 'custom_hospitals_shortcode'
			);

			extract($attr);

			//Protect against arbitrary paged values
			$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

			$query_args = array(
				'post_type'			=> 'hospitals',
				'publish'			=> true,
				'posts_per_page'	=> $posts_per_page,
				'paged' 			=> $paged,
				'order'				=> 'DESC'
			);

			$query = new WP_QUERY($query_args);

			$return .= '
				<div class="Hospitals">
					<ul>
			';

			while ($query->have_posts()) : $query->the_post();
			
				$return .= '
					<li>
						<a href="'.get_permalink().'">'.get_the_post_thumbnail( get_the_ID(), 'thumbnail').
						get_the_title().'</a>
					</li>
				';
			endwhile;

			$return .= '
					</ul>';

					$big = 999999999; // need an unlikely integer
				$return .= get_query_var( 'paged' ) ? '<div class="Hospitals-pagination">' : '';
					$return .= paginate_links( array(
						'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format' => '?paged=%#%',
						'current' => max( 1, get_query_var('paged') ),
						'total' => $query->max_num_pages
					) );
				$return .= get_query_var( 'paged' ) ? '</div>' : '';

			$return .='
				</div>
			';

			return $return;
		}


/*
  =================================================  CUSTOM TAXONOMY SHORTCODE       =======================================

*/
  function get_category(){

  				$args = array(
				'post_type' => 'hospitals',
				'post_status' => 'publish',
				'posts_per_page'	=> ''
			);
	$args = array(
				'orderby'           => 'name', 
				'order'             => 'ASC',
				'hide_empty'        => true, 
				'exclude'           => array(), 
				'exclude_tree'      => array(), 
				'include'           => array(),
				'number'            => 8, 
				'fields'            => 'all', 
				'slug'              => '',
				'parent'            => '',
				'hierarchical'      => true, 
				'child_of'          => 0,
				'childless'         => false,
				'get'               => '', 
				'name__like'        => '',
				'description__like' => '',
				'pad_counts'        => false, 
				'offset'            => '', 
				'search'            => '', 
				'cache_domain'      => 'core'
			); 
			
			$terms = get_terms('treatments', $args);

			 $aks= '<ul class="treatments-img">';
			foreach ( $terms as $term ) {
				$aks.='<div class="imageshow" style="width:23%; float:left; margin-left:5px; margin-right:5px;">';
				//$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
				$term_link = get_term_link( $term );
				$term_meta = get_option( "taxonomy_term_".$term->term_id );
				$your_img_src = wp_get_attachment_image_src( $term_meta['term_img'],'medium', 'thumbnail' );
				$aks.= '<img src="'.$your_img_src[0].'" alt="" width="" />';
				//$aks.= '<h3 align="center">'.$term->name;'</h3>';
				$aks .= '
				<a href="' . esc_url( $term_link ) . '">' . $term->name . '</a>';	
				$aks.='</div>';
				
				//$aks.= '<p>'.$term->name;'</p>';
			}
			$aks.= '</ul>';
			wp_reset_postdata();
			return $aks;


  }

/*
	==================================   END ==============================================
*/
/* HOME PAGE SHORTCODE */
function put_category(){

  				$args = array(
				'post_type' => 'hospitals',
				'post_status' => 'publish',
				'posts_per_page'	=> ''
			);
	$args = array(
				'orderby'           => 'name', 
				'order'             => 'ASC',
				'hide_empty'        => true, 
				'exclude'           => array(), 
				'exclude_tree'      => array(), 
				'include'           => array(),
				'number'            => 8, 
				'fields'            => 'all', 
				'slug'              => '',
				'parent'            => '',
				'hierarchical'      => true, 
				'child_of'          => 0,
				'childless'         => false,
				'get'               => '', 
				'name__like'        => '',
				'description__like' => '',
				'pad_counts'        => false, 
				'offset'            => '', 
				'search'            => '', 
				'cache_domain'      => 'core'
			); 
			
			$terms = get_terms('treatments', $args);

			 $aks= '<ul class="treatments-img">';
			foreach ( $terms as $term ) {
				$aks.='<div class="imageshow" style="width:23%; float:left; margin-left:5px; margin-right:5px;">';
				//$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); 
				$term_link = get_term_link( $term );
				$term_meta = get_option( "taxonomy_term_".$term->term_id );
				$your_img_src = wp_get_attachment_image_src( $term_meta['term_img'],'medium', 'thumbnail' );
				$aks.= '<img src="'.$your_img_src[0].'" alt="" width="" />';
				//$aks.= '<h3 align="center">'.$term->name;'</h3>';
				$aks .= '
				<a href="' . esc_url( $term_link ) . '">' . $term->name . '</a>';	
				$aks.='</div>';
				
				//$aks.= '<p>'.$term->name;'</p>';
			}
			$aks.= '</ul>';
			wp_reset_postdata();
			return $aks;


  }
/*   END  */

///image upload 
function presenters_taxonomy_custom_fields($tag)
 {  
   // Check for existing taxonomy meta for the term you're editing  
    $t_id = $tag->term_id; // Get the ID of the term you're editing  
    $term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check 
	
	wp_enqueue_media(); 
?>

<tr class="form-field ">
  <th scope="row" valign="top"> <label for="presenter_id">
      <?php _e('Select Image'); ?>
    </label>
  </th>
  <td><div class="taxo-image">
      <?php 
        $your_img_src = wp_get_attachment_image_src( $term_meta['term_img'], 'thumbnail' );
        $you_have_img = is_array( $your_img_src );
        ?>
      <div class="custom-img-container">
        <?php if ( $you_have_img ) : ?>
        <img src="<?php echo $your_img_src[0] ?>" alt="" style="max-width:100%;" />
        <?php endif; ?>
      </div>
      <p class="hide-if-no-js">
        <button type="button" <?php if ( $you_have_img  ) { echo 'style="display:none;"'; } ?> class="upload-custom-img" id="">Select Image</button>
        <a class="delete-custom-img <?php if ( ! $you_have_img  ) { echo 'hidden'; } ?>" 
              href="#">
        <?php _e('Remove this image') ?>
        </a> </p>
      <!-- A hidden input to set and post the chosen image id -->
      <input class="custom-img-id" name="term_meta[term_img]" type="hidden" value="<?php echo $term_meta['term_img'] ? $term_meta['term_img'] : ''; ?>" />
    </div></td>
</tr>
<script type="text/javascript">
	//jQuery(function($){

  // Set all variables to be used in scope
  var frame,
      metaBox = jQuery('.taxo-image'), // Your meta box id here
      addImgLink = metaBox.find('.upload-custom-img'),
      delImgLink = metaBox.find( '.delete-custom-img'),
      imgContainer = metaBox.find( '.custom-img-container'),
      imgIdInput = metaBox.find( '.custom-img-id' );
  
  // ADD IMAGE LINK
  jQuery('.taxo-image').on( 'click', '.upload-custom-img', function( event )
  {
   // alert('anjfn');
    event.preventDefault();
    
    // If the media frame already exists, reopen it.
    if ( frame )
	 {
      frame.open();
      return;
    }
    
    // Create a new media frame
    frame = wp.media({
      title: 'Select or Upload Media Of Your Chosen Persuasion',
      button: {
        text: 'Use this media'
      },
      multiple: false  // Set to true to allow multiple files to be selected
    }); 
    // When an image is selected in the media frame...
    frame.on( 'select', function()
	 {  
      // Get media attachment details from the frame state
      var attachment = frame.state().get('selection').first().toJSON();
      // Send the attachment URL to our custom image input field.
      imgContainer.append( '<img src="'+attachment.url+'" alt="" style="max-width:100%;"/>' );
      // Send the attachment id to our hidden input
      imgIdInput.val( attachment.id );

      // Hide the add image link
      addImgLink.addClass( 'hidden' );

      // Unhide the remove image link
      delImgLink.removeClass( 'hidden' );
    });

    // Finally, open the modal on click
    frame.open();
  });
  
  
  // DELETE IMAGE LINK
  jQuery('.taxo-image').on( 'click',  '.delete-custom-img', function( event ){

    event.preventDefault();

    // Clear out the preview image
    imgContainer.html( '' );

    // Un-hide the add image link
    addImgLink.removeAttr( 'style' );
	addImgLink.removeClass( 'hidden' );

    // Hide the delete image link
    delImgLink.addClass( 'hidden' );

    // Delete the image id from the hidden input
    imgIdInput.val( '' );

 // });

});
</script>
<?php  } 


function save_taxonomy_custom_fields( $term_id ) {  
    //if ( isset( $_POST['term_meta'] ) ) {  
        $t_id = $term_id;  
        $term_meta = get_option( "taxonomy_term_$t_id" );  
        $cat_keys = array_keys( $_POST['term_meta'] );  
            foreach ( $cat_keys as $key ){  
            if ( isset( $_POST['term_meta'][$key] ) ){  
                $term_meta[$key] = $_POST['term_meta'][$key];  
            }  
        }  
        //save the option array  
        update_option( "taxonomy_term_$t_id", $term_meta );  
    //}  
}  		/////////////////////////
/*
	================================================     START META BOX    ===================================================
*/
	public function my_custom_meta_box(){
			$multi_posts = array('hospitals');
			foreach ($multi_posts as $multi_post) {
				# code...
				add_meta_box(
						'Custom_meta_box_id',
						__('Hospitals', 'textdomain'),
						//'meta_box_callback_funct',
						array( $this, 'meta_box_callback_funct' ),
						$multi_post,
						'normal'
					);
			}
			
	}
	//add_action('add_meta_boxes','my_custom_meta_box');

	public function meta_box_callback_funct($post,$metabox){
			$address = get_post_meta($post->ID,'address',true);
			$city = get_post_meta($post->ID,'city',true);
			$pincode = get_post_meta($post->ID,'pincode',true);
			$map = get_post_meta($post->ID,'map',true);
			$phone = get_post_meta($post->ID,'phone',true);
			$email = get_post_meta($post->ID,'email',true);
			$no_of_beds = get_post_meta($post->ID,'no_of_beds',true);
			$no_of_icu_beds = get_post_meta($post->ID,'no_of_icu_beds',true);
			$no_of_oper_rooms = get_post_meta($post->ID,'no_of_oper_rooms',true);
		    $payment_mode = get_post_meta($post->ID,'_payment_mode',true);
			$website_url = get_post_meta($post->ID,'website_url',true);
			wp_nonce_field('hospitals_nonce_action','hospitals_nonce_name');
			?>
			<table>
				<tr>
					<th>Address:</th>
					<td><textarea name="address" id="address"><?php echo $address; ?></textarea></td>
				</tr>
				<tr>
					<th>City:</th>
					<td>
						<select name="city" id="city">
							<option value="">SELECT YOUR CITY...</option>
							<option value="Indore" <?php selected( $city, 'Indore' ); ?>>Indore</option>
							<option value="Mumbai" <?php selected( $city, 'Mumbai' ); ?>>Mumbai</option>
						    <option value="Kota" <?php selected( $city, 'Kota' ); ?>>Kota</option>
						    <option value="Punne" <?php selected( $city, 'Punne' ); ?>>Punne</option>
						    <option value="Patna" <?php selected( $city, 'Patna' ); ?>>Patna</option>
						</select>
					</td>
				</tr>
				<tr>
					<th>Pin-Code:</th>
					<td><input type="text" name="pincode" id="pincode" value="<?php echo $pincode; ?>"></td>
				</tr>
				<tr>
					<th>Phone No. :</th>
					<td><input type="text" name="phone" id="phone" value="<?php echo $phone; ?>"></td>
				</tr>
				<tr>
					<th>Email-ID.:</th>
					<td><input type="email" name="email" id="email" value="<?php echo $email; ?>"></td>
				</tr>
				<tr>
					<th>Number-of-Beds.:</th>
					<td><input type="number" name="no_of_beds" id="no_of_beds" value="<?php echo $no_of_beds; ?>"></td>
				</tr>
				<tr>
					<th>Number-of-ICU-Beds.:</th>
					<td><input type="number" name="no_of_icu_beds" id="no_of_icu_beds" value="<?php echo $no_of_icu_beds; ?>"></td>
				</tr>
				<tr>
					<th>Number-of-Operations-Rooms.:</th>
					<td><input type="number" name="no_of_oper_rooms" id="no_of_oper_rooms" value="<?php echo $no_of_oper_rooms; ?>"></td>
				</tr>
				<tr>
					<th>Payment Mode:</th>
					<td><input type="checkbox" name="payment_mode[]" value="Cash" <?php if(($payment_mode != '')) echo (in_array('Cash', $payment_mode)) ? 'checked="checked"' : ''; ?> />Cash </td>
	        		<td><input type="checkbox" name="payment_mode[]" value="Bank-Transfer" <?php if(($payment_mode != '')) echo (in_array('Bank-Transfer', $payment_mode)) ? 'checked="checked"' : ''; ?> />Bank Transfer
	        		</td>
	        	</tr>
				<tr>
					<th>Web-Site URL:</th>
					<td><input type="url" name="website_url" id="website_url" value="<?php echo $website_url; ?>"></td>
				</tr>
			</table>
		
		<?php
			//wp_editor($post->post_content, $post->ID);
	}

/*
	=====================================   SAVING PROCESS   =================================================
*/
function save_our_custom_data($post_id){
	// if we are doing an autosave then return
	if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
		return;
	// if the nonce is not present there or we can not verify it.
	if( !isset($_POST['hospitals_nonce_name']) || !wp_verify_nonce($_POST['hospitals_nonce_name'],'hospitals_nonce_action'))
		return;

	if( isset($_POST['address']) && ($_POST['address'] !=''))
	{
		update_post_meta($post_id,'address',esc_html($_POST['address']));
	}
	if( isset($_POST['city']) && ($_POST['city'] !=''))
	{
		update_post_meta($post_id,'city',esc_html($_POST['city']));
	}
	
	if( isset($_POST['pincode']) && ($_POST['pincode'] !=''))
	{
		update_post_meta($post_id,'pincode',esc_html($_POST['pincode']));
	}
	if( isset($_POST['phone']) && ($_POST['phone'] !=''))
	{
		update_post_meta($post_id,'phone',esc_html($_POST['phone']));
	}
	if( isset($_POST['email']) && ($_POST['email'] !=''))
	{
		update_post_meta($post_id,'email',esc_html($_POST['email']));
	}
	if( isset($_POST['no_of_beds']) && ($_POST['no_of_beds'] !=''))
	{
		update_post_meta($post_id,'no_of_beds',esc_html($_POST['no_of_beds']));
	}
	if( isset($_POST['no_of_icu_beds']) && ($_POST['no_of_icu_beds'] !=''))
	{
		update_post_meta($post_id,'no_of_icu_beds',esc_html($_POST['no_of_icu_beds']));
	}
	if( isset($_POST['no_of_oper_rooms']) && ($_POST['no_of_oper_rooms'] !=''))
	{
		update_post_meta($post_id,'no_of_oper_rooms',esc_html($_POST['no_of_oper_rooms']));
	}
	global $post;
    // Get our form field
    if(isset( $_POST['payment_mode'] ))
    {
        $custom = $_POST['payment_mode'];
        $old_meta = get_post_meta($post->ID, '_payment_mode', true);
        // Update post meta
        if(!empty($old_meta)){
            update_post_meta($post->ID, '_payment_mode', $custom);
        } else {
            add_post_meta($post->ID, '_payment_mode', $custom, true);
        }
    }
        
	if( isset($_POST['website_url']) && ($_POST['website_url'] !=''))
	{
		update_post_meta($post_id,'website_url',esc_html($_POST['website_url']));
	}
}
//add_action('save_post','save_our_custom_data');
/*
	================================================     CLOSE META BOX    ===================================================
*/

/*
	================================================    CREATE SHORTCODE FOR SINGLE.PHP   =====================================
*/	
//add_shortcode('singlepage', 'hospitals_shortcode_query');

function hospitals_shortcode_query( $atts) {    
						global $post; 

						 extract( shortcode_atts( array(
						        'meta' => ''
						    	), $atts ) );

						    	?>
						    <div class="hos-fields-rep">

						    <?php echo $address = get_post_meta($post->ID,'address',true); ?>


						    </div>
						    <?php

 							echo $address = get_post_meta($post->ID,'address',true).'<br>';
							echo $city = get_post_meta($post->ID,'city',true).'<br>';
							echo $pincode = get_post_meta($post->ID,'pincode',true).'<br>';
							echo $phone = get_post_meta($post->ID,'phone',true).'<br>';
							echo $email = get_post_meta($post->ID,'email',true).'<br>';
							echo $no_of_beds = get_post_meta($post->ID,'no_of_beds',true).'<br>';
							echo $no_of_icu_beds = get_post_meta($post->ID,'no_of_icu_beds',true).'<br>';
							echo $no_of_oper_rooms = get_post_meta($post->ID,'no_of_oper_rooms',true).'<br>';
							$payment_mode = get_post_meta($post->ID,'_payment_mode',true);
							 print_r($payment_mode).'<br>';
							echo $website_url = get_post_meta($post->ID,'website_url',true).'<br>';
 		
 		return $custom_field_value; 
} 

/*


*/

}

$Hospitals = Hospitals::get_instance();
